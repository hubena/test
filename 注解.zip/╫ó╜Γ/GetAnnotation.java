@SuppressWarnings("rawtypes")
public List<ExcelHeader> getHeaderList(Class clz) {
	List<ExcelHeader> headers = new ArrayList<ExcelHeader>();
	Method[] method = clz.getDeclaredMethods();
	for (Method m : method) {
		String mn = m.getName();
		if (mn.startsWith("get")) {
			if (m.isAnnotationPresent(ExcelResources.class)) {
				ExcelResources er = m.getAnnotation(ExcelResources.class);
				headers.add(new ExcelHeader(er.title(), er.order(), mn));
			}
		}
	}
	Collections.sort(headers);
	return headers;
}

@ExcelResources(title = "ҵ�񶩵���", order = 15)
public String getOrdersId() {
	return ordersId;
}
	