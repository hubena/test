package com.threeweidu.service;

import com.threeweidu.entity.PaymentRecord;
import com.threeweidu.view.req.page.Page;
import com.threeweidu.view.result.EasyUIData;
import com.threeweidu.view.result.JsonResult;

public interface PaymentRecordService {

	/**
	 * 获取支付交易记录列表
	 * @param paymentRecord
	 * @param page
	 * @return
	 * @throws Exception
	 */
	public EasyUIData findList(PaymentRecord paymentRecord, Page page) throws Exception;

	/**
	 * 支付交易记录导出excel表
	 * @param paymentRecord
	 * @return
	 * @throws Exception
	 */
	public JsonResult doExportExcel(PaymentRecord paymentRecord, Page page) throws Exception;

	public JsonResult asynNotice(PaymentRecord record, String ordid, String rechargeUrl,
			StringBuffer returnMsg);

	public PaymentRecord findAsynByOrdId(String ordid);

	public PaymentRecord findRechargeRecordByMerIdAndBusinessOrdid(
			String merId, String businessOrdid);

	public JsonResult notice(PaymentRecord record);

	public JsonResult doExportCSV(PaymentRecord paymentRecord, Page page) throws Exception;

}
