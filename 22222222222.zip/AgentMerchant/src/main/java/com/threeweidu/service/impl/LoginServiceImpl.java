package com.threeweidu.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.threeweidu.dao.mybatis.AgentIPWhiteRecordMapper;
import com.threeweidu.dao.mybatis.AgentMapper;
import com.threeweidu.dao.mybatis.LoginMapper;
import com.threeweidu.entity.Agent;
import com.threeweidu.service.LoginService;
import com.threeweidu.utils.Null2;
import com.threeweidu.utils.SystemExceptionUtil;
import com.threeweidu.view.result.JsonResult;




@Service
public class LoginServiceImpl implements LoginService{
	
	@Autowired
	private LoginMapper loginMapper;
	@Autowired
	private AgentIPWhiteRecordMapper agentIPWhiteRecordMapper;
	@Autowired
	private AgentMapper agentMapper;

	@Override
	public JsonResult loginValidate(String username, String password, String domainName) {
		try{
			//账号是否存在,校验代理商的状态、登陆失败次数、审核状态.
			Agent agent=loginMapper.findAgentInfo(username);
			if(Null2.isNull(agent)||Null2.isNull(agent.getAgentAccount())){
				return new JsonResult(false, "账号不正确");
			}
			if(!"1002".equals(agent.getAgentState())){
				return new JsonResult(false, "该账号无效");
			}
			if(agent.getLoginFailureNum()>10){
				return new JsonResult(false, "该账号登陆失败超过10次");
			}
			if(!"1002".equals(agent.getVerifyState())){
				return new JsonResult(false, "该账号未审核通过");
			}
			//密码是否正确
			if(!password.equals(agent.getPasswd())){
				return new JsonResult(false, "密码不正确");
			}
			if(Null2.isNull(domainName) || !domainName.equals(agent.getDomainName())){
				return new JsonResult(false, "该账号无效");
			}
			//登陆成功,清空登陆失败次数
			loginMapper.updateLoginFailNum(username);
			return new JsonResult(true, "成功",agent);
		}catch(Exception e){
			e.printStackTrace();
			SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			return new JsonResult(false, "数据库异常");
		}
		
	}
	
	@Override
	public JsonResult checkWhiteIP(String loginIP, String username){
		Agent agent=loginMapper.findAgentInfo(username);
		if ("1002".equals(String.valueOf(agent.getIsBindingIP()))) {
			if (StringUtils.isEmpty(loginIP)) {
				return new JsonResult(false, "页面数据错误，登录IP为空！");
			}
			List<String> ipList = agentIPWhiteRecordMapper.findAgentIPWhiteRecord(agent.getAgentId(), 1001);
			for (String ipStr : ipList) {
				if(loginIP.equals(ipStr) || "all".equals(ipStr)){
					return new JsonResult(true, "");
				}
			}
			agentMapper.insertAgentOperateLog(agent.getAgentId(), "登录禁止：非绑定IP登录", loginIP);
			return new JsonResult(false, "请在绑定的IP地址登录！");
		}
		return new JsonResult(true, "");
	}
	
}
