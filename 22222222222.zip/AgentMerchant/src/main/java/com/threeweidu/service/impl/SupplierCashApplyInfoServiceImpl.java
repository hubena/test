package com.threeweidu.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.threeweidu.dao.mybatis.SupplierCashApplyMapper;
import com.threeweidu.dao.proc.SupplierCashApplyInfoDao;
import com.threeweidu.entity.SupplierCashApply;
import com.threeweidu.entity.SupplierCashApplyInfo;
import com.threeweidu.pepos.util.ConnectionUtil.FieldsDB;
import com.threeweidu.service.SupplierCashApplyInfoService;
import com.threeweidu.utils.CSVUtil;
import com.threeweidu.utils.Null2;
import com.threeweidu.utils.POIExcelUtil;
import com.threeweidu.view.req.page.Page;
import com.threeweidu.view.result.EasyUIData;
import com.threeweidu.view.result.JsonResult;

@Service
public class SupplierCashApplyInfoServiceImpl implements SupplierCashApplyInfoService {

	private SupplierCashApplyInfoDao supplierCashApplyDao;
	
	@Autowired
	private SupplierCashApplyMapper supplierCashApplyMapper;

	@Autowired
	@Qualifier(value = "supplierCashApplyInfoProcDao")
	public void setSupplierCashApplyInfoDao(SupplierCashApplyInfoDao supplierCashApplyDao) {
		this.supplierCashApplyDao = supplierCashApplyDao;
		this.supplierCashApplyDao.setDataBaseType(FieldsDB.THREEWEIDU_PEPOS_SHOP);
	}

	@Override
	public EasyUIData queryEasyUIData(Page page) throws Exception {
		EasyUIData easyUIData = supplierCashApplyDao.queryEasyUIData(page);
		@SuppressWarnings("unchecked")
		List<SupplierCashApplyInfo> rows = (List<SupplierCashApplyInfo>) easyUIData.getRows();
		//展示星号加密
		if (Null2.isNotNull(rows)) {
			easyUIData.setRows(decryptData(rows));
		}
		List<?> footer = getFooter(page);
		easyUIData.setFooter(footer);
		return easyUIData;
	}

	private List<?> getFooter(Page page) {
		List<SupplierCashApply> footer = new  ArrayList<SupplierCashApply>();
		SupplierCashApply applyInfo = supplierCashApplyMapper.findSumFooter(page);
		if(Null2.isNull(applyInfo)){
			applyInfo = new SupplierCashApply();
		}
		footer.add(applyInfo);
		return footer;
	}

	@Override
	public JsonResult exportList(Page page, String exportType) throws Exception {
		List<String> paths = new ArrayList<String>();
		long total = supplierCashApplyDao.countPage(page);
		if (total > 0) {
			long batchCount = POIExcelUtil.getInstance().getBatchCount(total, page.getPageSize());
			for (int i = 0; i < batchCount; i++) {// 有几个报表
				page.setPageNo(i + 1L);
				List<SupplierCashApplyInfo> supplierCashApplys = supplierCashApplyDao.page(page);
				Map<String, String> datas = new HashMap<String, String>();
				datas.put("title", "商户转账记录查询");
				String path = "";
				if ("CSV".equals(exportType.toUpperCase())) {
					supplierCashApplys = processExportData(supplierCashApplys, exportType);
					path = CSVUtil.getInstance().exportCsv(supplierCashApplys, SupplierCashApplyInfo.class, i + 1, "GBK");
				} else if ("XLS".equals(exportType.toUpperCase())) {
					path = POIExcelUtil.getInstance().exportObjXSSFSingleExcel(supplierCashApplys, SupplierCashApplyInfo.class, datas, i + 1);
				}
				paths.add(path);
			}
			return new JsonResult(true, "导出报表成功", paths);
		} else {
			return new JsonResult(false, "没有需要导出的数据");
		}
	}
	
	/**
	 * 导出数据处理
	 */
	private List<SupplierCashApplyInfo> processExportData(List<SupplierCashApplyInfo> supplierCashApplys, String exportType) {
		if(Null2.isNotNull(supplierCashApplys) && supplierCashApplys.size() > 0){
			for(SupplierCashApplyInfo applyInfo : supplierCashApplys){
				applyInfo.setCashId(processExportData(applyInfo.getCashId(), exportType));
				applyInfo.setSupplierId(processExportData(applyInfo.getSupplierId(), exportType));
				applyInfo.setBusinessId(processExportData(applyInfo.getBusinessIdStr(), exportType));
				applyInfo.setBankCode(processExportData(applyInfo.getBankCode(), exportType));
				applyInfo.setCreateTime(processExportData(applyInfo.getCreateTime(), exportType));
				applyInfo.setPlayMoneyTime(processExportData(applyInfo.getPlayMoneyTime(), exportType));
			}
		}		
		return supplierCashApplys;
	}

	/**
	 * 导出数据处理
	 */
	private String processExportData(String str, String exportType){
		if(Null2.isNotNull(str) && Null2.isNotNull(exportType)){
			if("CSV".equals(exportType)){
				str = "'" + str + "'";
			}
		}
		return str;
	}
	
	// 加密方法
	private List<SupplierCashApplyInfo> decryptData(List<SupplierCashApplyInfo> rows) {

		for (SupplierCashApplyInfo supplierCashApply : rows) {
			String cardNo = supplierCashApply.getCardNo();
			if (!StringUtils.isEmpty(cardNo)) {
				String cardNoTemp = cardNo.substring(4, cardNo.length() - 4);
				cardNo = cardNo.replace(cardNoTemp, "****");
				supplierCashApply.setCardNo(cardNo);
			}
		}
		return rows;
	}
}
