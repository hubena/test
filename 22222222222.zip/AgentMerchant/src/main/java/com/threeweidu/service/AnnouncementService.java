package com.threeweidu.service;

import com.threeweidu.entity.Announcement;
import com.threeweidu.view.req.page.Page;
import com.threeweidu.view.result.EasyUIData;
import com.threeweidu.view.result.JsonResult;

public interface AnnouncementService {

	public EasyUIData findList(Announcement announcement, Page page) throws Exception;

	public JsonResult addAnnouncement(Announcement announcement);

	public JsonResult updateAnnouncement(Announcement announcement);

	public JsonResult updatePublish(Announcement announcement);

}
