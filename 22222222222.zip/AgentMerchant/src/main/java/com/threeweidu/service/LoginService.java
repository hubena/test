package com.threeweidu.service;

import com.threeweidu.view.result.JsonResult;

public interface LoginService {
	
	/**
	 * 登陆业务
	* @author XuPing
	* @createTime 2016-9-30下午1:53:54
	* @return JsonResult
	 */
	JsonResult loginValidate(String username, String password, String domainName);
	
	/**
	 * 绑定登录IP判断
	 * @param loginIP
	 * @param domainName
	 * @return
	 */
	JsonResult checkWhiteIP(String loginIP, String username);
}
