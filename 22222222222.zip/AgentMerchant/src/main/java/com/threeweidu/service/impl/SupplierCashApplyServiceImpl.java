package com.threeweidu.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.threeweidu.dao.mybatis.SupplierCashApplyMapper;
import com.threeweidu.dao.proc.SupplierCashApplyDao;
import com.threeweidu.entity.SupplierCashApply;
import com.threeweidu.pepos.util.ConnectionUtil.FieldsDB;
import com.threeweidu.service.SupplierCashApplyService;
import com.threeweidu.view.req.page.Page;
import com.threeweidu.view.result.EasyUIData;

@Service
public class SupplierCashApplyServiceImpl implements SupplierCashApplyService {

	@Autowired
	private SupplierCashApplyMapper supplierCashApplyMapper;

	private SupplierCashApplyDao supplierCashApplyDao;

	@Autowired
	public void setSupplierCashApplyDao(SupplierCashApplyDao supplierCashApplyDao) {
		this.supplierCashApplyDao = supplierCashApplyDao;
		this.supplierCashApplyDao.setDataBaseType(FieldsDB.THREEWEIDU_PEPOS_SHOP);
	}

	@Override
	public EasyUIData queryEasyUIData(Page page) throws Exception {
		return supplierCashApplyDao.queryEasyUIData(page);
	}

	@Override
	public SupplierCashApply findByCashId(String cashId) {
		return supplierCashApplyMapper.findByCashId(cashId);
	}

}
