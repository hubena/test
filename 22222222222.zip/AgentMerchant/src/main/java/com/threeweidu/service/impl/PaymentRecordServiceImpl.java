package com.threeweidu.service.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.httpclient.NameValuePair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.threeweidu.config.DefaultProfile;
import com.threeweidu.dao.mybatis.PaymentRecordMapper;
import com.threeweidu.entity.PaymentRecord;
import com.threeweidu.entity.report.AccountReport;
import com.threeweidu.pepos.util.AESEncryption;
import com.threeweidu.pepos.util.Base64Local;
import com.threeweidu.pepos.yeepay.DigestUtil;
import com.threeweidu.service.PaymentRecordService;
import com.threeweidu.supplier.utils.JsonUtils;
import com.threeweidu.utils.Arith;
import com.threeweidu.utils.CSVUtil;
import com.threeweidu.utils.Null2;
import com.threeweidu.utils.POIExcelUtil;
import com.threeweidu.utils.http.HttpSendResult;
import com.threeweidu.utils.http.SanweiduHttp;
import com.threeweidu.utils.http.SimpleHttpsClient;
import com.threeweidu.view.req.page.Page;
import com.threeweidu.view.result.EasyUIData;
import com.threeweidu.view.result.JsonResult;

@Service
public class PaymentRecordServiceImpl implements PaymentRecordService {

	@Autowired
	private PaymentRecordMapper paymentRecordMapper;

	@Override
	public EasyUIData findList(PaymentRecord paymentRecord, Page page) throws Exception {
		paymentRecord = encryptData(paymentRecord);
		List<PaymentRecord> rows = paymentRecordMapper.findList(paymentRecord, page);
		if(Null2.isNull(rows)){
			return new EasyUIData(true, "数据为空", 0L, Collections.EMPTY_LIST);
		} else {
			rows = decryptListData(rows);
			Long count = paymentRecordMapper.findListCount(paymentRecord);
			List<?> footer = getFooter(paymentRecord);
			return new EasyUIData(true, "查询成功", count, rows, footer);
		}
	}
	
	private List<?> getFooter(PaymentRecord paymentRecord) {
		List<PaymentRecord> footer = new ArrayList<PaymentRecord>();
		PaymentRecord record = paymentRecordMapper.findSumFooter(paymentRecord);
		if(Null2.isNull(record)){
			record = new PaymentRecord();
		}
		footer.add(record);
		return footer;
	}

	@SuppressWarnings("null")
	public JsonResult doExportExcelOld(PaymentRecord paymentRecord) throws Exception {
		List<AccountReport> accountReports = new ArrayList<AccountReport>();
		paymentRecord = encryptData(paymentRecord);
		accountReports = null;//paymentRecordMapper.exportExcel(paymentRecord);
		for (AccountReport accountReport : accountReports) {
			accountReport.setTradeMoneyStr(Arith.getMoney2(accountReport.getTradeMoney()));
			accountReport.setAuditMoneyToBankStr(Arith. getMoney2(accountReport.getAuditMoneyToBank()));
			accountReport.setMemberAuditAmountStr(Arith.getMoney2(accountReport.getMemberAuditAmount()));
//			if(!StringUtils.isEmpty(accountReport.getTradeDate())){
//				accountReport.setTradeDate(accountReport.getTradeDate().substring(0, 10));
//			}else{
//				accountReport.setTradeDate("----");
//			}
//			if(!StringUtils.isEmpty(accountReport.getTradeTime())){
//				accountReport.setTradeTime(accountReport.getTradeTime().substring(11, 19));
//			}else{
//				accountReport.setTradeTime("----");
//			}
		}
		Map<String, String> datas = new HashMap<String, String>();
		datas.put("title", "无卡支付交易记录报表");
		String path = null;
		path = POIExcelUtil.getInstance().exportObjXSSFSingleExcel(accountReports, AccountReport.class, datas, null);
		return new JsonResult(true, "生成报表成功", path);
	}
	
	private List<AccountReport> getExportData(List<PaymentRecord> paymentRecords, String exportType){
		List<AccountReport> list = new ArrayList<AccountReport>();
		//paymentRecords = decryptListData(paymentRecords);
		for (PaymentRecord record : paymentRecords) {
			AccountReport accountReport = new AccountReport();
			accountReport.setOrdid(processExportData(record.getOrdid(), exportType));
			accountReport.setOrderName(record.getOrderName());
			accountReport.setBusinessOrdid(processExportData(record.getBusinessOrdid(), exportType));
			accountReport.setMerId(processExportData(record.getMerId(), exportType));
			String payType = "---";
			if(1001==record.getPayType()){
				payType = "快捷支付";
			}else if(1002==record.getPayType()){
				payType = "刷卡器支付";
			}else if(1003==record.getPayType()){
				payType = "网关支付";
			}else if(1004==record.getPayType()){
				payType = "H5快捷支付";
			}else if(1005==record.getPayType()){
				payType = "微信支付";
			}else if(1006==record.getPayType()){
				payType = "支付宝支付";
			}else if(1007==record.getPayType()){
				payType = "外卡支付";
			}else if(1008==record.getPayType()){
				payType = "支付宝APP";
			}else if(1009==record.getPayType()){
				payType = "微信APP";
			}			
			accountReport.setPayType(payType);
			accountReport.setTradeMoneyStr(Arith.getMoney2_New(record.getTradeMoney()));
			accountReport.setTerId(processExportData(record.getTerId(), exportType));
			String ordidState = "-----";
			if(1001==record.getOrdidState()){
				ordidState = "初始值";
			}else if(1002==record.getOrdidState()){
				ordidState = "交易受理成功";
			}else if(1003==record.getOrdidState()){
				ordidState = "支付成功";
			}else if(1004==record.getOrdidState()){
				ordidState = "已申请退款";
			}else if(1005==record.getOrdidState()){
				ordidState = "退款受理成功";
			}else if(1006==record.getOrdidState()){
				ordidState = "已退款";
			}else if(1007==record.getOrdidState()){
				ordidState = "交易失败";
			}else if(1008==record.getOrdidState()){
				ordidState = "退款受理失败";
			}
			accountReport.setOrdidState(ordidState);
			accountReport.setDeductionRate(Arith.getPercentage5(record.getDeductionRate()));
			accountReport.setDeductionFee(Arith.getMoney4_New(record.getDeductionFee()));
			accountReport.setAuditAmount(Arith.getMoney4_New(record.getDeductionMoney()));
			String agentAuditState = "-----";
			if("1000".equals(record.getDeductionState())){
				agentAuditState = "未结算";
			}else if("1001".equals(record.getDeductionState())){
				agentAuditState = "待结算";
			}else if("1002".equals(record.getDeductionState())){
				agentAuditState = "结算处理中";
			}else if("1003".equals(record.getDeductionState())){
				agentAuditState = "已清算";
			}else if("1004".equals(record.getDeductionState())){
				agentAuditState = "结算失败 ";
			}
			accountReport.setAgentAuditState(agentAuditState);
			accountReport.setAgentAmount(Arith.getMoney4_New(record.getAgentProfit()));
			accountReport.setReturnTime(processExportData(record.getReturnTime(), exportType));
			accountReport.setCreateTime(processExportData(record.getCreateTime(), exportType));
			String rechargeState = "-----";
			if("1001".equals(record.getRechargeState())){
				rechargeState = "未充值";
			}else if("1002".equals(record.getRechargeState())){
				rechargeState = "充值失败";
			}else if("1003".equals(record.getRechargeState())){
				rechargeState = "充值成功";
			}else if("1004".equals(record.getRechargeState())){
				rechargeState = "充值处理中";
			}
			accountReport.setRechargeState(rechargeState);
			String asynSupState = "-----";
			if("1000".equals(record.getAsynState())){
				asynSupState = "未通知";
			} else if("1001".equals(record.getAsynState())){
				asynSupState = "通知失败";
			}else if("1002".equals(record.getAsynState())){
				asynSupState = "通知成功";
			}
			accountReport.setAsynSupState(asynSupState);
			list.add(accountReport);
		}
		return list;
	}
	
	/**
	 * 导出数据处理
	 */
	private String processExportData(String str, String exportType){
		if(Null2.isNotNull(str) && Null2.isNotNull(exportType)){
			if("csv".equals(exportType)){
				str = "'" + str + "'";
			}
		}
		return str;
	}
	
	@Override
	public JsonResult doExportExcel(PaymentRecord paymentRecord, Page page) throws Exception {
		List<AccountReport> list = new ArrayList<AccountReport>();
		List<PaymentRecord> paymentRecords = new ArrayList<PaymentRecord>();
		paymentRecord = encryptData(paymentRecord);
		paymentRecords = paymentRecordMapper.exportExcel(paymentRecord, page);
		list = getExportData(paymentRecords, "execl");
		Map<String, String> datas = new HashMap<String, String>();
		datas.put("title", "无卡支付交易记录报表");
		String path = null;
		path = POIExcelUtil.getInstance().exportObjXSSFSingleExcel(list, AccountReport.class, datas, null);
		return new JsonResult(true, "生成报表成功", path);
	}

	/**
	 * 解密数据
	 * @param paymentRecord
	 * @throws Exception
	 */
	private List<PaymentRecord> decryptListData(List<PaymentRecord> paymentRecords) throws Exception{
		AESEncryption.initKey();
		for (PaymentRecord paymentRecord : paymentRecords) {
			paymentRecord = decryptData(paymentRecord, false);
//			if(Null2.isNotNull(paymentRecord) && Null2.isNotNull(paymentRecord.getTradeMoney()) 
//					&& Null2.isNotNull(paymentRecord.getDeductionRate())){
//				paymentRecord.setDeductionFee((paymentRecord.getDeductionRate() * paymentRecord.getTradeMoney() /10000D));
//				paymentRecord.setAuditAmount(paymentRecord.getTradeMoney() - paymentRecord.getDeductionFee());
//				paymentRecord.setAgentAmount("-----");
//				paymentRecord.setAgentAuditState("1000");
//			}
		}
		return paymentRecords;
	}
	
	/**
	 * 解密数据
	 * @param paymentRecord
	 * @throws Exception
	 */
	private PaymentRecord encryptData(PaymentRecord paymentRecord) throws Exception{
		AESEncryption.initKey();
		if(!StringUtils.isEmpty(paymentRecord.getCardNo())){//卡号，加密
			String cardNo = AESEncryption.encryptByStateKey(paymentRecord.getCardNo());
			paymentRecord.setCardNo(cardNo);
		}
		if(!StringUtils.isEmpty(paymentRecord.getTradeCardNo())){//卡号，加密
			String tradeCardNo = AESEncryption.encryptByStateKey(paymentRecord.getTradeCardNo());
			paymentRecord.setTradeCardNo(tradeCardNo);
		}
		return paymentRecord;
	}

	/**
	 * 加密数据
	 * @param paymentRecord
	 * @param init 是否初始化
	 * @throws Exception
	 */
	private PaymentRecord decryptData(PaymentRecord paymentRecord, boolean init) throws Exception{
		if(init){
			AESEncryption.initKey();
		}
		String card = paymentRecord.getIdCard();//身份证号码
		if (!StringUtils.isEmpty(card)) {
			String desCard = AESEncryption.decryptByStateKey(card);
			if (!StringUtils.isEmpty(desCard)) {
				String temp = desCard.substring(4,desCard.length()-4);
				desCard = desCard.replace(temp, "****");
				paymentRecord.setIdCard(desCard);
			}
		}
		String tradeCardNo = paymentRecord.getTradeCardNo();//消费卡号
		if (!StringUtils.isEmpty(tradeCardNo)) {
			String temp = tradeCardNo.substring(4,tradeCardNo.length()-4);
			tradeCardNo = tradeCardNo.replace(temp, "****");
			paymentRecord.setTradeCardNo(tradeCardNo);
		}
		String cardNo = paymentRecord.getCardNo();//卡号
		if (!StringUtils.isEmpty(cardNo)) {
			String cardNoStr = null;
			if (cardNo.length() > 20) {
				cardNoStr = AESEncryption.decryptByStateKey(cardNo);
			} else {
				cardNoStr = cardNo;
			}
			if (!StringUtils.isEmpty(cardNoStr)) {
				String temp = cardNoStr.substring(4,cardNoStr.length()-4);
				cardNoStr = cardNoStr.replace(temp, "****");
				paymentRecord.setCardNo(cardNoStr);
			}
		}
		
		String phone = paymentRecord.getPhone();
		if (!StringUtils.isEmpty(phone)) {
			if (phone.length() > 11) {
				phone = AESEncryption.decryptByStateKey(phone);
			}
			paymentRecord.setPhone(phone);
		}
		return paymentRecord;
	}

	@SuppressWarnings("unchecked")
	@Override
	public JsonResult asynNotice(PaymentRecord record, String ordid, String rechargeUrl, StringBuffer returnMsg) {
		JsonResult result = null;
		int asynCount = record.getAsynCount();
		String synParam = record.getSynParam();
		String url = record.getAsynNotificationUrl();
		if (url.contains("updateOrderPayTrade")) {
			JsonResult isOk = supplierInform(rechargeUrl, record.getOrdid(), record.getBusinessOrdid(), record.getOrdidState().toString(), record.getMerId(), record.getTerId(), asynCount, record.getReturnTime(), "", record.getTradeMoney().toString(), record.getApiKey());
			if (isOk.getSuccess()) {
				result = new JsonResult(true, "异步地址请求成功");
			} else {
				result = new JsonResult(false, "异步地址请求失败");
			}
			returnMsg.append(isOk.getMessage() + "-----");
		}
		Map<String, String> ms = new HashMap<String, String>();
		ms = JsonUtils.jsonToObject(synParam, Map.class);
		int asynState = 1001; // 异步通知状态 1001失败 1002成功
		SimpleHttpsClient httpClient = new SimpleHttpsClient();
		HttpSendResult httpSendResult = null;
		try {
			httpSendResult = httpClient.postRequest(url, ms, 60000);
		} catch (Exception e) {
			e.printStackTrace();
			result = new JsonResult(false, "异步地址请求失败! "+e.getMessage());
			return result;
		}
		if(Null2.isNull(httpSendResult)){
			result = new JsonResult(false, "异步地址请求失败");
			return result;
		}
		String respTxt = httpSendResult.getResponseBody();
		returnMsg.append(respTxt + "-----");
		if (httpSendResult.getStatus() == 200) {
			if (respTxt != null && !"".equals(respTxt)) {
				respTxt = respTxt.toLowerCase();
				if (respTxt.contains("success") || respTxt.contains("error")) {
					asynState = 1002;
					result = new JsonResult(true, "异步通知成功");
				}
			}
		} else {
			result = new JsonResult(false, "异步地址请求失败");
		}
		asynCount++;
		// 修改异步通知次数
		paymentRecordMapper.updAsynInfo(ordid, asynState, asynCount, synParam);
		return result;
	}
	
	/**
	 * 通知商户
	 * 
	 * @param ordersId
	 * @param ordidState
	 * @return
	 */
	@SuppressWarnings("unused")
	public JsonResult supplierInform(String url, String payId, String ordersId, String ordidState, String merId, String terId, int asynCount, String payTime, String selfParam, String money, String apiKey) {
		try {
			Map<String, String> map = new HashMap<String, String>();
			String requestCode = "orderTrade1001";

			String supplierId = merId;

			map.put("orderId", ordersId);
			map.put("supplierId", supplierId);
			map.put("state", String.valueOf(ordidState));
			map.put("payOrderId", payId);
			map.put("money", money);
			map.put("selfParam", selfParam);
			map.put("payReturnTime", payTime);
			List<NameValuePair> data = new ArrayList<NameValuePair>();

			String enc = JsonUtils.objectToJson(map);
			String requestTime = getRequestTime();
			System.out.println("enc:" + enc);

			String eccData = encode(enc);
			data.add(new NameValuePair("requestCode", requestCode));

			StringBuffer sb = new StringBuffer();
			sb.append("requestCode=orderTrade1001").append("&timeStr" + requestTime).append("&data=" + eccData);
			// 加密数据格式：请求码+供应商编号+请求时间+业务数据（加密后）
			String aValue = requestCode + supplierId + requestTime + eccData;
			String aKey = apiKey;
			data.add(new NameValuePair("checkCode", DigestUtil.hmacSign(aValue, aKey)));
			data.add(new NameValuePair("timeStr", requestTime));
			data.add(new NameValuePair("data", eccData));

			Map<String, String> synParam = new HashMap<String, String>();
			synParam.put("checkCode", DigestUtil.hmacSign(aValue, aKey));
			synParam.put("timeStr", DigestUtil.hmacSign(aValue, aKey));
			synParam.put("data", eccData);
			String synParamStr = JsonUtils.objectToJson(synParam);

			String http[] = SanweiduHttp.getInstance().customHttp(url, data);
			String result=http[1];
			int asynState = 1002;
			String stateStr = "成功";
			if (!"8801".equals(http[0].toString())) {
				// 添加为异步通知失败
				asynState = 1001;
				stateStr = "失败";
				return new JsonResult(false, result);
			} else {
				return new JsonResult(true, result);
			}
		} catch (Exception e) {
			e.printStackTrace();
			return new JsonResult(false, "请求操作异常");
		}
	}
	
	private String getRequestTime() {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmssS");
		long mills = System.currentTimeMillis();
		Date date = new Date(mills);
		String currentTime = formatter.format(date);
		String uuid = UUID.randomUUID().toString();
		StringBuffer requestTime = new StringBuffer(currentTime);
		requestTime.append(uuid);
		return requestTime.toString();
	}

	private String encode(String str) throws Exception {
		str = Base64Local.encodeToString(str.getBytes("UTF-8"), false);
		str = str.replace("+", "*");
		str = str.replace("/", "-");
		str = str.replace("=", ".");
		return str;
	}

	@Override
	public PaymentRecord findAsynByOrdId(String ordid) {
		return paymentRecordMapper.findAsynByOrdId(ordid);
	}

	@Override
	public PaymentRecord findRechargeRecordByMerIdAndBusinessOrdid(
			String merId, String businessOrdid) {
		return paymentRecordMapper.findRechargeRecordByMerIdAndBusinessOrdid(merId, businessOrdid);
	}

	@Override
	public JsonResult notice(PaymentRecord record) {
		JsonResult result = new JsonResult(false, "补单通知失败");
		Map<String, String> ms = new HashMap<String, String>();
		ms.put("orderId", record.getOrdid());
		SimpleHttpsClient httpClient = new SimpleHttpsClient();
		HttpSendResult httpSendResult = null;
		try {
			httpSendResult = httpClient.postRequest(DefaultProfile.getInstance().NOTICE_URL, ms, 60000);
		} catch (Exception e) {
			e.printStackTrace();
			result = new JsonResult(false, "补单通知失败! "+e.getMessage());
			return result;
		}
		if(Null2.isNull(httpSendResult)){
			result = new JsonResult(false, "补单通知失败");
			return result;
		}
		String respTxt = httpSendResult.getResponseBody();
		System.out.println(respTxt);
		if (httpSendResult.getStatus() == 200) {
			if (respTxt != null && !"".equals(respTxt)) {
				respTxt = respTxt.toLowerCase();
				if (respTxt.contains("\"dq_code\":\"0\"")) {
					result = new JsonResult(true, "补单通知成功");
				} else {
					result = new JsonResult(true, "补单通知失败" + getMsg(respTxt));
				}
			}
		} else {
			result = new JsonResult(false, "补单通知失败");
		}
		return result;
	}

	private String getMsg(String respTxt) {
//		String[] strs = respTxt.split("\"show_msg\":\"");
//		String msg = strs[1].split("\"")[0];
//		if(Null2.isNotNull(msg)){
//			return ","+msg;
//		}
		return "";
	}

	@Override
	public JsonResult doExportCSV(PaymentRecord paymentRecord, Page page) throws Exception {
		List<AccountReport> list = new ArrayList<AccountReport>();
		List<PaymentRecord> paymentRecords = new ArrayList<PaymentRecord>();
		paymentRecord = encryptData(paymentRecord);
		paymentRecords = paymentRecordMapper.exportExcel(paymentRecord, page);
		list = getExportData(paymentRecords, "csv");
		String path = null;
		path = CSVUtil.getInstance().exportCsv(list, AccountReport.class, 1, "GBK");
		return new JsonResult(true, "生成报表成功", path);
	}
}
