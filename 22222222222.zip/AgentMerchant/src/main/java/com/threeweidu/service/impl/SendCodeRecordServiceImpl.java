package com.threeweidu.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.threeweidu.dao.proc.SendCodeRecordDao;
import com.threeweidu.pepos.util.ConnectionUtil.FieldsDB;
import com.threeweidu.service.SendCodeRecordService;
import com.threeweidu.view.req.page.Page;
import com.threeweidu.view.result.EasyUIData;

@Service
public class SendCodeRecordServiceImpl implements SendCodeRecordService {

	private SendCodeRecordDao sendCodeRecordDao;

	@Autowired
	public void setSendCodeRecordDao(SendCodeRecordDao sendCodeRecordDao) {
		this.sendCodeRecordDao = sendCodeRecordDao;
		this.sendCodeRecordDao.setDataBaseType(FieldsDB.THREEWEIDU_PEPOS_PAYMENT);
	}

	@Override
	public EasyUIData queryEasyUIData(Page page) throws Exception {
		return sendCodeRecordDao.queryEasyUIData(page);
	}

}
