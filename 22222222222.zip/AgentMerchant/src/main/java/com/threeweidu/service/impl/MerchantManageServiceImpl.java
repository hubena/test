package com.threeweidu.service.impl;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.threeweidu.config.DefaultProfile;
import com.threeweidu.dao.mybatis.AgentMapper;
import com.threeweidu.dao.mybatis.AgentPaymentWayMapper;
import com.threeweidu.dao.mybatis.MerAuthorizationInfoMapper;
import com.threeweidu.dao.mybatis.MerchantInfoMapper;
import com.threeweidu.dao.mybatis.MerchantManageMapper;
import com.threeweidu.dao.proc.MerchantManageDao;
import com.threeweidu.dao.proc.MerchantOperateLogDao;
import com.threeweidu.dao.proc.MerchantUserDao;
import com.threeweidu.dao.proc.SupplierCashApplyDao;
import com.threeweidu.entity.Agent;
import com.threeweidu.entity.AgentPaymentWay;
import com.threeweidu.entity.GoodsSupplier;
import com.threeweidu.entity.MerAuthorization;
import com.threeweidu.entity.Merchant;
import com.threeweidu.entity.MerchantInfo;
import com.threeweidu.entity.SupplierCashTransferFee;
import com.threeweidu.entity.Terminal;
import com.threeweidu.pepos.security.EncryptMoney;
import com.threeweidu.pepos.util.ConnectionUtil.FieldsDB;
import com.threeweidu.pepos.util.MD5;
import com.threeweidu.service.MerchantManageService;
import com.threeweidu.utils.Arith;
import com.threeweidu.utils.Null2;
import com.threeweidu.utils.ValidateUtils;
import com.threeweidu.view.req.page.Page;
import com.threeweidu.view.result.EasyUIData;
import com.threeweidu.view.result.JsonResult;

@Service
public class MerchantManageServiceImpl implements MerchantManageService {

	@Autowired
	private MerchantManageMapper merchantManageMapper;
	
	private MerchantManageDao merchantManageDao;
	
	@Autowired
	private MerAuthorizationInfoMapper merAuthorizationInfoMapper;
	
	@Autowired
	private MerchantInfoMapper merchantInfoMapper;
	
	@Autowired
	private AgentPaymentWayMapper agentPaymentWayMapper;
	
	@Autowired
	private AgentMapper agentMapper;
	
	private SupplierCashApplyDao supplierCashApplyDao;
	
	private MerchantOperateLogDao merchantOperateLogDao;
	
	@Autowired
	public void setSupplierCashApplyDao(SupplierCashApplyDao supplierCashApplyDao) {
		this.supplierCashApplyDao = supplierCashApplyDao;
		this.supplierCashApplyDao.setDataBaseType(FieldsDB.THREEWEIDU_PEPOS_SHOP);
	}

	
	@Autowired
	public void setMerchantManageDao(MerchantManageDao merchantManageDao) {
		this.merchantManageDao = merchantManageDao;
		this.merchantManageDao.setDataBaseType(FieldsDB.THREEWEIDU_PEPOS_PAYMENT);
	}
	
	private MerchantUserDao merchantUserDao;
	
	@Autowired
	public void setMerchantUserDao(MerchantUserDao merchantUserDao) {
		this.merchantUserDao = merchantUserDao;
		this.merchantUserDao.setDataBaseType(FieldsDB.THREEWEIDU_PEPOS_SHOP);
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public EasyUIData queryEasyUIData(Page page) throws Exception {
		EasyUIData easyUIData = merchantManageDao.queryEasyUIData(page);
		List<Merchant> merchantList = (List<Merchant>) easyUIData.getRows();
		for (Merchant merchant : merchantList) {
			Merchant supplier = merchantManageMapper.findSupllierInfo(merchant.getMerId());
			if(Null2.isNull(supplier)){
				continue;
			}
			// 账户余额
			String[] supAccount = EncryptMoney.decryptMoney(supplier.getAccountBalance(), supplier.getAbCheckCode(), merchant.getMerId(), supplier.getAbTableKey());
			if (Null2.isNotNull(supAccount[1].toString())) {
				merchant.setAccountBalance(supAccount[1].toString());
			}

			// 提现
			merchant.setWithdrawFeeType(supplier.getWithdrawFeeType());
			String withdrawFeeTypeValue = supplier.getWithdrawFeeTypeValue();
			if (Null2.isNotNull(withdrawFeeTypeValue)) {
				BigDecimal big = new BigDecimal(withdrawFeeTypeValue).movePointLeft(2);
				merchant.setWithdrawFeeTypeValue(big.toString());
			}
			String withdrawMaxfee = supplier.getWithdrawMaxfee();
			if (Null2.isNotNull(withdrawMaxfee)) {
				BigDecimal big = new BigDecimal(withdrawMaxfee).movePointLeft(2);
				merchant.setWithdrawMaxfee(big.toString());
			}

			// 充值
//			merchant.setRechargeFeeType(supplier.getRechargeFeeType());
//			String rechargeFeeTypeValue = supplier.getRechargeFeeTypeValue();
//			if (Null2.isNotNull(rechargeFeeTypeValue)) {
//				BigDecimal big = new BigDecimal(rechargeFeeTypeValue).movePointLeft(2);
//				merchant.setRechargeFeeTypeValue(big.toString());
//			}
//			String rechargeMaxFee = supplier.getRechargeMaxFee();
//			if (Null2.isNotNull(rechargeMaxFee)) {
//				BigDecimal big = new BigDecimal(rechargeMaxFee).movePointLeft(2);
//				merchant.setRechargeMaxFee(big.toString());
//			}
			merchant.setIsRealPay(supplier.getIsRealPay());
			merchant.setSuppliePhone(supplier.getSuppliePhone());
			merchant.setLoginIpSet(supplier.getLoginIpSet());
			merchant.setTransferRealWhiteList(supplier.getTransferRealWhiteList());
			merchant.setIsRealRecharge(supplier.getIsRealRecharge());
		}
		return easyUIData;
	}

	@Override
	public JsonResult updateMerchantRate(Merchant merchant) {

//		String rechargeFeeTypeValue = merchant.getRechargeFeeTypeValue();
//		String rechargeMaxFee = merchant.getRechargeMaxFee();

		String withdrawFeeTypeValue = merchant.getWithdrawFeeTypeValue();
		String withdrawMaxfee = merchant.getWithdrawMaxfee();
//		if (Null2.isNotNull(rechargeFeeTypeValue)) {
//			BigDecimal big = new BigDecimal(rechargeFeeTypeValue).movePointRight(2);
//			merchant.setRechargeFeeTypeValue(big.toString());
//		}
//		if (Null2.isNotNull(rechargeMaxFee)) {
//			BigDecimal big = new BigDecimal(rechargeMaxFee).movePointRight(2);
//			merchant.setRechargeMaxFee(big.toString());
//		}

		if (Null2.isNotNull(withdrawFeeTypeValue)) {
			BigDecimal big = new BigDecimal(withdrawFeeTypeValue).movePointRight(2);
			merchant.setWithdrawFeeTypeValue(big.toString());
		}
		if (Null2.isNotNull(withdrawMaxfee)) {
			BigDecimal big = new BigDecimal(withdrawMaxfee).movePointRight(2);
			merchant.setWithdrawMaxfee(big.toString());
		}
		Merchant fee = merchantManageMapper.findMerchantByMerId2(merchant.getMerId());
		if(Null2.isNull(fee)){			
			addSupplierCashTransferFee(merchant);
		}
		int num = merchantManageMapper.updateMerchantRate(merchant);
		if (num > 0) {
			return new JsonResult(true, "修改成功，请更新商户支付方式对应的扣率");
		} else {
			return new JsonResult(false, "修改失败");
		}
	}
	@Override
	public JsonResult checkIsRealPay(Merchant merchant) {
		if("1002".equals(merchant.getIsRealPay())){			
			List<AgentPaymentWay> agentPaymentWays = agentPaymentWayMapper.findAll(merchant.getAgentId());
			Map<Integer, AgentPaymentWay> map = new HashMap<Integer, AgentPaymentWay>();
			for (int i = 0; i < agentPaymentWays.size(); i++) {
				map.put(agentPaymentWays.get(i).getPaymentName(),
						agentPaymentWays.get(i));
			}
			List<MerAuthorization> list = merAuthorizationInfoMapper.getMerAuthorizationByMerid(merchant.getMerId());
			if(Null2.isNotNull(list)){
				for(MerAuthorization authorization : list){
					try {
						if(!Arith.compare(authorization.getDeductionRate(), map.get(authorization.getPaymentName()).getRealRate())){
							return new JsonResult(false, "支付方式实时扣率不可小于其成本");
						}
					} catch (Exception e) {
						//e.printStackTrace();
					}
				}
			}
		}
		return new JsonResult(true, "通过");
	}

	@Override
	public JsonResult updateEmail(Merchant merchant) throws Exception {
		long count = merchantUserDao.count(new Page("GoodsSupplier", " supplierId!='" + merchant.getSupplierId() + "' and nickName='" + merchant.getEmail() + "' "));
		if (count > 0) {
			return new JsonResult(false, "当前邮箱已被使用");
		}
		int num = merchantManageMapper.updateEmail(merchant);
		if (num > 0) {
			return new JsonResult(true, "修改成功");
		} else {
			return new JsonResult(false, "修改失败");
		}
	}

	@Override
	public EasyUIData findMerchantUser(Page page) throws Exception {
		return merchantUserDao.queryEasyUIData(page);
	}

	@Override
	public Merchant findMerchantByMerId(String merId) {		
		return merchantManageMapper.findMerchantByMerId2(merId);
	}

	@Override
	public JsonResult updatePhone(Merchant merchant) {
		if(!ValidateUtils.phoneNumber(merchant.getSuppliePhone())){
			return new JsonResult(false, "电话号码格式错误");
		}
		int num = merchantManageMapper.updatePhone(merchant.getSupplierId(), merchant.getSuppliePhone());
		if (num > 0) {
			return new JsonResult(true, "修改成功");
		} else {
			return new JsonResult(false, "修改失败");
		}
	}
	
	@Override
	public JsonResult updateUseState(String merId){
		HashMap<String, String> delock = new HashMap<String, String>();
		delock.put("merId", merId);
		delock.put("useState", "1002");
		int num = merAuthorizationInfoMapper.deblock(delock);
		if (num > 0) {
			return new JsonResult(true, "解锁成功");
		} else {
			return new JsonResult(false, "解锁失败");
		}
	}
	
	@Override
	public JsonResult updatePasswd(String supplierId, String encryptPassWd){
		int num = merchantManageMapper.updatePasswd(supplierId, encryptPassWd);
		if (num == 1) {
			return new JsonResult(true, "登录密码重置成功");
		}else{
			return new JsonResult(false, "登录密重置失败");
		}
		
	}
	
	@Override
	public JsonResult updatePayPasswd(String supplierId, String encryptPayPassWd){
		int num = merchantManageMapper.updatePayPasswd(supplierId, encryptPayPassWd);
		if (num == 1) {
			return new JsonResult(true, "支付密码重置成功");
		}else{
			return new JsonResult(false, "支付密码重置失败");
		}
	}

	@Override
	public String getMerIds(String agentId) {
		List<Merchant> list = merchantManageMapper.findMerchantByAgentId(agentId);
		String merIds = toMerIds(list);
		if(Null2.isNull(merIds)){
			return "''";
		}
		return merIds;
	}

	private String toMerIds(List<Merchant> list) {
		StringBuilder merIds = new StringBuilder("");
		if(Null2.isNotNull(list)){
			for (int i = 0; i < list.size(); i++) {
				try {
					if(i==(list.size()-1)){
						merIds.append("'").append(list.get(i).getMerId()).append("'");
						continue;
					}
					merIds.append("'").append(list.get(i).getMerId()).append("',");
				} catch (Exception e) {
				}
			}
		}		
		return merIds.toString();
	}

	@Override
	public JsonResult addMerchant(Merchant merchant) throws Exception {
		MerchantInfo merchantInfo = merchantInfoMapper.findMerchantInfoById(merchant.getMerInfoId());
		Agent agent = agentMapper.findAgentInfoByAgentid(merchant.getAgentId());
		if(Null2.isNull(merchantInfo) || Null2.isNull(merchantInfo.getMaxMers()) 
				|| Null2.isNull(merchantInfo.getHasMers()) || merchantInfo.getHasMers() >= merchantInfo.getMaxMers()){
			return new JsonResult(false, "该资料已达最大使用次数");
		}
		
		if (!"1002".equals(merchantInfo.getVerifyState())) {
			return new JsonResult(false, "请选择审核通过的商户资料");
		}
		Merchant merchant2 = merchantInfoMapper.findMerchantById(merchant.getMerInfoId());
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd dd:HH:mm:ss");
		String date=df.format(new Date());
		String merchantId=date.replaceAll("[^\\d]+","");
		merchantId =merchantId.substring(0, merchantId.length()-1);
		int n=(int)(Math.random()*99999-9999); 
		String apiKey=merchantId+n;
		String rsaKeyDec =MD5.MD5Encode(apiKey);
		merchant2.setMerId(merchantId);
		merchant2.setApiKey(rsaKeyDec);
		merchant2.setAddMan(agent.getAgentAccount());
		merchant2.setUseState(1002);
		int num = merchantManageMapper.addMerchant(merchant2);
		merchantInfoMapper.updateMerchantInfoCount(merchant.getMerInfoId());
		merchantManageMapper.addAgentMerchant(merchant2);
		if (num == 1) {
			return new JsonResult(true, "添加商户成功，商户编号：" + merchantId+",请去修改转账充值扣率，否则此账号无法正常使用", merchant2);
		}else{
			return new JsonResult(false, "添加失败");
		}
	}	
	
	public int addTerminal(Merchant merchant) {
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd dd:HH:mm:ss");
		String date = df.format(new Date());
		String terminalId = date.replaceAll("[^\\d]+", "");
		terminalId = terminalId.substring(0, terminalId.length() - 1);
		terminalId = terminalId.substring(0, 15);
		Terminal terminal = new Terminal();
		terminal.setAddMan(merchant.getAddMan());
		terminal.setMerId(merchant.getMerId());
		terminal.setTerId(terminalId);
		terminal.setAstrictSingleMoeny(DefaultProfile.ASTRICT_SINGLE_MOENY);
		terminal.setAstrictDayMoeny(DefaultProfile.ASTRICT_DAY_MOENY);
		int num = merchantManageMapper.addTerminal(terminal);
		return num;
	}


	public int addSupplierCashTransferFee(Merchant merchant) {
		SupplierCashTransferFee fee = new SupplierCashTransferFee();
		fee.setSupplierId(merchant.getMerId());
		fee.setAddMan(merchant.getAddMan());
		fee.setWithdrawFeeType("1002");
		int num = merchantManageMapper.addSupplierCashTransferFee(fee);
		return num;
	}


	public int addGoodSupplier(Merchant merchant, String[] result) {
		GoodsSupplier goodsSupplier = new GoodsSupplier();
		goodsSupplier.setSupplierId(merchant.getMerId());
		goodsSupplier.setSupplieName(merchant.getMerName());
		goodsSupplier.setSupplieAddress(merchant.getLinkAddress());
		goodsSupplier.setSuppliePhone(merchant.getLinkPhone());
		goodsSupplier.setPasswd(DefaultProfile.DEFAULT_PASSWORD);
		goodsSupplier.setExpireTime(merchant.getEndTime());
		goodsSupplier.setAddMan(merchant.getAddMan());
		goodsSupplier.setEditMan(merchant.getAddMan());
		goodsSupplier.setMemberNo(merchant.getMemberNo());
		
		String money = result[1];
		String checkCode = result[2];
		String tableKey = result[3];
		goodsSupplier.setAccountBalance(money);
		goodsSupplier.setFreezeAccountBalance(money);
		goodsSupplier.setAbCheckCode(checkCode);
		goodsSupplier.setAbTableKey(tableKey);
		goodsSupplier.setAabCheckCode(checkCode);
		goodsSupplier.setAabTableKey(tableKey);
		goodsSupplier.setEarnestMoney(money);
		goodsSupplier.setEmCheckCode(checkCode);
		goodsSupplier.setEmTableKey(tableKey);
		
		goodsSupplier.setDeductionRate(toString(merchant.getYield(), "0"));
		goodsSupplier.setBillingStyle("1001");
		goodsSupplier.setBillingCycle("5");
		
		goodsSupplier.setSupplierClass(toString(merchant.getMerchantType(), "1001"));
		goodsSupplier.setNickName(merchant.getMerId());
		goodsSupplier.setSupplierType("1003");
		goodsSupplier.setSupplierState("1002");
		goodsSupplier.setVerifyState("1002");
		
		goodsSupplier.setCouCode(merchant.getCouCode());
		goodsSupplier.setEmail(merchant.getEmail());
		int num = merchantManageMapper.addGoodSupplier(goodsSupplier);
		return num;
	}


	private String toString(Object obj, String defaultStr) {
		if(Null2.isNotNull(obj)){
			return obj.toString();
		}
		return defaultStr;
	}


	@Override
	public String getMerIdsBySec(String secAgentId) {
		List<Merchant> list = merchantManageMapper.findMerchantBySecAgentId(secAgentId);
		String merIds = toMerIds(list);
		if(Null2.isNull(merIds)){
			return "''";
		}
		return merIds;
	}


	@Override
	public JsonResult updateRemark(Merchant merchant) throws Exception {
		int num = merchantManageMapper.updateRemark(merchant);		
		if (num > 0) {
			return new JsonResult(true, "修改成功");
		} else {
			return new JsonResult(false, "修改失败");
		}
	}


	@Override
	public JsonResult loginIPUnwrap(Merchant merchant) throws Exception {
		int num = merchantManageMapper.loginIPUnwrap(merchant);
		String merId = merchant.getSupplierId();
		String operateContent = "渠道商："+merchant.getAgentId()+",关闭商户登录IP绑定";
		String operateIp = merchant.getOperateIp();
		merchantOperateLogDao.saveTrans("PAYMENT_MERCHANTOPERATELOG_ADD", new Object[]{merId, operateContent, operateIp});
		if (num > 0) {
			return new JsonResult(true, "登录IP绑定成功");
		} else {
			return new JsonResult(false, "登录IP绑定失败");
		}
	}

	@Autowired
	public void setMerchantOperateLogDao(MerchantOperateLogDao merchantOperateLogDao) {
		this.merchantOperateLogDao = merchantOperateLogDao;
		this.merchantOperateLogDao.setDataBaseType(FieldsDB.THREEWEIDU_PEPOS_PAYMENT);
	}


	@Override
	public JsonResult updateTransferReal(Merchant merchant) {
		int num = merchantManageMapper.updateTransferReal(merchant);
		if (num > 0) {
			return new JsonResult(true, "登录IP绑定成功");
		} else {
			return new JsonResult(false, "登录IP绑定失败");
		}
	}

}
