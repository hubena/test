package com.threeweidu.service;


import java.util.List;

import com.threeweidu.entity.MerAuthorization;
import com.threeweidu.entity.MerKeyInfo;
import com.threeweidu.entity.Merchant;
import com.threeweidu.entity.PaymentWay;
import com.threeweidu.view.req.page.Page;
import com.threeweidu.view.result.EasyUIData;
import com.threeweidu.view.result.JsonResult;

public interface MerAuthorizationInfoService {

	/**
	 * 组合条件分页查询支付方式信息
	 */
	EasyUIData findAllPayWay(Page page, PaymentWay paymentWay, Merchant merchant2) throws Exception;


	/**
	 * 商户授权支付方式
	 */
	JsonResult addMerAuthorization(MerAuthorization merAuthorization) throws Exception;

	/**
	 * 商户取消授权支付方式
	 */
	JsonResult deleteMerAuthorization(List<MerAuthorization> merAuthorizations);


	/**
	 * 添加微信支付
	 */
	JsonResult addMerKeyInfo(MerKeyInfo merKeyInfo);
	
	/**
	 * 修改商户授权扣率
	 */
	JsonResult updateDeductionRate(MerAuthorization merAuthorization) throws Exception;


	EasyUIData findAllAgentPayWay(Page page, String agentId);
}
