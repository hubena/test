package com.threeweidu.service;

import com.threeweidu.entity.SupplierCashApplyStatistics;
import com.threeweidu.view.req.page.Page;
import com.threeweidu.view.result.EasyUIData;

public interface SupplierCashApplyStatisticsService {

	/**
	 * 获取转账记录列表
	 * @param paymentRecord
	 * @param page
	 * @return
	 * @throws Exception
	 */
	public EasyUIData findList(SupplierCashApplyStatistics statistics, Page page) throws Exception;


}
