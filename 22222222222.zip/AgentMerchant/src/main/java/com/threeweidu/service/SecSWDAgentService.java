package com.threeweidu.service;

import java.util.List;

import com.threeweidu.entity.AssociateMerchant;
import com.threeweidu.entity.SecSWDAgent;
import com.threeweidu.view.req.page.Page;
import com.threeweidu.view.result.EasyUIData;
import com.threeweidu.view.result.JsonResult;

public interface SecSWDAgentService {
	
	/**
	 * 分页查询二级代理商记录
	 * @param page
	 * @param secSWDAgent 
	 * @return EasyUIData
	 * @throws Exception
	 */
	EasyUIData queryEasyUIData(SecSWDAgent secSWDAgent, Page page) throws Exception;
	
	/**
	 * 添加二级代理商
	 */
	JsonResult addSecSWDAgent(SecSWDAgent secSWDAgent);
	
	/**
	 * 获取一级代理商账户
	 */
	String findAgentAccount(String agentId);
	
	/**
	 * 获取指定二级代理商账户的数量
	 */
	Long findAccountCount(String secAgentAccount);
	
	/**
	 * 分页查询关联商户记录
	 * @param page
	 * @param associateMerchant 
	 * @return EasyUIData
	 * @throws Exception
	 */
	EasyUIData queryEasyUIData(AssociateMerchant associateMerchant, Page page) throws Exception;
	
	/**
	 * 二级代理商关联商户
	 */
	JsonResult updateAssociate(AssociateMerchant associateMerchant);
	
	/**
	 * 查询二级代理商对应得关联表信息
	 * 
	 */
	JsonResult selectByAmId(String amId);
	
	/**
	 * 批量取消商户关联
	 */
	JsonResult batchUpdateDisAssociate(List<AssociateMerchant> associateMerchants);
}
