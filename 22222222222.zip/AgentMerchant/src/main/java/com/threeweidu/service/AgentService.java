package com.threeweidu.service;

import com.threeweidu.entity.Agent;
import com.threeweidu.entity.AgentIPWhiteRecord;
import com.threeweidu.view.result.EasyUIData;
import com.threeweidu.view.result.JsonResult;

public interface AgentService {

	/**
	 * 获取代理商基本信息
	 * @param agentId
	 * @return
	 */
	EasyUIData findMessage(String agentId);

	/**
	 * 修改代理商基本信息
	 * @param agent
	 * @return
	 */
	JsonResult updateAgentInfo(Agent agent);

	/**
	 * 修改代理商用户密码
	 * @param agentId
	 * @param agentOldPassword
	 * @param agentNewPassword1
	 * @param agentNewPassword2
	 * @return
	 */
	JsonResult updatePassword(String agentId, String agentOldPassword,
			String agentNewPassword1, String agentNewPassword2);

	/**
	 * 获取代理商扣率信息
	 * @param agentId
	 * @return
	 */
	Agent getAgentByAgentid(String agentId);

	Agent getAgentLogo(String domainName);

	boolean checkPayPasswd(String agentId, String payPasswd); 
	
	/**
	 * 修改代理商支付密码
	 * @param agentId
	 * @param agentOldPayPassword
	 * @param agentNewPayPassword1
	 * @param agentNewPayPassword2
	 * @return
	 */
	public JsonResult updatePayPassword(String agentId, String agentOldPayPassword,
			String agentNewPayPassword1, String agentNewPayPassword2);

	Agent getAgentInfoByAgentid(String agentId);

	/**
	 * 
	 * @param sendType 发送类型，1001：短信；1002：邮件
	 * @param sendNumber 发送号码，邮箱或者手机号
	 * @param agentId 代理商编号
	 * @param couCode 国家区号
	 * @param operation 操作内容
	 * @param businessType 操作类型，用于区分发送短信或邮件
	 * @return JsonResult
	 * @throws Exception
	 */
	JsonResult sendIdentifyCode(String sendType, String sendNumber, String agentId, String couCode, String operation, String businessType) throws Exception;
	
	/**
	 * 开启或关闭IP绑定
	 * @param agentIPWhiteRecord
	 * @return
	 */
	JsonResult openOrCloseIPWhite(AgentIPWhiteRecord agentIPWhiteRecord);
}
