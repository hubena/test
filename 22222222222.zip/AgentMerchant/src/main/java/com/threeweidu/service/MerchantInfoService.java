package com.threeweidu.service;

import com.threeweidu.entity.MerchantInfo;
import com.threeweidu.view.req.page.Page;
import com.threeweidu.view.result.EasyUIData;

public interface MerchantInfoService {

	EasyUIData queryEasyUIData(Page page, MerchantInfo merchantInfo);

}
