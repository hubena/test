package com.threeweidu.service;

import com.threeweidu.view.req.page.Page;
import com.threeweidu.view.result.EasyUIData;

public interface SendCodeRecordService {
	/**
	 * 分页查询SendCodeRecord记录
	 * 
	 * @param page
	 * @return
	 * @throws Exception
	 */
	EasyUIData queryEasyUIData(Page page) throws Exception;
	
}
