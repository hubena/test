package com.threeweidu.service.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sanweidu.jniPassword.JniPassword;
import com.sanweidu.sms.util.SendSmsUtil;
import com.threeweidu.dao.mybatis.AgentMapper;
import com.threeweidu.dao.proc.MerchantManageDao;
import com.threeweidu.entity.Agent;
import com.threeweidu.entity.AgentIPWhiteRecord;
import com.threeweidu.pepos.ocs.OCSUtil;
import com.threeweidu.pepos.util.ConnectionUtil.FieldsDB;
import com.threeweidu.service.AgentService;
import com.threeweidu.utils.Arith;
import com.threeweidu.utils.ConvertUtil;
import com.threeweidu.utils.EmailSender;
import com.threeweidu.utils.Null2;
import com.threeweidu.utils.SystemExceptionUtil;
import com.threeweidu.utils.ValidateUtils;
import com.threeweidu.view.result.EasyUIData;
import com.threeweidu.view.result.JsonResult;

@Service
public class AgentServiceImpl implements AgentService {
	private static final Logger logger = LoggerFactory.getLogger(AgentServiceImpl.class);
	@Autowired
	private AgentMapper agentMapper;
	
	private MerchantManageDao merchantManageDao;
	
	@Autowired
	public void setMerchantManageDao(MerchantManageDao merchantManageDao) {
		this.merchantManageDao = merchantManageDao;
		this.merchantManageDao.setDataBaseType(FieldsDB.THREEWEIDU_PEPOS_PAYMENT);
	}

	@Override
	public EasyUIData findMessage(String agentId) {
		try {
			merchantManageDao.batchUpdate("PAYMENT_SWDAGENT_HASCASHMONEY_UPDATE", new Object[]{agentId});
		} catch (Exception e) {
		}
		Agent agent = agentMapper.findAgentInfoByAgentid(agentId);
		agent = decryption(agent);
		if(Null2.isNull(agent)){
			return new EasyUIData(true, "数据为空", 0L, Collections.EMPTY_LIST);
		} else {
			List<Agent> rows = new ArrayList<Agent>();
			rows.add(agent);
			return new EasyUIData(true, "查询成功", 1L, rows);
		}
	}

	@Override
	public JsonResult updateAgentInfo(Agent agent) {
		if(!ValidateUtils.phoneNumber(agent.getAgentPhone())){
			return new JsonResult(false, "电话号码格式错误");
		}
		if(!ValidateUtils.checkEmail(agent.getEmail())){
			return new JsonResult(false, "邮箱格式错误");
		}
		Agent agent2 = agentMapper.findAgentInfoByAgentid(agent.getAgentId());
		if(Null2.isNotNull(agent2) && Null2.isNotNull(agent2.getAgentAccount())){
			agent.setEditMan(agent2.getAgentAccount());
		}
		int num = agentMapper.updateAgentInfo(agent);
		if (num > 0) {
			return new JsonResult(true, "修改成功");
		} else {
			return new JsonResult(false, "修改失败");
		}
	}	

	@Override
	public JsonResult updatePassword(String agentId, String agentOldPassword,
			String agentNewPassword1, String agentNewPassword2) {
		if(Null2.isNull(agentOldPassword)){
			return new JsonResult(false, "密码不能为空");
		}
		//agentOldPassword = toEncrypt(agentOldPassword);
		String agentPassword = agentMapper.findAgentPassword(agentId);
		if(Null2.isNull(agentPassword) || !agentPassword.equals(agentOldPassword)){
			return new JsonResult(false, "密码不正确");
		}
		if(Null2.isNull(agentNewPassword1) || Null2.isNull(agentNewPassword2) || !agentNewPassword1.equals(agentNewPassword2)){
			return new JsonResult(false, "两次新密码为空或不一样");
		}
		//agentNewPassword1 = toEncrypt(agentNewPassword1);
		if(agentOldPassword.equals(agentNewPassword1)){
			return new JsonResult(false, "新旧密码一样");
		}
		Agent agent = agentMapper.findAgentInfoByAgentid(agentId);
		String editMan = "";
		if(Null2.isNotNull(agent) && Null2.isNotNull(agent.getAgentAccount())){
			editMan = agent.getAgentAccount();
		}
		int num = agentMapper.updatePassword(agentId, agentNewPassword1, editMan);
		if (num > 0) {
			return new JsonResult(true, "修改成功");
		} else {
			return new JsonResult(false, "修改失败");
		}
	}
	
	/*
	 * 修改支付密码
	 */
	public JsonResult updatePayPassword(String agentId, String agentOldPayPassword,
			String agentNewPayPassword1, String agentNewPayPassword2){
		if(Null2.isNull(agentOldPayPassword)){
			return new JsonResult(false, "密码不能为空");
		}
		//查找支付密码
		String agentPassword = agentMapper.findAgentPayPassword(agentId);
		if(Null2.isNull(agentPassword) || !agentPassword.equals(agentOldPayPassword)){
			return new JsonResult(false, "密码不正确");
		}
		if(Null2.isNull(agentNewPayPassword1) || Null2.isNull(agentNewPayPassword2) || !agentNewPayPassword1.equals(agentNewPayPassword2)){
			return new JsonResult(false, "两次新密码为空或不一样");
		}
		//agentNewPassword1 = toEncrypt(agentNewPassword1);
		if(agentOldPayPassword.equals(agentNewPayPassword1)){
			return new JsonResult(false, "新旧密码一样");
		}
		//判断当前登录的代理商是否存在且取得代理商账户
		Agent agent = agentMapper.findAgentInfoByAgentid(agentId);
		String editMan = "";
		if(Null2.isNotNull(agent) && Null2.isNotNull(agent.getAgentAccount())){
			editMan = agent.getAgentAccount();
		}
		int num = agentMapper.updatePayPassword(agentId, agentNewPayPassword1, editMan);
		if (num > 0) {
			return new JsonResult(true, "修改成功");
		} else {
			return new JsonResult(false, "修改失败");
		}
	}

	public String toEncrypt(String password){
		JniPassword jniNative = JniPassword.getInstance();
		boolean bLoad = JniPassword.loadLibrary("JniPassword");
		if (bLoad) {
			password = jniNative.getSha512Value(password);
		}
		return password;
	}

	@Override
	public Agent getAgentByAgentid(String agentId) {
		Agent agent = agentMapper.getAgentByAgentid(agentId);
		agent = decryption(agent);
		return agent;
	}

	/**
	 * 解密
	 * @param agent
	 * @return
	 */
	private Agent decryption(Agent agent){
		// 提现
		if (Null2.isNotNull(agent.getWithdrawFixedFee())) {
			agent.setWithdrawFixedFee(Arith.movePointLeft(agent.getWithdrawFixedFee(), 2));
		}
		if (Null2.isNotNull(agent.getWithdrawDiscountMaxFee())) {
			agent.setWithdrawDiscountMaxFee(Arith.movePointLeft(agent.getWithdrawDiscountMaxFee(), 2));
		}
		if (Null2.isNotNull(agent.getWithdrawDiscountFee())) {
			agent.setWithdrawDiscountFee(Arith.movePointLeft(agent.getWithdrawDiscountFee(), 2));
		}
		//充值
//		if (Null2.isNotNull(agent.getRechargeDiscountFee())) {
//			agent.setRechargeDiscountFee(Arith.movePointLeft(agent.getRechargeDiscountFee(), 2));
//		}
//		if (Null2.isNotNull(agent.getRechargeDiscountMaxFee())) {
//			agent.setRechargeDiscountMaxFee(Arith.movePointLeft(agent.getRechargeDiscountMaxFee(), 2));
//		}
//		if (Null2.isNotNull(agent.getRechargeFixedFee())) {
//			agent.setRechargeFixedFee(Arith.movePointLeft(agent.getRechargeFixedFee(), 2));
//		}
//		agent.setUsableMaxAdvanceMoney(toLong(agent.getRealAdvanceMoney()) + toLong(agent.getTotalRecharge()));
//		agent.setUsableAdvanceMoney(toLong(agent.getUsableMaxAdvanceMoney()) - toLong(agent.getUsedAdvanceMoney()));
		agent.settZeroCanCashMoney(toLong(agent.gettZeroTotalBalance()) + toLong(agent.getRealAdvanceMoney()) 
				- toLong(agent.gettZeroHasCashMoney()));
		agent.settOneCanCashMoney(toLong(agent.gettOneTotalBalance()) - toLong(agent.gettOneHasCashMoney()));
		return agent;
	}

	private Long toLong(Long l){
		if(l==null){
			return 0L;
		}
		return l;
	}
	
	@Override
	public Agent getAgentLogo(String domainName) {		
		return agentMapper.getAgentLogo(domainName);
	}

	@Override
	public boolean checkPayPasswd(String agentId, String payPasswd) {
		Agent agent = agentMapper.getAgentByIdAndPayPasswd(agentId, payPasswd);
		if(Null2.isNotNull(agent)){
			return true;
		}
		return false;
	}

	@Override
	public Agent getAgentInfoByAgentid(String agentId) {
		return agentMapper.findAgentInfoByAgentid(agentId);
	}
	
	
	
	/**
	 * 发送手机验证码
	 * @param phone
	 * @param agentId
	 * @return JsonResult
	 * @throws Exception
	 */
	public JsonResult sendSms(String phone, String agentId, String couCode, String operation, String businessType) throws Exception {
		// 验证码缓存中;累积发送的次数,24小时内只能20次;时间的间隔
		Object obj = OCSUtil.getData("agentIPWhite_" + businessType + phone);
		String verifyCode = "";
		String currentDate = "";
		boolean flag = false;
		boolean flag2 = false;// 发送成功与否的标识
		int limitCount = 1;
		if (Null2.isNotNull(obj)) {
			// 数据加1，判断时间是否相隔一分钟,如果大于1分就更新，不然就提示
			String[] info = obj.toString().split("_");
			String lastTime = info[2];// 上次的时间
			long differTime = ConvertUtil.calLastedTime(lastTime);
			if (differTime < 60) {
				return new JsonResult(false, "您的验证码请求还没有超过1分钟,请稍后重试");
			}
			if (differTime < 1800)
				verifyCode = info[0];
			// 就正常操作
			limitCount = Integer.parseInt(info[1]);
			if (limitCount > 20) {
				return new JsonResult(false, "您的验证码请求已经超过20次了,请24小时后重试");
			}
			limitCount++;
		}
		if (Null2.isNull(verifyCode)) {
			verifyCode = ConvertUtil.createRandom();// 验证码
		}
		flag2 = SendSmsUtil.getInstance().sendSms(couCode,phone, operation + ",验证码为：" + verifyCode + "，工作人员不会向您索取,请勿泄漏！");
		if (flag2 == false) {
			return new JsonResult(false, "验证码发送失败");
		}
		currentDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
		flag = OCSUtil.setData("agentIPWhite_" + businessType + phone, verifyCode + "_" + limitCount + "_" + currentDate, 1 * 24 * 60 * 60);
		logger.info(operation + ",验证码为：" + verifyCode + "，工作人员不会向您索取,请勿泄漏！");
		// 发送验证码
		if (!flag) {
			SystemExceptionUtil.getInstance().addMemberLog(phone, "代理商基本信息修改,验证码存入缓存失败", "0200", "0223");
			logger.info("存入到缓存数据中失败");
			return new JsonResult(false, "验证码发送失败");
		}
		flag = OCSUtil.setData("agentIPWhite_" + businessType + "_param_" + agentId, "phone", 1 * 24 * 60 * 60);
		if (!flag) {
			return new JsonResult(false, "验证码发送失败");
		}
		if (!flag) {
			return new JsonResult(false, "验证码发送失败");
		}
		int count = agentMapper.insertAgentSendCodeRecord(agentId, 1001, phone, operation + ",验证码为：" + verifyCode + "，工作人员不会向您索取,请勿泄漏！");
		if (count > 0) {
//			if ("1001".equals(OrderIdGenerator.NOTPRODUCT)) { // 本地环境
//				return new JsonResult(true, "发送成功,请在60秒内验证" + verifyCode);
//			}
			return new JsonResult(true, "发送成功,请在60秒内验证");
		} else {
			return new JsonResult(false, "验证码发送失败", "添加验证码发送记录失败");
		}
	}

	/**
	 * 发送邮箱验证码
	 * @param email
	 * @param agentId
	 * @param couCode
	 * @param operation
	 * @param businessType
	 * @return
	 * @throws Exception
	 */
	public JsonResult sendSmsByEmail(String email, String agentId, String couCode, String operation, String businessType) throws Exception {
		// 验证码缓存中;累积发送的次数,24小时内只能20次;时间的间隔
		Object obj = OCSUtil.getData("agentIPWhite_" + businessType + email);
		String verifyCode = "";
		String currentDate = "";
		boolean flag = false;
		boolean flag2 = false;// 发送成功与否的标识
		int limitCount = 1; //用于判断发送次数
		if (Null2.isNotNull(obj)) {
			// 数据加1，判断时间是否相隔一分钟,如果大于1分就更新，不然就提示
			String[] info = obj.toString().split("_");
			String lastTime = info[2];// 上次的时间
			long differTime = ConvertUtil.calLastedTime(lastTime);
			if (differTime < 60) {
				return new JsonResult(false, "您的验证码请求还没有超过1分钟,请稍后重试");
			}
			if (differTime < 1800)
				verifyCode = info[0];
			// 就正常操作
			limitCount = Integer.parseInt(info[1]);
			if (limitCount > 20) {
				return new JsonResult(false, "您的验证码请求已经超过20次了,请24小时后重试");
			}
			limitCount++;
		}
		if (Null2.isNull(verifyCode)) {
			verifyCode = ConvertUtil.createRandom();// 验证码
		}
		flag2 = EmailSender.send(email, "操作确认验证", operation + ",验证码为：" + verifyCode + "，工作人员不会向您索取,请勿泄漏！");
		logger.info(operation + ",验证码为：" + verifyCode + "，工作人员不会向您索取,请勿泄漏！");
		if (flag2 == false) {
			return new JsonResult(false, "验证码发送失败");
		}
		currentDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
		flag = OCSUtil.setData("agentIPWhite_" + businessType + email, verifyCode + "_" + limitCount + "_" + currentDate, 1 * 24 * 60 * 60);
		// 发送验证码
		if (!flag) {
			SystemExceptionUtil.getInstance().addMemberLog(email, "代理商基本信息修改,验证码存入缓存失败", "0200", "0223");
			logger.info("存入到缓存数据中失败");
			return new JsonResult(false, "验证码发送失败");
		}
		flag = OCSUtil.setData("agentIPWhite_" + businessType + "_param_" + agentId, "email", 1 * 24 * 60 * 60);
		if (!flag) {
			return new JsonResult(false, "验证码发送失败");
		}
		int count = agentMapper.insertAgentSendCodeRecord(agentId, 1002, email, operation + ",验证码为：" + verifyCode + "，工作人员不会向您索取,请勿泄漏！");
		if (count > 0) {
//			if ("1001".equals(OrderIdGenerator.NOTPRODUCT)) { // 本地环境
//				return new JsonResult(true, "发送成功,请在60秒内验证" + verifyCode);
//			}
			return new JsonResult(true, "发送成功,请在60秒内验证");
		} else {
			return new JsonResult(false, "验证码发送失败", "添加验证码发送记录失败");
		}
	}
	
	/**
	 * 发送短信或者邮件
	 * @param se
	 */
	@Override
	public JsonResult sendIdentifyCode(String sendType, String sendNumber, String agentId, String couCode, String operation, String businessType) throws Exception {
		if ("1001".equals(sendType)) {
			return sendSms(sendNumber, agentId, couCode, operation, businessType);
		}else if("1002".equals(sendType)){
			return sendSmsByEmail(sendNumber, agentId, couCode, operation, businessType);
		}
		return new JsonResult(false, "页面数据错误，发送类型为空！");
	}

	@Override
	public JsonResult openOrCloseIPWhite(AgentIPWhiteRecord agentIPWhiteRecord) {
		String agentId = agentIPWhiteRecord.getAgentId();
		//验证手机验证码发送类型与缓存中存储的类型是否一致
		String businessType = new String();
		if (1001 == agentIPWhiteRecord.getSendType()) {
			businessType = "phone_setIPCode";
			String codeType = (String) OCSUtil.getData("agentIPWhite_" + businessType +"_param_" + agentId);
			if (!"phone".equals(codeType)) {
				return new JsonResult(false, "页面数据错误，发送类型错误！");
			}
		}else if (1002 == agentIPWhiteRecord.getSendType()) {
			businessType = "email_setIPCode";
			String codeType = (String) OCSUtil.getData("agentIPWhite_" + businessType + "_param_" + agentId);
			if (!"email".equals(codeType)) {
				return new JsonResult(false, "页面数据错误，发送类型错误！");
			}
		}
		
		//验证验证码
		String sendCodeForCheck = (String) OCSUtil.getData("agentIPWhite_" + businessType + agentIPWhiteRecord.getSendNumber());
		if (Null2.isNull(sendCodeForCheck)) {
			agentMapper.insertAgentOperateLog(agentIPWhiteRecord.getAgentId(), "设置代理商登录IP操作失败：缓存中验证码为空！", agentIPWhiteRecord.getAddManIP());
			return new JsonResult(false, "验证码验证失败!");
		}
		String[] infos = sendCodeForCheck.split("_");
		if (!agentIPWhiteRecord.getSendCode().equalsIgnoreCase(infos[0])) {
			agentMapper.insertAgentOperateLog(agentIPWhiteRecord.getAgentId(), "设置代理商登录IP操作失败：验证码错误！", agentIPWhiteRecord.getAddManIP());
			return new JsonResult(false, "验证码不正确!");
		}
		OCSUtil.setData("agentIPWhite_" + businessType + agentIPWhiteRecord.getSendNumber(), "", 60);
		agentMapper.updateAgentIsBindingIP(agentId, agentIPWhiteRecord.getIsBindingIP());
		agentMapper.insertAgentOperateLog(agentIPWhiteRecord.getAgentId(), "设置代理商登录IP操作成功！", agentIPWhiteRecord.getAddManIP());
		return new JsonResult(true, "设置登录IP操作成功!");
	}
}
