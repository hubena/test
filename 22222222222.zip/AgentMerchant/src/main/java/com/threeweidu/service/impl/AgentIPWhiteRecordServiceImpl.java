package com.threeweidu.service.impl;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.threeweidu.dao.mybatis.AgentIPWhiteRecordMapper;
import com.threeweidu.entity.AgentIPWhiteRecord;
import com.threeweidu.service.AgentIPWhiteRecordService;
import com.threeweidu.utils.Null2;
import com.threeweidu.view.req.page.Page;
import com.threeweidu.view.result.EasyUIData;
import com.threeweidu.view.result.JsonResult;

@Service
public class AgentIPWhiteRecordServiceImpl implements AgentIPWhiteRecordService {
	
	@Autowired
	private AgentIPWhiteRecordMapper agentIPWhiteRecordMapper;
	
	@Override
	public EasyUIData queryEasyUIData(Page page, AgentIPWhiteRecord agentIPWhiteRecord) {
		List<AgentIPWhiteRecord> rows = agentIPWhiteRecordMapper.findList(agentIPWhiteRecord, page);
		if(Null2.isNull(rows)){
			return new EasyUIData(true, "数据为空", 0L, Collections.EMPTY_LIST);
		} else {
			Long count = agentIPWhiteRecordMapper.findListCount(agentIPWhiteRecord);
			return new EasyUIData(true, "查询成功", count, rows);
		}
	}

	@Override
	public JsonResult addAgentIPWhiteRecord(AgentIPWhiteRecord agentIPWhiteRecord) {
		int num = agentIPWhiteRecordMapper.addAgentIPWhiteRecord(agentIPWhiteRecord);
		if (num > 0) {
			return new JsonResult(true, "添加成功.");
		}	
		return new JsonResult(false, "添加失败.");
	}

	@Override
	public Integer findCountSame(AgentIPWhiteRecord agentIPWhiteRecord) {
		return agentIPWhiteRecordMapper.findCountSame(agentIPWhiteRecord);
	}

	@Override
	public JsonResult deleteAgentIPWhiteRecord(List<AgentIPWhiteRecord> agentIPWhiteRecords) {
		long num = agentIPWhiteRecordMapper.deleteAgentIPWhiteRecord(agentIPWhiteRecords);
		if (num > 0) {
			return new JsonResult(true, "删除成功.");
		}	
		return new JsonResult(false, "删除失败.");
	}
	
	@Override
	public JsonResult updateStateBatch(List<AgentIPWhiteRecord> agentIPWhiteRecords){
		int num = agentIPWhiteRecordMapper.updateStateBatch(agentIPWhiteRecords);
		if (num > 0) {
			return new JsonResult(true, "批量操作成功.");
		}	
		return new JsonResult(false, "批量操作失败.");
	}
	
	
}
