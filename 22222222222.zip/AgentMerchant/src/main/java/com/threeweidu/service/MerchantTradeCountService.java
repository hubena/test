package com.threeweidu.service;

import com.threeweidu.entity.MerchantTradeCount;
import com.threeweidu.view.req.page.Page;
import com.threeweidu.view.result.EasyUIData;

public interface MerchantTradeCountService {

	EasyUIData findList(MerchantTradeCount merchantTradeCount, Page page);

}
