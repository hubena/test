package com.threeweidu.service;

import java.util.List;

import com.threeweidu.entity.AgentIPWhiteRecord;
import com.threeweidu.view.req.page.Page;
import com.threeweidu.view.result.EasyUIData;
import com.threeweidu.view.result.JsonResult;

public interface AgentIPWhiteRecordService {

	EasyUIData queryEasyUIData(Page page, AgentIPWhiteRecord agentIPWhiteRecord);
	
	/**
	 * 添加IP白名单
	 * @param AgentIPWhiteRecord
	 * @return JsonResult
	 */
	JsonResult addAgentIPWhiteRecord(AgentIPWhiteRecord agentIPWhiteRecord);
	
	/**
	 * 查询渠道商编号及绑定IP相同的记录条数
	 * @param AgentIPWhiteRecord
	 * @return Integer
	 */
	Integer findCountSame(AgentIPWhiteRecord agentIPWhiteRecord);
	
	/**
	 * 解绑IP
	 * @param List<AgentIPWhiteRecord>
	 * @return JsonResult
	 */
	JsonResult deleteAgentIPWhiteRecord(List<AgentIPWhiteRecord> agentIPWhiteRecords);

	/**
	 * 批量绑定或解绑IP
	 * @param agentIPWhiteRecords
	 * @return JsonResult
	 */
	JsonResult updateStateBatch(List<AgentIPWhiteRecord> agentIPWhiteRecords);
	
}
