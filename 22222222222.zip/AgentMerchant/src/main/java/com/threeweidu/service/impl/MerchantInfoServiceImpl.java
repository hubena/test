package com.threeweidu.service.impl;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.threeweidu.dao.mybatis.MerchantInfoMapper;
import com.threeweidu.entity.MerchantInfo;
import com.threeweidu.service.MerchantInfoService;
import com.threeweidu.utils.Null2;
import com.threeweidu.view.req.page.Page;
import com.threeweidu.view.result.EasyUIData;

@Service
public class MerchantInfoServiceImpl implements MerchantInfoService {
	
	@Autowired
	private MerchantInfoMapper merchantInfoMapper;
	
	@Override
	public EasyUIData queryEasyUIData(Page page, MerchantInfo merchantInfo) {
		List<MerchantInfo> rows = merchantInfoMapper.findList(merchantInfo, page);
		if(Null2.isNull(rows)){
			return new EasyUIData(true, "数据为空", 0L, Collections.EMPTY_LIST);
		} else {
			Long count = merchantInfoMapper.findListCount(merchantInfo);
			return new EasyUIData(true, "查询成功", count, rows);
		}
	}
}
