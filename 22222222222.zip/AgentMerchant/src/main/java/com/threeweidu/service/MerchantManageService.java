package com.threeweidu.service;

import com.threeweidu.entity.Merchant;
import com.threeweidu.view.req.page.Page;
import com.threeweidu.view.result.EasyUIData;
import com.threeweidu.view.result.JsonResult;



public interface MerchantManageService {

	/**
	 * 分页组合条件查询商户信息
	 * 
	 * @author XuPing
	 * @createTime 2016-9-29下午4:58:11
	 * @return EasyUIData
	 * @throws Exception
	 */
	EasyUIData queryEasyUIData(Page page) throws Exception;

	/**
	 * 修改商户的扣率信息
	 * 
	 * @author XuPing
	 * @createTime 2016-9-29下午6:55:38
	 * @return JsonResult
	 */
	JsonResult updateMerchantRate(Merchant merchant);

	/**
	 * 修改邮箱
	 * 
	 * @param merchant
	 * @return
	 */
	JsonResult updateEmail(Merchant merchant) throws Exception;

	EasyUIData findMerchantUser(Page page) throws Exception;

	Merchant findMerchantByMerId(String merId);

	JsonResult checkIsRealPay(Merchant merchant);

	JsonResult updatePhone(Merchant merchant);
	
	/**
	 * 商户解锁
	 * @param merchant
	 * @return
	 */
	JsonResult updateUseState(String merId);
	
	/**
	 * 商户登录密码重置
	 * @param String
	 * @param String
	 * @return JsonResult
	 */
	JsonResult updatePasswd(String supplierId, String encryptPassWd);

	/**
	 * 商户支付密码重置
	 * @param String
	 * @param String
	 * @return JsonResult
	 */
	JsonResult updatePayPasswd(String supplierId, String encryptPayPassWd);

	String getMerIds(String agentId);

	JsonResult addMerchant(Merchant merchant) throws Exception;

	int addGoodSupplier(Merchant merchant, String[] result);

	int addSupplierCashTransferFee(Merchant merchant);

	int addTerminal(Merchant merchant);

	String getMerIdsBySec(String secAgentId);

	JsonResult updateRemark(Merchant merchant) throws Exception;

	JsonResult loginIPUnwrap(Merchant merchant) throws Exception;

	JsonResult updateTransferReal(Merchant merchant);

}
