package com.threeweidu.service.impl;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.threeweidu.dao.mybatis.AgentMapper;
import com.threeweidu.dao.mybatis.SecSWDAgentMapper;
import com.threeweidu.entity.Agent;
import com.threeweidu.entity.AssociateMerchant;
import com.threeweidu.entity.SecSWDAgent;
import com.threeweidu.service.SecSWDAgentService;
import com.threeweidu.utils.Null2;
import com.threeweidu.view.req.page.Page;
import com.threeweidu.view.result.EasyUIData;
import com.threeweidu.view.result.JsonResult;

@Service
public class SecSWDAgentServiceImpl implements SecSWDAgentService {

	@Autowired
	private SecSWDAgentMapper secSWDAgentMapper;
	@Autowired
	private AgentMapper agentMapper;

	@Override
	public EasyUIData queryEasyUIData(SecSWDAgent agent, Page page) throws Exception {
		List<SecSWDAgent> rows = secSWDAgentMapper.findList(agent, page);
		if(Null2.isNull(rows)){
			return new EasyUIData(true, "数据为空", 0L, Collections.EMPTY_LIST);
		} else {
			Long count = secSWDAgentMapper.findListCount(agent);
			return new EasyUIData(true, "查询成功", count, rows);
		}
	}

	@Override
	public JsonResult addSecSWDAgent(SecSWDAgent secSWDAgent) {
		int num = secSWDAgentMapper.insertSecSWDAgent(secSWDAgent);
		if (num > 0) {
			return new JsonResult(true,"添加成功");
		}
		return new JsonResult(false,"添加失败");
	}

	@Override
	public String findAgentAccount(String agentId) {
		Agent agent = agentMapper.findAgentInfoByAgentid(agentId);
		return agent.getAgentAccount();
	}
	
	@Override
	public Long findAccountCount(String secAgentAccount){
		return secSWDAgentMapper.findAccountCount(secAgentAccount);
	}

	@Override
	public EasyUIData queryEasyUIData(AssociateMerchant associateMerchant,
			Page page) throws Exception {
		List<AssociateMerchant> rows = secSWDAgentMapper.findAssociateList(associateMerchant, page);
		if(Null2.isNull(rows)){
			return new EasyUIData(true, "数据为空", 0L, Collections.EMPTY_LIST);
		} else {
			Long count = secSWDAgentMapper.findAssociateCount(associateMerchant);
			return new EasyUIData(true, "查询成功", count, rows);
		}
	}

	@Override
	public JsonResult updateAssociate(AssociateMerchant associateMerchant) {
		int num = secSWDAgentMapper.updateAssociate(associateMerchant);
		if (num > 0) {
			return new JsonResult(true, "关联成功");
		}
		return new JsonResult(false, "关联失败");
	}
	
	@Override
	public JsonResult selectByAmId(String amId){
		AssociateMerchant associateMerchant = secSWDAgentMapper.selectByAmId(amId);
		if (Null2.isNull(associateMerchant)) {
			return new JsonResult(false, "要取消关联的商户不存在");
		}else if (Null2.isNull(associateMerchant.getSecAgentId())) {
			return new JsonResult(false, "选取的商户必须是已关联的");
		}
		return new JsonResult(true, "", associateMerchant);
		
	}
	
	@Override
    public JsonResult batchUpdateDisAssociate(List<AssociateMerchant> associateMerchants){
		long num = secSWDAgentMapper.batchUpdateDisAssociate(associateMerchants);
		if (num > 0) {
			return new JsonResult(true, "取消关联成功");
		}
		return new JsonResult(false, "取消关联失败");
	}
}
