package com.threeweidu.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.threeweidu.dao.mybatis.AgentPaymentWayMapper;
import com.threeweidu.dao.mybatis.MerAuthorizationInfoMapper;
import com.threeweidu.dao.mybatis.MerchantManageMapper;
import com.threeweidu.entity.AgentPaymentWay;
import com.threeweidu.entity.Chancel;
import com.threeweidu.entity.MerAuthorization;
import com.threeweidu.entity.MerKeyInfo;
import com.threeweidu.entity.Merchant;
import com.threeweidu.entity.PaymentWay;
import com.threeweidu.service.MerAuthorizationInfoService;
import com.threeweidu.utils.Arith;
import com.threeweidu.utils.Null2;
import com.threeweidu.view.req.page.Page;
import com.threeweidu.view.result.EasyUIData;
import com.threeweidu.view.result.JsonResult;


@Service
public class MerAuthorizationInfoServiceImpl implements MerAuthorizationInfoService {

	@Autowired
	private MerAuthorizationInfoMapper merAuthorizationInfoMapper;
	
	@Autowired
	private MerchantManageMapper merchantManageMapper;
	@Autowired
	private AgentPaymentWayMapper agentPaymentWayMapper;
	
	@Override
	public EasyUIData findAllPayWay(Page page, PaymentWay paymentWay, Merchant merchant2) throws Exception {
		Merchant merchant = merchantManageMapper.findMerchantByMerId(paymentWay.getMerId());
		if(Null2.isNull(merchant)){
			return new EasyUIData(false, "此商户不可进行授权操作", 0L, Collections.EMPTY_LIST);
		}
		List<PaymentWay> rows = merAuthorizationInfoMapper.findPaymentWayList(page, paymentWay);
		if(Null2.isNull(rows)){
			return new EasyUIData(true, "数据为空", 0L, Collections.EMPTY_LIST);
		} else {
			Long count = merAuthorizationInfoMapper.findPaymentWayCount(paymentWay);
			List<AgentPaymentWay> agentPaymentWays = agentPaymentWayMapper.findAll(paymentWay.getAgentId());
			rows = setPaymentRate(agentPaymentWays, rows, merchant2); // 设置是否方式扣率
			return new EasyUIData(true, "查询成功", count, rows);
		}
	}
	
	/**
	 * 设置是否方式扣率
	 */
	private List<PaymentWay> setPaymentRate(List<AgentPaymentWay> agentPaymentWays,
			List<PaymentWay> rows, Merchant merchant) {
		List<PaymentWay> list = new ArrayList<PaymentWay>();
		Map<Integer, AgentPaymentWay> map = new HashMap<Integer, AgentPaymentWay>();
		for (int i = 0; i < agentPaymentWays.size(); i++) {
			map.put(agentPaymentWays.get(i).getPaymentName(),
					agentPaymentWays.get(i));
		}
		AgentPaymentWay agentPaymentWay = null;
		for (PaymentWay paymentWay2 : rows) {
			agentPaymentWay = map.get(paymentWay2.getPaymentName());
			if (Null2.isNull(agentPaymentWay)) {
				continue;
			}
//			if ("1002".equals(merchant.getIsRealPay())) {
//				paymentWay2.setPaymentRate(agentPaymentWay.getRealRate());
//			} else {
//				paymentWay2.setPaymentRate(agentPaymentWay.getNotRealRate());
//			}
			paymentWay2.setRealRate(agentPaymentWay.getRealRate());
			paymentWay2.setNotRealRate(agentPaymentWay.getNotRealRate());
			if (StringUtils.isEmpty(paymentWay2.getAddTime())) {
				paymentWay2.setAddTime("-----");
			}
			list.add(paymentWay2);
		}
		return list;
	}

	@Override
	public JsonResult addMerAuthorization(MerAuthorization merAuthorization)
			throws Exception {
		String deductionRate = merAuthorization.getDeductionRate();
		BigDecimal big = new BigDecimal(deductionRate).movePointRight(2);
		merAuthorization.setDeductionRate(big.toString());
		// 支付方式和商户是否授权过
		JsonResult result2 = checkdPayWayAauthorization(merAuthorization);
		if(!result2.getSuccess()){
			return result2;
		}
		// 三维度支付方式的扣率大于等于成本扣率
		result2 = checkdPayWayDuctionRate(merAuthorization);
		if(!result2.getSuccess()){
			return result2;
		}
		Chancel chancel = merAuthorizationInfoMapper.findChancelByPaymentid(merAuthorization.getPaymentId());
		if(Null2.isNull(chancel)){
			return new JsonResult(false, "支付方式或者通道不存在！");
		}
		merAuthorization.setBillingCycle(chancel.getBillingCycle());
		int num = merAuthorizationInfoMapper.addMerAuthorization(merAuthorization);
		if (num > 0) {
			PaymentWay paymentWay = merAuthorizationInfoMapper.getPaymentWayByPaymentId(merAuthorization.getPaymentId());
			//当添加微信扫码（1005 ）时，添加微信支付商户信息
			if(Null2.isNotNull(paymentWay) && 1005 == paymentWay.getPaymentName()){
				JsonResult result = addMerKeyInfo(merAuthorization);
				if(!result.getSuccess()){
					return new JsonResult(false, "商户信息添加失败");
				}
			}
			return new JsonResult(true, "授权成功");
		} else {
			return new JsonResult(false, "授权失败");
		}
	}

	/**
	 * 校验是否授权
	 * @param merAuthorization
	 * @return
	 */
	private JsonResult checkdPayWayAauthorization(MerAuthorization merAuthorization) {
		MerAuthorization merAuthorization2 = merAuthorizationInfoMapper.getMerAuthorizationByMeridAndPaymentId(merAuthorization.getMerId(), merAuthorization.getPaymentId());
		if (Null2.isNotNull(merAuthorization2)) {
			return new JsonResult(false, "授权失败,此支付方式已授权!");
		}
		return new JsonResult(true, "校验通过");
	}

	@Override
	public JsonResult deleteMerAuthorization(List<MerAuthorization> merAuthorizations) {
		int num = merAuthorizationInfoMapper.deleteMerAuthorization(merAuthorizations);
		deleteMerKeyInfo(merAuthorizations);
		if(num>0){
			return new JsonResult(true, "取消关联成功");
		} else {
			return new JsonResult(false, "取消关联失败");
		}
	}

	@Override
	public JsonResult addMerKeyInfo(MerKeyInfo merKeyInfo) {
		MerKeyInfo keyInfo = merAuthorizationInfoMapper.getMerKeyInfoByMerid(merKeyInfo.getMerId());
		int num = 0;
		if (Null2.isNull(keyInfo)) {
			num = merAuthorizationInfoMapper.addMerKeyInfo(merKeyInfo);
		} else {
			num = merAuthorizationInfoMapper.updateMerKeyInfo(merKeyInfo);
		}
		if (num > 0) {
			return new JsonResult(true, "操作成功");
		} else {
			return new JsonResult(false, "操作失败");
		}
	}

	public JsonResult updateDeductionRate(MerAuthorization merAuthorization) throws Exception {
		merAuthorization.setDeductionRate(Arith.movePointRight(merAuthorization.getDeductionRate(), 2));
		// 三维度支付方式的扣率大于等于成本扣率
		JsonResult result2 = checkdPayWayDuctionRate(merAuthorization);
		if(!result2.getSuccess()){
			return result2;
		}
		Chancel chancel = merAuthorizationInfoMapper.findChancelByPaymentid(merAuthorization.getPaymentId());
		if(Null2.isNull(chancel)){
			return new JsonResult(false, "支付方式或者通道不存在！");
		}
		merAuthorization.setBillingCycle(chancel.getBillingCycle());
		int num=merAuthorizationInfoMapper.updateDeductionRate(merAuthorization);
		if(num>0){
			return new JsonResult(true, "修改扣率成功");
		} else {
			return new JsonResult(false, "修改扣率失败");
		}
	}

	/**
	 * 添加微信支付商户信息
	 */
	private JsonResult addMerKeyInfo(MerAuthorization merAuthorization) {
		MerKeyInfo merKeyInfo = merAuthorization.getMerKeyInfo();
		if(Null2.isNotNull(merKeyInfo)){
			merKeyInfo.setMerId(merAuthorization.getMerId());
			return addMerKeyInfo(merKeyInfo);				
		}
		return new JsonResult(false, "商户信息为空");
	}
	
	/**
	 * 删除微信商户授权支付方式
	 */
	private int deleteMerKeyInfo(List<MerAuthorization> merAuthorizations) {
		int count = 0;
		for(MerAuthorization merAuthorization : merAuthorizations) {
			PaymentWay paymentWay = merAuthorizationInfoMapper.getPaymentWayByPaymentId(merAuthorization.getPaymentId());
			//当添加微信扫码（1005 ）时，添加微信支付商户信息
			if(Null2.isNotNull(paymentWay) && 1005 == paymentWay.getPaymentName()){
				count += merAuthorizationInfoMapper.deleteMerKeyInfo(merAuthorization.getMerId());
			}
		}
		return count;
	}
	
	/**
	 * 校验支付方式扣率
	 */
	@SuppressWarnings("unused")
	private JsonResult checkdPayWayDuctionRateOld(MerAuthorization merAuthorization) throws Exception{
		// 三维度支付方式的扣率大于等于通道和银行卡的扣率
		PaymentWay paymentWay = merAuthorizationInfoMapper.getPaymentWayByPaymentIdAndMerid(merAuthorization.getPaymentId(), merAuthorization.getMerId());
		if (Null2.isNotNull(paymentWay) && Null2.isNotNull(paymentWay.getPaymentChancelName())) {
			if (!Arith.compare(merAuthorization.getDeductionRate(), paymentWay.getChancelDeductionRate())) {
				return new JsonResult(false, "授权失败,支付方式的扣率不能小于通道扣率!");
			}
		} else {
			return new JsonResult(false, "授权失败,该通道或支付方式不存在");
		}
		return new JsonResult(true, "校验通过");
	}
	
	/**
	 * 校验支付方式扣率
	 */
	private JsonResult checkdPayWayDuctionRate(MerAuthorization merAuthorization)
			throws Exception {
		// 三维度支付方式的扣率大于等于成本扣率
		AgentPaymentWay paymentWay = agentPaymentWayMapper.findByPaymentWay(merAuthorization.getAgentId(), merAuthorization.getPaymentName());
		if (Null2.isNotNull(paymentWay)) {
			if ("1002".equals(merAuthorization.getIsRealPay())
					&& Null2.isNotNull(paymentWay.getRealRate())) {
				if (!Arith.compare(merAuthorization.getDeductionRate(),
						paymentWay.getRealRate())) {
					return new JsonResult(false, "授权失败,支付方式的扣率不能小于成本扣率!");
				}
			} else if (Null2.isNotNull(paymentWay.getNotRealRate())) {
				if (!Arith.compare(merAuthorization.getDeductionRate(),
						paymentWay.getNotRealRate())) {
					return new JsonResult(false, "授权失败,支付方式的扣率不能小于成本扣率!");
				}
			}
		} else {
			return new JsonResult(false, "授权失败,该通道或支付方式不存在");
		}
		return new JsonResult(true, "校验通过");
	}

	@Override
	public EasyUIData findAllAgentPayWay(Page page, String agentId) {
		List<AgentPaymentWay> rows = agentPaymentWayMapper.findAll(agentId);
		if(Null2.isNull(rows)){
			return new EasyUIData(true, "数据为空", 0L, Collections.EMPTY_LIST);
		} else {
			return new EasyUIData(true, "查询成功", (long) rows.size(), rows);
		}
	}
}
