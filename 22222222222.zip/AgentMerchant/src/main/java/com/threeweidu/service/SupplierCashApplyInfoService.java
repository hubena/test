package com.threeweidu.service;

import com.threeweidu.view.req.page.Page;
import com.threeweidu.view.result.EasyUIData;
import com.threeweidu.view.result.JsonResult;



public interface SupplierCashApplyInfoService {
	
	/**
	 * 分页查询SupplierCashApply记录
	 * 
	 * @param page
	 * @return
	 * @throws Exception
	 */
	EasyUIData queryEasyUIData(Page page) throws Exception;


	
	/**
	 * 导出报表
	 * 
	 * @param page
	 * @return
	 * @throws Exception
	 */
	JsonResult exportList(Page page, String exportType) throws Exception;
	
}
