package com.threeweidu.service;

import com.threeweidu.entity.SupplierCashApply;
import com.threeweidu.view.req.page.Page;
import com.threeweidu.view.result.EasyUIData;

public interface SupplierCashApplyService {
	
	/**
	 * 分页查询SupplierCashApply记录
	 * 
	 * @param page
	 * @return
	 * @throws Exception
	 */
	EasyUIData queryEasyUIData(Page page) throws Exception;

	/**
	 * 根据提现订单查询提现记录
	 * 
	 * @param cashId
	 * @return
	 */
	SupplierCashApply findByCashId(String cashId);

}
