package com.threeweidu.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.threeweidu.dao.mybatis.PaymentRecordProfitStatisticsMapper;
import com.threeweidu.entity.PaymentRecordProfitStatistics;
import com.threeweidu.service.PaymentRecordProfitStatisticsService;
import com.threeweidu.utils.Null2;
import com.threeweidu.view.req.page.Page;
import com.threeweidu.view.result.EasyUIData;

@Service
public class PaymentRecordProfitStatisticsServiceImpl implements PaymentRecordProfitStatisticsService {

	@Autowired
	private PaymentRecordProfitStatisticsMapper statisticsMapper;

	@Override
	public EasyUIData findList(PaymentRecordProfitStatistics statistics, Page page) throws Exception {
		List<PaymentRecordProfitStatistics> rows = statisticsMapper.findList(statistics, page);
		if (Null2.isNull(rows)) {
			return new EasyUIData(true, "数据为空", 0L, Collections.EMPTY_LIST);
		} else {
			Long count = statisticsMapper.findListCount(statistics);
			List<?> footer = getFooter(statistics);
			return new EasyUIData(true, "查询成功", count, rows, footer);
		}
	}

	private List<?> getFooter(PaymentRecordProfitStatistics statistics) {
		List<PaymentRecordProfitStatistics> footer = new ArrayList<PaymentRecordProfitStatistics>();
		PaymentRecordProfitStatistics statistics2 = statisticsMapper.findSumFooter(statistics);
		if(Null2.isNull(statistics2)){
			statistics2 = new PaymentRecordProfitStatistics();
		}
		footer.add(statistics2);
		return footer;
	}
}
