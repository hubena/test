package com.threeweidu.service;

import com.threeweidu.entity.PaymentRecordProfitStatistics;
import com.threeweidu.view.req.page.Page;
import com.threeweidu.view.result.EasyUIData;

public interface PaymentRecordProfitStatisticsService {

	/**
	 * 交易
	 */
	public EasyUIData findList(PaymentRecordProfitStatistics statistics, Page page) throws Exception;

}
