package com.threeweidu.service.impl;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.threeweidu.dao.mybatis.AnnouncementMapper;
import com.threeweidu.entity.Announcement;
import com.threeweidu.service.AnnouncementService;
import com.threeweidu.utils.Null2;
import com.threeweidu.view.req.page.Page;
import com.threeweidu.view.result.EasyUIData;
import com.threeweidu.view.result.JsonResult;

@Service
public class AnnouncementServiceImpl implements AnnouncementService {

	@Autowired
	private AnnouncementMapper announcementMapper;

	@Override
	public EasyUIData findList(Announcement announcement, Page page) throws Exception {
		List<Announcement> rows = announcementMapper.findList(announcement, page);
		if(Null2.isNull(rows)){
			return new EasyUIData(true, "数据为空", 0L, Collections.EMPTY_LIST);
		} else {
			Long count = announcementMapper.findListCount(announcement);
			return new EasyUIData(true, "查询成功", count, rows);
		}
	}

	@Override
	public JsonResult addAnnouncement(Announcement announcement) {
		int num = announcementMapper.addAnnouncement(announcement);
		if (num > 0) {
			return new JsonResult(true,"添加成功");
		}
		return new JsonResult(false,"添加失败");
	}

	@Override
	public JsonResult updateAnnouncement(Announcement announcement) {
		int num = announcementMapper.updateAnnouncement(announcement);
		if (num > 0) {
			return new JsonResult(true,"修改成功");
		}
		return new JsonResult(false,"修改失败");
	}

	@Override
	public JsonResult updatePublish(Announcement announcement) {
		int num = announcementMapper.updatePublish(announcement);
		if (num > 0) {
			return new JsonResult(true,"更新成功");
		}
		return new JsonResult(false,"更新失败");
	}
	
}
