package com.threeweidu.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.threeweidu.dao.mybatis.MerchantTradeCountMapper;
import com.threeweidu.entity.MerchantTradeCount;
import com.threeweidu.service.MerchantTradeCountService;
import com.threeweidu.utils.Null2;
import com.threeweidu.view.req.page.Page;
import com.threeweidu.view.result.EasyUIData;

@Service
public class MerchantTradeCountServiceImpl implements MerchantTradeCountService{

	@Autowired
	private MerchantTradeCountMapper merchantTradeCountMapper;
	
	@Override
	public EasyUIData findList(MerchantTradeCount merchantTradeCount, Page page) {
		List<MerchantTradeCount> rows = merchantTradeCountMapper.findList(merchantTradeCount, page);
		if(Null2.isNull(rows)){
			return new EasyUIData(true, "数据为空", 0L, Collections.EMPTY_LIST);
		} else {
			Long count = merchantTradeCountMapper.findListCount(merchantTradeCount);
			List<?> footer = getFooter(merchantTradeCount);
			return new EasyUIData(true, "查询成功", count, rows, footer);
		}
	}

	private List<?> getFooter(MerchantTradeCount merchantTradeCount) {
		List<MerchantTradeCount> footer = new ArrayList<MerchantTradeCount>();
		MerchantTradeCount record = merchantTradeCountMapper.findSumFooter(merchantTradeCount);
		if(Null2.isNull(record)){
			record = new MerchantTradeCount();
		}
		footer.add(record);
		return footer;
	}

}
