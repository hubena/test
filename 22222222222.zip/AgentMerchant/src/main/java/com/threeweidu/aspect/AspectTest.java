package com.threeweidu.aspect;

import javax.servlet.http.HttpServletRequest;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

import com.threeweidu.filter.SysContent;

@Component
@Aspect
public class AspectTest {

	@Pointcut("execution(* com.threeweidu.service..*Impl.*(..))")
	public void test() {
	}

	// 使用@Pointcut Annotation 时指定切入点表达式
	@Before("test()")
	public void test(JoinPoint joinPoint) {
		HttpServletRequest request = SysContent.getRequest();
		// HttpServletResponse response = SysContent.getResponse();
		// HttpSession session = SysContent.getSession();
		System.out.println("请求路径：" + request.getRequestURI());
		// System.out.println("前置增强方法：" + joinPoint.getSignature().getName());
	}

}
