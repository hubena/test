package com.threeweidu.session;

public class SystemUserSession {

	public static final String SYSTEMUSER_SYSTEM_SESSIONID = "system_user_system_sessionid";

	private String userId;
	private String userName;

	public SystemUserSession(String userId, String userName) {
		this.userId = userId;
		this.userName = userName;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

}
