package com.threeweidu.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.threeweidu.utils.APIKeyUtils;
import com.threeweidu.utils.mybatis.FastJsonUtils;
import com.threeweidu.view.result.JsonResult;

public class APIKeyInterceptor extends HandlerInterceptorAdapter {

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
		String apikey = request.getParameter("apikey");
		if (StringUtils.isEmpty(apikey) 
				|| !APIKeyUtils.getInstance().checkAPIKey(apikey)) {
			String json = FastJsonUtils.toJsonStringWithDateFormat(new JsonResult("1002", "登录失效，请重新登录!"));
			response.setContentType("text/html;charset=utf-8");
			response.getWriter().write(json);
			response.getWriter().flush();
			response.getWriter().close();
			return false;
		} 
		return true;
	}

}
