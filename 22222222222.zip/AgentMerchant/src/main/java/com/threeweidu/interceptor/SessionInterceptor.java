package com.threeweidu.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.threeweidu.session.SystemUserSession;
import com.threeweidu.utils.mybatis.FastJsonUtils;
import com.threeweidu.view.result.JsonResult;

public class SessionInterceptor extends HandlerInterceptorAdapter {

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
		String param = request.getParameter("easyui_form_cust_param_key");
		String path = request.getContextPath();
		String basePath = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort() + path + "/";

		Object adminSessionObject = request.getSession().getAttribute(SystemUserSession.SYSTEMUSER_SYSTEM_SESSIONID);

		if (null == adminSessionObject) {
			if (request.getHeader("x-requested-with") != null && request.getHeader("x-requested-with").equalsIgnoreCase("XMLHttpRequest")) {
				// ajax超时处理
				response.addHeader("sessionstatus", "timeout");
			} else {
				if (StringUtils.isEmpty(param)) {
					// http超时的处理
					response.sendRedirect(basePath + "login/loginRedirect");
				} else {
					// easyui提交form
					String json = FastJsonUtils.toJsonStringWithDateFormat(new JsonResult(false, "session超时", "SESSIONOUT"));
					response.setContentType("text/html;charset=utf-8");
					response.getWriter().write(json);
					response.getWriter().flush();
					response.getWriter().close();
				}
			}
			return false;
		}
		return true;
	}

}
