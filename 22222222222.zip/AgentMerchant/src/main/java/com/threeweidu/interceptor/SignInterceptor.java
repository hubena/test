package com.threeweidu.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.threeweidu.pepos.util.MD5;
import com.threeweidu.utils.mybatis.FastJsonUtils;
import com.threeweidu.view.result.JsonResult;

public class SignInterceptor extends HandlerInterceptorAdapter {

	private static final String SIGN_KEY = "08c30091044ff23c6fa99b569d5bc438";//验签密钥
	
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
		if(!check(request)){//验签未通过
			String json = FastJsonUtils.toJsonStringWithDateFormat(new JsonResult("1001", "登录失效，请重新登录!"));
			response.setContentType("text/html;charset=utf-8");
			response.getWriter().write(json);
			response.getWriter().flush();
			response.getWriter().close();
			return false;
		}
		return true;
	}
	/**
	 * 校验
	 * @param request
	 * @return
	 */
	private boolean check(HttpServletRequest request){
		String method = request.getMethod();
		String sign = request.getParameter("signData");
		String time = request.getParameter("signTime");
		if ("POST".equalsIgnoreCase(method)) {
			if (StringUtils.isEmpty(sign) || StringUtils.isEmpty(time)) { // 参数为空，验证不通过
				return false;
			}
			String newSign = MD5.MD5Encode(SIGN_KEY + time);
			if (!sign.equals(newSign)) { // 验签失败
				return false;
			}
		}
		return true;
	}

}
