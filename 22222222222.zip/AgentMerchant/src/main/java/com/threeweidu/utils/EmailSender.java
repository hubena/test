package com.threeweidu.utils;

import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeUtility;


public class EmailSender {

	private static final String charset = "UTF-8";
	private static final String MAIL_SMTP_HOST = "54.238.234.84";
	private static final String MAIL_SMTP_PORT = "25";
	private static final String MAIL_ACCOUNT_NAME = "postmaster@pay.casino";
	private static final String MAIL_ACCOUNT_PASSWORD = "iovpay@#$postmaster";
	private static final String MAIL_INTERNETADDRESS = "postmaster@pay.casino";

	/**
	 * 发送邮件
	 * 
	 * @param receiver 收件人
	 * @param subject 标题
	 * @param mailContent 邮件内容
	 * @param mimetype 内容类型 默认为text/plain,如果要发送HTML内容,应设置为text/html
	 * @return
	 */
	public static boolean send(String receiver, String subject, String mailContent) {
		return send(new String[] { receiver }, subject, mailContent);
	}

	/**
	 * 发送邮件
	 * 
	 * @param receivers 收件人
	 * @param subject 标题
	 * @param mailContent 邮件内容
	 * @param attachements 附件
	 * @param mimetype 内容类型 默认为text/plain,如果要发送HTML内容,应设置为text/html
	 */
	public static boolean send(String[] receivers, String subject, String mailContent) {
		// 配置发送邮件的环境属性
		final Properties props = new Properties();
		props.put("mail.smtp.auth", "true");// 需要校验
		props.put("mail.smtp.host", MAIL_SMTP_HOST);// Smtp服务器地址
		props.put("mail.smtp.port", MAIL_SMTP_PORT);
		props.put("mail.user", MAIL_ACCOUNT_NAME);
		props.put("mail.password", MAIL_ACCOUNT_PASSWORD);

		// 构建授权信息，用于进行SMTP进行身份验证
		Authenticator authenticator = new Authenticator() {
			@Override
			protected PasswordAuthentication getPasswordAuthentication() {
				String userName = props.getProperty("mail.user");// 用户名
				String password = props.getProperty("mail.password");// 密码
				return new PasswordAuthentication(userName, password);
			}
		};
		// 使用环境属性和授权信息，创建邮件会话
		Session mailSession = Session.getInstance(props, authenticator);
		try {
			// 创建邮件消息
			MimeMessage message = new MimeMessage(mailSession);
			// 设置发件人
			message.setFrom(new InternetAddress("\"" + MimeUtility.encodeText("渠道商平台") + "\" <" + MAIL_INTERNETADDRESS + ">"));
			// 设置收件人
			InternetAddress[] toAddress = new InternetAddress[receivers.length];
			for (int i = 0; i < receivers.length; i++) {
				toAddress[i] = new InternetAddress(receivers[i]);
			}
			message.setRecipients(Message.RecipientType.TO, toAddress);// 收件人邮件
			message.setSubject(subject, charset);
			// 设置邮件标题
			message.setSubject(subject);
			// 设置邮件的内容体
			message.setContent(mailContent, "text/html;charset=" + charset);
			// 发送邮件
			Transport.send(message);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

}
