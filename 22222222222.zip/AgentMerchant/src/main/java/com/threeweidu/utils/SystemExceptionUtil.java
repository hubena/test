package com.threeweidu.utils;



import java.net.InetAddress;
import java.net.UnknownHostException;

import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.threeweidu.dao.proc.ManageLogDao;
import com.threeweidu.dao.proc.SysExceptionDao;
import com.threeweidu.pepos.util.ConnectionUtil.FieldsDB;


/**  
 * 版权所有(C)2012
 * 公司名称：三维度
 * 公司地址：深圳市南山区长虹科技大厦2512
 * 网址:  www.3weidu.com
 * 版本:  1.0
 * 文件名：  SystemExceptionUtil.java
 * 文件描述:系统异常的添加处理
 * 作者:   HuYaping
 * 创建时间:2013-4-17上午10:19:40
 * 负责人:  
 * 修改者：  
 * 修改时间：2013-4-17上午10:19:40
 */
public class SystemExceptionUtil {
	private static SystemExceptionUtil instance = null;
	private static Logger log = LoggerFactory.getLogger(SystemExceptionUtil.class);
	@Autowired
	private SysExceptionDao sysExceptionDao; // 异常日志处理DAO
	private ManageLogDao manageLogDao; // 记录日志的DAO
	
	
	private SystemExceptionUtil() {
	}

	public  static SystemExceptionUtil getInstance(){
		if(instance == null){
			instance = new SystemExceptionUtil();
			instance.setSysExceptionDao(new SysExceptionDao());
			instance.setManageLogDao(new ManageLogDao());
		}
		return instance;
	}
	
	
	public int addLog2(String content, String pId, String childId, String mainKey)
			throws Exception {
		int count = 0;
		try {
			InetAddress addr = InetAddress.getLocalHost();
			String currentLocalIp=addr.getHostAddress().toString();//获得本机IP
				count = manageLogDao.addManageLog("MANAGELOG_ADDLOG_ADD",new Object[] {"peposAdmin",content, currentLocalIp, pId, childId,mainKey });
		} catch (Exception e) {
			e.printStackTrace();
			addSysExceptionLog(e);
			log.info(content + "日志添加失败");
		}
		return count;
	}
	/***
	 * 添加会员日志
	 * 
	 * @param content
	 * @param pId
	 * @param childId
	 * @param mainKey
	 * @return
	 * @throws Exception
	 */
	public int addMemberLog(String memberNo,String content, String pId, String childId)
			throws Exception {
	
		int count = 0;
		try {
			//服务器Ip
			InetAddress addr = InetAddress.getLocalHost();
			String ip = "服务器Ip:"+addr.getHostAddress().toString()+",";
			count = manageLogDao.addManageLog("PEPOSLOG_MANAGELOG_ADDLOG_ADD",new Object[] {memberNo,ip + content,pId, childId });
		} catch (Exception e) {
			e.printStackTrace();
			addSysExceptionLog(e);
			log.info(content + "日志添加失败");
		}
		return count;
	}
	 /**
	  *  添加异常日志
	 * @return
	 * @throws Exception
	 */
	public boolean addSysExceptionLog(Exception e){
		boolean flag = false;
		try {
			HttpServletRequest request = null;
			request=((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest();
			InetAddress addr = InetAddress.getLocalHost();
			String currentLocalIp=addr.getHostAddress().toString();//获得本机IP
			StringBuffer sb = new StringBuffer();
			if (request!=null) { //不是request请求时，通过另一种方式获取Ip
				sb.append("服务器IP(" + request.getLocalAddr()).append(")<br>");
			}else{
				sb.append("服务器IP(" + currentLocalIp).append(")<br>");
			}
			StackTraceElement[] messages = e.getStackTrace();
			sb.append("" + e.toString() + "<br>");
			int length = messages.length;
			for (int i = 0; i < length; i++) {
				sb.append("   " + messages[i].toString());
				sb.append("<br>");
			}
			String uri = "同步信息URL"; //不是request请求时，URL使用默认设置
			if (request!=null) {
				uri = request.getRequestURI();
				String ctx = request.getContextPath();
				uri = uri.substring(ctx.length());
				currentLocalIp = getIpAddr();
			}
			// 加入到数据
			int addRecord = sysExceptionDao.addSysException("SysException_ADDLOG_ADD", new Object[] { sb.toString(), currentLocalIp, uri, "代理商平台" });
			if (addRecord == 1) {
				//log.info("功能路径为" + uri + "系统异常日志添加成功！");
				flag = true;
			}
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		return flag;
	}
	/**
	 * 添加系统异常日志
	 * @return
	 * @throws UnknownHostException 
	 */
	public boolean addSysExceptionLog2(String sysContents) throws Exception{
		boolean flag = false;
		InetAddress addr = InetAddress.getLocalHost();
		String currentLocalIp=addr.getHostAddress().toString();//获得本机IP
		int addRecord = sysExceptionDao.addSysException(
				"SysException_ADDLOG_ADD", new Object[] {sysContents,currentLocalIp, "同步信息URL", "网站后台" });
		if (addRecord == 1) {
			//log.info("功能路径为" + uri + "系统异常日志添加成功！");
			flag = true;
		}
		return flag;
	}
	/***
	 * 获取IP
	 * 
	 * @return
	 */
	private static String getIpAddr() {
//		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletRequest request = ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest();
		String ipAddress = null;
		// ipAddress = this.getRequest().getRemoteAddr();
		ipAddress = request.getHeader("x-forwarded-for");
		if (ipAddress == null || ipAddress.length() == 0
				|| "unknown".equalsIgnoreCase(ipAddress)) {
			ipAddress = request.getHeader("Proxy-Client-IP");
		}
		if (ipAddress == null || ipAddress.length() == 0
				|| "unknown".equalsIgnoreCase(ipAddress)) {
			ipAddress = request.getHeader("WL-Proxy-Client-IP");
		}
		if (ipAddress == null || ipAddress.length() == 0
				|| "unknown".equalsIgnoreCase(ipAddress)) {
			ipAddress = request.getRemoteAddr();
			if (ipAddress.equals("127.0.0.1")) {
				// 根据网卡取本机配置的IP
				InetAddress inet = null;
				try {
					inet = InetAddress.getLocalHost();
				} catch (UnknownHostException e) {
					e.printStackTrace();
				}
				ipAddress = inet.getHostAddress();
			}

		}

		// 对于通过多个代理的情况，第一个IP为客户端真实IP,多个IP按照','分割
		if (ipAddress != null && ipAddress.length() > 15) { // "***.***.***.***".length()
			// = 15
			if (ipAddress.indexOf(",") > 0) {
				ipAddress = ipAddress.substring(0, ipAddress.indexOf(","));
			}
		}
		return ipAddress;
	}

	public SysExceptionDao getSysExceptionDao() {
		return sysExceptionDao;
	}

	public void setSysExceptionDao(SysExceptionDao sysExceptionDao) {
		this.sysExceptionDao = sysExceptionDao;
		this.sysExceptionDao.setDataBaseType(FieldsDB.THREEWEIDU_PEPOS_LOG);
	}

	public ManageLogDao getManageLogDao() {
		return manageLogDao;
	}

	public void setManageLogDao(ManageLogDao manageLogDao) {
		this.manageLogDao = manageLogDao;
		this.manageLogDao.setDataBaseType(FieldsDB.THREEWEIDU_PEPOS_LOG);
	}
	
	
}
