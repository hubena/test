package com.threeweidu.utils.mybatis;

public class DBContextHolder {
	public static final String DATA_SOURCE_PLATFORM_INTERFACE = "platform_interface"; // 鸿星尔克数据库
	public static final String DATA_SOURCE_PEPOS = "pepos";
	public static final String DATA_SOURCE_SHOP = "shop";
	public static final String DATA_SOURCE_PEPOSLOG = "peposlog";
	public static final String DATA_SOURCE_PEPOSCHAT = "peposchat";
	public static final String DATA_SOURCE_VASERVICE = "vaservice";
	public static final String DATA_SOURCE_PAYMENT="payment";
	private static final ThreadLocal<String> contextHolder = new ThreadLocal<String>();

	public static void setDBType(String dbType) {
		contextHolder.set(dbType);
	}

	public static String getDBType() {
		return contextHolder.get();
	}

	public static void clearDBType() {
		contextHolder.remove();
	}
}
