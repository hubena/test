package com.threeweidu.utils;

import com.threeweidu.pepos.util.Base64Local;

public class Base64Util {
	
	public static String encode(String str) throws Exception{
		  str = Base64Local.encodeToString(str.getBytes("UTF-8"), false);
		    str = str.replace("+", "*");
		    str = str.replace("/", "-");
		    str = str.replace("=", ".");
		   return str;
	}
	
	public static String Base64DecodeReplaceSpecialChar(String str) throws Exception {
		str = str.replace("*", "+");
		str = str.replace("-", "/");
		str = str.replace(".", "=");
		byte[] strByte = Base64Local.decode(str);
		if (strByte == null) {
			return null;
		}
		str = new String(Base64Local.decode(str), "UTF-8");
		return str;
	}
	 
}
