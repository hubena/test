package com.threeweidu.utils;

import java.util.Collection;

public class Null2 {
	@SuppressWarnings("rawtypes")
	public static boolean isNull(Object obj) {
		if (obj == null)
			return true;
		if (obj instanceof String) {
			String o = (String) obj;
			if (o.trim().length() == 0)
				return true;
		} else if (obj instanceof Collection) {
			Collection col = (Collection) obj;
			if (col.isEmpty())
				return true;
		}
		return false;
	}

	@SuppressWarnings("rawtypes")
	public static boolean isNotNull(Object obj) {
		if (obj == null)
			return false;
		if (obj instanceof String) {
			String o = (String) obj;
			if (o.trim().length() > 0)
				return true;
			else
				return false;
		} else if (obj instanceof Collection) {
			Collection col = (Collection) obj;
			if (col.isEmpty())
				return false;
			else
				return true;
		}
		return true;
	}
}
