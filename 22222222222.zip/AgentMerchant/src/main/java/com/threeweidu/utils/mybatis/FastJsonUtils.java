package com.threeweidu.utils.mybatis;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;

public class FastJsonUtils {
	
	public static String toJsonStringWithDateFormat(Object object){
		return JSON.toJSONStringWithDateFormat(object, "yyyy-MM-dd HH:mm:ss",
				SerializerFeature.WriteEnumUsingToString, 
				SerializerFeature.WriteMapNullValue,				//是否输出值为null的字段，默认为false
				SerializerFeature.WriteNullStringAsEmpty, 
				SerializerFeature.WriteDateUseDateFormat,
				SerializerFeature.DisableCircularReferenceDetect);
	}
	
	public static String toJsonStringWithDateFormat(Object object, Boolean outNull){
		if(null == outNull || outNull){
			return toJsonStringWithDateFormat(object);
		}
		return JSON.toJSONStringWithDateFormat(object, "yyyy-MM-dd HH:mm:ss",
				SerializerFeature.WriteEnumUsingToString, 
//				SerializerFeature.WriteMapNullValue,				//是否输出值为null的字段，默认为false
				SerializerFeature.WriteNullStringAsEmpty, 
				SerializerFeature.WriteDateUseDateFormat,
				SerializerFeature.DisableCircularReferenceDetect);
	}
}
