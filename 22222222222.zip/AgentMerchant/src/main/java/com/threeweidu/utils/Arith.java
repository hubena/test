package com.threeweidu.utils;

import java.math.BigDecimal;
import java.text.DecimalFormat;

import org.apache.log4j.Logger;

/**
 * 由于Java的简单类型不能够精确的对浮点数进行运算，这个工具类提供精 确的浮点数运算，包括加减乘除和四舍五入。
 */
public class Arith {
	/**
	 * Logger for this class
	 */
	@SuppressWarnings("unused")
	private static final Logger log = Logger.getLogger(Arith.class);

	// 默认除法运算精度
	private static final int DEF_DIV_SCALE = 2;

	// 这个类不能实例化
	private Arith() {
	}

	/**
	 * 大值数值百分比相乘
	 * 
	 * @return
	 */
	public static int getBigPercentageMul(Object obj1, Object obj2) {
		int payFinancRate = Integer.parseInt(obj1.toString());// 商户的扣率,计算利润
		BigDecimal b1 = new BigDecimal(payFinancRate);
		BigDecimal b2 = new BigDecimal(obj2.toString());
		long x = Long.valueOf(b1.multiply(b2).toString());
		int mulVal = (int) Arith.round(x / 10000f, 0); // 三维度应扣回佣以分存入数据库
		return mulVal;
	}

	/**
	 * 大值数值百分比相乘，三位小数需要除以100000
	 * 
	 * @return
	 */
	public static int getBigPercentageMul2(Object obj1, Object obj2) {
		int payFinancRate = Integer.parseInt(obj1.toString());// 商户的扣率,计算利润
		BigDecimal b1 = new BigDecimal(payFinancRate);
		BigDecimal b2 = new BigDecimal(obj2.toString());
		long x = Long.valueOf(b1.multiply(b2).toString());
		int mulVal = (int) Arith.round(x / 100000f, 0); // 三维度应扣回佣以分存入数据库
		return mulVal;
	}

	/**
	 * 转换为W
	 * 
	 * @return
	 */
	public static String conversionWan(Object obj) {
		if (obj != null && !"".equals(obj)) {
			long data = Long.valueOf(obj.toString());
			double realityMoneyDou = Arith.div(data, 10000 * 100);
			String moneyStr = String.valueOf(realityMoneyDou);
			moneyStr = moneyStr.substring(moneyStr.lastIndexOf(".") + 1);
			if (Integer.parseInt(moneyStr) == 0) {
				return (int) realityMoneyDou + "W";
			} else {
				return realityMoneyDou + "W";
			}

		} else {
			return "---";
		}
	}

	/***
	 * 扣率乘以10000
	 * 
	 * @param obj
	 * @return
	 */
	public static int getDisIntoData(Object obj) {
		if (obj != "" && !"".equals(obj)) {
			return (int) round(Double.valueOf(obj.toString()) * 10000 / 100f, 0);
		} else {
			return 0;
		}
	}

	/***
	 * 乘以x
	 * 
	 * @param obj
	 * @return
	 */
	public static int getDisIntoData2(Object obj, String x) {
		if (obj != "" && !"".equals(obj)) {
			return (int) (Double.valueOf(obj.toString()) * Integer.valueOf(x));
		} else {
			return 0;
		}
	}

	/**
	 * 扣率除以10000
	 * 
	 * @param obj
	 * @return
	 */
	public static double getChuIntoData(Object obj, String num) {
		if (obj != "" && !"".equals(obj)) {
			return Double.valueOf(obj.toString()) / Double.valueOf(num);
		} else {
			return 0;
		}
	}

	/***
	 * 百分比的处理
	 * 
	 * @param discount
	 * @return
	 */
	public static String getPercentage(Object obj) {
		if (obj != null && !"".equals(obj)) {
			return Arith.round(Integer.valueOf(Integer.valueOf(obj.toString()) * 100) / 10000f, 2) + "";
		} else {
			return "-";
		}
	}

	/***
	 * 百分比的处理
	 * 
	 * @param discount
	 * @return
	 */
	public static String getPercentage3(Object obj) {
		if (obj != null && !"".equals(obj)) {
			return Arith.round(Integer.valueOf(Integer.valueOf(obj.toString()) * 100) / 100000f, 3) + "";
		} else {
			return "-";
		}
	}

	/***
	 * 百分比的处理
	 * 
	 * @param discount
	 * @return
	 */
	public static String getPercentage4(Object obj) {
		if (obj != null && !"".equals(obj)) {
			return Arith.round(Integer.valueOf(Integer.valueOf(obj.toString()) * 100) / 100000f, 3) + "%";
		} else {
			return "-";
		}
	}

	/***
	 * 百分比的处理
	 * 
	 * @param discount
	 * @return
	 */
	public static String getPercentage2(Object obj) {
		if (obj != null && !"".equals(obj)) {
			return Arith.round(Integer.valueOf(Integer.valueOf(obj.toString()) * 100) / 10000f, 2) + "%";
		} else {
			return "-";
		}
	}

	/***
	 * 百分比的处理
	 * 
	 * @param discount
	 * @return
	 */
	public static String getPercentage5(Object obj) {
		if (obj != null && !"".equals(obj)) {
			return (Double.valueOf(Double.valueOf(obj.toString()) * 100) / 10000f) + "%";
		} else {
			return "-";
		}
	}

	/***
	 * 金额处理
	 * 
	 * @param money
	 * @return
	 */
	public static String getMoneyFormat(Object money) {
		if (money != null && !"".equals(money)) {
			double realityMoneyDou = Arith.div(Long.valueOf(money.toString()), 100);
			return "￥" + new DecimalFormat("##,##0.00").format(realityMoneyDou);
		} else {
			return "-";
		}
	}

	public static String getMoneyFormat2(Object money) {
		if (money != null && !"".equals(money)) {
			double realityMoneyDou = Arith.div(Long.valueOf(money.toString()), 100);
			String moneyStr = new DecimalFormat("##,##0.00").format(realityMoneyDou);
			if (moneyStr.contains(",")) {
				moneyStr = moneyStr.replace(",", "");
			}
			return moneyStr;
		} else {
			return "-";
		}

	}

	/***
	 * 没得标记的金额处理
	 * 
	 * @param money
	 * @return
	 */
	public static String getMoneyFormatBySign(Object money) {
		if (money != null && !"".equals(money)) {
			double realityMoneyDou = Arith.div(Long.valueOf(money.toString()), 100);
			return new DecimalFormat("##,##0.00").format(realityMoneyDou);
		} else {
			return "---";
		}
	}

	/***
	 * 没得标记的金额处理[支付网站处理]
	 * 
	 * @param money
	 * @return
	 */
	public static String getMoney(Object money) {
		if (money != null && !"".equals(money)) {
			double realityMoneyDou = Arith.div(Long.valueOf(money.toString()), 100);
			return "￥" + new DecimalFormat("##,##0").format(realityMoneyDou);
		} else {
			return "---";
		}
	}

	/***
	 * 没得标记的金额处理[支付网站处理]
	 * 
	 * @param money
	 * @return
	 */
	public static String getMoney2(Object money) {
		if (money != null && !"".equals(money)) {
			double realityMoneyDou = Arith.div(Long.valueOf(money.toString()), 100f);
			return "￥" + new DecimalFormat("##,##0.00").format(realityMoneyDou);
		} else {
			return "---";
		}
	}
	
	/***
	 * 没得标记的金额处理[支付网站处理]
	 * 
	 * @param money
	 * @return
	 */
	public static String getMoney2_New(Object money) {
		if (money != null && !"".equals(money)) {
			double realityMoneyDou = Arith.div(Long.valueOf(money.toString()), 100f);
			return new DecimalFormat("##,##0.00").format(realityMoneyDou);
		} else {
			return "---";
		}
	}
	
	/***
	 * 没得标记的金额处理[支付网站处理]
	 * 
	 * @param money
	 * @return
	 */
	public static String getMoney3(Object money) {
		if (money != null && !"".equals(money)) {
			return "￥" + new DecimalFormat("##,##0.00").format(money);
		} else {
			return "---";
		}
	}
	
	/***
	 * 没得标记的金额处理[支付网站处理]
	 * 
	 * @param money
	 * @return
	 */
	public static String getMoney4(Object money) {
		if (money != null && !"".equals(money)) {
			double realityMoneyDou = Arith.div(Double.valueOf(money.toString()), 100f);
			return "￥" + new DecimalFormat("##,##0.00").format(realityMoneyDou);
		} else {
			return "---";
		}
	}
	
	/***
	 * 没得标记的金额处理[支付网站处理]
	 * 
	 * @param money
	 * @return
	 */
	public static String getMoney4_New(Object money) {
		if (money != null && !"".equals(money)) {
			double realityMoneyDou = Arith.div(Double.valueOf(money.toString()), 100f);
			return new DecimalFormat("##,##0.00").format(realityMoneyDou);
		} else {
			return "---";
		}
	}

	/**
	 * 除以100的整数
	 * 
	 * @param obj
	 * @return
	 */
	public static int getDivByhundred(Object obj) {
		if (obj != null && !"".equals(obj)) {
			return (int) div(Double.valueOf(obj.toString()), 100, 0);
		} else {
			return 0;
		}
	}

	/***
	 * 负数字符串的修改
	 * 
	 * @param val
	 * @return
	 */
	public static int getIntLostVal(String val) {
		String valMsg = val.substring(val.indexOf("-") + 1, val.length());
		return (int) Arith.mul(Double.valueOf(valMsg), 100);
	}

	/***
	 * 正数字符的修改
	 * 
	 * @param val
	 * @return
	 */
	public static int getIntVal(Object val) {
		return (int) Arith.mul(Double.valueOf(val.toString()), 100);
	}

	public static int getIntVal2(Object val) {
		return (int) Arith.mul(Double.valueOf(val.toString()), 10000);
	}

	public static long getLongVal(Object val) {
		return (long) Arith.mul(Double.valueOf(val.toString()), 100);
	}

	/**
	 * 提供精确的加法运算。
	 * 
	 * @param v1被加数
	 * @param v2加数
	 * @return 两个参数的和
	 */

	public static float add(float v1, float v2) {
		BigDecimal b1 = new BigDecimal(Float.toString(v1));
		BigDecimal b2 = new BigDecimal(Float.toString(v2));
		return b1.add(b2).floatValue();
	}

	/**
	 * 提供精确的减法运算。
	 * 
	 * @param v1被减数
	 * @param v2减数
	 * @return 两个参数的差
	 */

	public static float sub(float v1, float v2) {
		BigDecimal b1 = new BigDecimal(Float.toString(v1));
		BigDecimal b2 = new BigDecimal(Float.toString(v2));
		return b1.subtract(b2).floatValue();
	}

	/**
	 * 提供精确的乘法运算。
	 * 
	 * @param v1被乘数
	 * @param v2
	 *            乘数
	 * @return 两个参数的积
	 */

	public static float mul(float v1, float v2) {
		BigDecimal b1 = new BigDecimal(Float.toString(v1));
		BigDecimal b2 = new BigDecimal(Float.toString(v2));
		return b1.multiply(b2).floatValue();
	}

	/**
	 * 提供精确的乘法运算。
	 * 
	 * @param v1被乘数
	 * @param v2
	 *            乘数
	 * @return 两个参数的积
	 */

	public static double mul(double v1, double v2) {
		BigDecimal b1 = new BigDecimal(Double.toString(v1));
		BigDecimal b2 = new BigDecimal(Double.toString(v2));
		return b1.multiply(b2).doubleValue();
	}

	/**
	 * 提供（相对）精确的除法运算，当发生除不尽的情况时，精确到 小数点以后10位，以后的数字四舍五入。
	 * 
	 * @param v1被除数
	 * @param v2除数
	 * @return 两个参数的商
	 */

	public static double div(double v1, double v2) {
		return div(v1, v2, DEF_DIV_SCALE);
	}

	/**
	 * 结算折扣
	 * 
	 * @param v1
	 * @param v2
	 * @return
	 */
	public static double divDiscount(double v1, double v2) {
		return div(v1, v2, 4);
	}

	/**
	 * 提供（相对）精确的除法运算。当发生除不尽的情况时，由scale参数指 定精度，以后的数字四舍五入。
	 * 
	 * @param v1被除数
	 * @param v2除数
	 * @param scale表示表示需要精确到小数点以后几位
	 *            。
	 * @return 两个参数的商
	 */

	public static double div(double v1, double v2, int scale) {
		if (scale < 0) {
			throw new IllegalArgumentException("The   scale   must   be   a   positive   integer   or   zero");
		}
		BigDecimal b1 = new BigDecimal(Double.toString(v1));
		BigDecimal b2 = new BigDecimal(Double.toString(v2));
		return b1.divide(b2, scale, BigDecimal.ROUND_HALF_UP).doubleValue();
	}

	/**
	 * 提供精确的小数位四舍五入处理。
	 * 
	 * @param v
	 *            需要四舍五入的数字
	 * @param scale小数点后保留几位
	 * @return 四舍五入后的结果
	 */

	public static double round(double v, int scale) {
		if (scale < 0) {
			throw new IllegalArgumentException("The   scale   must   be   a   positive   integer   or   zero");
		}
		BigDecimal b = new BigDecimal(Double.toString(v));
		BigDecimal one = new BigDecimal("1");
		return b.divide(one, scale, BigDecimal.ROUND_HALF_UP).doubleValue();
	}

	/**
	 * 比较两个数的大小
	 * @param str1
	 * @param str2
	 * @return str1 >= str2 ? true : false
	 * @throws Exception
	 */
	public static boolean compare(String str1, String str2) throws Exception{
		double i1 = Double.parseDouble(str1);
		double i2 = Double.parseDouble(str2);
		return i1 >= i2 ? true : false;
	}
	
	/**
	 * 比较两个数的大小
	 * @param str1
	 * @param str2
	 * @return str1 > str2 ? true : false
	 * @throws Exception
	 */
	public static boolean compare2(String str1, String str2) throws Exception{
		double i1 = Double.parseDouble(str1);
		double i2 = Double.parseDouble(str2);
		return i1 > i2 ? true : false;
	}
	
	/**
	 * 数据小数点右偏移
	 * @param size 偏移位数
	 */
	public static String movePointRight(String value, int size){
		BigDecimal big=new BigDecimal(value).movePointRight(size);
		return big.toString();
	}
	
	/**
	 * 数据小数点左偏移
	 * @param size 偏移位数
	 */
	public static String movePointLeft(String value, int size){
		BigDecimal big=new BigDecimal(value).movePointLeft(size);
		return big.toString();
	}
	
	public static void main(String[] args) {
		/*
		 * long a = 4653123134234234l;
		 * 
		 * 
		 * double b = 100;
		 * 
		 * log.info(a);
		 * 
		 * 
		 * 
		 * log.info(Arith.div(a, b));
		 */
		String aString = "1.21";
		@SuppressWarnings("unused")
		int a = getDisIntoData2(aString, "10000");
		System.out.println(Arith.div(1350, 100f));
		System.out.println(getMoney2("1350"));

	}
};