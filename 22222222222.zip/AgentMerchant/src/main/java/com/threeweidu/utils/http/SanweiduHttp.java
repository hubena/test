package com.threeweidu.utils.http;

import java.util.List;

import org.apache.commons.httpclient.NameValuePair;

import com.threeweidu.pepos.util.CodeSetting;
import com.threeweidu.pepos.valueadded.service.HttpProtocolHandler;

/**  
 * 版权所有(C)2012
 * 公司名称：三维度
 * 公司地址：深圳市南山区科苑北路科兴科学园B1栋15楼整层
 * 网址:  www.3weidu.com
 * 版本:  1.0
 * 文件名：  SanweiduHttp.java
 * 文件描述:
 * 作者:   HuangBo
 * 创建时间：
 * 负责人：
 * 修改者：  
 * 修改时间：
 */
public class SanweiduHttp extends HttpProtocolHandler {

	private static String reqUrl = "http://192.168.1.8:80";

	private SanweiduHttp() {
		if ("1002".equals(CodeSetting.SCP_ENVIRONMENT)) {
			if ("1002".equals(CodeSetting.IS_ONLIEN_TEST)) {
				reqUrl = "http://" + CodeSetting.NLB_INTERFACE_IP + ":8320"; // 正式环境负载均衡地址127.0.0.1:8320
			} else if ("1003".equals(CodeSetting.IS_ONLIEN_TEST)) {
				reqUrl = "http://" + CodeSetting.ONLINE_TEST_IP_213 + ":8320"; // 线上测试环境
			} else if ("1001".equals(CodeSetting.IS_ONLIEN_TEST)) {
				reqUrl = "http://" + CodeSetting.ONLINE_TEST_IP_163 + ":8320"; // 模拟上线
			}
		}
	}

	public static SanweiduHttp getInstance() {
		return Instance.instance;
	}

	private static class Instance {
		private static SanweiduHttp instance = new SanweiduHttp();
	}

	public String[] sanweiduHttp(String url, List<NameValuePair> data) {
		return sendData(reqUrl + url, data);
	}

	public String[] customHttp(String url, List<NameValuePair> data) {
		return sendData(url, data);
	}
	
}
