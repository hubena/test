package com.threeweidu.utils;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.UUID;

import org.apache.log4j.Logger;

import com.threeweidu.pepos.upyun.CustFileBucketToYun;
import com.threeweidu.pepos.upyun.UploadImageToYun;

/**  
 * 版权所有(C)2012
 * 公司名称：三维度
 * 公司地址：深圳市南山区科苑北路科兴科学园B1栋15楼整层
 * 网址:  www.3weidu.com
 * 版本:  1.0
 * 文件名：  POIExcelUtil.java
 * 文件描述: 文件操作工具类
 * 作者:   HuangBo
 * 创建时间:
 * 负责人:  
 * 修改者：  
 * 修改时间:
 */
public class FileUtil {
	
	private static Logger log = Logger.getLogger(FileUtil.class.getName());

	private FileUtil() {

	}

	public static FileUtil getInstance() {
		return Instance.instance;
	}

	private static class Instance {
		private static FileUtil instance = new FileUtil();
	}

	/**
	 * 上传视频到云
	 * @param videoPath
	 * @return
	 */
	public String uploadVideoToYun(String videoPath) {
		String typeVideo = null;
		try {
			String[] video = CustFileBucketToYun.writeFile(videoPath);
			if("1001".equals(video[0])){
				log.info("上传视频成功!");
				for (String string : video) {
					log.info(string);
					typeVideo=string;
				}
				// 删除服务器中原来的图片
				File delfile = null;
				if (videoPath != null && !"".equals(videoPath)) {
					delfile = new File(videoPath);
				}
				if (delfile != null && delfile.exists()) {
					if (delfile.delete()) {
						log.info("本地视频删除成功！");
					} else {
						log.info("本地视频删除失败！");
					}
				}
			}else if("1002".equals(video[0])){
				log.info("上传视频失败!");
				return null;
			}
		} catch (IOException e) {
			e.printStackTrace();
			try {
				SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return typeVideo;
	}
	
	/**
	 * 上传图片到云
	 * @param imgPath
	 * @param fileType：1011("/goods/")，1012("/category/")，1013("/ad/")，1014("/head/")，1015("/sanad/")，1016("/appad/")，1022("/cust/")，1031("/life/")
	 * @return
	 */
	public String uploadImageToYun(String imgPath, String fileType) {
		String typeImg = null;
		String []img =UploadImageToYun.uploadFile(imgPath, fileType);
		if("1001".equals(img[0])){
			log.info("上传图片成功!");
			for (String string : img) {
				log.info(string);
				typeImg=string;
			}
			// 删除服务器中原来的图片
			File delfile = null;
			if (imgPath != null && !"".equals(imgPath)) {
				delfile = new File(imgPath);
			}
			if (delfile != null && delfile.exists()) {
				if (delfile.delete()) {
					log.info("本地图片删除成功！");
				} else {
					log.info("本地图片删除失败！");
				}
			}
		}else if("1002".equals(img[0])){
			log.info("上传图片失败!");
			return null;
		}
		return typeImg;
	}
	

	/**
	 * 判断文件夹目录是否存在，不存在则创建
	 * @param folderPath
	 */
	public void checkFolderPathIsExists(String folderPath) {
		File file = new File(folderPath);
		if (!file.exists() && !file.isDirectory()) {
			file.mkdir();
		}
	}
	
	/**
	 * 改名
	 */
	@SuppressWarnings("unused")
	private String updateNameUUID(String oldname) {
		String newName = null;
		UUID uuid = UUID.randomUUID();
		String lastname = oldname.substring(oldname.lastIndexOf("."));
		newName = uuid.toString() + lastname;
		return newName;
	}
	
	/**
	 * 获取文件名字
	 * @param clz
	 * @param page
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public String getFileName(Class clz, Integer page) {
		if (page == null) {
			return //"3WEIDU_" + clz.getSimpleName().toUpperCase() + "_" + 
		new java.text.SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
		}
		return //"3WEIDU_" + clz.getSimpleName().toUpperCase() + "_" + 
		new java.text.SimpleDateFormat("yyyyMMddhhmmss").format(new Date()) + "_" + page;
	}
	
}
