package com.threeweidu.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 版权所有(C)2012 
 * 公司名称：三维度 公司
 * 地址：深圳市南山区科苑北路科兴科学园B1栋15楼整层 
 * 网址: www.3weidu.com 
 * 版本: 1.0 
 * 文件名： ValidateUtils.java
 * 文件描述:
 * 作者: ZhangXiaohui 
 * 创建时间:2016-1-7下午4:52:15 
 * 负责人: 
 * 修改者：ZhangXiaohui
 * 修改时间：2016-1-7下午4:52:15 
 */
public class ValidateUtils {
	
	//校验邮箱是否正确
	public static boolean checkEmail(String email){
      boolean flag = false;
      try{
		String check = "^([a-z0-9A-Z]+[-|\\.]?)+[a-z0-9A-Z]@([a-z0-9A-Z]+(-[a-z0-9A-Z]+)?\\.)+[a-zA-Z]{2,}$";
		Pattern regex = Pattern.compile(check);
		Matcher matcher = regex.matcher(email);
		flag = matcher.matches();
      }catch(Exception e){
    	flag = false;
      }
       
      	return flag;
	}
	//验证手机号码
	public static boolean phoneNumber(String number){
		String rgx = "^((13[0-9])|(15[^4,\\D])|(18[0,5-9]))\\d{8}$";
		return isCorrect(rgx, number);
	}
	public static boolean isCorrect(String rgx, String res)
	  {
	    Pattern p = Pattern.compile(rgx);
	    
	    Matcher m = p.matcher(res);
	    
	    return m.matches();
	  }
	
	/*
	 * 校验是否为中文
	 */
	public static boolean checkChinese(String str){
	    boolean flag = false;
		String check = "[\u4e00-\u9fa5]"; //匹配中文
		Pattern regex = Pattern.compile(check);
		Matcher matcher = regex.matcher(str);
		if (!matcher.find()) {
			flag = true;
		};
      	return flag;
	}
	
	/**
	 * checkIP(ipString)
	 */
	public static boolean checkIP(String ipString){
		String regex = "^(\\d{1,2}|1\\d\\d|2[0-4]\\d|25[0-5])\\.(\\d{1,2}|1\\d\\d|2[0-4]\\d|25[0-5])\\.(\\d{1,2}|1\\d\\d|2[0-4]\\d|25[0-5])\\.(\\d{1,2}|1\\d\\d|2[0-4]\\d|25[0-5])$";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(ipString);
		return matcher.matches();
	}
}
