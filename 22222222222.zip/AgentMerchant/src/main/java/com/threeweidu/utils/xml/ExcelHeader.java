package com.threeweidu.utils.xml;

/**  
 * 版权所有(C)2012
 * 公司名称：三维度
 * 公司地址：深圳市平哥有限公司
 * 网址:  www.hyp.com
 * 版本:  1.0
 * 文件名：com.hyp.util.ExcelHeader.java 
 * 文件描述： 得到标题信息
 * 作者:   HuYaping
 * 创建时间: 2013-1-6下午08:58:51  
 * 负责人: 
 * 部门:   
 * 修改者：  
 * 修改时间：2013-1-6下午08:58:51  
 */
public class ExcelHeader implements Comparable<ExcelHeader> {
	private String title;
	private int order;
	private String methodName;

	public ExcelHeader() {
	}

	public ExcelHeader(String title, int order, String methodName) {
		this.title = title;
		this.order = order;
		this.methodName = methodName;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getOrder() {
		return order;
	}

	public void setOrder(int order) {
		this.order = order;
	}

	public String getMethodName() {
		return methodName;
	}

	public void setMethodName(String methodName) {
		this.methodName = methodName;
	}

	/***
	 * 1：顺着排序，-1倒序 0：表示一样
	 */
	public int compareTo(ExcelHeader o) {
		return order > o.order ? 1 : (order < o.order ? -1 : 0);
	}

	@Override
	public String toString() {
		return "ExcelHeader [methodName=" + methodName + ", order=" + order + ", title=" + title + "]";
	}

}
