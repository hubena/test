package com.threeweidu.utils.mybatis;

import java.util.Properties;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;

import com.threeweidu.pepos.util.CodeSetting;

public class PropertyUtils extends PropertyPlaceholderConfigurer {
	
	@SuppressWarnings("unused")
	@Override
	protected void processProperties(ConfigurableListableBeanFactory beanFactoryToProcess, Properties props) throws BeansException {
		String peposIp = null;
		String shopIp = null;
		String peposadminIp = null;
		String peposlogIp = null;
		String peposchatIp = null;
		String pepossignIp = null;
		String chestsIp = null;
		String gameIp = null;
		String shakeIp = null;
		String vaserviceIp = null;
		String paymentIp = null;
		String syncshopIp = null;
		String port = null;
		if ("1002".equals(CodeSetting.SCP_ENVIRONMENT)) {
			if ("1002".equals(CodeSetting.IS_ONLIEN_TEST)) {
				port = "1433";
				peposIp = "192.168.10.16";
				shopIp = "192.168.10.16";
				peposadminIp = "192.168.10.16";
				peposlogIp = "192.168.10.16";
				peposchatIp = "192.168.10.16";
				pepossignIp = "192.168.10.16";
				chestsIp = "192.168.10.16";
				gameIp = "192.168.10.16";
				shakeIp = "192.168.10.16";
				vaserviceIp = "192.168.10.16";
				paymentIp = "192.168.10.16";
			} else if ("1003".equals(CodeSetting.IS_ONLIEN_TEST)) {// 新审核测试
				port = "1433";
				peposIp = "120.55.76.101";
				shopIp = "120.55.76.101";
				peposadminIp = "120.55.76.101";
				peposlogIp = "120.55.76.101";
				peposchatIp = "120.55.76.101";
				pepossignIp = "120.55.76.101";
				chestsIp = "120.55.76.101";
				gameIp = "120.55.76.101";
				shakeIp = "120.55.76.101";
				vaserviceIp = "120.55.76.101";
				paymentIp = "120.55.76.101";
			} else {// 新163测试
				port = "1433";
				peposIp = "121.40.123.163";
				shopIp = "121.40.123.163";
				peposadminIp = "121.40.123.163";
				peposlogIp = "121.40.123.163";
				peposchatIp = "121.40.123.163";
				pepossignIp = "121.40.123.163";
				chestsIp = "121.40.123.163";
				gameIp = "121.40.123.163";
				shakeIp = "121.40.123.163";
				vaserviceIp = "121.40.123.163";
				paymentIp = "121.40.123.163";
				syncshopIp = "lshopdate.sqlserver.rds.aliyuncs.com";
			}
		} else if ("1002".equals(CodeSetting.IS_ONLIEN_TEST)) {
			port = "1433";
			peposIp = "192.168.1.189";
			shopIp = "192.168.1.189";
			peposadminIp = "192.168.1.189";
			peposlogIp = "192.168.1.189";
			peposchatIp = "192.168.1.189";
			pepossignIp = "192.168.1.189";
			chestsIp = "192.168.1.189";
			gameIp = "192.168.1.189";
			shakeIp = "192.168.1.189";
			vaserviceIp = "192.168.1.189";
			paymentIp = "192.168.1.189";
		} else {
			port = "1433";
			peposIp = "192.168.1.181";
			shopIp = "192.168.1.181";
			peposadminIp = "192.168.1.181";
			peposlogIp = "192.168.1.181";
			peposchatIp = "192.168.1.181";
			pepossignIp = "192.168.1.181";
			chestsIp = "192.168.1.181";
			gameIp = "192.168.1.181";
			shakeIp = "192.168.1.181";
			vaserviceIp = "192.168.1.181";
			paymentIp = "192.168.1.181";
			syncshopIp = "192.168.1.189";
		}

		if (("1002".equals(CodeSetting.SCP_ENVIRONMENT)) && ("1002".equals(CodeSetting.IS_ONLIEN_TEST))) {
			props.put("pepos.url", "jdbc:sqlserver://192.168.10.16;databaseName=pepos");
			props.put("pepos.username", "peposweb");
			props.put("pepos.password", "bdCRFKv5IqiYjplTMtNNSZsckU3VhKez23bPovVfbdxppfI8hZyOg1NujzK3hDpWRGiZE46QKX3YPcBoz9GAQw==");
			props.put("pepos.publickey", "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBALclJDtRDfcd0gjiuNv0DmegP+rqTgq0As/M8hU+Gh/dfmEpI3G0Ix8FBxaHv+a3J6ru6rpAoasRvULrhVO0OlECAwEAAQ==");

			props.put("shop.url", "jdbc:sqlserver://192.168.10.16;databaseName=shop");
			props.put("shop.username", "shopweb");
			props.put("shop.password", "hubL5cMufynm8Wv1lUP7YxHxZXsGxO9KQaec8FmF2iFDSY/21S2DtfYbNX6Fpb4bw/2AfFi0LlVNPeGIUDWNkw==");
			props.put("shop.publickey", "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAI+VI1gKeiQzN9f+klASxcVLc7JqH2WfRJcgTr5lD+vMTqiav7vHQ9hO9WoLE3hUm/sjyYIkwCjMdaWE4ArhFxkCAwEAAQ==");

			props.put("peposlog.url", "jdbc:sqlserver://192.168.10.16;databaseName=peposlog");
			props.put("peposlog.username", "peposlogweb");
			props.put("peposlog.password", "uS7ACpibht8e7AkguNTtipMpFu7MkyRz9mBoRM8+/QmFEiy2+vx9EYU4Z4I7RV5qV2CL0cxqeAuCznheS8dWpg==");
			props.put("peposlog.publickey", "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAMfqtBraoLJWEetDBLHyYOPj3QY/yKDCpbuHnIfbPLmju22bt2n/aNQfqQPGZ85/SuPUdsbmGDqrX//Rzn4VqyECAwEAAQ==");

			props.put("peposadmin.url", "jdbc:sqlserver://192.168.10.16;databaseName=peposadmin");
			props.put("peposadmin.username", "peposadminweb");
			props.put("peposadmin.password", "ZIHkIXJfXt/MZZnHIYr+1kz3KLC+UVpDq/ydrM/XDlyczWEOWxWN96/S1Q5AmNuk3ANjV0aCt0twyNOJF79M6g==");
			props.put("peposadmin.publickey", "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAKMuLLRH/IatdkfAQrbRGzuqymyWsz3Tro5bjtOpuax4hQhleOJHVaJYkO2iQOrWllvqXo8wgYDaOsLsUkseAAECAwEAAQ==");

			props.put("peposchat.url", "jdbc:sqlserver://192.168.10.16;databaseName=peposchat");
			props.put("peposchat.username", "peposchatweb");
			props.put("peposchat.password", "iWCuE7uT7y7N0gLK+9IlgwBy8OTeqA3WZaAqkYR3Zn14qmPdnRnUpAbL5Uf5X/cn6oGOZzuCPgysIDRyGLHlaw==");
			props.put("peposchat.publickey", "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBALNtAucG9tXuSybTt1baMess4H+VdITnXhEG65aS+dipBOlpqfuFgIU1ReyfEtsmFM5Mz1zq+d4jumo8sD0h+dcCAwEAAQ==");

			props.put("pepossign.url", "jdbc:sqlserver://192.168.10.16;databaseName=pepossign");
			props.put("pepossign.username", "pepossignweb");
			props.put("pepossign.password", ":MPQyv/9dMUsOACnylaM0YOqCvfGKcNA8NiBNoijnlUnSFXXA/Y0XM7rjPS4e7iKf8wyFHKFmu6go1znx4BXvoA==");
			props.put("pepossign.publickey", "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAJbUBLsf47CgopHs5MHL8kzKdl7kRVoPHyQVm6s6ELd7eMxOysfBdYEjvGz2KFGvMbF7SK2LCC2QoDBc9A5ocysCAwEAAQ==");

			props.put("chests.url", "jdbc:sqlserver://192.168.10.16;databaseName=chests");
			props.put("chests.username", "chestsweb");
			props.put("chests.password", "Ev6erWY0s6ba3/kA924MvscPjZDVT+M+5zkOppjCytZHD/lN2/a+XJf1Uol6MokRWF1lo2E+mlX1+KXrjbXpRA==");
			props.put("chests.publickey", "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAMIvSDECRWtSPFPbsVIZAGa+GnqflLNkSIAKJrkkPfR4i3BQbfP4pyOYI46syqscbTGbRp1l0JfngY0WUvbzIHUCAwEAAQ==");

			props.put("shake.url", "jdbc:sqlserver://192.168.10.16;databaseName=shake");
			props.put("shake.username", "shakeweb");
			props.put("shake.password", "MTXYPfrSXPKdSwIm3aa4EKvFOAqbQ4S+B7RCquKYPQb80VWFT2UbTbhKkdpvkoI6B0n4ROqqOC5TsaAi9Gpx0w==");
			props.put("shake.publickey", "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAISlbtYFFHtRDoOporQdiCpEzC6mPYLLHCLWjW3WNBzx9Ui6rwOROXbYaUd05Rga8cE04xNJ8mWf18pTeiw6EH0CAwEAAQ==");

			props.put("game.url", "jdbc:sqlserver://192.168.10.16;databaseName=game");
			props.put("game.username", "gameweb");
			props.put("game.password", "EcfNsdMH5oHtkMtHln2cFnhlNkw7Ss2WfQpcYtQmQba6vmbxPb7uqdoUK2CrZE6lFExwCTBw62wwT8Wnj9wR+w==");
			props.put("game.publickey", "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAMEJuiEckyIIKo6si4+V5t3hBpNDUFRH/rzwS9we06ij9umWPnXql7PPf5aJ8/KemmA4Dq6mNnNPQGkL9fhq9+8CAwEAAQ==");

			props.put("vaservice.url", "jdbc:sqlserver://192.168.10.16;databaseName=vaservice");
			props.put("vaservice.username", "vaserviceweb");
			props.put("vaservice.password", "Gm3AIz00OVncJYHyBPZRZdWBs+cZOdPY6LFViKAfKymPFfWarBJDK5O/3DiWhr4CUSBcVX7AV2JbabAI/ui2uA==");
			props.put("vaservice.publickey", "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAITQqCEVNIpR3ZGFUVU7VqjLDqPcxPOflFWKRIgfVSdS461JOmHupJimm56NZdEfjBW8QiO4t7W4DYd5zwXsGHcCAwEAAQ==");

			props.put("payment.url", "jdbc:sqlserver://192.168.10.16;databaseName=payment");
			props.put("payment.username", "paymentweb");
			props.put("payment.password", "kcb10Nd/ab266lGUD1xD+RrYMxW3/AyJHZd2uE7i36QudC1n3cBTTcX2W8e/8VwMXJEhA5Svx8C4FAd01ewyZg==");
			props.put("payment.publickey", "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAKRx1grrJHwAhX18c4GFWRTpHV+lNizO579tz8inn2GdJ/+I2NoKsKL3q1nLT3y79brfY9vxThDVL/eoCgF74AcCAwEAAQ==");

		} else {
			props.put("pepos.url", "jdbc:sqlserver://" + peposIp + ":" + port + ";databaseName=pepos");
			props.put("pepos.username", "PEposJavaUser");
			props.put("pepos.password", "ucUwtj5vRHvqwqpROQ2Zirmj5ZPIWzEKC1tKHqstZADgbcoSANsBv8IPK4KI9hFoJ/a1p2W312bGF7Jl1c3ZpQ==");
			props.put("pepos.publickey", "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBANYVIwr4dR3GwLZ5e8a9o9KtDe1K7VS0xLZ34NrQqGuodlf1jOuRv/RB1ze9j6BUyPwoHvAg7KLsCe8iPIPNIXcCAwEAAQ==");

			props.put("shop.url", "jdbc:sqlserver://" + shopIp + ":" + port + ";databaseName=shop");
			props.put("shop.username", "PEposJavaUser");
			props.put("shop.password", "ucUwtj5vRHvqwqpROQ2Zirmj5ZPIWzEKC1tKHqstZADgbcoSANsBv8IPK4KI9hFoJ/a1p2W312bGF7Jl1c3ZpQ==");
			props.put("shop.publickey", "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBANYVIwr4dR3GwLZ5e8a9o9KtDe1K7VS0xLZ34NrQqGuodlf1jOuRv/RB1ze9j6BUyPwoHvAg7KLsCe8iPIPNIXcCAwEAAQ==");

			props.put("peposlog.url", "jdbc:sqlserver://" + peposlogIp + ":" + port + ";databaseName=peposlog");
			props.put("peposlog.username", "PEposJavaUser");
			props.put("peposlog.password", "ucUwtj5vRHvqwqpROQ2Zirmj5ZPIWzEKC1tKHqstZADgbcoSANsBv8IPK4KI9hFoJ/a1p2W312bGF7Jl1c3ZpQ==");
			props.put("peposlog.publickey", "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBANYVIwr4dR3GwLZ5e8a9o9KtDe1K7VS0xLZ34NrQqGuodlf1jOuRv/RB1ze9j6BUyPwoHvAg7KLsCe8iPIPNIXcCAwEAAQ==");

			props.put("peposadmin.url", "jdbc:sqlserver://" + peposadminIp + ":" + port + ";databaseName=peposadmin");
			props.put("peposadmin.username", "PEposJavaUser");
			props.put("peposadmin.password", "ucUwtj5vRHvqwqpROQ2Zirmj5ZPIWzEKC1tKHqstZADgbcoSANsBv8IPK4KI9hFoJ/a1p2W312bGF7Jl1c3ZpQ==");
			props.put("peposadmin.publickey", "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBANYVIwr4dR3GwLZ5e8a9o9KtDe1K7VS0xLZ34NrQqGuodlf1jOuRv/RB1ze9j6BUyPwoHvAg7KLsCe8iPIPNIXcCAwEAAQ==");

			props.put("peposchat.url", "jdbc:sqlserver://" + peposchatIp + ":" + port + ";databaseName=peposchat");
			props.put("peposchat.username", "PEposJavaUser");
			props.put("peposchat.password", "ucUwtj5vRHvqwqpROQ2Zirmj5ZPIWzEKC1tKHqstZADgbcoSANsBv8IPK4KI9hFoJ/a1p2W312bGF7Jl1c3ZpQ==");
			props.put("peposchat.publickey", "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBANYVIwr4dR3GwLZ5e8a9o9KtDe1K7VS0xLZ34NrQqGuodlf1jOuRv/RB1ze9j6BUyPwoHvAg7KLsCe8iPIPNIXcCAwEAAQ==");

			props.put("pepossign.url", "jdbc:sqlserver://" + pepossignIp + ":" + port + ";databaseName=pepossign");
			props.put("pepossign.username", "PEposJavaUser");
			props.put("pepossign.password", "ucUwtj5vRHvqwqpROQ2Zirmj5ZPIWzEKC1tKHqstZADgbcoSANsBv8IPK4KI9hFoJ/a1p2W312bGF7Jl1c3ZpQ==");
			props.put("pepossign.publickey", "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBANYVIwr4dR3GwLZ5e8a9o9KtDe1K7VS0xLZ34NrQqGuodlf1jOuRv/RB1ze9j6BUyPwoHvAg7KLsCe8iPIPNIXcCAwEAAQ==");

			props.put("chests.url", "jdbc:sqlserver://" + chestsIp + ":" + port + ";databaseName=chests");
			props.put("chests.username", "PEposJavaUser");
			props.put("chests.password", "ucUwtj5vRHvqwqpROQ2Zirmj5ZPIWzEKC1tKHqstZADgbcoSANsBv8IPK4KI9hFoJ/a1p2W312bGF7Jl1c3ZpQ==");
			props.put("chests.publickey", "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBANYVIwr4dR3GwLZ5e8a9o9KtDe1K7VS0xLZ34NrQqGuodlf1jOuRv/RB1ze9j6BUyPwoHvAg7KLsCe8iPIPNIXcCAwEAAQ==");

			props.put("shake.url", "jdbc:sqlserver://" + shakeIp + ":" + port + ";databaseName=shake");
			props.put("shake.username", "PEposJavaUser");
			props.put("shake.password", "ucUwtj5vRHvqwqpROQ2Zirmj5ZPIWzEKC1tKHqstZADgbcoSANsBv8IPK4KI9hFoJ/a1p2W312bGF7Jl1c3ZpQ==");
			props.put("shake.publickey", "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBANYVIwr4dR3GwLZ5e8a9o9KtDe1K7VS0xLZ34NrQqGuodlf1jOuRv/RB1ze9j6BUyPwoHvAg7KLsCe8iPIPNIXcCAwEAAQ==");

			props.put("game.url", "jdbc:sqlserver://" + gameIp + ":" + port + ";databaseName=game");
			props.put("game.username", "PEposJavaUser");
			props.put("game.password", "ucUwtj5vRHvqwqpROQ2Zirmj5ZPIWzEKC1tKHqstZADgbcoSANsBv8IPK4KI9hFoJ/a1p2W312bGF7Jl1c3ZpQ==");
			props.put("game.publickey", "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBANYVIwr4dR3GwLZ5e8a9o9KtDe1K7VS0xLZ34NrQqGuodlf1jOuRv/RB1ze9j6BUyPwoHvAg7KLsCe8iPIPNIXcCAwEAAQ==");

			props.put("vaservice.url", "jdbc:sqlserver://" + vaserviceIp + ":" + port + ";databaseName=vaservice");
			props.put("vaservice.username", "PEposJavaUser");
			props.put("vaservice.password", "ucUwtj5vRHvqwqpROQ2Zirmj5ZPIWzEKC1tKHqstZADgbcoSANsBv8IPK4KI9hFoJ/a1p2W312bGF7Jl1c3ZpQ==");
			props.put("vaservice.publickey", "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBANYVIwr4dR3GwLZ5e8a9o9KtDe1K7VS0xLZ34NrQqGuodlf1jOuRv/RB1ze9j6BUyPwoHvAg7KLsCe8iPIPNIXcCAwEAAQ==");

			props.put("payment.url", "jdbc:sqlserver://" + paymentIp + ":" + port + ";databaseName=payment");
			props.put("payment.username", "PEposJavaUser");
			props.put("payment.password", "ucUwtj5vRHvqwqpROQ2Zirmj5ZPIWzEKC1tKHqstZADgbcoSANsBv8IPK4KI9hFoJ/a1p2W312bGF7Jl1c3ZpQ==");
			props.put("payment.publickey", "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBANYVIwr4dR3GwLZ5e8a9o9KtDe1K7VS0xLZ34NrQqGuodlf1jOuRv/RB1ze9j6BUyPwoHvAg7KLsCe8iPIPNIXcCAwEAAQ==");
		}
		super.processProperties(beanFactoryToProcess, props);
	}

}
