package com.threeweidu.utils.mybatis;

import java.util.Map;

import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;

public class DynamicDataSource extends AbstractRoutingDataSource {

	// 查找当前用户上下文变量中设置的数据源
	protected Object determineCurrentLookupKey() {
		return DBContextHolder.getDBType();
	}

	// 设置默认的数据源
	public void setDefaultTargetDataSource(Object defaultTargetDataSource) {
		super.setDefaultTargetDataSource(defaultTargetDataSource);
	}

	// 设置数据源集合.
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void setTargetDataSources(Map targetDataSources) {
		super.setTargetDataSources(targetDataSources);
	}
}
