package com.threeweidu.utils;

import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.threeweidu.entity.utils.LoginUser;
import com.threeweidu.pepos.util.MD5;

public class APIKeyUtils {	
	private APIKeyUtils(){}
	public static APIKeyUtils getInstance() {
		return Instance.instance;
	}
	private static class Instance {
		private static APIKeyUtils instance = new APIKeyUtils();
	}
	private Map<String, LoginUser> map = new HashMap<String, LoginUser>();//apikey-loginUser对应集合
	
	/**
	 * 获取value
	 */
	public LoginUser getData(String apikey){
		return map.get(apikey);
	}
	
	/**
	 * 保存key-value
	 */
	public String setData(LoginUser data){		
		String key = getAPIKey(data);
		if(key!=null){
//			key = map.put(generateAPIKey(data), data);
//			removeData(key);
		}
		key = generateAPIKey(data);
		add(key, data);
		return key;				
	}
	/**
	 * 添加APIKey
	 */
	public LoginUser add(String key, LoginUser data){
		synchronized(map){
			return map.put(key, data);
		}
	}
	
	/**
	 * 判断此apikey是否存在
	 * @param apikey
	 * @return
	 */
	public boolean checkAPIKey(String apikey){
		LoginUser value = getData(apikey);
		if(value!=null){
			return true;
		}
		return false;
	}
	
	/**
	 * 生成APIKey
	 */
	private static String generateAPIKey(LoginUser data){
		int num = (int) (Math.random() * 99999 - 9999);
		String apiKey = toString(data) + getTime() +  num;
		String rsaKeyDec = MD5.MD5Encode(apiKey);
		return rsaKeyDec;
	}
	
	/**
	 * 获取APIKey
	 */
	private String getAPIKey(LoginUser data){
		Collection<String> collection = map.keySet();
		Iterator<String> iterator = collection.iterator();
		while(iterator.hasNext()){
			String key = iterator.next();
			LoginUser value = getData(key);
			if(value!=null && value.equals(data)){
				return key;
			}
		}
		return null;
	}
	/**
	 * 删除apikey
	 * @param apikey
	 */
	public void removeData(String apikey) {
		if(checkAPIKey(apikey)){
			synchronized (map) {
				map.remove(apikey);
			}
		}
	}
	
	/**
	 * toString
	 * @return
	 */
	private static String toString(Object data){
		if(data==null){
			return "";
		} else if(data instanceof Collection<?> && ((Collection<?>)data).isEmpty()){
			return "";
		}
		return data.toString();
	}
	
	/**
	 * 获取当前时间
	 * @return
	 */
	private static long getTime(){
		return new Date().getTime();
	}
	
	
}
