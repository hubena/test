package com.threeweidu.utils;

import java.io.Serializable;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.threeweidu.pepos.dao.AbstractDaoSupport;
import com.threeweidu.pepos.util.ConnectionUtil.FieldsDB;

/**  
 * 版权所有(C)2012
 * 公司名称：三维度
 * 公司地址：深圳市南山区长虹科技大厦2512
 * 网址:  www.3weidu.com
 * 版本:  1.0
 * 文件名：  OderIdGenerator.java
 * 文件描述:
 * 作者:   HuangBo
 * 创建时间:2014-12-19下午4:30:27
 * 负责人:  
 * 修改者：  
 * 修改时间:2014-12-19下午4:30:27
 */
public class OrderIdGenerator {
	
	public static String NOTPRODUCT = "1001";   //这个是本地的配置，方便获取验证码测试，不能提交到SVN及上生产环境
	private static Logger log = Logger.getLogger(OrderIdGenerator.class.getName());

	private static Map<Order, Long> datas = new HashMap<Order, Long>();

	private String serIp;

	private OrderIdGenerator() {
		init();
	}
	
	/**
	 * 初始化方法，清空全部重新开始
	 */
	private void init() {
		String ip = "";
		String port = "";
		try {
			InetAddress addr = InetAddress.getLocalHost();
			ip = addr.getHostAddress().toString();// 获得本机IP

			String path = this.getClass().getResource("").getPath().toLowerCase();
			int start = path.indexOf("tomcat") + 6;
			int end = path.indexOf("/webapps");
			if (start >= 0 && end >= 0) {
				port = path.substring(start, end);// 当前服务端口
				if (isNumeric(port)) {
					log.info("当前服务IP地址:" + ip + "，当前服务器目录配置的端口号:" + port);
					OnlineServerDao onlineServerDao = new OnlineServerDao();
					onlineServerDao.setDataBaseType(FieldsDB.THREEWEIDU_PEPOS_BUSINESS);
					List<Object[]> list = onlineServerDao.getMsg("ADMIN_ONLINESERVER_GETSERIDBYIPANDPORT_SELECT", new Object[] { ip, port }, 1);
					if (list != null && list.size() != 0) {
						serIp = list.get(0)[0].toString();
						log.info("初始化服务器编号成功，当前服务器编号serIp:" + serIp);
					}
				} else {
					log.info("Tomcat目录配置不符合规范，获得当前服务器目录配置的端口号失败");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			try {
				SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		} finally {
			if (serIp == null || "".equals(serIp)) {
				serIp = String.valueOf((int) (Math.random() * (9999 - 2000)) + 2000);
				log.info("初始化服务器编号失败，随机生成当前服务器编号serIp:" + serIp);
				/**
				if ("1002".equals(CodeSetting.SCP_ENVIRONMENT) && "1002".equals(CodeSetting.IS_ONLIEN_TEST)) {
					// 发送短信
					boolean res = SendSmsUtil.getInstance().sendSms("86","15602313398", "尊敬的三维度管理员用户，您正在进行启动服务器" + ip + ":" + port + "加载服务器编号（当前随机生成的编号为：" + serIp + "）操作，本次操作结果是失败的。");
					if (!res) {
						log.info("信息发送失败");
					} else {
						log.info("信息发送成功");
					}
				}
				**/
			}
		}
	}

	/**
	 * 重置自增标量
	 */
	public void reset() {
		datas.clear();
	}

	public synchronized String getOrderId(Order consumType, int length) {
		Calendar calendar = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");
		String time = sdf.format(calendar.getTime());
		String before = time.substring(2, 14);
		if (serIp == null || "".equals(serIp)) {
			throw new RuntimeException("The parameter serIp is empty");
		} else if ((before.length() + serIp.length()) >= length) {
			throw new RuntimeException("The length of orderId must be greater than " + (before.length() + serIp.length()));
		} else if (length > 30) {
			throw new RuntimeException("The length of orderId not greater than 30");
		}
		int afterLength = length - before.length() - serIp.length();
		Long in = datas.get(consumType);
		if (in == null) {
			in = 0l;
		} else {
			in++;
			if (in > getMaxValue(afterLength)) {
				in = 0l;
			}
		}
		datas.put(consumType, in);
		in = datas.get(consumType);
		return before + serIp + getAfterString(afterLength, in);
	}

	public String getAfterString(int length, Long numCount) {
		StringBuffer after = new StringBuffer();
		String numCountStr = String.valueOf(numCount);
		length = length - numCountStr.length();
		for (int i = 0; i < length; i++) {
			after.append("0");
		}
		return after.toString() + numCountStr;
	}

	private long getMaxValue(int length) {
		StringBuffer after = new StringBuffer();
		for (int i = 0; i < length; i++) {
			after.append("9");
		}
		return Long.parseLong(after.toString());
	}

	private boolean isNumeric(String str) {
		Pattern pattern = Pattern.compile("[0-9]*");
		return pattern.matcher(str).matches();
	}

	public String getMACAddr() throws Exception {
		StringBuffer mac = new StringBuffer();
		// 获得ＩＰ
		NetworkInterface netInterface = NetworkInterface.getByInetAddress(InetAddress.getLocalHost());
		// 获得Mac地址的byte数组
		byte[] macAddr = netInterface.getHardwareAddress();
		// 循环输出
		for (int i = 0; i < macAddr.length; i++) {
			byte b = macAddr[i];
			if (i == macAddr.length - 1) {
				mac.append(toHexString(b));
			} else {
				mac.append(toHexString(b) + "-");
			}
		}
		return mac.toString();
	}

	private String toHexString(int integer) {
		// 将得来的int类型数字转化为十六进制数
		String str = Integer.toHexString((int) (integer & 0xff));
		// 如果遇到单字符，前置0占位补满两格
		if (str.length() == 1) {
			str = "0" + str;
		}
		return str.toUpperCase();
	}

	public static OrderIdGenerator getInstance() {
		return Instance.instance;
	}

	private static class Instance {
		private static OrderIdGenerator instance = new OrderIdGenerator();
	}

	public String getSerIp() {
		return serIp;
	}

	public void setSerIp(String serIp) {
		this.serIp = serIp;
	}

	public class OnlineServerDao extends AbstractDaoSupport<Object[]> implements Serializable {

		private static final long serialVersionUID = 1L;

		@Override
		protected Object[] limitRowMapper(ResultSet arg0, Integer arg1) throws Exception {
			return null;
		}

		@Override
		protected Object[] rowMapper(ResultSet arg0) throws Exception {
			return null;
		}

		public List<Object[]> getMsg(String callName, Object[] args, int fieldCount) throws Exception {
			return this.getCustFieldObjectList(callName, args, fieldCount);
		}
	}
	
	public static enum Order {
		SHOPCHANGEID(1001), //
		SHOPBALANCEINCOME(1002), // 充值宝
		AUDITACCOUNT(1003), // 对账
		AUDITSTATISTICS(1004), // 统计
		AUDITTRANSFER(1005), // 转账
		AUDITTRANSFED(1006), // 推送
		ACTIVITYCHESTBADGE(1007), // 活动宝箱徽章
		MERAPPLYID(1008), // 无卡支付明细转账订单号
		QUICKPAYMENTLIQUIDATE(1009); // 无卡支付对账清算明细订单号

		private int value;

		private Order(int value) {
			this.value = value;
		}

		@Override
		public String toString() {
			return String.valueOf(value);
		}
	}
	
}
