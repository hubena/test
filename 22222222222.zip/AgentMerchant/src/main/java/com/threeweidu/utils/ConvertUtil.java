package com.threeweidu.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 版权所有(C)2012 
 * 公司名称：三维度 
 * 公司地址：深圳市福田区中国凤凰大厦2栋20A 
 * 网址: www.3weidu.com 版本: 1.0
 * 文件名：com.threeweidu.pepos.util.ConvertUtil.java
 * 文件描述：时间与字符串的转换，判断是否是数字还是字符串，随机数的生成 
 * 作者: HuYaping 
 * 创建时间: 2012-7-20上午10:04:27
 * 负责人: 
 * 修改者： 
 * 修改时间：2012-7-20上午10:04:27
 */
public class ConvertUtil {
	private static String[] RANDOM_VALUES = new String[] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" };
	private static int CHECK_LENGTH = 6;

	/**
	 * 
	 * 随机生成6为手机短息效检码
	 * 
	 * @param length
	 * @return
	 */
	public synchronized static String createRandom() {
		StringBuffer str = new StringBuffer();
		for (int i = 0; i < CHECK_LENGTH; i++) {
			Double number = Math.random() * (RANDOM_VALUES.length - 1);
			str.append(RANDOM_VALUES[number.intValue()]);
		}
		return str.toString();
	}

	/**
	 * 比较时间相差多少秒数
	 * 
	 * @param dateString
	 * @return
	 * @throws ParseException
	 */
	public static long calLastedTime(String dateString) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date startDate = sdf.parse(dateString);
		long a = new Date().getTime();
		long b = startDate.getTime();
		long c = (a - b) / 1000;
		return c;
	}

}
