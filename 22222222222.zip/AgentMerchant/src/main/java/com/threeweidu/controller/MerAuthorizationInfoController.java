package com.threeweidu.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.threeweidu.entity.MerAuthorization;
import com.threeweidu.entity.MerKeyInfo;
import com.threeweidu.entity.Merchant;
import com.threeweidu.entity.PaymentWay;
import com.threeweidu.service.MerAuthorizationInfoService;
import com.threeweidu.service.MerchantManageService;
import com.threeweidu.utils.Null2;
import com.threeweidu.utils.SystemExceptionUtil;
import com.threeweidu.utils.mybatis.DBContextHolder;
import com.threeweidu.view.req.page.Page;
import com.threeweidu.view.result.EasyUIData;
import com.threeweidu.view.result.JsonResult;

@Controller
@RequestMapping(value = "/merchant/merAuthorizationInfo")
public class MerAuthorizationInfoController extends BaseController {
	
	@Autowired
	private MerAuthorizationInfoService merAuthorizationInfoService;	
	@Autowired
	private MerchantManageService merchantService;

	/**
	 * 支付方式组合条件分页查询
	 */
	@RequestMapping(value = "/findAllPayWay")
	public void findAllPayWay(
			@RequestParam(required = true, value = "page", defaultValue = "1") Long pageNo, 
			@RequestParam(required = true, value = "rows", defaultValue = "10") Long pageSize, 
			@RequestParam(required = true, value = "sort", defaultValue = "addTime") String sortField, 
			@RequestParam(required = true, value = "order", defaultValue = "asc") String sortType, 
			HttpServletRequest request, HttpServletResponse response,
			PaymentWay paymentWay) {
		EasyUIData uiData = null;
		Page page = new Page(pageNo, pageSize, sortField, sortType);
		try {
			String agentId = getAgentId(request);
			if (Null2.isNull(agentId)) {
				uiData = new EasyUIData(false, "代理商编号不能为空", 0L, Collections.EMPTY_LIST);
				return;
			}
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_SHOP);
			Merchant merchant = merchantService.findMerchantByMerId(paymentWay.getMerId());
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_PAYMENT);
			paymentWay.setAgentId(agentId);
			uiData = merAuthorizationInfoService.findAllPayWay(page, paymentWay, merchant);
		} catch (Exception e) {
			e.printStackTrace();
			SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			uiData = new EasyUIData(false, "查询异常,请联系管理员", 0L, Collections.EMPTY_LIST);
		}
		super.outJson(response, uiData);
	}	
	
	/**
	 * 支付方式组合条件分页查询
	 */
	@RequestMapping(value = "/findAllAgentPayWay")
	public void findAllAgentPayWay(
			@RequestParam(required = true, value = "page", defaultValue = "1") Long pageNo, 
			@RequestParam(required = true, value = "rows", defaultValue = "10") Long pageSize, 
			@RequestParam(required = true, value = "sort", defaultValue = "updateTime") String sortField, 
			@RequestParam(required = true, value = "order", defaultValue = "asc") String sortType, 
			HttpServletRequest request, HttpServletResponse response,
			PaymentWay paymentWay) {
		EasyUIData uiData = null;
		Page page = new Page(pageNo, pageSize, sortField, sortType);
		try {
			String agentId = getAgentId(request);
			if (Null2.isNull(agentId)) {
				uiData = new EasyUIData(false, "代理商编号不能为空", 0L, Collections.EMPTY_LIST);
				return;
			}
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_PAYMENT);
			uiData = merAuthorizationInfoService.findAllAgentPayWay(page, agentId);
		} catch (Exception e) {
			e.printStackTrace();
			SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			uiData = new EasyUIData(false, "查询异常,请联系管理员", 0L, Collections.EMPTY_LIST);
		}
		super.outJson(response, uiData);
	}	
	
	/**
	 * 商户授权支付方式
	 */
	@RequestMapping(value = "/addMerAuthorization")
	public void addMerAuthorization(HttpServletRequest request, HttpServletResponse response, MerAuthorization merAuthorization) {
		JsonResult result = null;
		try {
			// 设置连接的库
			
			String agentId = getAgentId(request);
			if (Null2.isNull(agentId)) {
				result = new JsonResult(false, "代理商编号不能为空");
				return;
			}
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_SHOP);
			Merchant merchant = merchantService.findMerchantByMerId(merAuthorization.getMerId());
			if(Null2.isNotNull(merchant)){
				merAuthorization.setIsRealPay(merchant.getIsRealPay());
			}
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_PAYMENT);
			merAuthorization.setAgentId(agentId);
			result = merAuthorizationInfoService.addMerAuthorization(merAuthorization);
		} catch (Exception e) {
			e.printStackTrace();
			SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			result = new JsonResult(false, "发生异常");
		}
		super.outJson(response, result);
	}
	
	/**
	 * 商户取消授权支付方式
	 */
	@RequestMapping(value = "/deleteMerAuthorization")
	public void deleteMerAuthorization(HttpServletRequest request, HttpServletResponse response, MerAuthorization merAuthorization) {
		JsonResult result = null;
		try {
			// 设置连接的库
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_PAYMENT);
			List<MerAuthorization> merAuthorizations=new ArrayList<MerAuthorization>();
			if(Null2.isNull(merAuthorization)){
				result = new JsonResult(false, "数据异常");
				return;
			}
			String paymentId=merAuthorization.getPaymentId();
			String paymentIds[]=paymentId.split(",");
			for(String pId:paymentIds){
				MerAuthorization merAuth=new MerAuthorization();
				merAuth.setMerId(merAuthorization.getMerId());
				merAuth.setPaymentId(pId);
				merAuthorizations.add(merAuth);
			}
			result = merAuthorizationInfoService.deleteMerAuthorization(merAuthorizations);
		} catch (Exception e) {
			e.printStackTrace();
			SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			result = new JsonResult(false, "发生异常");
		}finally{
			super.outJson(response, result);
		}
		
	}
	
	/**
	 * 添加商户微信支付信息
	 */
	@RequestMapping(value = "/addMerKeyInfo")
	public void addMerKeyInfo(HttpServletRequest request, HttpServletResponse response, MerKeyInfo merKeyInfo) {
		JsonResult result = null;
		try {
			if (StringUtils.isEmpty(merKeyInfo.getMerId())) {
				result = new JsonResult(false, "商户编号不能为空");
				return;
			}
			// 设置连接的库
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_PAYMENT);
			result = merAuthorizationInfoService.addMerKeyInfo(merKeyInfo);
		} catch (Exception e) {
			e.printStackTrace();
			SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			result = new JsonResult(false, "发生异常");
		} finally {
			super.outJson(response, result);
		}
	}
	
	/**
	 * 确定修改商户授权扣率
	 */
	@RequestMapping(value = "/confirmToAddUpdateDeductionRate")
	public void confirmToAddUpdateDeductionRate(HttpServletRequest request, HttpServletResponse response, MerAuthorization merAuthorization) {
		JsonResult result = null;
		try {
			if(Null2.isNull(merAuthorization)){
				result = new JsonResult(false, "数据异常");
				return;
			}
			if(Null2.isNull(merAuthorization.getDeductionRate())){
				result = new JsonResult(false, "扣率不能为空");
				return;
			}
			String agentId = getAgentId(request);
			if (Null2.isNull(agentId)) {
				result = new JsonResult(false, "代理商编号不能为空");
				return;
			}
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_SHOP);
			Merchant merchant = merchantService.findMerchantByMerId(merAuthorization.getMerId());
			if(Null2.isNotNull(merchant)){
				merAuthorization.setIsRealPay(merchant.getIsRealPay());
			}
			// 设置连接的库
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_PAYMENT);
			merAuthorization.setAgentId(agentId);
			result = merAuthorizationInfoService.updateDeductionRate(merAuthorization);
		} catch (Exception e) {
			e.printStackTrace();
			SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			result = new JsonResult(false, "发生异常");
		}finally{
			super.outJson(response, result);
		}
		
	}
	
}