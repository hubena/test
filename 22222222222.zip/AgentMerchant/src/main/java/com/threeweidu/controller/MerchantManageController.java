package com.threeweidu.controller;

import java.util.Collections;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.sanweidu.jniPassword.JniPassword;
import com.threeweidu.config.DefaultProfile;
import com.threeweidu.entity.Agent;
import com.threeweidu.entity.Merchant;
import com.threeweidu.pepos.security.EncryptMoney;
import com.threeweidu.service.AgentService;
import com.threeweidu.service.MerchantManageService;
import com.threeweidu.utils.Arith;
import com.threeweidu.utils.Null2;
import com.threeweidu.utils.SystemExceptionUtil;
import com.threeweidu.utils.mybatis.DBContextHolder;
import com.threeweidu.view.req.page.Page;
import com.threeweidu.view.result.EasyUIData;
import com.threeweidu.view.result.JsonResult;


/**
 * 商户管理控制台
 * 公司名称：三维度
 * 公司地址：深圳市南山区科苑北路科兴科学园B1栋15楼整层
 * 网址:  www.3weidu.com
 */
@Controller
@RequestMapping(value = "/merchant/merchantManage")
public class MerchantManageController extends BaseController {

	@Autowired
	private MerchantManageService merchantService;
	@Autowired
	private AgentService agentService;

	@RequestMapping(value = "/list")
	public String list(HttpServletRequest request, HttpServletResponse response) {
		return "merchant/merchantManage";
	}

	/**
	 * 商户信息(分页查询）
	 * 
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "/findAll")
	public void findAll(
			@RequestParam(required = true, value = "page", defaultValue = "1") Long pageNo, 
			@RequestParam(required = true, value = "rows", defaultValue = "10") Long pageSize, 
			@RequestParam(required = true, value = "sort", defaultValue = "m.merId") String sortField, 
			@RequestParam(required = true, value = "order", defaultValue = "desc") String sortType, 
			HttpServletRequest request, HttpServletResponse response) {
		EasyUIData uiData = null;
		Page page = new Page(pageNo, pageSize, sortField, sortType);
		try {
			String agentId = getAgentId(request);
			if (Null2.isNull(agentId)) {
				uiData = new EasyUIData(false, "代理商编号不能为空", 0L, Collections.EMPTY_LIST);
				return;
			}
			setPageInfo(request, page, agentId);
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_SHOP);
			uiData = merchantService.queryEasyUIData(page);
		} catch (Exception e) {
			e.printStackTrace();
			SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			uiData = new EasyUIData(false, "查询异常,请联系管理员", 0L, Collections.EMPTY_LIST);
		}finally{
			super.outJson(response, uiData);
		}
	}

	private void setPageInfo(HttpServletRequest request, Page page, String agentId) {
		String merId = request.getParameter("merId");
		String merName = request.getParameter("merName");
		StringBuffer sb = new StringBuffer();
		sb.append("1=1 ");
		String tableField = "Merchant m "
				+ " left join AgentMerchant ag on m.merId = ag.merId "
				+ " left join SecSWDAgent ssa on ag.secAgentId = ssa.secAgentId";
		String merIds = super.getMerIdsByOrder(request);
		String where = "";
		if(Null2.isNotNull(merIds)){
			where = "and m.merid in (" + merIds +") ";
		}
//		String where = " and m.merid in(" +
//				"	select  m.merid as 'merId' from  Merchant m ,AgentMerchant am where m.fatherMerId=am.merId and am.agentId="+agentId+
//				" union " +
//				" select merId as 'merId' from AgentMerchant where agentId="+agentId+
//				") ";
		sb.append(where);
		String valueField = "m.merId,m.merName,m.fatherMerId,m.useState,m.remark,ssa.secAgentAccount,ssa.secAgentName";
		if (Null2.isNotNull(merId)) {
			sb.append(" and m.merId='" + merId + "'");
		}
		if (Null2.isNotNull(merName)) {
			sb.append(" and m.merName like '%" + merName + "%'");
		}
		page.setTableField(tableField);
		page.setValueField(valueField);
		page.setWhereField(sb.toString());
	}

	/**
	 * 修改商户充值和提现扣率、手续费
	 */
	@RequestMapping(value = "/updateMerchantRate")
	public void updateMerchantRate(HttpServletRequest request, HttpServletResponse response, Merchant merchant) {
		JsonResult result = null;
		String agentId = getAgentId(request);
		if (Null2.isNull(agentId)) {
			result = new JsonResult(false, "代理商编号不能为空");
			return;
		}
		try {
			if (Null2.isNull(merchant.getMerId())) {
				result = new JsonResult(false, "请选择要修改的商户");
				return;
			}
			if (Null2.isNull(merchant.getWithdrawFeeType())) {
				result = new JsonResult(false, "提现扣费模式不能为空");
				return;
			}
			if (Null2.isNull(merchant.getWithdrawFeeTypeValue())) {
				result = new JsonResult(false, "提现扣费金额不能为空");
				return;
			} else {
				try {
					Double.parseDouble(merchant.getWithdrawFeeTypeValue());
				} catch (Exception e) {
					result = new JsonResult(false, "提现封顶手续费填入太大");
					return;
				}
			}
			if(!("1001".equals(merchant.getIsRealPay()) || "1002".equals(merchant.getIsRealPay()))){
				result = new JsonResult(false, "请选择到账方式");
				return;
			}
			if(!("1001".equals(merchant.getIsRealRecharge()) || "1002".equals(merchant.getIsRealRecharge()))){
				result = new JsonResult(false, "请选择充值到账方式");
				return;
			}
			if ("1001".equals(merchant.getWithdrawFeeType())) {
				if (Null2.isNull(merchant.getWithdrawMaxfee())) {
					result = new JsonResult(false, "提现封顶手续费不能为空");
					return;
				}
			} else if ("1002".equals(merchant.getWithdrawFeeType())) {
				merchant.setWithdrawMaxfee("0");
			}

//			if (Null2.isNull(merchant.getRechargeFeeType())) {
//				result = new JsonResult(false, "充值扣费模式不能为空");
//				return;
//			}
//			if (Null2.isNull(merchant.getRechargeFeeTypeValue())) {
//				result = new JsonResult(false, "充值扣费金额不能为空");
//				return;
//			}
//			if ("1001".equals(merchant.getRechargeFeeType())) {
//				if (Null2.isNull(merchant.getRechargeMaxFee())) {
//					result = new JsonResult(false, "提现封顶手续费不能为空");
//					return;
//				}
//			} else if ("1002".equals(merchant.getRechargeMaxFee())) {
//				merchant.setWithdrawMaxfee("0");
//			}
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_PAYMENT);
			Agent agent = agentService.getAgentByAgentid(agentId);
			result = checkMerchant(agent, merchant);
			if(!result.getSuccess()){
				return;
			}
			merchant.setAgentId(agentId);
			result = merchantService.checkIsRealPay(merchant);
			if(!result.getSuccess()){
				return;
			}
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_SHOP);
			result = merchantService.updateMerchantRate(merchant);
		} catch (Exception e) {
			e.printStackTrace();
			SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			result = new JsonResult(false, "服务器异常");
		} finally {
			super.outJson(response, result);
		}
	}
	
	/**
	 * 与成本相比较
	 */
	private JsonResult checkMerchant(Agent agent, Merchant merchant) {
		try {
			if("1001".equals(merchant.getWithdrawFeeType())){
				if(!Arith.compare(merchant.getWithdrawFeeTypeValue(), agent.getWithdrawDiscountFee())){
					return new JsonResult(false, "提现扣率模式费率不可小于成本值！");
				}
				if(!Arith.compare(merchant.getWithdrawMaxfee(), agent.getWithdrawDiscountMaxFee())){
					return new JsonResult(false, "提现扣率模式封顶手续费不可小于成本值！");
				}
			} else if("1002".equals(merchant.getWithdrawFeeType())){
				if(!Arith.compare(merchant.getWithdrawFeeTypeValue(), agent.getWithdrawFixedFee())){
					return new JsonResult(false, "提现固定模式单笔手续费不可小于成本值！");
				}
			}
//			if("1001".equals(merchant.getRechargeFeeType())){
//				if(!Arith.compare(merchant.getRechargeFeeTypeValue(), agent.getRechargeDiscountFee())){
//					return new JsonResult(false, "充值扣率模式费率不可小于成本值！");
//				}
//				if(!Arith.compare(merchant.getRechargeMaxFee(), agent.getRechargeDiscountMaxFee())){
//					return new JsonResult(false, "充值扣率模式封顶手续费不可小于成本值！");
//				}
//			} else if("1002".equals(merchant.getRechargeFeeType())){
//				if(!Arith.compare(merchant.getRechargeFeeTypeValue(), agent.getRechargeFixedFee())){
//					return new JsonResult(false, "充值固定模式单笔手续费不可小于成本值！");
//				}
//			}
		} catch (Exception e) {
			return new JsonResult(false, "输入数据格式有误！");
		}
		return new JsonResult(true, "检验成功！");
	}

	/**
	 * 修改邮箱
	 * 
	 * @author HuangBo
	 * @createTime 2016-10-06
	 * @return void
	 */
	@RequestMapping(value = "/updateEmail")
	public void updateEmail(HttpServletRequest request, HttpServletResponse response, Merchant merchant) {
		JsonResult result = null;
		try {
			if (Null2.isNull(merchant.getSupplierId())) {
				result = new JsonResult(false, "请选择要修改的用户");
				return;
			}
			if (Null2.isNull(merchant.getEmail())) {
				result = new JsonResult(false, "邮箱不能为空");
				return;
			}
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_SHOP);
			result = merchantService.updateEmail(merchant);
		} catch (Exception e) {
			e.printStackTrace();
			SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			result = new JsonResult(false, "服务器异常");
		} finally {
			super.outJson(response, result);
		}
	}
	
	/**
	 * 修改手机号
	 */
	@RequestMapping(value = "/updatePhone")
	public void updatePhone(HttpServletRequest request, HttpServletResponse response, Merchant merchant) {
		JsonResult result = null;
		try {
			if (Null2.isNull(merchant.getSupplierId())) {
				result = new JsonResult(false, "请选择要修改的用户");
				return;
			}
			if (Null2.isNull(merchant.getSuppliePhone())) {
				result = new JsonResult(false, "手机号不能为空");
				return;
			}
			if (Null2.isNull(merchant.getPayPasswd())) {
				result = new JsonResult(false, "支付密码不能为空");
				return;
			}
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_PAYMENT);
			if(!checkPayPasswd(super.getAgentId(request), merchant.getPayPasswd())){
				result = new JsonResult(false, "支付密码错误");
				return;
			}
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_SHOP);
			result = merchantService.updatePhone(merchant);
		} catch (Exception e) {
			e.printStackTrace();
			SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			result = new JsonResult(false, "服务器异常");
		} finally {
			super.outJson(response, result);
		}
	}
	
	/**
	 * 判断代理商支付密码是否正确
	 */
	private boolean checkPayPasswd(String agentId, String payPasswd) {
		return agentService.checkPayPasswd(agentId, payPasswd);
	}

	/**
	 * 查询该商户的用户信息
	 * 
	 * @author XuPing
	 * @createTime 2016-9-30上午11:02:38
	 * @return void
	 */
	@RequestMapping(value = "/findMerchantUser")
	public void findMerchantUser(
			@RequestParam(required = true, value = "page", defaultValue = "1") Long pageNo, 
			@RequestParam(required = true, value = "rows", defaultValue = "10") Long pageSize, 
			@RequestParam(required = true, value = "sort", defaultValue = "gs.supplierId") String sortField, 
			@RequestParam(required = true, value = "order", defaultValue = "desc") String sortType, 
			HttpServletRequest request, HttpServletResponse response) {
		EasyUIData uiData = null;
		Page page = new Page(pageNo, pageSize, sortField, sortType);
		try {
			String merId = request.getParameter("merId");
			if (Null2.isNull(merId)) {
				uiData = new EasyUIData(false, "商户编号不能为空", 0L, Collections.EMPTY_LIST);
				return;
			}
			setUserPageInfo(request, page);
			uiData = merchantService.findMerchantUser(page);
		} catch (Exception e) {
			e.printStackTrace();
			SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			uiData = new EasyUIData(false, "查询异常,请联系管理员", 0L, Collections.EMPTY_LIST);
		} finally {
			super.outJson(response, uiData);
		}
	}

	private void setUserPageInfo(HttpServletRequest request, Page page) {
		String merId = request.getParameter("merId");
		String supplierId = request.getParameter("supplierId");
		String supplieName = request.getParameter("supplieName");
		StringBuffer sb = new StringBuffer();
		sb.append("1=1 and gs.fatherSupplierId='" + merId + "'");
		String tableField = "GoodsSupplier gs left join SupplierCashTransferFee sctf on sctf.supplierId=gs.supplierId";
		String valueField="gs.supplierId,gs.supplieName,gs.email,sctf.withdrawFeeType,sctf.withdrawFeeTypeValue,sctf.withdrawMaxfee," +
			"sctf.rechargeFeeType,sctf.rechargeFeeTypeValue,sctf.rechargeMaxFee,gs.accountBalance," +
			"gs.abCheckCode,gs.abTableKey,sctf.isRealPay";
		if (Null2.isNotNull(supplierId)) {
			sb.append(" and gs.supplierId = '" + supplierId + "'");
		}
		if (Null2.isNotNull(supplieName)) {
			sb.append(" and gs.supplieName like '%" + supplieName + "%'");
		}
		page.setTableField(tableField);
		page.setValueField(valueField);
		page.setWhereField(sb.toString());
	}
	
	/**
	 * 商户解锁功能
	 * @author Zengxb
	 * @createTime 2016-11-23
	 * @return void
	 */
	@RequestMapping(value = "/deblock")
	public void deblock(HttpServletRequest request, HttpServletResponse response){
		JsonResult jsonResult = new JsonResult();
		try {
			String merId = request.getParameter("merId");
			if (Null2.isNull(merId) || Null2.isNull(getAgentId(request))) {
				jsonResult = new JsonResult(false, "代理商编号不能为空");
				return;
			}
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_PAYMENT);
			jsonResult = merchantService.updateUseState(merId);
		} catch (Exception e) {
			e.printStackTrace();
			SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			jsonResult = new JsonResult(false, "查询异常,请联系管理员");
		}finally{
			super.outJson(response, jsonResult);
		}
	}
	
	
	/**
	 * 商户重置登录密码功能
	 * 
	 * @author Zengxb
	 * @createTime 2016-11-23
	 * @return void
	 */
	@RequestMapping(value = "updatePasswd")
	public void updatePasswd(HttpServletRequest request, HttpServletResponse response){
		JsonResult result = null;
		String resetPassWd = DefaultProfile.DEFAULT_RAW_PASSWORD;//重置的密码
		try {
			String supplierId = request.getParameter("supplierId");
			if (Null2.isNull(supplierId)) {
				result = new JsonResult(false, "商户编号为空");
				return;
			}
			
			String payPasswd = request.getParameter("payPasswd");
			if (Null2.isNull(payPasswd)) {
				result = new JsonResult(false, "支付密码不能为空");
				return;
			}
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_PAYMENT);
			if(!checkPayPasswd(super.getAgentId(request), payPasswd)){
				result = new JsonResult(false, "支付密码错误");
				return;
			}
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_SHOP);
			//登录密码重置为“123456”，并加密存入商户表
			String encryptPassWd = toEncrypt(resetPassWd); 
			
			result = merchantService.updatePasswd(supplierId, encryptPassWd);
		} catch (Exception e) {
			e.printStackTrace();
			SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			result = new JsonResult(false, "服务器异常");
		} finally {
			super.outJson(response, result);
		}
		
	}
	
	
	/**
	 * 商户重置支付密码功能
	 * 
	 * @author Zengxb
	 * @createTime 2016-11-23
	 * @return void
	 */
	@RequestMapping(value = "updatePayPasswd")
	public void updatePayPasswd(HttpServletRequest request, HttpServletResponse response){
		JsonResult result = null;
		String resetPayPassWd = DefaultProfile.DEFAULT_RAW_PASSWORD;//重置的密码
		try {
			String supplierId = request.getParameter("supplierId");
			if (Null2.isNull(supplierId)) {
				result = new JsonResult(false, "商户编号为空");
				return;
			}
			
			String payPasswd = request.getParameter("payPasswd");
			if (Null2.isNull(payPasswd)) {
				result = new JsonResult(false, "支付密码不能为空");
				return;
			}
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_PAYMENT);
			if(!checkPayPasswd(super.getAgentId(request), payPasswd)){
				result = new JsonResult(false, "支付密码错误");
				return;
			}
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_SHOP);
			//支付密码重置为“123456”，并加密存入商户表
			String encryptPayPassWd = toEncrypt(resetPayPassWd); 
			
			result = merchantService.updatePayPasswd(supplierId, encryptPayPassWd);
		} catch (Exception e) {
			e.printStackTrace();
			SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			result = new JsonResult(false, "服务器异常");
		} finally {
			super.outJson(response, result);
		}
		
	}
	
	/*
	 * 加密
	 */
	public String toEncrypt(String password){
		JniPassword jniNative = JniPassword.getInstance();
		boolean bLoad = JniPassword.loadLibrary("JniPassword");
		if (bLoad) {
			password = jniNative.getSha512Value(password);
		}
		return password;
	}
	
	/**
	 * 添加商户
	 */
	@RequestMapping(value = "/addMerchant")
	public void addMerchant(HttpServletRequest request, HttpServletResponse response, Merchant merchant) {
		JsonResult result = null;
		try {
			String agentId = getAgentId(request);
			if (Null2.isNull(agentId)) {
				result = new JsonResult(false, "代理商编号不能为空");
				return;
			}
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_PAYMENT);
			merchant.setAgentId(agentId);
			result = merchantService.addMerchant(merchant);
			if(result.getSuccess()){
				registerAddSupplier((Merchant)result.getData());
				result.setData(null);
			}
		} catch (Exception e) {
			e.printStackTrace();
			SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			result = new JsonResult(false, "服务器异常");
		} finally {
			super.outJson(response, result);
		}
	}
	
	/**
	 * 添加商户初始化一些数据
	 */
	private JsonResult registerAddSupplier(Merchant merchant) throws Exception {
		String result[] = EncryptMoney.encyptMoney(0, merchant.getMerId());
		DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_SHOP);
		int n = merchantService.addGoodSupplier(merchant, result);
		//n += merchantService.addSupplierCashTransferFee(merchant);
		DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_PAYMENT);
		n += merchantService.addTerminal(merchant);
		if(n == 2){
			return new JsonResult(true, "初始化成功");
		}
		return new JsonResult(true, "初始化失败");
	}
	
	@RequestMapping(value = "/updateRemark")
	public void updateRemark(HttpServletRequest request, HttpServletResponse response, Merchant merchant) {
		JsonResult result = null;
		try {
			if (Null2.isNull(merchant.getMerId())) {
				result = new JsonResult(false, "请选择要修改的用户");
				return;
			}
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_PAYMENT);
			result = merchantService.updateRemark(merchant);
		} catch (Exception e) {
			e.printStackTrace();
			SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			result = new JsonResult(false, "服务器异常");
		} finally {
			super.outJson(response, result);
		}
	}
	
	@RequestMapping(value = "/loginIPUnwrap")
	public void loginIPUnwrap(HttpServletRequest request, HttpServletResponse response, Merchant merchant) {
		JsonResult result = null;
		try {
			if (Null2.isNull(merchant.getSupplierId())) {
				result = new JsonResult(false, "请选择要修改的用户");
				return;
			}
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_SHOP);
			merchant.setOperateIp(request.getRemoteHost());
			merchant.setAgentId(getAgentId(request));
			result = merchantService.loginIPUnwrap(merchant);
		} catch (Exception e) {
			e.printStackTrace();
			SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			result = new JsonResult(false, "服务器异常");
		} finally {
			super.outJson(response, result);
		}
	}
	
	@RequestMapping(value = "/openTransferReal")
	public void openTransferReal(HttpServletRequest request, HttpServletResponse response, Merchant merchant) {
		JsonResult result = null;
		try {
			if (Null2.isNull(merchant.getSupplierId())) {
				result = new JsonResult(false, "请选择要修改的用户");
				return;
			}
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_SHOP);
			merchant.setTransferRealWhiteList("1002");
			result = merchantService.updateTransferReal(merchant);
		} catch (Exception e) {
			e.printStackTrace();
			SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			result = new JsonResult(false, "服务器异常");
		} finally {
			super.outJson(response, result);
		}
	}
	
	@RequestMapping(value = "/closeTransferReal")
	public void closeTransferReal(HttpServletRequest request, HttpServletResponse response, Merchant merchant) {
		JsonResult result = null;
		try {
			if (Null2.isNull(merchant.getSupplierId())) {
				result = new JsonResult(false, "请选择要修改的用户");
				return;
			}
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_SHOP);
			merchant.setTransferRealWhiteList("1001");
			result = merchantService.updateTransferReal(merchant);
		} catch (Exception e) {
			e.printStackTrace();
			SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			result = new JsonResult(false, "服务器异常");
		} finally {
			super.outJson(response, result);
		}
	}

}