package com.threeweidu.controller;

import java.util.Collections;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.threeweidu.service.SendCodeRecordService;
import com.threeweidu.utils.Null2;
import com.threeweidu.view.req.page.Page;
import com.threeweidu.view.result.EasyUIData;

@Controller
@RequestMapping(value = "/merchant/sendCodeRecord")
public class SendCodeRecordController extends BaseController {

	@Autowired
	private SendCodeRecordService sendCodeRecordService;

	/**
	 * 跳转页面
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/list")
	public String list(HttpServletRequest request, HttpServletResponse response) {
		return "merchant/sendCodeRecord";
	}

	@RequestMapping(value = "/findAll")
	public void findAll(
			@RequestParam(required = true, value = "page", defaultValue = "1") Long pageNo, 
			@RequestParam(required = true, value = "rows", defaultValue = "10") Long pageSize, 
			@RequestParam(required = true, value = "sort", defaultValue = "sendTime") String sortField, 
			@RequestParam(required = true, value = "order", defaultValue = "desc") String sortType, 
			HttpServletRequest request, HttpServletResponse response) {
		EasyUIData uiData = null;
		Page page = new Page(pageNo, pageSize, "s." + sortField, sortType);
		try {
			String agentId = getAgentId(request);
			if (Null2.isNull(agentId)) {
				uiData =  new EasyUIData(false, "代理商编号不能为空", 0L, Collections.EMPTY_LIST);
				return;
			}
			page.setWhereField(buildWhereField(request, getAgentId(request)));
			uiData = sendCodeRecordService.queryEasyUIData(page);
		} catch (Exception e) {
			e.printStackTrace();
			uiData = new EasyUIData(false, "查询异常,请联系管理员", 0L, Collections.EMPTY_LIST);
		}finally{
			super.outJson(response, uiData);
		}
	}
	
	/**
	 * 拼接查询条件
	 * 
	 * @param request
	 * @return
	 */
	private String buildWhereField(HttpServletRequest request, String agentId) {
		StringBuffer sb = new StringBuffer();
		sb.append(" 1=1 and am.agentId='" + agentId + "' ");

		String merId = request.getParameter("merId");
		if (merId != null && merId.length() > 0) {
			sb.append(" and s.merId='" + merId + "' ");
		}

		String sendType = request.getParameter("sendType");
		if (sendType != null && sendType.length() > 0) {
			sb.append(" and s.sendType='" + sendType + "' ");
		}

		String sendAccount = request.getParameter("sendAccount");
		if (sendAccount != null && sendAccount.length() > 0) {
			sb.append(" and s.sendAccount='" + sendAccount + "' ");
		}

		String sendTimeStart = request.getParameter("sendTimeStart");
		String sendTimeEnd = request.getParameter("sendTimeEnd");
		if (sendTimeStart != null && sendTimeStart.length() > 0) {
			sb.append(" and s.sendTime >='" + sendTimeStart + "' ");
		}
		if (sendTimeEnd != null && sendTimeEnd.length() > 0) {
			sb.append(" and s.sendTime <dateadd(dd,1,'" + sendTimeEnd + "')");
		}

		return sb.toString();
	}
}
