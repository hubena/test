package com.threeweidu.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.threeweidu.entity.MerchantTradeCount;
import com.threeweidu.service.MerchantTradeCountService;
import com.threeweidu.utils.Arith;
import com.threeweidu.utils.Null2;
import com.threeweidu.utils.SystemExceptionUtil;
import com.threeweidu.utils.mybatis.DBContextHolder;
import com.threeweidu.view.req.page.Page;
import com.threeweidu.view.result.EasyUIData;


@Controller
@RequestMapping(value="/merchant/merchantTradeCount")
public class MerchantTradeCountController extends BaseController {
	
	@Autowired
	private MerchantTradeCountService merchantTradeCountService;
	
	
	@RequestMapping(value="/list/find")
	@ResponseBody
	public void paymentRecordList(
			@RequestParam(required = true, value = "page", defaultValue = "1") Long pageNo, 
			@RequestParam(required = true, value = "rows", defaultValue = "10") Long pageSize, 
			@RequestParam(required = true, value = "sort", defaultValue = "merId") String sortField, 
			@RequestParam(required = true, value = "order", defaultValue = "desc") String sortType, 
			MerchantTradeCount merchantTradeCount,
			HttpServletRequest request, HttpServletResponse response) {
		EasyUIData uiData = null;
		Page page = new Page(pageNo, pageSize, sortField, sortType);
		try {
			String agentId = getAgentId(request);
			if (Null2.isNull(agentId)) {
				uiData = new EasyUIData(false, "代理商编号不能为空", 0L, Collections.EMPTY_LIST);
				return;
			}
			uiData = checkForDownlod(merchantTradeCount);
			if (!uiData.isSuccess()) {
				return;
			}
			uiData = checkTradeCount(merchantTradeCount);
			if (!uiData.isSuccess()) {
				return;
			}
			merchantTradeCount.setAgentId(agentId);
			merchantTradeCount.setMerIds(super.getMerIdsByOrder(request));
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_PAYMENT);
			uiData = merchantTradeCountService.findList(merchantTradeCount, page);
		} catch (Exception e) {
			e.printStackTrace();
			SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			uiData = new EasyUIData(false, "查询异常,请联系管理员", 0L, Collections.EMPTY_LIST);
		}finally{
			super.outJson(response, uiData);
		}
	}	
	
	
	/*
	 * 判断数据是否合法及准备查询条件
	 */
	private EasyUIData checkForDownlod(MerchantTradeCount merchantTradeCount) {
		EasyUIData uiData = new EasyUIData(true, "");
		String tradedateStart = merchantTradeCount.getTradedateStart();
		String tradedateEnd = merchantTradeCount.getTradedateEnd();
		if (Null2.isNull(tradedateStart) || Null2.isNull(tradedateEnd)) {
			return new EasyUIData(false, "统计日期为必设置项", 0L, Collections.EMPTY_LIST);
		}
		if (!checkDate(tradedateEnd, tradedateStart)) {
			return new EasyUIData(false, "统计日期间隔最大为6个月", 0L, Collections.EMPTY_LIST);
		}
		return uiData;
	}
	
	/*
	 * 判断数据是否合法及准备查询条件
	 */
	private EasyUIData checkTradeCount(MerchantTradeCount merchantTradeCount) {
		EasyUIData uiData = new EasyUIData(true, "");
		String min = merchantTradeCount.getMinTradeCount();
		String max = merchantTradeCount.getMaxTradeCount();
		if (Null2.isNotNull(min) || Null2.isNotNull(max)) {
			try {
				Double minL = null;
				Double maxL = null;
				if(Null2.isNotNull(min)){					
					minL = Double.parseDouble(min);
					if(Null2.isNull(minL) || minL < 0){
						return new EasyUIData(false, "输入的交易总金额不可小于0", 0L, Collections.EMPTY_LIST);
					}
					merchantTradeCount.setMinTradeCount(Arith.movePointRight(min, 2));
				}
				if(Null2.isNotNull(max)){	
					maxL = Double.parseDouble(max);
					if(Null2.isNull(maxL) || maxL < 0){
						return new EasyUIData(false, "输入的交易总金额不可小于0", 0L, Collections.EMPTY_LIST);
					}
					merchantTradeCount.setMaxTradeCount(Arith.movePointRight(max, 2));
				}
				if (Null2.isNotNull(minL) && Null2.isNotNull(maxL)) {
					if(minL > maxL){
						return new EasyUIData(false, "输入的交易总金额区间不正确", 0L, Collections.EMPTY_LIST);
					}
				}
			} catch (NumberFormatException e) {
				return new EasyUIData(false, "输入的交易总金额格式不对", 0L, Collections.EMPTY_LIST);
			}
		}		
		return uiData;
	}
	
	
	private boolean checkDate(String createEndTime, String createStartTime) {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		try {
			Date start = format.parse(createStartTime);
			Date end = format.parse(createEndTime);
			long day = (end.getTime() - start.getTime()) / (1000L * 60L * 60L * 24L);
			if (day > (6 * 31)) {
				return false;
			}
		} catch (ParseException e) {
			return false;
		}
		return true;
	}
}
