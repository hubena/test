package com.threeweidu.controller;

import java.util.Collections;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.codehaus.jackson.type.TypeReference;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.threeweidu.entity.Agent;
import com.threeweidu.entity.AgentIPWhiteRecord;
import com.threeweidu.service.AgentIPWhiteRecordService;
import com.threeweidu.service.AgentService;
import com.threeweidu.supplier.utils.JsonUtils;
import com.threeweidu.utils.Null2;
import com.threeweidu.utils.SystemExceptionUtil;
import com.threeweidu.utils.ValidateUtils;
import com.threeweidu.utils.mybatis.DBContextHolder;
import com.threeweidu.view.req.page.Page;
import com.threeweidu.view.result.EasyUIData;
import com.threeweidu.view.result.JsonResult;


@Controller
@RequestMapping(value = "/merchant/agentIPWhiteRecord")
public class AgentIPWhiteRecordController extends BaseController {

	@Autowired
	private AgentIPWhiteRecordService agentIPWhiteRecordService;
	@Autowired 
	private AgentService agentService;

	/**
	 * 渠道商IP白名单管理(分页查询）
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "/findAll")
	public void findAll(
			@RequestParam(required = true, value = "page", defaultValue = "1") Long pageNo, 
			@RequestParam(required = true, value = "rows", defaultValue = "10") Long pageSize, 
			@RequestParam(required = true, value = "sort", defaultValue = "addTime") String sortField, 
			@RequestParam(required = true, value = "order", defaultValue = "desc") String sortType, 
			AgentIPWhiteRecord agentIPWhiteRecord,
			HttpServletRequest request, HttpServletResponse response) {
		EasyUIData uiData = null;
		Page page = new Page(pageNo, pageSize, sortField, sortType);
		try {
			String agentId = getAgentId(request);
			if (Null2.isNull(agentId)) {
				uiData = new EasyUIData(false, "渠道商编号不能为空", 0L, Collections.EMPTY_LIST);
				return;
			}
			agentIPWhiteRecord.setAgentId(agentId);
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_PAYMENT);
			uiData = agentIPWhiteRecordService.queryEasyUIData(page, agentIPWhiteRecord);
		} catch (Exception e) {
			e.printStackTrace();
			SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			uiData = new EasyUIData(false, "查询异常,请联系管理员", 0L, Collections.EMPTY_LIST);
		}finally{
			super.outJson(response, uiData);
		}
	}
	
	/**
	 * 添加IP白名单
	 * 
	 */
	@RequestMapping(value="/addAgentIPWhiteRecord")
	public void addAgentIPWhiteRecord(HttpServletRequest request, HttpServletResponse response,AgentIPWhiteRecord agentIPWhiteRecord){
		JsonResult result = null;
		try {
			String agentId = getAgentId(request);
			if (Null2.isNull(agentId)) {
				result = new JsonResult(false, "渠道商编号不能为空");
				return;
			}
			agentIPWhiteRecord.setAgentId(agentId);
			agentIPWhiteRecord.setIpType(1001);
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_PAYMENT);
			result = checkParam(agentIPWhiteRecord);
			if(!result.getSuccess()){
				return;
			}
			Agent agent = agentService.getAgentInfoByAgentid(agentId);
			agentIPWhiteRecord.setAddMan(agent.getAgentName());
			result = agentIPWhiteRecordService.addAgentIPWhiteRecord(agentIPWhiteRecord);
		} catch (Exception e) {
			e.printStackTrace();
			SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			result = new JsonResult(false, "查询异常,请联系管理员");
		}finally{
			super.outJson(response, result);
		}
	}
	
	/**
	 * 批量删除IP白名单
	 * @param request
	 * @param response
	 * @param agentIPWhiteRecord
	 */
	@RequestMapping(value="/deleteAgentIPWhiteRecord")
	public void deleteAgentIPWhiteRecord(HttpServletRequest request, HttpServletResponse response){
		JsonResult result = null;
		try {
			String agentId = getAgentId(request);
			if (Null2.isNull(agentId)) {
				result = new JsonResult(false, "渠道商编号不能为空");
				return;
			}
			
			String selectData = request.getParameter("selectData");
			if (StringUtils.isEmpty(selectData)) {
				result = new JsonResult(false, "需要处理的数据不能为空");
				return;
			}
			List<AgentIPWhiteRecord> list = JsonUtils.jsonToObject(selectData, new TypeReference<List<AgentIPWhiteRecord>>() {
			});
			for (AgentIPWhiteRecord ipWhiteRecord : list) {
				ipWhiteRecord.setAgentId(agentId);
			}
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_PAYMENT);
			result = agentIPWhiteRecordService.deleteAgentIPWhiteRecord(list);
		} catch (Exception e) {
			e.printStackTrace();
			SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			result = new JsonResult(false, "查询异常,请联系管理员");
		}finally{
			super.outJson(response, result);
		}
	}
	
	/**
	 * 批量绑定或解绑
	 * @param request
	 * @param response
	 */					    
	@RequestMapping(value="/batchBindingOrUnbinding")
	public void batchBindingOrUnbinding(HttpServletRequest request, HttpServletResponse response){
		JsonResult result = null;
		try {
			String agentId = getAgentId(request);
			if (Null2.isNull(agentId)) {
				result = new JsonResult(false, "渠道商编号不能为空");
				return;
			}
			
			String selectData = request.getParameter("selectData");
			String state = request.getParameter("state");  //启用状态，1001：启用（绑定），1002：未启用（解绑）
			if (StringUtils.isEmpty(selectData)) {
				result = new JsonResult(false, "需要处理的数据不能为空");
				return;
			}
			List<AgentIPWhiteRecord> list = JsonUtils.jsonToObject(selectData, new TypeReference<List<AgentIPWhiteRecord>>() {
			});
			for (AgentIPWhiteRecord ipWhiteRecord : list) {
				ipWhiteRecord.setAgentId(agentId);
				ipWhiteRecord.setState(Integer.valueOf(state));
				int num = agentIPWhiteRecordService.findCountSame(ipWhiteRecord);
				if (num < 1) {
					result = new JsonResult(false, "页面数据错误，白名单IP为" + ipWhiteRecord.getWhiteIP() + "记录不存在！");
					return;
				}
			}
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_PAYMENT);
			result = agentIPWhiteRecordService.updateStateBatch(list);
		} catch (Exception e) {
			e.printStackTrace();
			SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			result = new JsonResult(false, "查询异常,请联系管理员");
		}finally{
			super.outJson(response, result);
		}
	}
	
	//为添加IP白名单做校验
	private JsonResult checkParam(AgentIPWhiteRecord agentIPWhiteRecord){
		
		String ipString = agentIPWhiteRecord.getWhiteIP().replaceAll("\\s*", "");
		if (StringUtils.isEmpty(agentIPWhiteRecord.getWhiteIP())) {
			return new JsonResult(false, "登录IP地址/域名不能为空");
		}else {
			if(!"all".equals(ipString)){
				//判断IP格式是否正确
				boolean isIp = ValidateUtils.checkIP(ipString);
				if (!isIp) {
					return new JsonResult(false, "IP地址/域名格式不正确");
				}
			}
		}
		AgentIPWhiteRecord agentIPWhiteRecordCount = new AgentIPWhiteRecord();
		agentIPWhiteRecordCount.setAgentId(agentIPWhiteRecord.getAgentId());
		agentIPWhiteRecordCount.setWhiteIP(agentIPWhiteRecord.getWhiteIP());
		int num = agentIPWhiteRecordService.findCountSame(agentIPWhiteRecordCount);
		if (num > 0) {
			return new JsonResult(false, "已绑定相同IP");
		}
		if (StringUtils.isEmpty(agentIPWhiteRecord.getAddManIP())) {
			return new JsonResult(false, "添加人IP为空，请联系管理员");
		}
		return new JsonResult(true, "");
	}
	
	
	

}