package com.threeweidu.controller;

import java.util.Collections;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.codehaus.jackson.type.TypeReference;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.threeweidu.config.DefaultProfile;
import com.threeweidu.entity.AssociateMerchant;
import com.threeweidu.entity.SecSWDAgent;
import com.threeweidu.service.SecSWDAgentService;
import com.threeweidu.supplier.utils.JsonUtils;
import com.threeweidu.utils.Null2;
import com.threeweidu.utils.OrderIdGenerator;
import com.threeweidu.utils.OrderIdGenerator.Order;
import com.threeweidu.utils.SystemExceptionUtil;
import com.threeweidu.utils.ValidateUtils;
import com.threeweidu.utils.mybatis.DBContextHolder;
import com.threeweidu.view.req.page.Page;
import com.threeweidu.view.result.EasyUIData;
import com.threeweidu.view.result.JsonResult;
/**
 * 添加二级渠道商
 * @author zengxb
 */

@Controller
@RequestMapping(value = "/merchant/secSWDAgent")
public class SecSWDAgentController extends BaseController {
   
	@Autowired
	private SecSWDAgentService secSWDAgentService;
	
	/**
	 * 查询二级渠道商列表
	 * @param pageNo 当前页
	 * @param pageSize 每页记录数
	 * @param sortField 排序字段
	 * @param sortType 排序方式
	 * @param secSWDAgent 实体类
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "/findAll")
	public void findAll(
			@RequestParam(required = true, value = "page", defaultValue = "1") Long pageNo, 
			@RequestParam(required = true, value = "rows", defaultValue = "10") Long pageSize, 
			@RequestParam(required = true, value = "sort", defaultValue = "s.addTime") String sortField, 
			@RequestParam(required = true, value = "order", defaultValue = "asc") String sortType, 
			SecSWDAgent secSWDAgent,
			HttpServletRequest request, HttpServletResponse response) {
		EasyUIData uiData = null;
		Page page = new Page(pageNo, pageSize, sortField, sortType);
		try {
			String agentId = getAgentId(request);
			if (Null2.isNull(agentId)) {
				uiData = new EasyUIData(false, "渠道商编号不能为空", 0L, Collections.EMPTY_LIST);
				return;
			}
			secSWDAgent.setAgentId(agentId);
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_PAYMENT);
			uiData = secSWDAgentService.queryEasyUIData(secSWDAgent, page);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			uiData = new EasyUIData(false, "查询异常,请联系管理员", 0L, Collections.EMPTY_LIST);
		} finally {
			super.outJson(response, uiData);
		}
	}
	
	/**
	 * 添加二级渠道商
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "/addAgent")
	public void addAgent(HttpServletRequest request,HttpServletResponse response, SecSWDAgent secSWDAgent){
		JsonResult jsonResult = null;
		try {
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_PAYMENT);
			jsonResult = checkParam(request, secSWDAgent);
			if (jsonResult.getSuccess() == false) {
				return;
			}
			jsonResult = secSWDAgentService.addSecSWDAgent(secSWDAgent);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			} catch (Exception e2) {
				e2.printStackTrace();
			}
			jsonResult = new JsonResult(false, "服务器异常");
		}finally{
			super.outJson(response, jsonResult);
		}
		
	}
	
	/**
	 * 校验数据并准备实体类
	 * @param request
	 */
	private JsonResult checkParam(HttpServletRequest request, SecSWDAgent secSWDAgent){

		String agentId = getAgentId(request);
		if (Null2.isNull(agentId)) {
			return new JsonResult(false, "渠道商编号不能为空");
		}
		secSWDAgent.setAgentId(agentId);
		
		String secAgentAccount = secSWDAgent.getSecAgentAccount();
		if (Null2.isNull(secAgentAccount)) {
			return new JsonResult(false, "二级渠道商编号不能为空");
		}else if (!ValidateUtils.checkChinese(secAgentAccount)) {
			return new JsonResult(false, "二级渠道商编号不能包含中文");
		}else if (secSWDAgentService.findAccountCount(secAgentAccount) > 0) {
			return new JsonResult(false, "二级渠道商账户号已存在");
		}
		
		String secAgentName = secSWDAgent.getSecAgentName();
		if (Null2.isNull(secAgentName)) {
			return new JsonResult(false, "二级渠道商名称不能为空");
		}
		
		String secAgentPhone = secSWDAgent.getSecAgentPhone();
		if (Null2.isNull(secAgentPhone)) {
			return new JsonResult(false, "二级渠道商电话不能为空");
		}else if (!ValidateUtils.phoneNumber(secAgentPhone)) {
			return new JsonResult(false, "电话号码格式不正确");
		}
		
		String email = secSWDAgent.getEmail();
		if (Null2.isNotNull(email)) {
			if (!ValidateUtils.checkEmail(email)) {
				return new JsonResult(false, "邮箱格式不正确");
			}
		}
		
		String secAgentId = OrderIdGenerator.getInstance().getOrderId(Order.AUDITTRANSFER, 20);  //生成20位二级渠道商编号
		secSWDAgent.setSecAgentId(secAgentId);
		secSWDAgent.setPasswd(DefaultProfile.DEFAULT_PASSWORD);
		secSWDAgent.setSecAgentType(1001); //类型：对外渠道商
		secSWDAgent.setSecAgentState(1002); //渠道商状态：有效
		secSWDAgent.setVerifyState(1002); //审核状态：审核通过
		
		String agentAccount = secSWDAgentService.findAgentAccount(agentId);
		if (Null2.isNull(agentAccount)) {
			return new JsonResult(false, "渠道商账户为空");
		}
		secSWDAgent.setAddMan(agentAccount); //添加人，默认为系统登录账户
		
		return new JsonResult(true, "", secSWDAgent);
	}
	
	/**
	 * 查询二级渠道商列表
	 * @param pageNo 当前页
	 * @param pageSize 每页记录数
	 * @param sortField 排序字段
	 * @param sortType 排序方式
	 * @param secSWDAgent 实体类
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "/findAssociateList")
	public void findAssociateList(
			@RequestParam(required = true, value = "page", defaultValue = "1") Long pageNo, 
			@RequestParam(required = true, value = "rows", defaultValue = "10") Long pageSize, 
			@RequestParam(required = true, value = "sort", defaultValue = "addTime") String sortField, 
			@RequestParam(required = true, value = "order", defaultValue = "asc") String sortType, 
			AssociateMerchant associateMerchant,
			HttpServletRequest request, HttpServletResponse response) {
		EasyUIData uiData = null;
		Page page = new Page(pageNo, pageSize, "s." + sortField, sortType);
		try {
			String agentId = getAgentId(request);
			if (Null2.isNull(agentId)) {
				uiData = new EasyUIData(false, "渠道商编号不能为空", 0L, Collections.EMPTY_LIST);
				return;
			}
			associateMerchant.setAgentId(agentId);
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_PAYMENT);
			uiData = secSWDAgentService.queryEasyUIData(associateMerchant, page);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			uiData = new EasyUIData(false, "查询异常,请联系管理员", 0L, Collections.EMPTY_LIST);
		} finally {
			super.outJson(response, uiData);
		}
	}	
	
	
	/**
	 * 二级渠道商关联商户
	 * @param request
	 * @param response
	 * @param associateMerchant
	 */
	@RequestMapping(value = "/associateMerchant")
	public void associateMerchant(HttpServletRequest request,HttpServletResponse response, AssociateMerchant associateMerchant){
		JsonResult jsonResult = new JsonResult();
		try {
			
			if (Null2.isNull(associateMerchant.getAmId())) {
				jsonResult = new JsonResult(false, "关联表Id不能为空");
				return;
			}
			if (Null2.isNull(associateMerchant.getSecAgentId())) {
				jsonResult = new JsonResult(false, "二级渠道商编号不能为空");
				return;
			}
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_PAYMENT);
			jsonResult = secSWDAgentService.updateAssociate(associateMerchant);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			} catch (Exception e2) {
				e2.printStackTrace();
			}
			jsonResult = new JsonResult(false, "服务器异常");
		}finally{
			super.outJson(response, jsonResult);
		}
		
	}	
	
	/**
	 * 二级渠道商取消关联商户
	 * @param request
	 * @param response
	 * @param associateMerchant
	 */
	@RequestMapping(value = "/disAssociateMerchant")
	public void disAssociateMerchant(HttpServletRequest request,HttpServletResponse response){
		JsonResult jsonResult = new JsonResult();
		try {
			
			String selectData = request.getParameter("selectData");
			if (StringUtils.isEmpty(selectData)) {
				jsonResult = new JsonResult(false, "需要处理的数据不能为空");
				return;
			}
			List<AssociateMerchant> list = JsonUtils.jsonToObject(selectData, new TypeReference<List<AssociateMerchant>>() {
			});
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_PAYMENT);
			for (AssociateMerchant s : list) {
				jsonResult = secSWDAgentService.selectByAmId(s.getAmId()); //校验是否存在且是否为已关联数据
				if (!jsonResult.getSuccess()) {
					return;
				}
			}
			jsonResult = secSWDAgentService.batchUpdateDisAssociate(list);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			} catch (Exception e2) {
				e2.printStackTrace();
			}
			jsonResult = new JsonResult(false, "服务器异常");
		}finally{
			super.outJson(response, jsonResult);
		}
	}		
	
}