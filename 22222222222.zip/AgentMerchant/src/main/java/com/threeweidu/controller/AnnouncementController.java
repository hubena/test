package com.threeweidu.controller;

import java.util.Collections;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.threeweidu.entity.Agent;
import com.threeweidu.entity.Announcement;
import com.threeweidu.service.AgentService;
import com.threeweidu.service.AnnouncementService;
import com.threeweidu.utils.Null2;
import com.threeweidu.utils.SystemExceptionUtil;
import com.threeweidu.utils.mybatis.DBContextHolder;
import com.threeweidu.view.req.page.Page;
import com.threeweidu.view.result.EasyUIData;
import com.threeweidu.view.result.JsonResult;


@Controller
@RequestMapping(value="/merchant/announcement")
public class AnnouncementController extends BaseController {
	
	@Autowired
	private AnnouncementService announcementService;
	@Autowired
	private AgentService agentService;
	
	@RequestMapping(value="/list/find")
	@ResponseBody
	public void paymentRecordList(
			@RequestParam(required = true, value = "page", defaultValue = "1") Long pageNo, 
			@RequestParam(required = true, value = "rows", defaultValue = "10") Long pageSize, 
			@RequestParam(required = true, value = "sort", defaultValue = "announcementId") String sortField, 
			@RequestParam(required = true, value = "order", defaultValue = "desc") String sortType, 
			Announcement announcement,
			HttpServletRequest request, HttpServletResponse response) {
		EasyUIData uiData = null;
		Page page = new Page(pageNo, pageSize, sortField, sortType);
		try {
			String agentId = getAgentId(request);
			if (Null2.isNull(agentId)) {
				uiData = new EasyUIData(false, "代理商编号不能为空", 0L, Collections.EMPTY_LIST);
				return;
			}
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_PAYMENT);
			Agent agent = agentService.getAgentInfoByAgentid(agentId);
			announcement.setAddMan(agent.getAgentAccount());
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_SHOP);
			uiData = announcementService.findList(announcement, page);
		} catch (Exception e) {
			e.printStackTrace();
			SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			uiData = new EasyUIData(false, "查询异常,请联系管理员", 0L, Collections.EMPTY_LIST);
		}finally{
			super.outJson(response, uiData);
		}
	}
	
	@RequestMapping(value="/addAnnouncement")
	@ResponseBody
	public void addAnnouncement(Announcement announcement,
			HttpServletRequest request, HttpServletResponse response) {
		JsonResult result = null;
		try {
			String agentId = getAgentId(request);
			if (Null2.isNull(agentId)) {
				result = new JsonResult(false, "代理商编号不能为空");
				return;
			}
			result = checkNull(announcement);
			if(!result.getSuccess()){
				return;
			}
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_PAYMENT);
			Agent agent = agentService.getAgentInfoByAgentid(agentId);
			announcement.setAddMan(agent.getAgentAccount());
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_SHOP);
			result = announcementService.addAnnouncement(announcement);
		} catch (Exception e) {
			e.printStackTrace();
			SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			result = new JsonResult(false, "查询异常,请联系管理员");
		}finally{
			super.outJson(response, result);
		}
	}
	
	@RequestMapping(value="/updateAnnouncement")
	@ResponseBody
	public void updateAnnouncement(Announcement announcement,
			HttpServletRequest request, HttpServletResponse response) {
		JsonResult result = null;
		try {
			String agentId = getAgentId(request);
			if (Null2.isNull(agentId)) {
				result = new JsonResult(false, "代理商编号不能为空");
				return;
			}
			result = checkNull(announcement);
			if(!result.getSuccess()){
				return;
			}
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_PAYMENT);
			Agent agent = agentService.getAgentInfoByAgentid(agentId);
			announcement.setAddMan(agent.getAgentAccount());
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_SHOP);
			result = announcementService.updateAnnouncement(announcement);
		} catch (Exception e) {
			e.printStackTrace();
			SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			result = new JsonResult(false, "查询异常,请联系管理员");
		}finally{
			super.outJson(response, result);
		}
	}

	@RequestMapping(value="/updatePublish")
	@ResponseBody
	public void updatePublish(Announcement announcement,
			HttpServletRequest request, HttpServletResponse response) {
		JsonResult result = null;
		try {
			String agentId = getAgentId(request);
			if (Null2.isNull(agentId)) {
				result = new JsonResult(false, "代理商编号不能为空");
				return;
			}
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_PAYMENT);
			Agent agent = agentService.getAgentInfoByAgentid(agentId);
			announcement.setAddMan(agent.getAgentAccount());
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_SHOP);
			result = announcementService.updatePublish(announcement);
		} catch (Exception e) {
			e.printStackTrace();
			SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			result = new JsonResult(false, "查询异常,请联系管理员");
		}finally{
			super.outJson(response, result);
		}
	}	
	
	private JsonResult checkNull(Announcement announcement) {
		JsonResult result = new JsonResult(true, "");
		if(Null2.isNull(announcement.getTitle())){
			return new JsonResult(false, "公告标题不允许为空");
		}
		if(Null2.isNull(announcement.getContent())){
			return new JsonResult(false, "公告内容不允许为空");
		}
		if(Null2.isNull(announcement.getPublishOrganization())){
			return new JsonResult(false, "公告发布组织不允许为空");
		}
		if(Null2.isNull(announcement.getPublishDate())){
			return new JsonResult(false, "公告发布日期不允许为空");
		}
		if(Null2.isNull(announcement.getAnnType())){
			return new JsonResult(false, "公告类型不允许为空");
		}
		if(Null2.isNull(announcement.getAnnState())){
			return new JsonResult(false, "公告状态不允许为空");
		}
		if(Null2.isNull(announcement.getAcceptPlatform())){
			return new JsonResult(false, "公告接受平台不允许为空");
		}
		return result;
	}
	
	
}
