package com.threeweidu.controller;

import java.util.Collections;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.threeweidu.entity.SupplierCashApplyStatistics;
import com.threeweidu.service.SupplierCashApplyStatisticsService;
import com.threeweidu.utils.Null2;
import com.threeweidu.utils.SystemExceptionUtil;
import com.threeweidu.utils.mybatis.DBContextHolder;
import com.threeweidu.view.req.page.Page;
import com.threeweidu.view.result.EasyUIData;

@Controller
@RequestMapping(value="/merchant/supplierCashStatistics")
public class SupplierCashApplyStatisticsController extends BaseController {
	
	@Autowired
	private SupplierCashApplyStatisticsService cashApplyStatisticsService;
	
	@RequestMapping(value = "/list")
	public String list(HttpServletRequest request, HttpServletResponse response) {
		return "supplier/cashApplyStatistics_list";
	}
		
	@RequestMapping(value="/list/find")
	@ResponseBody
	public void paymentRecordList(
			@RequestParam(required = true, value = "page", defaultValue = "1") Long pageNo, 
			@RequestParam(required = true, value = "rows", defaultValue = "10") Long pageSize, 
			@RequestParam(required = true, value = "sort", defaultValue = "createTime") String sortField, 
			@RequestParam(required = true, value = "order", defaultValue = "desc") String sortType, 
			SupplierCashApplyStatistics statistics,
			HttpServletRequest request, HttpServletResponse response) {
		EasyUIData uiData = null;
		Page page = new Page(pageNo, pageSize, sortField, sortType);
		try {
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_SHOP);
			if(Null2.isNotNull(statistics) && Null2.isNotNull(statistics.getStatisticsID())){
				try {
					Long.parseLong(statistics.getStatisticsID());
				} catch (Exception e) {
					uiData = new EasyUIData(true, "数据为空", 0L, Collections.EMPTY_LIST);
					return;
				}
			}
			uiData = cashApplyStatisticsService.findList(statistics, page);
		} catch (Exception e) {
			e.printStackTrace();
			SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			uiData = new EasyUIData(false, "查询异常,请联系管理员", 0L, Collections.EMPTY_LIST);
		}finally{
			super.outJson(response, uiData);
		}
	}
	
}
