package com.threeweidu.controller;

import java.util.Collections;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.threeweidu.entity.SupplierCashApply;
import com.threeweidu.service.SupplierCashApplyService;
import com.threeweidu.utils.mybatis.DBContextHolder;
import com.threeweidu.view.req.page.Page;
import com.threeweidu.view.result.EasyUIData;
import com.threeweidu.view.result.JsonResult;

@Controller
@RequestMapping(value = "/merchant/supplierCashApply")
public class SupplierCashApplyController extends BaseController {

	@Autowired
	private SupplierCashApplyService supplierCashApplyService;

	/**
	 * 跳转页面
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/list")
	public String list(HttpServletRequest request, HttpServletResponse response) {
		return "merchant/supplierCashApplyList";
	}

	@RequestMapping(value = "/findAll")
	public void findAll(
			@RequestParam(required = true, value = "page", defaultValue = "1") Long pageNo, 
			@RequestParam(required = true, value = "rows", defaultValue = "10") Long pageSize, 
			@RequestParam(required = true, value = "sort", defaultValue = "createTime") String sortField, 
			@RequestParam(required = true, value = "order", defaultValue = "asc") String sortType, 
			HttpServletRequest request, HttpServletResponse response) {
		EasyUIData uiData = null;
		Page page = new Page(pageNo, pageSize, sortField, sortType);
		try {
			page.setWhereField(buildWhereField(request));
			uiData = supplierCashApplyService.queryEasyUIData(page);
		} catch (Exception e) {
			e.printStackTrace();
			uiData = new EasyUIData(false, "查询异常,请联系管理员", 0L, Collections.EMPTY_LIST);
		}
		super.outJson(response, uiData);
	}

	/**
	 * 拼接查询条件
	 * 
	 * @param request
	 * @return
	 */
	private String buildWhereField(HttpServletRequest request) {
		StringBuffer sb = new StringBuffer();
		sb.append(" 1=1 ");

		String cashId = request.getParameter("cashId");
		if (cashId != null && cashId.length() > 0) {
			sb.append(" and cashId='" + cashId + "' ");
		}

		String supplierId = request.getParameter("supplierId");
		if (supplierId != null && supplierId.length() > 0) {
			sb.append(" and supplierId='" + supplierId + "' ");
		}

		String mobile = request.getParameter("mobile");
		if (mobile != null && mobile.length() > 0) {
			sb.append(" and mobile='" + mobile + "' ");
		}

		String createTimeStart = request.getParameter("createTimeStart");
		String createTimeEnd = request.getParameter("createTimeEnd");
		if (createTimeStart != null && createTimeStart.length() > 0) {
			sb.append(" and createTime >='" + createTimeStart + "' ");
		}
		if (createTimeEnd != null && createTimeEnd.length() > 0) {
			sb.append(" and createTime <dateadd(dd,1,'" + createTimeEnd + "')");
		}

		String accountFlag = request.getParameter("accountFlag");
		if (accountFlag != null && accountFlag.length() > 0) {
			sb.append(" and accountFlag='" + accountFlag + "' ");
		}

		String consumType = request.getParameter("consumType");
		if (StringUtils.isNotEmpty(consumType)) {
			sb.append(" and consumType=" + consumType);
		}

		String cashState = request.getParameter("cashState");
		if (cashState != null && cashState.length() > 0) {
			sb.append(" and cashState='" + cashState + "' ");
		}

		return sb.toString();
	}

	/**
	 * 根据提现订单号查询提现申请记录
	 * 
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "/findByCashId")
	public void findByCashId(HttpServletRequest request, HttpServletResponse response) {
		JsonResult result = null;
		try {
			String cashId = request.getParameter("cashId");// 提现订单号
			if (StringUtils.isEmpty(cashId)) {
				super.outJson(response, new JsonResult(false, "页面参数错误！"));
				return;
			}
			if (request.getSession().getAttribute("adminAccount") == null) {
				super.outJson(response, new JsonResult(false, "登录超时，请重新登录！"));
				return;
			}
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_SHOP);
			SupplierCashApply supplierCashApply = supplierCashApplyService.findByCashId(cashId);
			result = new JsonResult(true, "查询成功", supplierCashApply);
		} catch (Exception e) {
			e.printStackTrace();
			result = new JsonResult(false, "服务器异常");
		}
		super.outJson(response, result);
	}

}
