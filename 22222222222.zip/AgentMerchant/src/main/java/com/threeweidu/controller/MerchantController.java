package com.threeweidu.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.threeweidu.view.result.JsonResult;

@Controller
@RequestMapping("/merchant")
public class MerchantController extends BaseController {

	// 用户退出
	@RequestMapping(value = "/logoutOld")
	public String logoutOld(HttpServletRequest request, HttpServletResponse response) {
		request.getSession().invalidate();
		return "redirect:/login";
	}
	
	// 用户退出
	@RequestMapping(value = "/logout")
	@ResponseBody
	public void logout(HttpServletRequest request, HttpServletResponse response) {		
		super.removeAPIkey(request);
		JsonResult result = new JsonResult(true, "退出成功！");		
		super.outJson(response, result);
	}

	/**
	 * 后台管理界面主接口 /merchant/index
	 * 
	 * @return
	 */
	@RequestMapping(value = "/index")
	public String index(ModelMap modelMap, HttpServletRequest request, HttpServletResponse response) {
		return "merchant/index";
	}

	/**
	 * 默认显示主页
	 * 
	 * @param modelMap
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/indexdefault")
	public String indexdefault(HttpServletRequest request, HttpServletResponse response) {
		return "merchant/indexdefault";
	}

	/**
	 * 进入商户页面
	 * 
	 * @param modelMap
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/toMerInfoPage")
	public String toMerInfoPage(HttpServletRequest request, HttpServletResponse response) {
		return "merchant/list";
	}

}
