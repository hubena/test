package com.threeweidu.controller;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.URL;
import java.net.URLConnection;
import java.util.Collections;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.threeweidu.entity.Agent;
import com.threeweidu.entity.AgentIPWhiteRecord;
import com.threeweidu.service.AgentService;
import com.threeweidu.utils.Null2;
import com.threeweidu.utils.SystemExceptionUtil;
import com.threeweidu.utils.mybatis.DBContextHolder;
import com.threeweidu.view.result.EasyUIData;
import com.threeweidu.view.result.JsonResult;


@Controller
@RequestMapping(value="/merchant/agent")
public class AgentController extends BaseController {
	
	@Autowired
	private AgentService agentService;
	
	@RequestMapping(value="/message")
	public String message(){
		return "merchant/agentMessage";
	}
	
	@RequestMapping(value="/message/find")
	@ResponseBody
	public void findMessage(
			@RequestParam(required = true, value = "page", defaultValue = "1") Integer pageNo, 
			@RequestParam(required = true, value = "rows", defaultValue = "10") Integer pageSize, 
			@RequestParam(required = true, value = "sort", defaultValue = "agentId") String sortField, 
			@RequestParam(required = true, value = "order", defaultValue = "desc") String sortType, 
			HttpServletRequest request, HttpServletResponse response) {
		EasyUIData uiData = null;
		try {
			String agentId = getAgentId(request);
			if (Null2.isNull(agentId)) {
				uiData = new EasyUIData(false, "代理商编号不能为空", 0L, Collections.EMPTY_LIST);
				return;
			}			
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_PAYMENT);
			uiData = agentService.findMessage(agentId);
		} catch (Exception e) {
			e.printStackTrace();
			SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			uiData = new EasyUIData(false, "查询异常,请联系管理员", 0L, Collections.EMPTY_LIST);
		}finally{
			super.outJson(response, uiData);
		}
	}
	
	@RequestMapping(value="/update/password")
	@ResponseBody
	public void updatePassword(String agentOldPassword, String agentNewPassword1, String agentNewPassword2,
			HttpServletRequest request, HttpServletResponse response) {
		JsonResult result = null;
		try {
			String agentId = getAgentId(request);
			if (Null2.isNull(agentId)) {
				result = new JsonResult(false, "代理商编号不能为空");
				return;
			}
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_PAYMENT);
			result = agentService.updatePassword(agentId, agentOldPassword, agentNewPassword1, agentNewPassword2);
		} catch (Exception e) {
			e.printStackTrace();
			SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			result = new JsonResult(false, "服务器异常");
		} finally {
			super.outJson(response, result);
		}
	}
	
	/*
	 * 修改代理商支付密码
	 * 
	 */
	@RequestMapping(value="/update/payPasswd")
	@ResponseBody
	public void updatePayPassword(String agentOldPayPassword, String agentNewPayPassword1, String agentNewPayPassword2,
			HttpServletRequest request, HttpServletResponse response) {
		JsonResult result = null;
		try {
			String agentId = getAgentId(request);
			if (Null2.isNull(agentId)) {
				result = new JsonResult(false, "代理商编号不能为空");
				return;
			}
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_PAYMENT);
			result = agentService.updatePayPassword(agentId, agentOldPayPassword, agentNewPayPassword1, agentNewPayPassword2);
		} catch (Exception e) {
			e.printStackTrace();
			SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			result = new JsonResult(false, "服务器异常");
		} finally {
			super.outJson(response, result);
		}
	}
	
	
	@RequestMapping(value="/update/agentInfo")
	@ResponseBody
	public void updateAgentInfo(Agent agent, 
			HttpServletRequest request, HttpServletResponse response) {
		JsonResult result = null;
		try {
			String agentId = getAgentId(request);
			if (Null2.isNull(agentId)) {
				result = new JsonResult(false, "代理商编号不能为空");
				return;
			}
			if (Null2.isNull(agent.getAgentPhone())) {
				result = new JsonResult(false, "电话号码不能为空");
				return;
			}
			if (Null2.isNull(agent.getEmail())) {
				result = new JsonResult(false, "邮箱不能为空");
				return;
			}
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_PAYMENT);
			agent.setAgentId(agentId);
			result = agentService.updateAgentInfo(agent);
		} catch (Exception e) {
			e.printStackTrace();
			SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			result = new JsonResult(false, "服务器异常");
		} finally {
			super.outJson(response, result);
		}
	}
	
	/**
	 * 发送验证码
	 * @author Zengxb
	 * @param request
	 * @param response
	 */
	@RequestMapping(value="/sendIdentifyCode")
	@ResponseBody
	public void sendIdentifyCode(HttpServletRequest request, HttpServletResponse response) {
		JsonResult result = null;
		try {
			String agentId = getAgentId(request);
			if (Null2.isNull(agentId)) {
				result = new JsonResult(false, "渠道商编号不能为空！");
				return;
			}
			String sendType = request.getParameter("sendType"); //1001：发送手机验证码，1002：发送邮箱验证码
			if (Null2.isNull(sendType)) {
				result = new JsonResult(false, "页面数据错误，发送类型为空！");
				return;
			}
			String operation = request.getParameter("operation"); //操作内容，发送给用户及写入日志
			if (Null2.isNull(operation)) {
				result = new JsonResult(false, "页面数据错误，操作内容为空！");
				return;
			}
			String businessType = request.getParameter("businessType");//一段用于写入及取出户缓存中验证码的字段，判断是手机验证码还是邮箱验证码
			if (Null2.isNull(businessType)) {
				result = new JsonResult(false, "页面数据错误，业务类型为空！");
			}
			String couCode = request.getParameter("couCode");  //国家区号，用于发送手机验证码
			String sendNumber = new String();
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_PAYMENT);
			Agent agent = agentService.getAgentInfoByAgentid(agentId);
			if ("1001".equals(sendType)) {
				if (Null2.isNull(couCode)) {
					result = new JsonResult(false, "页面数据错误，国家区号为空！");
				}
				if (Null2.isNull(agent.getAgentPhone())) {
					result = new JsonResult(false, "页面数据错误，渠道商手机号为空！");
					return;
				}
				sendNumber = agent.getAgentPhone();
			}else if("1002".equals(sendType)){
				if (Null2.isNull(agent.getEmail())) {
					result = new JsonResult(false, "页面数据错误，渠道商邮箱为空！");
					return;
				}
				sendNumber = agent.getEmail();
			}
			result = agentService.sendIdentifyCode(sendType, sendNumber, agentId, couCode, operation, businessType);
		} catch (Exception e) {
			e.printStackTrace();
			SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			result = new JsonResult(false, "服务器异常");
		} finally {
			super.outJson(response, result);
		}
	}
	
	/**
	 * 为开启或关闭IP绑定做校验
	 * @param request
	 * @return
	 */
	private JsonResult checkForIP(HttpServletRequest request){
		AgentIPWhiteRecord agentIPWhiteRecord = new AgentIPWhiteRecord();
		String agentId = getAgentId(request);
		if (Null2.isNull(agentId)) {
			return new JsonResult(false, "渠道商编号不能为空");
		}
		agentIPWhiteRecord.setAgentId(agentId);
		String isBindingIP = request.getParameter("isBindingIP"); //绑定或解绑登录IP，1001：否，1002：是
		String sendType = request.getParameter("sendType");//1001：发送手机验证码，1002：发送邮箱验证码
		String operateIp = request.getParameter("operateIp"); //操作IP，即要绑定的IP地址
		String phoneCode = request.getParameter("phoneCode"); //手机验证码
		String emailCode = request.getParameter("emailCode"); //邮箱验证码
		Agent agent = agentService.getAgentInfoByAgentid(agentId);
		agentIPWhiteRecord.setAddMan(agent.getAgentAccount());
		if (StringUtils.isEmpty(isBindingIP)) {
			return new JsonResult(false, "页面数据错误，绑定解绑标志为空！");
		}
		agentIPWhiteRecord.setIsBindingIP(Integer.valueOf(isBindingIP));
		if (StringUtils.isEmpty(sendType)) {
			return new JsonResult(false, "页面数据错误，发送类型为空！");
		}
		agentIPWhiteRecord.setSendType(Integer.valueOf(sendType));
		if (StringUtils.isEmpty(operateIp)) {
			return new JsonResult(false, "页面数据错误，操作IP为空！");
		}
		agentIPWhiteRecord.setAddManIP(operateIp);
		if ("1001".equals(isBindingIP)&&isBindingIP.equals(String.valueOf(agent.getIsBindingIP()))) {
			return new JsonResult(false, "页面数据错误，已经关闭IP绑定！");
		}else if ("1002".equals(isBindingIP)&&isBindingIP.equals(String.valueOf(agent.getIsBindingIP()))) {
			return new JsonResult(false, "页面数据错误，已经开启IP绑定！");
		}
		
		if ("1001".equals(sendType)) {
			if(StringUtils.isEmpty(agent.getAgentPhone())){
				return new JsonResult(false, "页面数据错误，未绑定手机号！");
			}
			if (StringUtils.isEmpty(phoneCode)) {
				return new JsonResult(false, "验证码不能为空");
			}
			agentIPWhiteRecord.setSendNumber(agent.getAgentPhone());
			agentIPWhiteRecord.setSendCode(phoneCode);
		}else if ("1002".equals(sendType)) {
			if (StringUtils.isEmpty(agent.getEmail())) {
				return new JsonResult(false, "页面数据错误，未绑定邮箱！");
			}
			if (StringUtils.isEmpty(emailCode)) {
				return new JsonResult(false, "验证码不能为空");
			}
			agentIPWhiteRecord.setSendNumber(agent.getEmail());
			agentIPWhiteRecord.setSendCode(emailCode);
		}
		return new JsonResult(true, "", agentIPWhiteRecord);
	}
	
	/**
	 * 开启或关闭绑定IP白名单
	 * @author Zengxb
	 * @param request
	 * @param response
	 */
	@RequestMapping(value="/openOrCloseIPWhite")
	public void openOrCloseIPWhite(HttpServletRequest request, HttpServletResponse response) {
		JsonResult result = null;
		try {
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_PAYMENT);
			result = checkForIP(request);
			if (!result.getSuccess()) {	
				return;
			}
			AgentIPWhiteRecord agentIPWhiteRecord = (AgentIPWhiteRecord)result.getData();
			result = agentService.openOrCloseIPWhite(agentIPWhiteRecord);
		} catch (Exception e) {
			e.printStackTrace();
			SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			result = new JsonResult(false, "服务器异常");
		} finally {
			super.outJson(response, result);
		}
	}


	
	/**
	 * 测试
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "/testForSelf")
	public void testForSelf(HttpServletRequest request, HttpServletResponse response){
		PrintWriter out = null;
		BufferedReader in = null;
		String param = "agentOldPassword="+request.getParameter("agentOldPassword");
		JsonResult result = null;
		String resString = "";
		String urlName = "http://127.0.0.1:8080/pay/supplierBalanceFreeze/list/findAll";
		try {
			URL realUrl = new URL(urlName);
			// 打开和URL之间的连接
			URLConnection conn  = realUrl.openConnection();
			// 设置通用的请求属性
			conn.setRequestProperty("accept", "*/*");
			conn.setRequestProperty("connection", "Keep-Alive");
			conn.setRequestProperty("user-agent",
					"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
			conn.setRequestProperty("Accept-Charset", "utf-8");
            conn.setRequestProperty("contentType", "utf-8");
//            conn.setRequestProperty("Cookie", "agent_merchant_system_username=huiwang; username=peposAdmin; JSESSIONID=341260DB464CB5067DA04E84B98DC52D; app3weidu=s%3ArmieMmAobpvXtKggudQZ1dUDdqa1e3cY.CZIlwKLFtNL6v2bxeZ6SU9oe1tXgPFKSFcHA1z4XB%2Bk");
//            conn.setReadTimeout(5000);
			// 发送POST请求必须设置如下两行
			conn.setDoOutput(true);
			conn.setDoInput(true);
			// 获取URLConnection对象对应的输出流
			out = new PrintWriter(conn.getOutputStream());
			// 发送请求参数
			out.print(param);
			// flush输出流的缓冲
			out.flush();
			// 定义BufferedReader输入流来读取URL的响应
			in = new BufferedReader(
					new InputStreamReader(conn.getInputStream(),"utf-8"));
			String line;
			while ((line = in.readLine()) != null) {
				resString += line;
			}
			result = new JsonResult(true, resString);
		} catch (Exception e) {
			e.printStackTrace();
			result = new JsonResult(false, e.getMessage());
		} finally{
			super.outJson(response, result);
		}
		
		
	}
}
