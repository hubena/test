package com.threeweidu.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.threeweidu.service.SupplierCashApplyInfoService;
import com.threeweidu.utils.Null2;
import com.threeweidu.utils.SystemExceptionUtil;
import com.threeweidu.utils.export.FilesOperate;
import com.threeweidu.utils.mybatis.DBContextHolder;
import com.threeweidu.view.req.page.Page;
import com.threeweidu.view.result.EasyUIData;
import com.threeweidu.view.result.JsonResult;

/**
 * @description 商户转账记录查询
 */

@Controller
@RequestMapping(value = "/merchant/supplierCashApplyList")
public class SupplierCashApplyInfoController extends BaseController {

	@Autowired
	private SupplierCashApplyInfoService supplierCashApplyService;

	@RequestMapping(value = "/findAll")
	public void findAll(@RequestParam(required = true, value = "page", defaultValue = "1") Long pageNo,
						@RequestParam(required = true, value = "rows", defaultValue = "10") Long pageSize, 
						@RequestParam(required = true, value = "sort", defaultValue = "createTime") String sortField, 
						@RequestParam(required = true, value = "order", defaultValue = "asc") String sortType, 
						HttpServletRequest request, HttpServletResponse response) {
		EasyUIData uiData = null;
		Page page = new Page(pageNo, pageSize, "s." + sortField, sortType);
		try {
			//校验
			JsonResult jsonResult = checkForDownlod(request);
			if (!jsonResult.getSuccess()) {
				uiData = new EasyUIData(false, jsonResult.getMessage(), 0L, Collections.EMPTY_LIST);
				return;
			}
			page.setWhereField(buildWhereField(request));
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_SHOP);
			uiData = supplierCashApplyService.queryEasyUIData(page);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			uiData = new EasyUIData(false, "查询异常,请联系管理员", 0L, Collections.EMPTY_LIST);
		} finally {
			super.outJson(response, uiData);
		}
	}

	/**
	 * 拼接查询条件
	 * 
	 * @param request
	 * @return
	 */
	private String buildWhereField(HttpServletRequest request) {
		StringBuffer sb = new StringBuffer();		
		String merIds = super.getMerIdsByOrder(request);
		sb.append(" 1=1 and s.cashState != '1000'");

		if(Null2.isNotNull(merIds)){
			sb.append(" and s.supplierId in("+merIds+")");
		}

		String cashId = request.getParameter("cashId");
		if (cashId != null && cashId.length() > 0) {
			sb.append(" and s.cashId='" + cashId + "' ");
		}

		String supplierId = request.getParameter("supplierId");
		if (supplierId != null && supplierId.length() > 0) {
			sb.append(" and s.supplierId='" + supplierId + "' ");
		}

		String cardNo = request.getParameter("cardNo");
		if (cardNo != null && cardNo.length() > 0) {
			sb.append(" and s.cardNo='" + cardNo + "' ");
		}

		String bankName = request.getParameter("bankName");
		if (bankName != null && bankName.length() > 0) {
			sb.append(" and s.bankName like '%" + bankName + "%' ");
		}

		String bankCode = request.getParameter("bankCode");
		if (bankCode != null && bankCode.length() > 0) {
			sb.append(" and s.bankCode='" + bankCode + "' ");
		}

//		String createTimeStart = request.getParameter("createTimeStart");
//		String createTimeEnd = request.getParameter("createTimeEnd");
//		if (createTimeStart != null && createTimeStart.length() > 0) {
//			sb.append(" and s.createTime >='" + createTimeStart + "' ");
//		}
//		if (createTimeEnd != null && createTimeEnd.length() > 0) {
//			sb.append(" and s.createTime <dateadd(dd,1,'" + createTimeEnd + "')");
//		}

		String tradeMoney1 = request.getParameter("tradeMoney1");
		String tradeMoney2 = request.getParameter("tradeMoney2");
		if ((tradeMoney1 != null && !"".equals(tradeMoney1)) && (tradeMoney2 != null && !"".equals(tradeMoney2))) {
			int tradeMoney1I = (int) (Double.parseDouble(tradeMoney1) * 100);
			int tradeMoney2I = (int) (Double.parseDouble(tradeMoney2) * 100);
			sb.append(" and (s.tradeMoney >='" + tradeMoney1I + "' and s.tradeMoney <='" + tradeMoney2I + "')");
		} else if ((tradeMoney1 != null && !"".equals(tradeMoney1))) {
			int tradeMoneyI = (int) (Double.parseDouble(tradeMoney1) * 100);
			sb.append(" and s.tradeMoney >='" + tradeMoneyI + "'");
		} else if ((tradeMoney2 != null && !"".equals(tradeMoney2))) {
			int tradeMoneyI = (int) (Double.parseDouble(tradeMoney2) * 100);
			sb.append(" and s.tradeMoney <='" + tradeMoneyI + "')");
		}

		String businessId = request.getParameter("businessId");
		if (businessId != null && businessId.length() > 0) {
			sb.append(" and s.businessId='" + businessId + "' ");
		}

		String isRealPay = request.getParameter("isRealPay");
		if (isRealPay != null && isRealPay.length() > 0) {
			sb.append(" and s.isRealPay='" + isRealPay + "' ");
		}

		String cashState = request.getParameter("cashState");
		if (cashState != null && cashState.length() > 0) {
			sb.append(" and s.cashState='" + cashState + "' ");
		}
		String deductionState = request.getParameter("deductionState");
		if (Null2.isNotNull(deductionState)) {
			if("1000".equals(deductionState)){
				sb.append("and sp.deductionState is null");
			}else {
				sb.append(" and sp.deductionState='" + deductionState + "' ");
			}
		}
		
		String playMoneyTimeStart = request.getParameter("playMoneyTimeStart");
		String playMoneyTimeEnd = request.getParameter("playMoneyTimeEnd");
		if (playMoneyTimeStart != null && playMoneyTimeStart.length() > 0) {
			sb.append(" and s.playMoneyTime >='" + playMoneyTimeStart + "' ");
		}
		if (playMoneyTimeEnd != null && playMoneyTimeEnd.length() > 0) {
			sb.append(" and s.playMoneyTime <dateadd(dd,1,'" + playMoneyTimeEnd + "')");
		}

		return sb.toString();
	}

	/**
	 * 导出Excel报表
	 * 
	 * @param request
	 * @param response
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/export", method = RequestMethod.POST)
	public void exportList(HttpServletRequest request, HttpServletResponse response, String exportType) {
		JsonResult result = null;
		try {
			if (Null2.isNull(exportType) || !"CSV".equals(exportType.toUpperCase())
					|| !"XLS".equals(exportType.toUpperCase())) {
				result = new JsonResult(false, "导出类型错误");
			}
			result = checkForDownlod(request);
			if (!result.getSuccess()) {
				return;
			}
			Long pageNo = 1L;
			// 设置每次下载记录条数为10000
			Long pageSize = 10000L;
			String sortField = "s.createTime";
			String sortType = "asc";
			Page page = new Page(pageNo, pageSize, sortField, sortType);
			page.setWhereField(buildWhereField(request));
			result = supplierCashApplyService.exportList(page, exportType);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			result = new JsonResult(false, "服务器异常");
		} finally {
			if (!result.getSuccess()) {
				super.outJson(response, result);
				return;
			}
		}
		List<String> paths = (List<String>) result.getData();
		FilesOperate.downLoadExcel(response, paths, "SupplierCashApply");
	}

	private boolean checkDate(String createEndTime, String createStartTime) {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			Date start = format.parse(createStartTime);
			Date end = format.parse(createEndTime);
			long day = (end.getTime() - start.getTime()) / (1000L * 60L * 60L * 24L);
			if (day > (6 * 31)) {
				return false;
			}
		} catch (ParseException e) {
			return false;
		}
		return true;
	}

	/*
	 * 判断数据是否合法及准备查询条件
	 */
	private JsonResult checkForDownlod(HttpServletRequest request) {
		JsonResult jsonResult = new JsonResult(true, "");
		String agentId = getAgentId(request);
		if (Null2.isNull(agentId)) {
			return new JsonResult(false, "代理商编号不能为空");
		}
//		if (Null2.isNull(request.getParameter("createTimeStart")) || Null2.isNull(request.getParameter("createTimeEnd"))) {
//			return new JsonResult(false, "创建时间为必设置项");
//		}
//		if (!checkDate(request.getParameter("createTimeEnd"), request.getParameter("createTimeStart"))) {
//			return new JsonResult(false, "创建时间间隔最大为6个月");
//		}

		if (Null2.isNull(request.getParameter("playMoneyTimeStart")) || Null2.isNull(request.getParameter("playMoneyTimeEnd"))) {
			return new JsonResult(false, "转账时间为必设置项");
		}
		if (!checkDate(request.getParameter("playMoneyTimeEnd"), request.getParameter("playMoneyTimeStart"))) {
			return new JsonResult(false, "转账时间间隔最大为6个月");
		}
		return jsonResult;
	}

}
