package com.threeweidu.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sanweidu.jniPassword.JniPassword;
import com.threeweidu.config.DefaultProfile;
import com.threeweidu.entity.Agent;
import com.threeweidu.entity.utils.LoginUser;
import com.threeweidu.service.AgentService;
import com.threeweidu.service.LoginService;
import com.threeweidu.utils.Base64Util;
import com.threeweidu.utils.Null2;
import com.threeweidu.utils.SystemExceptionUtil;
import com.threeweidu.utils.mybatis.DBContextHolder;
import com.threeweidu.view.result.JsonResult;

@Controller
@RequestMapping(value="/login")
public class LoginController extends BaseController {
	@Autowired
	private LoginService loginService;
	@Autowired
	private AgentService agentService;
	
	@RequestMapping
	public String login(){
		return "merchant/login";
	}
	
	
	/**
	 * 跳转至管理员登陆页面
	 * @return
	 */
	@RequestMapping(value="loginRedirect")
	public String loginRedirect(){
		return "merchant/loginRedirect";
	}
	
	
	
	/**
	 * 后台管理员登录
	 * @param username
	 * @param password
	 * @param kaptcha
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value="/doLogin")
	@ResponseBody
	public void doLogin(
			String username,
			String password,
//			String codeValue,
			String domainName,
			boolean encrypt,
			HttpServletRequest request, HttpServletResponse response) {
		JsonResult jsonResult=null;
		try{
			if(Null2.isNull(username)){
				jsonResult=new JsonResult(false, "用户名不能为空");
				return;
			}
			if(Null2.isNull(password)){
				jsonResult=new JsonResult(false, "密码不能为空");
				return;
			}
			// 密码加密处理
			if (!encrypt) {
				JniPassword jniNative = JniPassword.getInstance();
				boolean bLoad = JniPassword.loadLibrary("JniPassword");
				if (bLoad) {
					password = jniNative.getSha512Value(password);
				}
			}

			// 判断验证码是否输入正确
//			String sessionCodeValue = (String) request.getSession().getAttribute("rand");
//			if (StringUtils.isEmpty(codeValue) || !sessionCodeValue.equalsIgnoreCase(codeValue.trim())) {
//				jsonResult=new JsonResult(false, "验证码输入错误");
//				return;
//			}
			//判断登录IP是否绑定
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_PAYMENT);
			String loginIP = request.getParameter("loginIP");
			jsonResult = loginService.checkWhiteIP(loginIP, username);
			if (!jsonResult.getSuccess()) {
				return;
			}
			
			//登陆业务处理
			jsonResult=loginService.loginValidate(username,password, domainName);
			if(jsonResult.getSuccess()){
				Agent agent=(Agent)jsonResult.getData();
				LoginUser user = new LoginUser();
				user.setType(1001);
				user.setAgentId(agent.getAgentId());
				String apikey = getAPIKey(user);
				Agent agent2 = new Agent();
				agent2.setApikey(apikey);
				agent2.setAgentAccount(agent.getAgentAccount());
				agent2.setAgentName(agent.getAgentName());
				agent2.setLogoUrl(agent.getLogoUrl());
				agent2.setUserType("1001");
				if(Null2.isNull(agent2.getLogoUrl())){
					agent2.setLogoUrl(DefaultProfile.DEFAULT_LOGOURL);
				}
				jsonResult.setData(agent2);
				//request.getSession().setAttribute(SystemUserSession.SYSTEMUSER_SYSTEM_SESSIONID, new SystemUserSession(username, agent.getAgentId()));
			}
		}catch(Exception e){
			e.printStackTrace();
			SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			jsonResult=new JsonResult(false, "发生异常,请联系管理员");
		}finally{
			super.outJson(response, jsonResult);
		}
	}
	
	/**
	 * 跳转至管理员登陆页面
	 * @return
	 */
	@RequestMapping(value="/getAgentLogo")
	@ResponseBody
	public void getAgentLogo(HttpServletRequest request, HttpServletResponse response,
			String domainName){
		JsonResult jsonResult=null;
		try{
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_PAYMENT);
			Agent agent = agentService.getAgentLogo(domainName);
			if(Null2.isNull(agent)){
				agent = new Agent();
				agent.setLogoUrl(DefaultProfile.DEFAULT_LOGOURL);
				agent.setAgentName("");
			} else if(Null2.isNull(agent.getLogoUrl())){
				agent.setLogoUrl(DefaultProfile.DEFAULT_LOGOURL);
				if(Null2.isNull(agent.getAgentName())){					
					agent.setAgentName("");
				}
			}
			jsonResult=new JsonResult(true, "获取成功");
			jsonResult.setData(agent);
		}catch(Exception e){
			e.printStackTrace();
			SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			jsonResult=new JsonResult(false, "发生异常,请联系管理员");
		}finally{
			super.outJson(response, jsonResult);
		}
	}
	
	/**
	 * 获取Base64密码转密码空间密码返回
	 * 
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "/getPassWord")
	public void getPassWord(HttpServletRequest request, HttpServletResponse response) {
		JsonResult result = null;
		try {
			String password = request.getParameter("password");
			StringBuffer newPassword = new StringBuffer();
			if (password == null || password.length() == 0) {
				result = new JsonResult(false, "密码不能为空");
				return;
			}
			String[] passwords = password.split("@");
			for (int i = 0; i < passwords.length; i++) {
				String pwd = passwords[i];
				pwd = Base64Util.Base64DecodeReplaceSpecialChar(pwd);
				if (password == null) {
					result = new JsonResult(false, "密码获取失败");
					return;
				}
				// 密码加密处理
				JniPassword jniNative = JniPassword.getInstance();
				boolean bLoad = JniPassword.loadLibrary("JniPassword");
				if (bLoad) {
					newPassword.append(jniNative.getSha512Value(pwd));
					if (i < passwords.length - 1) {
						newPassword.append("@");
					}
				} else {
					result = new JsonResult(false, "密码获取失败");
				}
			}
			result = new JsonResult(true, "密码获取成功", newPassword.toString());
		} catch (Exception e) {
			e.printStackTrace();
			SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			result = new JsonResult(false, "密码获取异常");
		} finally {
			super.outJson(response, result);
		}
	}
	
}
