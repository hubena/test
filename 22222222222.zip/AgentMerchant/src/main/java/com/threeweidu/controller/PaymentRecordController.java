package com.threeweidu.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.threeweidu.config.DefaultProfile;
import com.threeweidu.entity.PaymentRecord;
import com.threeweidu.service.PaymentRecordService;
import com.threeweidu.utils.Null2;
import com.threeweidu.utils.SystemExceptionUtil;
import com.threeweidu.utils.export.FilesOperate;
import com.threeweidu.utils.mybatis.DBContextHolder;
import com.threeweidu.view.req.page.Page;
import com.threeweidu.view.result.EasyUIData;
import com.threeweidu.view.result.JsonResult;


@Controller
@RequestMapping(value="/merchant/payment/record")
public class PaymentRecordController extends BaseController {
	
	@Autowired
	private PaymentRecordService paymentRecordService;
	
	@RequestMapping(value="/list")
	public String paymentRecord(){
		return "merchant/paymentRecord";
	}
	
	@RequestMapping(value="/list/find")
	@ResponseBody
	public void paymentRecordList(
			@RequestParam(required = true, value = "page", defaultValue = "1") Long pageNo, 
			@RequestParam(required = true, value = "rows", defaultValue = "10") Long pageSize, 
			@RequestParam(required = true, value = "sort", defaultValue = "pr.ordid") String sortField, 
			@RequestParam(required = true, value = "order", defaultValue = "desc") String sortType, 
			PaymentRecord paymentRecord,
			HttpServletRequest request, HttpServletResponse response) {
		EasyUIData uiData = null;
		Page page = new Page(pageNo, pageSize, sortField, sortType);
		try {
			String agentId = getAgentId(request);
			if (Null2.isNull(agentId)) {
				uiData = new EasyUIData(false, "代理商编号不能为空", 0L, Collections.EMPTY_LIST);
				return;
			}
			uiData = checkForDownlod(paymentRecord);
			if (!uiData.isSuccess()) {
				return;
			}
			paymentRecord.setAgentId(agentId);
			paymentRecord.setMerIds(super.getMerIdsByOrder(request));
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_PAYMENT);
			uiData = paymentRecordService.findList(paymentRecord, page);
		} catch (Exception e) {
			e.printStackTrace();
			SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			uiData = new EasyUIData(false, "查询异常,请联系管理员", 0L, Collections.EMPTY_LIST);
		}finally{
			super.outJson(response, uiData);
		}
	}
	
	private boolean checkDate(String createEndTime, String createStartTime) {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			Date start = format.parse(createStartTime);
			Date end = format.parse(createEndTime);
			long day = (end.getTime() - start.getTime()) / (1000L * 60L * 60L * 24L);
			if(day > (6 * 31)){
				return false;
			}
		} catch (ParseException e) {
			return false;
		}
		return true;
	}

	/**
	 * 导出报表
	 */
	@RequestMapping(value="/exportExcel")
	@ResponseBody
	public void exportExcel(
			@RequestParam(required = true, value = "page", defaultValue = "1") Long pageNo, 
			@RequestParam(required = true, value = "rows", defaultValue = "10") Long pageSize, 
			@RequestParam(required = true, value = "sort", defaultValue = "pr.createTime") String sortField, 
			@RequestParam(required = true, value = "order", defaultValue = "desc") String sortType, 
			PaymentRecord paymentRecord,
			ModelMap modelMap,
			HttpServletRequest request, HttpServletResponse response){
		JsonResult result = new JsonResult();
		try {
			String agentId = getAgentId(request);
			if (Null2.isNull(agentId)) {
				result = new JsonResult(false, "代理商编号不能为空");
				return;				
			}
			if(Null2.isNull(paymentRecord.getCreateStartTime()) || Null2.isNull(paymentRecord.getCreateEndTime())){
				result = new JsonResult(false, "导出报表时，时间为必设置项");
				return;
			}
			if(!checkDate(paymentRecord.getCreateEndTime(), paymentRecord.getCreateStartTime())){
				result = new JsonResult(false, "导出报表时，时间间隔最大为6个月");
				return;
			}
			paymentRecord.setAgentId(agentId);
			paymentRecord.setMerIds(super.getMerIdsByOrder(request));
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_PAYMENT);
			if (Null2.isNotNull(paymentRecord.getExportType()) && "CSV".equals(paymentRecord.getExportType().toUpperCase())) {
				result = paymentRecordService.doExportCSV(paymentRecord, new Page(pageNo, pageSize, sortField, sortType));
			} else if (Null2.isNotNull(paymentRecord.getExportType()) && "XLS".equals(paymentRecord.getExportType().toUpperCase())) {
				result = paymentRecordService.doExportExcel(paymentRecord, new Page(pageNo, pageSize, sortField, sortType));
			} else {
				result = new JsonResult(false, "导出类型错误");
			}
			
			if(!result.getSuccess()){
				return;
			} 
		} catch (Exception e) {
			e.printStackTrace();
			result = new JsonResult(false, "获取报表数据异常,请联系管理员");
			return;
		} finally{
			if(!result.getSuccess()){				
				super.outJson(response, result);
			}
		}
		String path = (String) result.getData();
		FilesOperate.download(response, path, "merchant");
	}

	@RequestMapping(value="/asynNotice")
	@ResponseBody
	public void asynNotice(HttpServletRequest request, HttpServletResponse response) {
		JsonResult result = null;
		try {
			String rechargeUrl = request.getParameter("url");
			StringBuffer returnMsg = new StringBuffer();
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_PAYMENT);
			String ordid = request.getParameter("ordid");
			PaymentRecord record = paymentRecordService.findAsynByOrdId(ordid);
			if(Null2.isNull(record) || "".equals(record.getAsynState())){
				result = new JsonResult(false, "订单号" + ordid + "不可异步通知！");
				return;
			}
			String synParam = record.getSynParam();
			String url = record.getAsynNotificationUrl();
			if (Null2.isNotNull(rechargeUrl)) {
				url = rechargeUrl;
			}
			if (StringUtils.isEmpty(url) || StringUtils.isEmpty(synParam)) {
				result = new JsonResult(false, "订单号" + ordid + "参数异常，异步通知失败！");
				return;
			}
			result = paymentRecordService.asynNotice(record, ordid, rechargeUrl, returnMsg);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			result = new JsonResult(false, "服务器异常");
		} finally {
			super.outJson(response, result);
		}
	}
	
	
	@RequestMapping(value="/rechargeNotice")
	@ResponseBody
	public void rechargeNotice(HttpServletRequest request, HttpServletResponse response) {
		JsonResult result = null;
		try {
			String rechargeUrl = request.getParameter("url");
			StringBuffer returnMsg = new StringBuffer();
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_PAYMENT);
			String ordIds = request.getParameter("ordIds");
			if(Null2.isNull(ordIds)){
				result = new JsonResult(false, "订单号不可为空！");
				return;
			}
			String[] ordids = ordIds.split(",");
			for (int i = 0; i < ordids.length; i++) {
				String ordid = ordids[0];
				DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_PAYMENT);
				PaymentRecord record = paymentRecordService.findAsynByOrdId(ordid);
				if(Null2.isNotNull(record) && Null2.isNotNull(record.getOrdidState()) && 1001 == record.getOrdidState()){
					result = paymentRecordService.notice(record);
					continue;
				}
				if(Null2.isNull(record) || "".equals(record.getAsynState())){
					result = new JsonResult(false, "订单号" + ordid + "不存在，不可异步充值！");
					continue;
				}
				DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_SHOP);
				result = checkRecord(record);
				if(result.getSuccess()){
					rechargeUrl = result.getMessage();
				} else {
					continue;
				}
				String synParam = record.getSynParam();
				String url = record.getAsynNotificationUrl();
				if (Null2.isNotNull(rechargeUrl)) {
					url = rechargeUrl;
				}
				if (StringUtils.isEmpty(url) || StringUtils.isEmpty(synParam)) {
					result = new JsonResult(false, "订单号" + ordid + "参数异常，异步通知充值失败！");
					continue;
				}
				DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_PAYMENT);
				result = paymentRecordService.asynNotice(record, ordid, rechargeUrl, returnMsg);
			}			
		} catch (Exception e) {
			e.printStackTrace();
			try {
				SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			result = new JsonResult(false, "服务器异常");
		} finally {
			super.outJson(response, result);
		}
	}

	private JsonResult checkRecord(PaymentRecord record) {
		JsonResult result = new JsonResult(false, "订单号" + record.getOrdid() + "已通知到商户余额充值，无需再通知！");
		PaymentRecord paymentRecord = paymentRecordService.findRechargeRecordByMerIdAndBusinessOrdid(record.getMerId(), record.getBusinessOrdid());
		if(Null2.isNull(paymentRecord)){
			result = new JsonResult(true, DefaultProfile.API_RECHARGE_URL);
		} else if("1000".equals(paymentRecord.getRechargeState())){
			result = new JsonResult(true, DefaultProfile.RECHARGE_URL);
		}
		return result;
	}
	
	
	/*
	 * 判断数据是否合法及准备查询条件
	 */
	private EasyUIData checkForDownlod(PaymentRecord paymentRecord) {
		EasyUIData uiData = new EasyUIData(true, "");
		String createStartTime = paymentRecord.getCreateStartTime();
		String createEndTime = paymentRecord.getCreateEndTime();
		if (Null2.isNull(createStartTime) || Null2.isNull(createEndTime)) {
			return new EasyUIData(false, "交易时间为必设置项", 0L, Collections.EMPTY_LIST);
		}
		if (!checkDate(createEndTime, createStartTime)) {
			return new EasyUIData(false, "发送时间间隔最大为6个月", 0L, Collections.EMPTY_LIST);
		}
		return uiData;
	}
}
