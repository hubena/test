package com.threeweidu.controller;

import java.util.Collections;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.threeweidu.entity.PaymentRecordProfitStatistics;
import com.threeweidu.service.PaymentRecordProfitStatisticsService;
import com.threeweidu.utils.Null2;
import com.threeweidu.utils.SystemExceptionUtil;
import com.threeweidu.utils.mybatis.DBContextHolder;
import com.threeweidu.view.req.page.Page;
import com.threeweidu.view.result.EasyUIData;

@Controller
@RequestMapping(value="/merchant/supplierPaymentStatistics")
public class PaymentRecordProfitStatisticsController extends BaseController {
	
	@Autowired
	private PaymentRecordProfitStatisticsService statisticsService;
		
	@RequestMapping(value="/list/find")
	@ResponseBody
	public void paymentRecordList(
			@RequestParam(required = true, value = "page", defaultValue = "1") Long pageNo, 
			@RequestParam(required = true, value = "rows", defaultValue = "10") Long pageSize, 
			@RequestParam(required = true, value = "sort", defaultValue = "createTime") String sortField, 
			@RequestParam(required = true, value = "order", defaultValue = "desc") String sortType, 
			PaymentRecordProfitStatistics statistics,
			HttpServletRequest request, HttpServletResponse response) {
		EasyUIData uiData = null;
		Page page = new Page(pageNo, pageSize, sortField, sortType);
		try {
			DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_PAYMENT);
			if(Null2.isNotNull(statistics) && Null2.isNotNull(statistics.getStatisticsID())){
				try {
					Long.parseLong(statistics.getStatisticsID());
				} catch (Exception e) {
					uiData = new EasyUIData(true, "数据为空", 0L, Collections.EMPTY_LIST);
					return;
				}
			}
			uiData = statisticsService.findList(statistics, page);
		} catch (Exception e) {
			e.printStackTrace();
			SystemExceptionUtil.getInstance().addSysExceptionLog(e);
			uiData = new EasyUIData(false, "查询异常,请联系管理员", 0L, Collections.EMPTY_LIST);
		}finally{
			super.outJson(response, uiData);
		}
	}
	
}
