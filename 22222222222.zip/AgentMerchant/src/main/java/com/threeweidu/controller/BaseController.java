package com.threeweidu.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;

import com.threeweidu.entity.utils.LoginUser;
import com.threeweidu.service.MerchantManageService;
import com.threeweidu.supplier.utils.JsonUtils;
import com.threeweidu.utils.APIKeyUtils;
import com.threeweidu.utils.Null2;
import com.threeweidu.utils.mybatis.DBContextHolder;

/**
 * BaseController
 * <p>
 * 响应页面的公用方法
 * </p>
 * 
 * @author
 * 
 */
public class BaseController {

	@Autowired
	private MerchantManageService merchantManageService;
	
	public void outJson(HttpServletResponse response, Object object) {
		PrintWriter out = null;
		try {
			out = response.getWriter();
			String json = JsonUtils.objectToJson(object);
			response.setContentType("text/html;charset=utf-8");
			out.write(json);
			out.flush();
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void outString(HttpServletResponse response, String msg) {
		PrintWriter out = null;
		try {
			out = response.getWriter();
			response.setContentType("text/html;charset=utf-8");
			out.write(msg);
			out.flush();
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 获取代理商ID根据优先级
	 */
	public String getAgentIdByOrder(HttpServletRequest request){
		String value = getSecAgentId(request);
		if(Null2.isNull(value)){
			value = getAgentId(request);
		}
		return value;
	}
	/**
	 * 获取二级代理商ID
	 */
	public String getSecAgentId(HttpServletRequest request){
		String apikey = request.getParameter("apikey");
		LoginUser value = APIKeyUtils.getInstance().getData(apikey);
		return value.getSecAgentId();
	}
	
	/**
	 * 获取代理商ID
	 */
	public String getAgentId(HttpServletRequest request){
		String apikey = request.getParameter("apikey");
		LoginUser value = APIKeyUtils.getInstance().getData(apikey);
		return value.getAgentId();
	}
	
	/**
	 * 设置apikey
	 */
	public String getAPIKey(LoginUser user){
		String apikey = APIKeyUtils.getInstance().setData(user);
		return apikey;
	}
	
	/**
	 * 退出清除apikey
	 * @param request
	 */
	public boolean removeAPIkey(HttpServletRequest request) {
		String apikey = request.getParameter("apikey");
		APIKeyUtils.getInstance().removeData(apikey);
		return true;
	}

	/**
	 * 获取代理商下商户列表根据优先级
	 */
	public String getMerIdsByOrder(HttpServletRequest request){
		String merIds = getMerIdsBySecAgent(request);
		if(Null2.isNull(merIds) || "''".equals(merIds)){
			merIds = getMerIds(request);
		}
		return merIds;
	}
	/**
	 * 获取代理商下商户列表
	 */
	public String getMerIds(HttpServletRequest request) {
		DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_PAYMENT);
		return merchantManageService.getMerIds(getAgentId(request));
	}
	/**
	 * 获取二级代理商下商户列表
	 */
	public String getMerIdsBySecAgent(HttpServletRequest request) {
		DBContextHolder.setDBType(DBContextHolder.DATA_SOURCE_PAYMENT);
		return merchantManageService.getMerIdsBySec(getSecAgentId(request));
	}
	
	/**
	 * 获取登录用户
	 */
	public LoginUser getLoginUser(HttpServletRequest request){
		String apikey = request.getParameter("apikey");
		LoginUser value = APIKeyUtils.getInstance().getData(apikey);
		return value;
	}
}
