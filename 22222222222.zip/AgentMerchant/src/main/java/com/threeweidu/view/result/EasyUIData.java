package com.threeweidu.view.result;

import java.io.Serializable;
import java.util.List;

public class EasyUIData implements Serializable {

	private static final long serialVersionUID = 1L;

	private boolean success;

	private String message;

	private Long total;

	private List<?> rows;

	private List<?> footer;

	private Object data;

	public EasyUIData() {
		
	}

	public EasyUIData(boolean success, String message) {
		this.success = success;
		this.message = message;
	}

	public EasyUIData(boolean success, String message, Long total, List<?> rows) {
		this.success = success;
		this.message = message;
		this.total = total;
		this.rows = rows;
	}

	public EasyUIData(boolean success, String message, Long total, List<?> rows, List<?> footer) {
		this(success, message, total, rows);
		this.footer = footer;
	}

	public EasyUIData(boolean success, String message, Long total, List<?> rows, List<?> footer, Object data) {
		this(success, message, total, rows);
		this.footer = footer;
		this.data = data;
	}

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Long getTotal() {
		return total;
	}

	public void setTotal(Long total) {
		this.total = total;
	}

	public List<?> getRows() {
		return rows;
	}

	public void setRows(List<?> rows) {
		this.rows = rows;
	}

	public List<?> getFooter() {
		return footer;
	}

	public void setFooter(List<?> footer) {
		this.footer = footer;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

}
