package com.threeweidu.entity;

import java.io.Serializable;

public class MerchantTradeCount implements Serializable{
	private static final long serialVersionUID = 1L;
	private String merId;	//商户编号
	private String tradeDate;
	private Long tradeCount;
	private Long transferCount;//转账总金额
	private Long rechargeCount;//充值总金额
	private Long cashCount;//提现总金额
	private String addtime;
	private String agentId;//
	private String tradedateStart;
	private String tradedateEnd;
	private String merName;
	private Long balance;
	private String minTradeCount;
	private String maxTradeCount;
	private Double minTradeCountL;
	private Double maxTradeCountL;
	private Long transferCountFee;//转账总手续费
	private Long initBalance;//当日初始余额
	private Long rechargeCountFee;//充值总手续费
	private String merIds;

	public String getMerId() {
		return merId;
	}
	public void setMerId(String merId) {
		this.merId = merId;
	}
	public String getTradeDate() {
		return tradeDate;
	}
	public void setTradeDate(String tradeDate) {
		this.tradeDate = tradeDate;
	}
	public Long getTradeCount() {
		return tradeCount;
	}
	public void setTradeCount(Long tradeCount) {
		this.tradeCount = tradeCount;
	}
	public String getAddtime() {
		return addtime;
	}
	public void setAddtime(String addtime) {
		this.addtime = addtime;
	}
	public String getAgentId() {
		return agentId;
	}
	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}
	public String getTradedateStart() {
		return tradedateStart;
	}
	public void setTradedateStart(String tradedateStart) {
		this.tradedateStart = tradedateStart;
	}
	public String getTradedateEnd() {
		return tradedateEnd;
	}
	public void setTradedateEnd(String tradedateEnd) {
		this.tradedateEnd = tradedateEnd;
	}
	public String getMerName() {
		return merName;
	}
	public void setMerName(String merName) {
		this.merName = merName;
	}
	public Long getTransferCount() {
		return transferCount;
	}
	public void setTransferCount(Long transferCount) {
		this.transferCount = transferCount;
	}
	public Long getRechargeCount() {
		return rechargeCount;
	}
	public void setRechargeCount(Long rechargeCount) {
		this.rechargeCount = rechargeCount;
	}
	public Long getCashCount() {
		return cashCount;
	}
	public void setCashCount(Long cashCount) {
		this.cashCount = cashCount;
	}
	public Long getBalance() {
		return balance;
	}
	public void setBalance(Long balance) {
		this.balance = balance;
	}
	public String getMinTradeCount() {
		return minTradeCount;
	}
	public void setMinTradeCount(String minTradeCount) {
		this.minTradeCount = minTradeCount;
	}
	public String getMaxTradeCount() {
		return maxTradeCount;
	}
	public void setMaxTradeCount(String maxTradeCount) {
		this.maxTradeCount = maxTradeCount;
	}
	public Double getMinTradeCountL() {
		return minTradeCountL;
	}
	public void setMinTradeCountL(Double minTradeCountL) {
		this.minTradeCountL = minTradeCountL;
	}
	public Double getMaxTradeCountL() {
		return maxTradeCountL;
	}
	public void setMaxTradeCountL(Double maxTradeCountL) {
		this.maxTradeCountL = maxTradeCountL;
	}
	public Long getTransferCountFee() {
		return transferCountFee;
	}
	public void setTransferCountFee(Long transferCountFee) {
		this.transferCountFee = transferCountFee;
	}
	public Long getInitBalance() {
		return initBalance;
	}
	public void setInitBalance(Long initBalance) {
		this.initBalance = initBalance;
	}
	public Long getRechargeCountFee() {
		return rechargeCountFee;
	}
	public void setRechargeCountFee(Long rechargeCountFee) {
		this.rechargeCountFee = rechargeCountFee;
	}
	public String getMerIds() {
		return merIds;
	}
	public void setMerIds(String merIds) {
		this.merIds = merIds;
	}		      
}
