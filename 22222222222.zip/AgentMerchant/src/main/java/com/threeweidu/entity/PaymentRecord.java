package com.threeweidu.entity;

import java.io.Serializable;

public class PaymentRecord implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private String ordid; // 三维度订单号
	private String businessOrdid; // 商户订单号
	private String orderName; // 订单名称
	private Long tradeMoney; // 交易金额(分)
	private String tradeCardNo; // 消费卡号
	private String selfParam; // 商户自定义参数
	private Integer ordidState; // 订单状态
	private String merId; // 商户编号
	private String terId; // 终端编号
	private Integer payType; // 业务类型 1001 快捷支付(从表有数据) 1002 刷卡器支付(从表没数据)
	private String bankOrderId;// 银行流水号
	private String returnMoney;// 通道返回金额
	private String respCode;// 通道返回状态
	private String respDesc;// 通道返回状态描述
	private String returnTime;// 通道返回时间
	private String asynNotificationUrl;
	private Integer asynCount;
	private String asynTime;
	private Integer accountFlag;// 对账状态
	private String accountTime;// 对账时间
	private String accountMan;// 对账人
	private String createTime;// 创建时间
	private Integer gallerType; // 通道类型，1001平安，1002 易宝，1003 汇付天下，1004 京东网关
	
	//QuickPaymentRecord表信息
	private String bankCode;				//银行编号
	private String bankName;				//银行名称
	private String cardNo;					//卡号
	private String cardholder;				//持卡人
	private String idCard;					//身份证
	private String Phone;					//手机号码
		
	//QuickPaymentLiquidateReport信息
	private String quiId;				//主键 20位
	private String batchNumber;			//批次号
	private Long realityMoney;		//实际交易金额
	private String tradeTime;			//交易时间
	private Integer yield;				//商户扣率(乘以10000存入数据库中)
	
	private String agentId;//代理商编号
	private String createStartTime;//开始时间
	private String createEndTime;//结束时间
	private String repealId;//退款订单号
	
	private String agentAuditState;//渠道结算状态
	private String agentAmount;//渠道利润
	private Integer deductionRate;//结算扣率
	//private Double deductionFee;//手续费
	private Double auditAmount;//结算金额	
	
	private String agentProfit;//渠道利润
	private String deductionState = "1000";//1000无结算信息1001未结算1002;结算处理中1003;已结算1004,结算失败 
	private String deductionFee;//手续费  交易金额  * 结算扣率
	private String deductionMoney;//结算金额  交易金额 - 手续费
	
	private String asynState;
	private String synParam; // 通知参数
	private String apiKey;
	
	private String rechargeState;
	private String asynSupState;
	private String merIds;
	private String exportType;
	private String secAgentAccount;
	private String secAgentName;
	
	public String getCreateStartTime() {
		return createStartTime;
	}
	public void setCreateStartTime(String createStartTime) {
		this.createStartTime = createStartTime;
	}
	public String getCreateEndTime() {
		return createEndTime;
	}
	public void setCreateEndTime(String createEndTime) {
		this.createEndTime = createEndTime;
	}
	public String getRepealId() {
		return repealId;
	}
	public void setRepealId(String repealId) {
		this.repealId = repealId;
	}
	public String getAgentId() {
		return agentId;
	}
	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}
	public String getOrdid() {
		return ordid;
	}
	public void setOrdid(String ordid) {
		this.ordid = ordid;
	}
	public String getBusinessOrdid() {
		return businessOrdid;
	}
	public void setBusinessOrdid(String businessOrdid) {
		this.businessOrdid = businessOrdid;
	}
	public String getOrderName() {
		return orderName;
	}
	public void setOrderName(String orderName) {
		this.orderName = orderName;
	}
	public Long getTradeMoney() {
		return tradeMoney;
	}
	public void setTradeMoney(Long tradeMoney) {
		this.tradeMoney = tradeMoney;
	}
	public String getTradeCardNo() {
		return tradeCardNo;
	}
	public void setTradeCardNo(String tradeCardNo) {
		this.tradeCardNo = tradeCardNo;
	}
	public String getSelfParam() {
		return selfParam;
	}
	public void setSelfParam(String selfParam) {
		this.selfParam = selfParam;
	}
	public Integer getOrdidState() {
		return ordidState;
	}
	public void setOrdidState(Integer ordidState) {
		this.ordidState = ordidState;
	}
	public String getMerId() {
		return merId;
	}
	public void setMerId(String merId) {
		this.merId = merId;
	}
	public String getTerId() {
		return terId;
	}
	public void setTerId(String terId) {
		this.terId = terId;
	}
	public Integer getPayType() {
		return payType;
	}
	public void setPayType(Integer payType) {
		this.payType = payType;
	}
	public String getBankOrderId() {
		return bankOrderId;
	}
	public void setBankOrderId(String bankOrderId) {
		this.bankOrderId = bankOrderId;
	}
	public String getRespCode() {
		return respCode;
	}
	public void setRespCode(String respCode) {
		this.respCode = respCode;
	}
	public String getRespDesc() {
		return respDesc;
	}
	public void setRespDesc(String respDesc) {
		this.respDesc = respDesc;
	}
	public String getReturnTime() {
		return returnTime;
	}
	public void setReturnTime(String returnTime) {
		this.returnTime = returnTime;
	}
	public String getAsynNotificationUrl() {
		return asynNotificationUrl;
	}
	public void setAsynNotificationUrl(String asynNotificationUrl) {
		this.asynNotificationUrl = asynNotificationUrl;
	}
	public Integer getAsynCount() {
		return asynCount;
	}
	public void setAsynCount(Integer asynCount) {
		this.asynCount = asynCount;
	}
	public String getAsynTime() {
		return asynTime;
	}
	public void setAsynTime(String asynTime) {
		this.asynTime = asynTime;
	}
	public Integer getAccountFlag() {
		return accountFlag;
	}
	public void setAccountFlag(Integer accountFlag) {
		this.accountFlag = accountFlag;
	}
	public String getAccountTime() {
		return accountTime;
	}
	public void setAccountTime(String accountTime) {
		this.accountTime = accountTime;
	}
	public String getAccountMan() {
		return accountMan;
	}
	public void setAccountMan(String accountMan) {
		this.accountMan = accountMan;
	}
	public String getCreateTime() {
		return createTime;
	}
	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}
	public Integer getGallerType() {
		return gallerType;
	}
	public void setGallerType(Integer gallerType) {
		this.gallerType = gallerType;
	}
	public String getBankCode() {
		return bankCode;
	}
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getCardNo() {
		return cardNo;
	}
	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}
	public String getCardholder() {
		return cardholder;
	}
	public void setCardholder(String cardholder) {
		this.cardholder = cardholder;
	}
	public String getIdCard() {
		return idCard;
	}
	public void setIdCard(String idCard) {
		this.idCard = idCard;
	}
	public String getPhone() {
		return Phone;
	}
	public void setPhone(String phone) {
		Phone = phone;
	}
	public String getQuiId() {
		return quiId;
	}
	public void setQuiId(String quiId) {
		this.quiId = quiId;
	}
	public String getBatchNumber() {
		return batchNumber;
	}
	public void setBatchNumber(String batchNumber) {
		this.batchNumber = batchNumber;
	}
	public Long getRealityMoney() {
		return realityMoney;
	}
	public void setRealityMoney(Long realityMoney) {
		this.realityMoney = realityMoney;
	}
	public String getTradeTime() {
		return tradeTime;
	}
	public void setTradeTime(String tradeTime) {
		this.tradeTime = tradeTime;
	}
	public Integer getYield() {
		return yield;
	}
	public void setYield(Integer yield) {
		this.yield = yield;
	}
	public Integer getAuditMoneyToBank() {
		return auditMoneyToBank;
	}
	public void setAuditMoneyToBank(Integer auditMoneyToBank) {
		this.auditMoneyToBank = auditMoneyToBank;
	}
	public Integer getMemberAuditAmount() {
		return memberAuditAmount;
	}
	public void setMemberAuditAmount(Integer memberAuditAmount) {
		this.memberAuditAmount = memberAuditAmount;
	}
	public Integer getAuditState() {
		return auditState;
	}
	public void setAuditState(Integer auditState) {
		this.auditState = auditState;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	private Integer auditMoneyToBank;	//手续费金额
	private Integer memberAuditAmount;	//会员清算金额
	private Integer auditState;			//清算状态(1001-未清算,1002-清算处理中,1003-已清算,1004-清算失败)

	public String getReturnMoney() {
		return returnMoney;
	}
	public void setReturnMoney(String returnMoney) {
		this.returnMoney = returnMoney;
	}
	public String getAgentAmount() {
		return agentAmount;
	}
	public void setAgentAmount(String agentAmount) {
		this.agentAmount = agentAmount;
	}
	public Integer getDeductionRate() {
		return deductionRate;
	}
	public void setDeductionRate(Integer deductionRate) {
		this.deductionRate = deductionRate;
	}
	public String getDeductionFee() {
		return deductionFee;
	}
	public void setDeductionFee(String deductionFee) {
		this.deductionFee = deductionFee;
	}
	public Double getAuditAmount() {
		return auditAmount;
	}
	public void setAuditAmount(Double auditAmount) {
		this.auditAmount = auditAmount;
	}
	public String getAgentAuditState() {
		return agentAuditState;
	}
	public void setAgentAuditState(String agentAuditState) {
		this.agentAuditState = agentAuditState;
	}
	public String getAgentProfit() {
		return agentProfit;
	}
	public void setAgentProfit(String agentProfit) {
		this.agentProfit = agentProfit;
	}
	public String getDeductionState() {
		return deductionState;
	}
	public void setDeductionState(String deductionState) {
		this.deductionState = deductionState;
	}
	public String getDeductionMoney() {
		return deductionMoney;
	}
	public void setDeductionMoney(String deductionMoney) {
		this.deductionMoney = deductionMoney;
	}
	public String getAsynState() {
		return asynState;
	}
	public void setAsynState(String asynState) {
		this.asynState = asynState;
	}
	public String getSynParam() {
		return synParam;
	}
	public void setSynParam(String synParam) {
		this.synParam = synParam;
	}
	public String getApiKey() {
		return apiKey;
	}
	public void setApiKey(String apiKey) {
		this.apiKey = apiKey;
	}
	public String getRechargeState() {
		return rechargeState;
	}
	public void setRechargeState(String rechargeState) {
		this.rechargeState = rechargeState;
	}
	public String getAsynSupState() {
		return asynSupState;
	}
	public void setAsynSupState(String asynSupState) {
		this.asynSupState = asynSupState;
	}
	public String getMerIds() {
		return merIds;
	}
	public void setMerIds(String merIds) {
		this.merIds = merIds;
	}
	public String getExportType() {
		return exportType;
	}
	public void setExportType(String exportType) {
		this.exportType = exportType;
	}
	public String getSecAgentAccount() {
		return secAgentAccount;
	}
	public void setSecAgentAccount(String secAgentAccount) {
		this.secAgentAccount = secAgentAccount;
	}
	public String getSecAgentName() {
		return secAgentName;
	}
	public void setSecAgentName(String secAgentName) {
		this.secAgentName = secAgentName;
	}
	
}
