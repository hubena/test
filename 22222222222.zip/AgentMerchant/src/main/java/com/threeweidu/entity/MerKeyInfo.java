package com.threeweidu.entity;

import java.io.Serializable;

public class MerKeyInfo implements Serializable{
	private static final long serialVersionUID = 1L;
	private String merId;
	private String swiftpassId;
	private String swiftpassTradeKey;
	private String addDate;
	private String updateDate;
	public String getMerId() {
		return merId;
	}
	public void setMerId(String merId) {
		this.merId = merId;
	}
	public String getSwiftpassId() {
		return swiftpassId;
	}
	public void setSwiftpassId(String swiftpassId) {
		this.swiftpassId = swiftpassId;
	}
	public String getSwiftpassTradeKey() {
		return swiftpassTradeKey;
	}
	public void setSwiftpassTradeKey(String swiftpassTradeKey) {
		this.swiftpassTradeKey = swiftpassTradeKey;
	}
	public String getAddDate() {
		return addDate;
	}
	public void setAddDate(String addDate) {
		this.addDate = addDate;
	}
	public String getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}

}
