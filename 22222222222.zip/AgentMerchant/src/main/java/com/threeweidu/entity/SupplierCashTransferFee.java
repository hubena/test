package com.threeweidu.entity;

import java.io.Serializable;

public class SupplierCashTransferFee implements Serializable{
	private static final long serialVersionUID = 1L;
	private String supplierId;
	private String withdrawFeeType;
	private String withdrawFeeTypeValue;
	private String ithdrawMaxfee;
	private String rechargeFeeType;
	private String rechargeFeeTypeValue;
	private String rechargeMaxFee;
	private String addMan;
	private String addTime;
	private String isRealPay;
	public String getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	public String getWithdrawFeeType() {
		return withdrawFeeType;
	}
	public void setWithdrawFeeType(String withdrawFeeType) {
		this.withdrawFeeType = withdrawFeeType;
	}
	public String getWithdrawFeeTypeValue() {
		return withdrawFeeTypeValue;
	}
	public void setWithdrawFeeTypeValue(String withdrawFeeTypeValue) {
		this.withdrawFeeTypeValue = withdrawFeeTypeValue;
	}
	public String getIthdrawMaxfee() {
		return ithdrawMaxfee;
	}
	public void setIthdrawMaxfee(String ithdrawMaxfee) {
		this.ithdrawMaxfee = ithdrawMaxfee;
	}
	public String getRechargeFeeType() {
		return rechargeFeeType;
	}
	public void setRechargeFeeType(String rechargeFeeType) {
		this.rechargeFeeType = rechargeFeeType;
	}
	public String getRechargeFeeTypeValue() {
		return rechargeFeeTypeValue;
	}
	public void setRechargeFeeTypeValue(String rechargeFeeTypeValue) {
		this.rechargeFeeTypeValue = rechargeFeeTypeValue;
	}
	public String getRechargeMaxFee() {
		return rechargeMaxFee;
	}
	public void setRechargeMaxFee(String rechargeMaxFee) {
		this.rechargeMaxFee = rechargeMaxFee;
	}
	public String getAddMan() {
		return addMan;
	}
	public void setAddMan(String addMan) {
		this.addMan = addMan;
	}
	public String getAddTime() {
		return addTime;
	}
	public void setAddTime(String addTime) {
		this.addTime = addTime;
	}
	public String getIsRealPay() {
		return isRealPay;
	}
	public void setIsRealPay(String isRealPay) {
		this.isRealPay = isRealPay;
	}
}
