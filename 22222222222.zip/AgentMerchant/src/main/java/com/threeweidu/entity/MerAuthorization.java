package com.threeweidu.entity;

import java.io.Serializable;

public class MerAuthorization implements Serializable{
	private static final long serialVersionUID = 1L;
	private Integer attributeId;	//主键自增	属性ID
	private String merId;	//外键	商户编号
	private String	paymentId;	//外键	支付方式ID		
	private String	deductionRate; //扣率（一万为单位千分之八）
	private Integer	billingCycle;	//结算周期 单位：天
	private String	addTime;	//添加时间		
	private String	updateTime;	//更新时间
	private MerKeyInfo merKeyInfo;//微信商户授权支付方式
	private Integer paymentName;// 支付方式 1001 易宝网关 1002 京东快捷支付 1003 微信扫码 1004微信公众号支付 1005 鼎付外卡支付
	private String agentId; // 代理商编号
	private String isRealPay; // 是否实时到账 1001:非实时 1002：实时
	public Integer getAttributeId() {
		return attributeId;
	}
	public void setAttributeId(Integer attributeId) {
		this.attributeId = attributeId;
	}
	public String getMerId() {
		return merId;
	}
	public void setMerId(String merId) {
		this.merId = merId;
	}
	public String getPaymentId() {
		return paymentId;
	}
	public void setPaymentId(String paymentId) {
		this.paymentId = paymentId;
	}
	public String getDeductionRate() {
		return deductionRate;
	}
	public void setDeductionRate(String deductionRate) {
		this.deductionRate = deductionRate;
	}
	public Integer getBillingCycle() {
		return billingCycle;
	}
	public void setBillingCycle(Integer billingCycle) {
		this.billingCycle = billingCycle;
	}
	public String getAddTime() {
		return addTime;
	}
	public void setAddTime(String addTime) {
		this.addTime = addTime;
	}
	public String getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}
	public MerKeyInfo getMerKeyInfo() {
		return merKeyInfo;
	}
	public void setMerKeyInfo(MerKeyInfo merKeyInfo) {
		this.merKeyInfo = merKeyInfo;
	}
	public String getAgentId() {
		return agentId;
	}
	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}
	public String getIsRealPay() {
		return isRealPay;
	}
	public void setIsRealPay(String isRealPay) {
		this.isRealPay = isRealPay;
	}
	public Integer getPaymentName() {
		return paymentName;
	}
	public void setPaymentName(Integer paymentName) {
		this.paymentName = paymentName;
	}

}
