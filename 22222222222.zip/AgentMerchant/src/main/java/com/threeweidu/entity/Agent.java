package com.threeweidu.entity;

import java.io.Serializable;

public class Agent implements Serializable{
	private static final long serialVersionUID = 1L;
	private String	agentId;	//代理商编号
	private String	agentName;	//代理商名称
	private String	agentAddress;	//代理商地址
	private String	agentPhone;	//代理商电话
	private String	passwd;		//代理商账号密码
	private String	agentType;	//代理商类型1001 对外代理商1002 收银台
	private String	agentAccount;	//账号(可用于登录平台,不可有中文)
	private String	email;		//邮箱
	private String	agentHeadImg;		//审核人
	private String	agentState;		//代理商状态1001 无效1002 有效
	private String	lastLoginTime;			//最后登录时间
	private int 	loginFailureNum;	//登录失败次数
	private String	verifyState;		//审核状态1001 未审核1002 审核通过1003 审核失败1004 已过期
	private String 	verifyRemark;		//审核意见
		
	private String	verifyPassTime;		//审核通过时间
	private String	verifyMan;		//审核人
	private String	addMan;			
	private String 	addTime;
	private String	editMan;
	private String 	editTime;
	
	private String withdrawDiscountMaxFee;//提现-扣率-封顶手续费
	private String withdrawDiscountFee;//提现-扣率-费率
	private String withdrawFixedFee;//提现-固定-单笔手续费
	private String rechargeDiscountMaxFee;//充值-扣率-封顶手续费
	private String rechargeDiscountFee;//充值-扣率-费率
	private String rechargeFixedFee;//充值-固定-单笔手续费
	
	private String apikey;//apikey
	private String domainName;
	private String logoUrl;
	private String userType;////1001:一级渠道商，1002:二级渠道商
	
	
	private Long totalRecharge;//昨日充值总金额
	private Long usedAdvanceMoney;//当日已用垫资
	private Long usableMaxAdvanceMoney;//当日最大可用垫资 = 实际垫资金额 + 昨日充值总金额
	private Long usableAdvanceMoney;//目前可用垫资 = 当日最大可用垫资 - 当日已用垫资 
	private String batch;//批次号
	private Long canCashMoney;//可提现余额
	private Long cantCashMoney;//不可提现余额
	private Long realUseAdvanceMoney;//实际使用垫资金额
	
	private Long realAdvanceMoney;//垫资金额
	private Long tZeroTotalBalance;//昨日余额(T0)
	private Long tZeroHasCashMoney;//已提现金额(T0)
	private Long tZeroCanCashMoney;//可提现金额(T0)  = 昨日余额(T0)  + 垫资金额 - 已提现金额(T0)
	private Long tOneTotalBalance;//当前余额(T1)
	private Long tOneHasCashMoney;//已提现金额(T1)
	private Long tOneCanCashMoney;//可提现金额(T1)  = 当前余额(T1) - 已提现金额(T1)
	private Integer isBindingIP;//是否开启绑定IP，1001：否，1002：是
	
	public String getAgentId() {
		return agentId;
	}
	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}
	public String getAgentName() {
		return agentName;
	}
	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}
	public String getAgentAddress() {
		return agentAddress;
	}
	public void setAgentAddress(String agentAddress) {
		this.agentAddress = agentAddress;
	}
	public String getAgentPhone() {
		return agentPhone;
	}
	public void setAgentPhone(String agentPhone) {
		this.agentPhone = agentPhone;
	}
	public String getPasswd() {
		return passwd;
	}
	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}
	public String getAgentType() {
		return agentType;
	}
	public void setAgentType(String agentType) {
		this.agentType = agentType;
	}
	public String getAgentAccount() {
		return agentAccount;
	}
	public void setAgentAccount(String agentAccount) {
		this.agentAccount = agentAccount;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAgentHeadImg() {
		return agentHeadImg;
	}
	public void setAgentHeadImg(String agentHeadImg) {
		this.agentHeadImg = agentHeadImg;
	}
	public String getAgentState() {
		return agentState;
	}
	public void setAgentState(String agentState) {
		this.agentState = agentState;
	}
	public String getLastLoginTime() {
		return lastLoginTime;
	}
	public void setLastLoginTime(String lastLoginTime) {
		this.lastLoginTime = lastLoginTime;
	}
	
	public int getLoginFailureNum() {
		return loginFailureNum;
	}
	public void setLoginFailureNum(int loginFailureNum) {
		this.loginFailureNum = loginFailureNum;
	}
	public String getVerifyState() {
		return verifyState;
	}
	public void setVerifyState(String verifyState) {
		this.verifyState = verifyState;
	}
	public String getVerifyRemark() {
		return verifyRemark;
	}
	public void setVerifyRemark(String verifyRemark) {
		this.verifyRemark = verifyRemark;
	}
	public String getVerifyPassTime() {
		return verifyPassTime;
	}
	public void setVerifyPassTime(String verifyPassTime) {
		this.verifyPassTime = verifyPassTime;
	}
	public String getVerifyMan() {
		return verifyMan;
	}
	public void setVerifyMan(String verifyMan) {
		this.verifyMan = verifyMan;
	}
	public String getAddMan() {
		return addMan;
	}
	public void setAddMan(String addMan) {
		this.addMan = addMan;
	}
	public String getAddTime() {
		return addTime;
	}
	public void setAddTime(String addTime) {
		this.addTime = addTime;
	}
	public String getEditMan() {
		return editMan;
	}
	public void setEditMan(String editMan) {
		this.editMan = editMan;
	}
	public String getEditTime() {
		return editTime;
	}
	public void setEditTime(String editTime) {
		this.editTime = editTime;
	}
	public String getWithdrawDiscountMaxFee() {
		return withdrawDiscountMaxFee;
	}
	public void setWithdrawDiscountMaxFee(String withdrawDiscountMaxFee) {
		this.withdrawDiscountMaxFee = withdrawDiscountMaxFee;
	}
	public String getWithdrawDiscountFee() {
		return withdrawDiscountFee;
	}
	public void setWithdrawDiscountFee(String withdrawDiscountFee) {
		this.withdrawDiscountFee = withdrawDiscountFee;
	}
	public String getWithdrawFixedFee() {
		return withdrawFixedFee;
	}
	public void setWithdrawFixedFee(String withdrawFixedFee) {
		this.withdrawFixedFee = withdrawFixedFee;
	}
	public String getRechargeDiscountMaxFee() {
		return rechargeDiscountMaxFee;
	}
	public void setRechargeDiscountMaxFee(String rechargeDiscountMaxFee) {
		this.rechargeDiscountMaxFee = rechargeDiscountMaxFee;
	}
	public String getRechargeDiscountFee() {
		return rechargeDiscountFee;
	}
	public void setRechargeDiscountFee(String rechargeDiscountFee) {
		this.rechargeDiscountFee = rechargeDiscountFee;
	}
	public String getRechargeFixedFee() {
		return rechargeFixedFee;
	}
	public void setRechargeFixedFee(String rechargeFixedFee) {
		this.rechargeFixedFee = rechargeFixedFee;
	}
	public String getApikey() {
		return apikey;
	}
	public void setApikey(String apikey) {
		this.apikey = apikey;
	}
	public String getDomainName() {
		return domainName;
	}
	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}
	public String getLogoUrl() {
		return logoUrl;
	}
	public void setLogoUrl(String logoUrl) {
		this.logoUrl = logoUrl;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	public Long getRealAdvanceMoney() {
		return realAdvanceMoney;
	}
	public void setRealAdvanceMoney(Long realAdvanceMoney) {
		this.realAdvanceMoney = realAdvanceMoney;
	}
	public Long getTotalRecharge() {
		return totalRecharge;
	}
	public void setTotalRecharge(Long totalRecharge) {
		this.totalRecharge = totalRecharge;
	}
	public Long getUsedAdvanceMoney() {
		return usedAdvanceMoney;
	}
	public void setUsedAdvanceMoney(Long usedAdvanceMoney) {
		this.usedAdvanceMoney = usedAdvanceMoney;
	}
	public Long getUsableMaxAdvanceMoney() {
		return usableMaxAdvanceMoney;
	}
	public void setUsableMaxAdvanceMoney(Long usableMaxAdvanceMoney) {
		this.usableMaxAdvanceMoney = usableMaxAdvanceMoney;
	}
	public Long getUsableAdvanceMoney() {
		return usableAdvanceMoney;
	}
	public void setUsableAdvanceMoney(Long usableAdvanceMoney) {
		this.usableAdvanceMoney = usableAdvanceMoney;
	}
	public String getBatch() {
		return batch;
	}
	public void setBatch(String batch) {
		this.batch = batch;
	}
	public Long getCanCashMoney() {
		return canCashMoney;
	}
	public void setCanCashMoney(Long canCashMoney) {
		this.canCashMoney = canCashMoney;
	}
	public Long getCantCashMoney() {
		return cantCashMoney;
	}
	public void setCantCashMoney(Long cantCashMoney) {
		this.cantCashMoney = cantCashMoney;
	}
	public Long getRealUseAdvanceMoney() {
		return realUseAdvanceMoney;
	}
	public void setRealUseAdvanceMoney(Long realUseAdvanceMoney) {
		this.realUseAdvanceMoney = realUseAdvanceMoney;
	}
	public Long gettZeroTotalBalance() {
		return tZeroTotalBalance;
	}
	public void settZeroTotalBalance(Long tZeroTotalBalance) {
		this.tZeroTotalBalance = tZeroTotalBalance;
	}
	public Long gettZeroHasCashMoney() {
		return tZeroHasCashMoney;
	}
	public void settZeroHasCashMoney(Long tZeroHasCashMoney) {
		this.tZeroHasCashMoney = tZeroHasCashMoney;
	}
	public Long gettZeroCanCashMoney() {
		return tZeroCanCashMoney;
	}
	public void settZeroCanCashMoney(Long tZeroCanCashMoney) {
		this.tZeroCanCashMoney = tZeroCanCashMoney;
	}
	public Long gettOneTotalBalance() {
		return tOneTotalBalance;
	}
	public void settOneTotalBalance(Long tOneTotalBalance) {
		this.tOneTotalBalance = tOneTotalBalance;
	}
	public Long gettOneHasCashMoney() {
		return tOneHasCashMoney;
	}
	public void settOneHasCashMoney(Long tOneHasCashMoney) {
		this.tOneHasCashMoney = tOneHasCashMoney;
	}
	public Long gettOneCanCashMoney() {
		return tOneCanCashMoney;
	}
	public void settOneCanCashMoney(Long tOneCanCashMoney) {
		this.tOneCanCashMoney = tOneCanCashMoney;
	}
	public Integer getIsBindingIP() {
		return isBindingIP;
	}
	public void setIsBindingIP(Integer isBindingIP) {
		this.isBindingIP = isBindingIP;
	}
	
	
	
}
