package com.threeweidu.entity;

import java.io.Serializable;

public class Announcement implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private String announcementId;//ID
	private String title;//公告标题
	private String content;//公告内容
	private String publishOrganization;//公告发布组织
	private String publishDate;//公告发布日期
	private String addTime;//添加时间
	private String addMan;//添加人
	private String validityStartTime;//展示开始时间
	private String validityEndTime;//展示结束时间
	private String updateTime;//修改时间
	private String updateMan;//修改人
	private Integer annType;//公告类型 1001：系统公告，1002：平台公告 ....
	private Integer annState;//是否生效 1001:否， 1002：是
	private Integer acceptPlatform;//公告接受平台 1000：所有平台，1001：商户平台，1002：用户平台
	public String getAnnouncementId() {
		return announcementId;
	}
	public void setAnnouncementId(String announcementId) {
		this.announcementId = announcementId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getPublishOrganization() {
		return publishOrganization;
	}
	public void setPublishOrganization(String publishOrganization) {
		this.publishOrganization = publishOrganization;
	}
	public String getPublishDate() {
		return publishDate;
	}
	public void setPublishDate(String publishDate) {
		this.publishDate = publishDate;
	}
	public String getAddTime() {
		return addTime;
	}
	public void setAddTime(String addTime) {
		this.addTime = addTime;
	}
	public String getAddMan() {
		return addMan;
	}
	public void setAddMan(String addMan) {
		this.addMan = addMan;
	}
	public String getValidityStartTime() {
		return validityStartTime;
	}
	public void setValidityStartTime(String validityStartTime) {
		this.validityStartTime = validityStartTime;
	}
	public String getValidityEndTime() {
		return validityEndTime;
	}
	public void setValidityEndTime(String validityEndTime) {
		this.validityEndTime = validityEndTime;
	}
	public String getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}
	public String getUpdateMan() {
		return updateMan;
	}
	public void setUpdateMan(String updateMan) {
		this.updateMan = updateMan;
	}
	public Integer getAnnType() {
		return annType;
	}
	public void setAnnType(Integer annType) {
		this.annType = annType;
	}
	public Integer getAnnState() {
		return annState;
	}
	public void setAnnState(Integer annState) {
		this.annState = annState;
	}
	public Integer getAcceptPlatform() {
		return acceptPlatform;
	}
	public void setAcceptPlatform(Integer acceptPlatform) {
		this.acceptPlatform = acceptPlatform;
	}

	
}
