package com.threeweidu.entity;

import java.io.Serializable;

/**  
 * 版权所有(C)2012
 * 公司名称 : 三维度
 * 公司地址 : 深圳市南山区科苑北路科兴科学园B1栋15楼整层
 * 网址 : www.3weidu.com
 * 版本 : 1.0
 * 文件名 : SecSWDAgent.java
 * 文件描述 : 二级代理商
 * 作者 : zengxb
 * 创建时间 : 2016-08-05 11:07:58
 * 负责人 : 
 * 修改者 :  
 * 修改时间 : 
 */
public class SecSWDAgent implements Serializable {

	private static final long serialVersionUID = 1L;

	private String secAgentId;//二级代理商编号
	private String agentId; //一级代理商编号
	private String secAgentName;//名称
	private String secAgentAddress;//地址
	private String secAgentPhone;//电话
	private String passwd;//密码
	private Integer secAgentType;//类型：1001 对外代理商(默认),1002 收银台
	private String secAgentAccount; //账号
	private String email; //邮箱
	private String secAgentHeadImg;//审核人头像
	private Integer secAgentState;//代理商状态,1001 无效(默认),1002有效
	private String lastLoginTime; //最后登录时间
	private String loginFailureNum;//登录失败次数
	private Integer verifyState; //审核状态,1001 未审核(默认),1002 审核通过,1003 审核失败,1004 已过期
	private String verifyRemark;//审核意见
	private String verifyTime;//审核时间
	private String verifyMan;//审核人
	private String addTime;//添加时间
	private String addTimeStart;//添加时间起始值
	private String addTimeEnd;//添加时间结尾值
	private String addMan;//添加人
	private String editTime;//修改时间
	private String operator; //操作
	
	public String getSecAgentId() {
		return secAgentId;
	}
	public void setSecAgentId(String secAgentId) {
		this.secAgentId = secAgentId;
	}
	public String getAgentId() {
		return agentId;
	}
	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}
	public String getSecAgentName() {
		return secAgentName;
	}
	public void setSecAgentName(String secAgentName) {
		this.secAgentName = secAgentName;
	}
	public String getSecAgentAddress() {
		return secAgentAddress;
	}
	public void setSecAgentAddress(String secAgentAddress) {
		this.secAgentAddress = secAgentAddress;
	}
	public String getSecAgentPhone() {
		return secAgentPhone;
	}
	public void setSecAgentPhone(String secAgentPhone) {
		this.secAgentPhone = secAgentPhone;
	}
	public String getPasswd() {
		return passwd;
	}
	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}
	public Integer getSecAgentType() {
		return secAgentType;
	}
	public void setSecAgentType(Integer secAgentType) {
		this.secAgentType = secAgentType;
	}
	public String getSecAgentAccount() {
		return secAgentAccount;
	}
	public void setSecAgentAccount(String secAgentAccount) {
		this.secAgentAccount = secAgentAccount;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getSecAgentHeadImg() {
		return secAgentHeadImg;
	}
	public void setSecAgentHeadImg(String secAgentHeadImg) {
		this.secAgentHeadImg = secAgentHeadImg;
	}
	public Integer getSecAgentState() {
		return secAgentState;
	}
	public void setSecAgentState(Integer secAgentState) {
		this.secAgentState = secAgentState;
	}
	public String getLastLoginTime() {
		return lastLoginTime;
	}
	public void setLastLoginTime(String lastLoginTime) {
		this.lastLoginTime = lastLoginTime;
	}
	public String getLoginFailureNum() {
		return loginFailureNum;
	}
	public void setLoginFailureNum(String loginFailureNum) {
		this.loginFailureNum = loginFailureNum;
	}
	public Integer getVerifyState() {
		return verifyState;
	}
	public void setVerifyState(Integer verifyState) {
		this.verifyState = verifyState;
	}
	public String getVerifyRemark() {
		return verifyRemark;
	}
	public void setVerifyRemark(String verifyRemark) {
		this.verifyRemark = verifyRemark;
	}
	public String getVerifyTime() {
		return verifyTime;
	}
	public void setVerifyTime(String verifyTime) {
		this.verifyTime = verifyTime;
	}
	public String getVerifyMan() {
		return verifyMan;
	}
	public void setVerifyMan(String verifyMan) {
		this.verifyMan = verifyMan;
	}
	public String getAddTime() {
		return addTime;
	}
	public void setAddTime(String addTime) {
		this.addTime = addTime;
	}
	public String getAddMan() {
		return addMan;
	}
	public void setAddMan(String addMan) {
		this.addMan = addMan;
	}
	public String getEditTime() {
		return editTime;
	}
	public void setEditTime(String editTime) {
		this.editTime = editTime;
	}
	public String getOperator() {
		return operator;
	}
	public void setOperator(String operator) {
		this.operator = operator;
	}
	public String getAddTimeStart() {
		return addTimeStart;
	}
	public void setAddTimeStart(String addTimeStart) {
		this.addTimeStart = addTimeStart;
	}
	public String getAddTimeEnd() {
		return addTimeEnd;
	}
	public void setAddTimeEnd(String addTimeEnd) {
		this.addTimeEnd = addTimeEnd;
	}

}
