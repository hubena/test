package com.threeweidu.entity;

import java.io.Serializable;

import com.threeweidu.utils.Arith;
import com.threeweidu.utils.Null2;
import com.threeweidu.utils.xml.ExcelResources;

/**  
 * 版权所有(C)2012
 * 公司名称 : 三维度
 * 公司地址 : 深圳市南山区科苑北路科兴科学园B1栋15楼整层
 * 网址 : www.3weidu.com
 * 版本 : 1.0
 * 文件名 : SupplierCashApplyInfo.java
 * 文件描述 : 商户转账记录查询
 * 作者 : zengxb
 * 创建时间 : 2016-11-22 17:48:58
 * 负责人 : 
 * 修改者 :  
 * 修改时间 : 
 */
public class SupplierCashApplyInfo implements Serializable {

	private static final long serialVersionUID = 1L;

	private String cashId; // 转账订单号
	private String supplierId; // 供应商编号
	private String businessId; // 商户订单号
	private Long tradeMoney; // 申请金额
	private Long feeDiscount; // 手续费扣率
	private Long feeMoney; // 手续费
	private String cashMoney; // 转账金额
	private String checkCode; // 解密字段
	private String tableKey; // 解密字段
	private Integer cashState; // 转账状态
	private String cardNo; // 收款账号
	private String cardholder; // 持卡人
	private String bankName; // 根行名
	private String bankCode; // 根行行号
	private String createTime; // 创建时间
	private String playMoneyTime; // 转账时间
	private String failContent; // 描述信息
	private Integer isRealPay; // 是否实时到账
	private String remark; // 备注
	private String agentProfit;//渠道利润
	private String deductionState = "1000";//1000无结算信息1001未结算1002;结算处理中1003;已结算1004,结算失败 

	public SupplierCashApplyInfo() {

	}

	public void setCashId(String cashId) {
		this.cashId = cashId;
	}

	@ExcelResources(title = "转账订单号", order = 1)
	public String getCashId() {
		return this.cashId;
	}

	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}

	@ExcelResources(title = "供应商编号", order = 2)
	public String getSupplierId() {
		return this.supplierId;
	}

	public String getBusinessId() {
		return businessId;
	}

	@ExcelResources(title = "商户订单号", order = 3)
	public String getBusinessIdStr() {
		return this.supplierId;
	}

	public void setBusinessId(String businessId) {
		this.businessId = businessId;
	}

	public void setTradeMoney(Long tradeMoney) {
		this.tradeMoney = tradeMoney;
	}

	public Long getTradeMoney() {
		return this.tradeMoney;
	}

	@ExcelResources(title = "申请金额", order = 4)
	public String getTradeMoneyForShow() {
		return Arith.getMoney2_New(tradeMoney);
	}

	public void setFeeDiscount(Long feeDiscount) {
		this.feeDiscount = feeDiscount;
	}

	public Long getFeeDiscount() {
		return this.feeDiscount;
	}

	@ExcelResources(title = "手续费扣率", order = 5)
	public String getFeeDiscountForShow() {
		return (Arith.getPercentage(feeDiscount) + "%");
	}

	public void setFeeMoney(Long feeMoney) {
		this.feeMoney = feeMoney;
	}

	public Long getFeeMoney() {
		return this.feeMoney;
	}

	@ExcelResources(title = "手续费", order = 6)
	public String getFeeMoneyForShow() {
		return (Arith.getMoney2_New(feeMoney));
	}

	public String getCashMoney() {
		return cashMoney;
	}

	@ExcelResources(title = "转账金额", order = 7)
	public String getCashMoneyForShow() {
		return (Arith.getMoney2_New(cashMoney));
	}

	public void setCashMoney(String cashMoney) {
		this.cashMoney = cashMoney;
	}

	public String getCheckCode() {
		return checkCode;
	}

	public void setCheckCode(String checkCode) {
		this.checkCode = checkCode;
	}

	public String getTableKey() {
		return tableKey;
	}

	public void setTableKey(String tableKey) {
		this.tableKey = tableKey;
	}

	public void setCashState(Integer cashState) {
		this.cashState = cashState;
	}

	@ExcelResources(title = "转账状态", order = 8)
	public String getCashStateStr() {
		switch (cashState) {// 转账状态
		case 1000:
			return "已申请";
		case 1001:
			return "提交成功";
		case 1002:
			return "已审核通过";
		case 1003:
			return "审核失败";
		case 1004:
			return "银行受理成功";
		case 1005:
			return "已取消";
		case 1006:
			return "银行交易受理失败";
		case 1007:
			return "已退款";
		case 1008:
			return "转帐成功";
		default:
			return "----";
		}
	}

	public Integer getCashState() {
		return this.cashState;
	}

	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}

	@ExcelResources(title = "收款账号", order = 10)
	public String getCardNoForShow() {
		return cardNo.substring(0, 4) + "****" + cardNo.substring(cardNo.length() - 4, cardNo.length());
	}

	public String getCardNo() {
		return this.cardNo;
	}

	public void setCardholder(String cardholder) {
		this.cardholder = cardholder;
	}

	@ExcelResources(title = "持卡人", order = 11)
	public String getCardholder() {
		return this.cardholder;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	@ExcelResources(title = "根行名", order = 12)
	public String getBankName() {
		return this.bankName;
	}

	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	@ExcelResources(title = "根行行号", order = 13)
	public String getBankCode() {
		return bankCode;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	@ExcelResources(title = "创建时间", order = 14)
	public String getCreateTime() {
		return this.createTime;
	}

	public void setPlayMoneyTime(String playMoneyTime) {
		this.playMoneyTime = playMoneyTime;
	}

	@ExcelResources(title = "转账时间", order = 15)
	public String getPlayMoneyTime() {
		return playMoneyTime;
	}

	public void setFailContent(String failContent) {
		this.failContent = failContent;
	}

	@ExcelResources(title = "描述信息", order = 16)
	public String getFailContent() {
		return this.failContent;
	}

	public void setIsRealPay(Integer isRealPay) {
		this.isRealPay = isRealPay;
	}

	@ExcelResources(title = "是否实时到账", order = 17)
	public String getIsRealPayStr() {
		switch (isRealPay) {
		case 1001:
			return "非实时";
		case 1002:
			return "实时";
		default:
			return "----";
		}
	}

	public Integer getIsRealPay() {
		return isRealPay;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	@ExcelResources(title = "备注", order = 18)
	public String getRemark() {
		return this.remark;
	}

	public String getAgentProfit() {
		return agentProfit;
	}

	public void setAgentProfit(String agentProfit) {
		this.agentProfit = agentProfit;
	}

	public String getDeductionState() {
		return deductionState;
	}
	
	@ExcelResources(title = "渠道结算状态", order = 9)
	public String getDeductionStateStr() {
		if (Null2.isNull(deductionState)) {
			return "未结算";
		}
		switch (Integer.valueOf(deductionState)) {
		case 1000:
			return "未结算";
		case 1001:
			return "待结算";
		case 1002:
			return "结算处理中";
		case 1003:
			return "已结算";
		case 1004:
			return "结算失败";
		default:
			return "未结算";
		}
	}

	public void setDeductionState(String deductionState) {
		this.deductionState = deductionState;
	}

}
