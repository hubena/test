package com.threeweidu.entity;

import java.io.Serializable;

/**  
 * 版权所有(C)2012
 * 公司名称 : 三维度
 * 公司地址 : 深圳市南山区科苑北路科兴科学园B1栋15楼整层
 * 网址 : www.3weidu.com
 * 版本 : 1.0
 * 文件名 : SupplierCashApply.java
 * 文件描述 : 供应商提现信息
 * 作者 : HuangBo
 * 创建时间 : 2016-08-05 11:07:58
 * 负责人 : 
 * 修改者 :  
 * 修改时间 : 
 */
public class SupplierCashApply implements Serializable {

	private static final long serialVersionUID = 1L;

	private String cashId; // 提现订单号
	private String supplierId; // 供应商编号
	private Long cashMoney; // 提现金额
	private Integer feeDiscount; // 手续费扣率
	private Long feeMoney; // 手续费
	private Long tradeMoney; // 申请金额
	private String createTime; // 记录产生时间
	private String cardNo; // 收款账号
	private String openBankName; // 支行名
	private String acctRecCode; // 银联行行号（支行行号）
	private String bankName; // 根行名
	private String bankCode; // 根行行号
	private String accBankCity; // 开户银行所在城市
	private String accBankPro; // 开户银行所在省份
	private String cardholder; // 持卡人
	private String mobile; // 手机号码
	private Integer cashState; // 转账状态
	private String failContent; // 失败原因
	private Integer accountFlag; // 对账状态
	private String accountTime; // 对账时间
	private String accountMan; // 对账人
	private String checkTime; // 审核时间
	private String checkMan; // 审核人
	private String playMoneyHuman; // 打款人
	private String playMoneyTime; // 打款时间
	private Integer isRealPay; // 是否实时到账
	private String remark; // 备注
	private String agentProfit;

	public SupplierCashApply() {

	}

	public void setCashId(String cashId) {
		this.cashId = cashId;
	}

	public String getCashId() {
		return this.cashId;
	}

	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}

	public String getSupplierId() {
		return this.supplierId;
	}

	public Long getCashMoney() {
		return cashMoney;
	}

	public void setCashMoney(Long cashMoney) {
		this.cashMoney = cashMoney;
	}

	public void setFeeDiscount(Integer feeDiscount) {
		this.feeDiscount = feeDiscount;
	}

	public Integer getFeeDiscount() {
		return this.feeDiscount;
	}

	public void setFeeMoney(Long feeMoney) {
		this.feeMoney = feeMoney;
	}

	public Long getFeeMoney() {
		return this.feeMoney;
	}

	public void setTradeMoney(Long tradeMoney) {
		this.tradeMoney = tradeMoney;
	}

	public Long getTradeMoney() {
		return this.tradeMoney;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	public String getCreateTime() {
		return this.createTime;
	}

	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}

	public String getCardNo() {
		return this.cardNo;
	}

	public void setOpenBankName(String openBankName) {
		this.openBankName = openBankName;
	}

	public String getOpenBankName() {
		return this.openBankName;
	}

	public void setAcctRecCode(String acctRecCode) {
		this.acctRecCode = acctRecCode;
	}

	public String getAcctRecCode() {
		return this.acctRecCode;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBankName() {
		return this.bankName;
	}

	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	public String getBankCode() {
		return this.bankCode;
	}

	public void setAccBankCity(String accBankCity) {
		this.accBankCity = accBankCity;
	}

	public String getAccBankCity() {
		return this.accBankCity;
	}

	public void setAccBankPro(String accBankPro) {
		this.accBankPro = accBankPro;
	}

	public String getAccBankPro() {
		return this.accBankPro;
	}

	public void setCardholder(String cardholder) {
		this.cardholder = cardholder;
	}

	public String getCardholder() {
		return this.cardholder;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getMobile() {
		return this.mobile;
	}

	public void setCashState(Integer cashState) {
		this.cashState = cashState;
	}

	public Integer getCashState() {
		return this.cashState;
	}

	public void setFailContent(String failContent) {
		this.failContent = failContent;
	}

	public String getFailContent() {
		return this.failContent;
	}

	public void setAccountFlag(Integer accountFlag) {
		this.accountFlag = accountFlag;
	}

	public Integer getAccountFlag() {
		return this.accountFlag;
	}

	public void setAccountTime(String accountTime) {
		this.accountTime = accountTime;
	}

	public String getAccountTime() {
		return this.accountTime;
	}

	public void setAccountMan(String accountMan) {
		this.accountMan = accountMan;
	}

	public String getAccountMan() {
		return this.accountMan;
	}

	public void setCheckTime(String checkTime) {
		this.checkTime = checkTime;
	}

	public String getCheckTime() {
		return this.checkTime;
	}

	public void setCheckMan(String checkMan) {
		this.checkMan = checkMan;
	}

	public String getCheckMan() {
		return this.checkMan;
	}

	public void setPlayMoneyHuman(String playMoneyHuman) {
		this.playMoneyHuman = playMoneyHuman;
	}

	public String getPlayMoneyHuman() {
		return this.playMoneyHuman;
	}

	public void setPlayMoneyTime(String playMoneyTime) {
		this.playMoneyTime = playMoneyTime;
	}

	public String getPlayMoneyTime() {
		return this.playMoneyTime;
	}

	public void setIsRealPay(Integer isRealPay) {
		this.isRealPay = isRealPay;
	}

	public Integer getIsRealPay() {
		return this.isRealPay;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getRemark() {
		return this.remark;
	}

	public String getAgentProfit() {
		return agentProfit;
	}

	public void setAgentProfit(String agentProfit) {
		this.agentProfit = agentProfit;
	}

}
