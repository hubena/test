package com.threeweidu.entity;

import java.io.Serializable;

public class SupplierCashApplyStatistics implements Serializable{
	private static final long serialVersionUID = 1L;
	private String statisticsID;//统计ID
	private String merId;//商户编号
	private String statisticsDate;//统计日期
	private Long sumProfitStatistics;//总利润金额
	private String createTime;//最后一次统计时间	
	private Long agentProfitStatistics;//代理商利润金额
	private Long platformProfitStatistics;//平台利润（三维度）金额
	private String editMan;//修改人
	private String editTime;//修改时间
	private Integer deductionState;//结算状态 
	private String statisticsStartDate;
	private String statisticsEndDate;
	public String getStatisticsID() {
		return statisticsID;
	}
	public void setStatisticsID(String statisticsID) {
		this.statisticsID = statisticsID;
	}
	public String getMerId() {
		return merId;
	}
	public void setMerId(String merId) {
		this.merId = merId;
	}
	public String getStatisticsDate() {
		return statisticsDate;
	}
	public void setStatisticsDate(String statisticsDate) {
		this.statisticsDate = statisticsDate;
	}
	public Long getSumProfitStatistics() {
		return sumProfitStatistics;
	}
	public void setSumProfitStatistics(Long sumProfitStatistics) {
		this.sumProfitStatistics = sumProfitStatistics;
	}
	public String getCreateTime() {
		return createTime;
	}
	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}
	public Long getAgentProfitStatistics() {
		return agentProfitStatistics;
	}
	public void setAgentProfitStatistics(Long agentProfitStatistics) {
		this.agentProfitStatistics = agentProfitStatistics;
	}
	public Long getPlatformProfitStatistics() {
		return platformProfitStatistics;
	}
	public void setPlatformProfitStatistics(Long platformProfitStatistics) {
		this.platformProfitStatistics = platformProfitStatistics;
	}
	public String getEditMan() {
		return editMan;
	}
	public void setEditMan(String editMan) {
		this.editMan = editMan;
	}
	public String getEditTime() {
		return editTime;
	}
	public void setEditTime(String editTime) {
		this.editTime = editTime;
	}
	public Integer getDeductionState() {
		return deductionState;
	}
	public void setDeductionState(Integer deductionState) {
		this.deductionState = deductionState;
	}
	public String getStatisticsStartDate() {
		return statisticsStartDate;
	}
	public void setStatisticsStartDate(String statisticsStartDate) {
		this.statisticsStartDate = statisticsStartDate;
	}
	public String getStatisticsEndDate() {
		return statisticsEndDate;
	}
	public void setStatisticsEndDate(String statisticsEndDate) {
		this.statisticsEndDate = statisticsEndDate;
	}
	
}
