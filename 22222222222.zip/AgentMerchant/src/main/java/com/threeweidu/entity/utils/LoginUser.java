package com.threeweidu.entity.utils;

import java.io.Serializable;

public class LoginUser implements Serializable{
	private static final long serialVersionUID = 659760241293509902L;
	private Integer type;//1001:一级渠道商，1002:二级渠道商
	private String agentId;
	private String secAgentId;
	public Integer getType() {
		return type;
	}
	public void setType(Integer type) {
		this.type = type;
	}
	public String getAgentId() {
		return agentId;
	}
	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}
	public String getSecAgentId() {
		return secAgentId;
	}
	public void setSecAgentId(String secAgentId) {
		this.secAgentId = secAgentId;
	}
	public boolean equals(LoginUser user) {
		if(user!=null && user.getType()!=null && user.getType()==this.type){
			if(1001==user.getType() && user.getAgentId()!=null){//一级渠道商
				if(user.getAgentId().equals(this.agentId)){
					return true;
				}
			} else if(1002==user.getType() && user.getSecAgentId()!=null){//二级渠道商
				if(user.getSecAgentId().equals(this.secAgentId)){
					return true;
				}
			}
		}
		return false;
	}
}
