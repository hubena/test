package com.threeweidu.entity;

import java.io.Serializable;

public class AgentIPWhiteRecord implements Serializable{
	private static final long serialVersionUID = 1L;
	private String	agentId; //代理商编号
	private String	whiteIP; //IP白名单
	private Integer ipType; //IP类型：1001：登录IP
	private Integer state; //是否启用：1001：启用，1002：关闭
	private String addManIP; //添加人IP
	private String addMan; //添加人
	private String addTime; //添加时间
	private String addTimeStart; //起始添加时间
	private String addTimeEnd; //结束添加时间
	private Integer isBindingIP;//绑定或解绑登录IP，1001：否，1002：是
	private Integer sendType; //发送类,1001: 短信,1002: 邮箱
	private String sendCode; //发送的验证码
	private String sendNumber; //发送的号码
	
	public String getAgentId() {
		return agentId;
	}
	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}
	public String getWhiteIP() {
		return whiteIP;
	}
	public void setWhiteIP(String whiteIP) {
		this.whiteIP = whiteIP;
	}
	public Integer getIpType() {
		return ipType;
	}
	public void setIpType(Integer ipType) {
		this.ipType = ipType;
	}
	public Integer getState() {
		return state;
	}
	public void setState(Integer state) {
		this.state = state;
	}
	public String getAddManIP() {
		return addManIP;
	}
	public void setAddManIP(String addManIP) {
		this.addManIP = addManIP;
	}
	public String getAddMan() {
		return addMan;
	}
	public void setAddMan(String addMan) {
		this.addMan = addMan;
	}
	public String getAddTime() {
		return addTime;
	}
	public void setAddTime(String addTime) {
		this.addTime = addTime;
	}
	public String getAddTimeStart() {
		return addTimeStart;
	}
	public void setAddTimeStart(String addTimeStart) {
		this.addTimeStart = addTimeStart;
	}
	public String getAddTimeEnd() {
		return addTimeEnd;
	}
	public void setAddTimeEnd(String addTimeEnd) {
		this.addTimeEnd = addTimeEnd;
	}
	public Integer getIsBindingIP() {
		return isBindingIP;
	}
	public void setIsBindingIP(Integer isBindingIP) {
		this.isBindingIP = isBindingIP;
	}
	public Integer getSendType() {
		return sendType;
	}
	public void setSendType(Integer sendType) {
		this.sendType = sendType;
	}
	public String getSendCode() {
		return sendCode;
	}
	public void setSendCode(String sendCode) {
		this.sendCode = sendCode;
	}
	public String getSendNumber() {
		return sendNumber;
	}
	public void setSendNumber(String sendNumber) {
		this.sendNumber = sendNumber;
	}
	
}
