package com.threeweidu.entity;

import java.io.Serializable;

/**  
 * 版权所有(C)2012
 * 公司名称 : 三维度
 * 公司地址 : 深圳市南山区科苑北路科兴科学园B1栋15楼整层
 * 网址 : www.3weidu.com
 * 版本 : 1.0
 * 文件名 : AssociateMerchant.java
 * 文件描述 : 二级代理商关联商户
 * 作者 : zengxb
 * 创建时间 : 2016-08-05 11:07:58
 * 负责人 : 
 * 修改者 :  
 * 修改时间 : 
 */
public class AssociateMerchant implements Serializable {

	private static final long serialVersionUID = 1L;

	private String amId;//代理商户编号，id
	private String agentId; //代理商编号
	private String secAgentId;//二级代理商编号
	private String merId;//商户号
	private String merName;//商户名称
	private String linkMan;//联系人
	private String linkTell;//联系电话
	private String addTime; //添加时间
	private String addTimeStart;//起始时间
	private String addTimeEnd;//结束时间
	private String addMan;//添加人
	private String sellerType; //商户级别	商户级别、 1001 一级、1002二级
	
	public String getAmId() {
		return amId;
	}
	public void setAmId(String amId) {
		this.amId = amId;
	}
	public String getAgentId() {
		return agentId;
	}
	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}
	public String getSecAgentId() {
		return secAgentId;
	}
	public void setSecAgentId(String secAgentId) {
		this.secAgentId = secAgentId;
	}
	public String getMerId() {
		return merId;
	}
	public void setMerId(String merId) {
		this.merId = merId;
	}
	public String getMerName() {
		return merName;
	}
	public void setMerName(String merName) {
		this.merName = merName;
	}
	public String getLinkMan() {
		return linkMan;
	}
	public void setLinkMan(String linkMan) {
		this.linkMan = linkMan;
	}
	public String getLinkTell() {
		return linkTell;
	}
	public void setLinkTell(String linkTell) {
		this.linkTell = linkTell;
	}
	public String getAddTime() {
		return addTime;
	}
	public void setAddTime(String addTime) {
		this.addTime = addTime;
	}
	public String getAddTimeStart() {
		return addTimeStart;
	}
	public void setAddTimeStart(String addTimeStart) {
		this.addTimeStart = addTimeStart;
	}
	public String getAddTimeEnd() {
		return addTimeEnd;
	}
	public void setAddTimeEnd(String addTimeEnd) {
		this.addTimeEnd = addTimeEnd;
	}
	public String getAddMan() {
		return addMan;
	}
	public void setAddMan(String addMan) {
		this.addMan = addMan;
	}
	public String getSellerType() {
		return sellerType;
	}
	public void setSellerType(String sellerType) {
		this.sellerType = sellerType;
	}
}
