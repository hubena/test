package com.threeweidu.entity;

import java.io.Serializable;

public class Terminal implements Serializable{
	private static final long serialVersionUID = 1L;
	private String terId;
	private String merId;
	private String isSendcode;
	private String sender;
	private String astrictSingleMoeny;
	private String astrictDayMoeny;
	private String cardType;
	private String addTime;
	private String addMan;
	private String payType;
	public String getTerId() {
		return terId;
	}
	public void setTerId(String terId) {
		this.terId = terId;
	}
	public String getMerId() {
		return merId;
	}
	public void setMerId(String merId) {
		this.merId = merId;
	}
	public String getIsSendcode() {
		return isSendcode;
	}
	public void setIsSendcode(String isSendcode) {
		this.isSendcode = isSendcode;
	}
	public String getSender() {
		return sender;
	}
	public void setSender(String sender) {
		this.sender = sender;
	}
	public String getAstrictSingleMoeny() {
		return astrictSingleMoeny;
	}
	public void setAstrictSingleMoeny(String astrictSingleMoeny) {
		this.astrictSingleMoeny = astrictSingleMoeny;
	}
	public String getAstrictDayMoeny() {
		return astrictDayMoeny;
	}
	public void setAstrictDayMoeny(String astrictDayMoeny) {
		this.astrictDayMoeny = astrictDayMoeny;
	}
	public String getCardType() {
		return cardType;
	}
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}
	public String getAddTime() {
		return addTime;
	}
	public void setAddTime(String addTime) {
		this.addTime = addTime;
	}
	public String getAddMan() {
		return addMan;
	}
	public void setAddMan(String addMan) {
		this.addMan = addMan;
	}
	public String getPayType() {
		return payType;
	}
	public void setPayType(String payType) {
		this.payType = payType;
	}
}
