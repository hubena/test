package com.threeweidu.entity;

import java.io.Serializable;

public class SendCodeRecord implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer id; // 主键id
	private String merId;// 商户号
	private Integer sendType; // 发送类型，1001手机，1002邮箱
	private String sendAccount; // 发送账户
	private String sendMsg; // 发送内容
	private String sendTime; // 发送时间

	public SendCodeRecord() {

	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getMerId() {
		return merId;
	}

	public void setMerId(String merId) {
		this.merId = merId;
	}

	public Integer getSendType() {
		return sendType;
	}

	public void setSendType(Integer sendType) {
		this.sendType = sendType;
	}

	public String getSendAccount() {
		return sendAccount;
	}

	public void setSendAccount(String sendAccount) {
		this.sendAccount = sendAccount;
	}

	public String getSendMsg() {
		return sendMsg;
	}

	public void setSendMsg(String sendMsg) {
		this.sendMsg = sendMsg;
	}

	public String getSendTime() {
		return sendTime;
	}

	public void setSendTime(String sendTime) {
		this.sendTime = sendTime;
	}

}
