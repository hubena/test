package com.threeweidu.entity;

import java.io.Serializable;

public class Chancel implements Serializable{
	private static final long serialVersionUID = 1L;
	private String paymentId;
	private String paymentChancelId;
	private String paymentChancelName;
	private Integer billingCycle;
	public String getPaymentId() {
		return paymentId;
	}
	public void setPaymentId(String paymentId) {
		this.paymentId = paymentId;
	}
	public String getPaymentChancelId() {
		return paymentChancelId;
	}
	public void setPaymentChancelId(String paymentChancelId) {
		this.paymentChancelId = paymentChancelId;
	}
	public String getPaymentChancelName() {
		return paymentChancelName;
	}
	public void setPaymentChancelName(String paymentChancelName) {
		this.paymentChancelName = paymentChancelName;
	}
	public Integer getBillingCycle() {
		return billingCycle;
	}
	public void setBillingCycle(Integer billingCycle) {
		this.billingCycle = billingCycle;
	}
}
