package com.threeweidu.entity;

import java.io.Serializable;


public class MerchantOperateLog implements Serializable {
	private static final long serialVersionUID = 1L;
	private String merLogId;
	private String merId;
	private String operateContent;
	public MerchantOperateLog() {
	}
	public MerchantOperateLog(String merId, String operateContent,
			String operateIp) {
		this.merId = merId;
		this.operateContent = operateContent;
		this.operateIp = operateIp;
	}
	private String operateTime;
	private String operateIp;
	public String getMerLogId() {
		return merLogId;
	}
	public void setMerLogId(String merLogId) {
		this.merLogId = merLogId;
	}
	public String getMerId() {
		return merId;
	}
	public void setMerId(String merId) {
		this.merId = merId;
	}
	public String getOperateContent() {
		return operateContent;
	}
	public void setOperateContent(String operateContent) {
		this.operateContent = operateContent;
	}
	public String getOperateTime() {
		return operateTime;
	}
	public void setOperateTime(String operateTime) {
		this.operateTime = operateTime;
	}
	public String getOperateIp() {
		return operateIp;
	}
	public void setOperateIp(String operateIp) {
		this.operateIp = operateIp;
	}
}
