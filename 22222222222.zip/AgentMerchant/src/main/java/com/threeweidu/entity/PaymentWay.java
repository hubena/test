package com.threeweidu.entity;

import java.io.Serializable;

/**
 * 支付方式实体
 * 公司名称：三维度
 * 公司地址：深圳市南山区科苑北路科兴科学园B1栋15楼整层
 * 网址:  www.3weidu.com
 * 类描述: 
 * 作者:  tangs
 * 创建时间:2016-9-7下午2:01:52
 */
public class PaymentWay implements Serializable{
	private static final long serialVersionUID = 1L;
	private Integer paymentId;	//主键自增	支付方式编号
	private Integer paymentName;//	支付方式 1001 易宝网关 1002 京东快捷支付 1003 微信扫码 1004微信公众号支付 1005 鼎付外卡支付
	private Integer	cardType;	//卡类型 1001 借记卡 1002 信用卡
	private Integer paymentChancelId;	//支付通道ID
	private Integer	appSence;	//应用场景 1001 网关支付 1002 wap支付 1003 快捷API对接 1004 快捷SDK
	private String addTime;//添加时间
	private String	updateTime;//更新时间
	private String merId;//商户编号
	private String	deductionRate;//扣率
	private Integer	billingCycle;	//结算周期 单位：天
	private String paymentChancelName;	//支付通道名
	private String chancelDeductionRate;//通道扣率
	private String agentId; // 代理商编号
	private String paymentRate;// 支付方式成本扣率
	private String realRate;// 实时扣率
	private String notRealRate;// 非实时扣率
	public Integer getPaymentId() {
		return paymentId;
	}
	public void setPaymentId(Integer paymentId) {
		this.paymentId = paymentId;
	}
	public Integer getPaymentName() {
		return paymentName;
	}
	public void setPaymentName(Integer paymentName) {
		this.paymentName = paymentName;
	}
	public Integer getCardType() {
		return cardType;
	}
	public void setCardType(Integer cardType) {
		this.cardType = cardType;
	}
	public Integer getPaymentChancelId() {
		return paymentChancelId;
	}
	public void setPaymentChancelId(Integer paymentChancelId) {
		this.paymentChancelId = paymentChancelId;
	}
	public Integer getAppSence() {
		return appSence;
	}
	public void setAppSence(Integer appSence) {
		this.appSence = appSence;
	}
	public String getAddTime() {
		return addTime;
	}
	public void setAddTime(String addTime) {
		this.addTime = addTime;
	}
	public String getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}
	public String getMerId() {
		return merId;
	}
	public void setMerId(String merId) {
		this.merId = merId;
	}
	public String getDeductionRate() {
		return deductionRate;
	}
	public void setDeductionRate(String deductionRate) {
		this.deductionRate = deductionRate;
	}
	public Integer getBillingCycle() {
		return billingCycle;
	}
	public void setBillingCycle(Integer billingCycle) {
		this.billingCycle = billingCycle;
	}
	public String getPaymentChancelName() {
		return paymentChancelName;
	}
	public void setPaymentChancelName(String paymentChancelName) {
		this.paymentChancelName = paymentChancelName;
	}
	public String getChancelDeductionRate() {
		return chancelDeductionRate;
	}
	public void setChancelDeductionRate(String chancelDeductionRate) {
		this.chancelDeductionRate = chancelDeductionRate;
	}
	public String getAgentId() {
		return agentId;
	}
	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}
	public String getPaymentRate() {
		return paymentRate;
	}
	public void setPaymentRate(String paymentRate) {
		this.paymentRate = paymentRate;
	}
	public String getRealRate() {
		return realRate;
	}
	public void setRealRate(String realRate) {
		this.realRate = realRate;
	}
	public String getNotRealRate() {
		return notRealRate;
	}
	public void setNotRealRate(String notRealRate) {
		this.notRealRate = notRealRate;
	}
	
	
}
