package com.threeweidu.entity;

import java.io.Serializable;

public class MerchantInfo implements Serializable{
	private static final long serialVersionUID = 1L;
	private String	agentId;
	private String	merInfoId;
	private Integer maxMers;
	private Integer hasMers;
	private Integer canMers;
	private String addTime;
	private String linkMan;
	private String linkTell;
	private String linkPhone;
	private String verifyState;
	public String getAgentId() {
		return agentId;
	}
	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}
	public String getMerInfoId() {
		return merInfoId;
	}
	public void setMerInfoId(String merInfoId) {
		this.merInfoId = merInfoId;
	}
	public Integer getMaxMers() {
		return maxMers;
	}
	public void setMaxMers(Integer maxMers) {
		this.maxMers = maxMers;
	}
	public Integer getHasMers() {
		return hasMers;
	}
	public void setHasMers(Integer hasMers) {
		this.hasMers = hasMers;
	}
	public String getAddTime() {
		return addTime;
	}
	public void setAddTime(String addTime) {
		this.addTime = addTime;
	}
	public String getLinkMan() {
		return linkMan;
	}
	public void setLinkMan(String linkMan) {
		this.linkMan = linkMan;
	}
	public String getLinkTell() {
		return linkTell;
	}
	public void setLinkTell(String linkTell) {
		this.linkTell = linkTell;
	}
	public String getLinkPhone() {
		return linkPhone;
	}
	public void setLinkPhone(String linkPhone) {
		this.linkPhone = linkPhone;
	}
	public Integer getCanMers() {
		return canMers;
	}
	public void setCanMers(Integer canMers) {
		this.canMers = canMers;
	}
	public String getVerifyState() {
		return verifyState;
	}
	public void setVerifyState(String verifyState) {
		this.verifyState = verifyState;
	}
	
}
