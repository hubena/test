package com.threeweidu.entity;


import java.io.Serializable;
import java.sql.Timestamp;


public class SysException implements Serializable{
	/**
     * 
     */
    private static final long serialVersionUID = 5419585467318536098L;
	// Fields
	/**
	 * 
	 */
	
	private long sysId;			//ϵͳ�쳣��־��� 
	private String sysContents;	//���� 
	private String ipAddress;	//IP��ַ
	private String resourceURL;	//��ַ
	
	private Timestamp produceDate;	//����ʱ�� 
	private String produceDateStr;	//ʱ���ַ�
	
	private String useSystem;	//ʹ�õ�ϵͳ

	// Constructors
	/** default constructors */
	public SysException() {
	}

	
	/** full constructor */
	public SysException(long sysId, String sysContents, String resourceURL,
			Timestamp produceDate, String produceDateStr, String useSystem) {
		this.sysId = sysId;
		this.sysContents = sysContents;
		this.resourceURL = resourceURL;
		this.produceDate = produceDate;
		this.produceDateStr = produceDateStr;
		this.useSystem = useSystem;
	}


	// Property accessors
	public long getSysId() {
		return sysId;
	}

	public void setSysId(long sysId) {
		this.sysId = sysId;
	}

	public String getSysContents() {
		return sysContents;
	}

	public void setSysContents(String sysContents) {
		this.sysContents = sysContents;
	}

	public String getResourceURL() {
		return resourceURL;
	}

	public void setResourceURL(String resourceURL) {
		this.resourceURL = resourceURL;
	}

	public Timestamp getProduceDate() {
		return produceDate;
	}

	public void setProduceDate(Timestamp produceDate) {
		this.produceDate = produceDate;
	}

	public String getProduceDateStr() {
		return produceDateStr;
	}

	public void setProduceDateStr(String produceDateStr) {
		this.produceDateStr = produceDateStr;
	}

	public String getUseSystem() {
		return useSystem;
	}

	public void setUseSystem(String useSystem) {
		this.useSystem = useSystem;
	}


	public String getIpAddress() {
		return ipAddress;
	}


	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}
	
	
	

}
