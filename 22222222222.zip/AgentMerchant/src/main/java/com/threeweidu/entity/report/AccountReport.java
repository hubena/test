package com.threeweidu.entity.report;

import java.io.Serializable;

import com.threeweidu.utils.xml.ExcelResources;

public class AccountReport implements Serializable {
	private static final long serialVersionUID = 1L;

	private String ordid; // 三维度订单号 1
	private String businessOrdid; // 商户订单号 
	private String merId; // 商户号
	private String terId;//终端号
	private String payType; // 订单类型
	private Integer tradeMoney;
	private String tradeMoneyStr;//交易金额
	private Integer auditMoneyToBank;
	private String auditMoneyToBankStr;//手续费
	private Integer memberAuditAmount;
	private String memberAuditAmountStr;//清算金额
	private String orderName;//订单名称 2
//	private String tradeDate;//交易日期
//	private String tradeTime;//交易时间
	private String ordidState; // 订单状态
	
	private String agentAuditState;//渠道结算状态
	private String agentAmount;//渠道利润
	private String deductionRate;//结算扣率
	private String deductionFee;//手续费
	private String auditAmount;//结算金额	
	
	private String returnTime;//交易时间
	private String createTime;//支付时间
	
	private String rechargeState;//异步通知状态
	private String asynSupState;//充值状态

	@ExcelResources(title = "支付订单号", order = 1)	
	public String getOrdid() {
		return ordid;
	}

	public void setOrdid(String ordid) {
		this.ordid = ordid;
	}

	@ExcelResources(title = "商户订单号", order = 3)
	public String getBusinessOrdid() {
		return businessOrdid;
	}

	public void setBusinessOrdid(String businessOrdid) {
		this.businessOrdid = businessOrdid;
	}

	@ExcelResources(title = "商户编号", order = 4)
	public String getMerId() {
		return merId;
	}

	public void setMerId(String merId) {
		this.merId = merId;
	}

	@ExcelResources(title = "商户终端号", order = 14)
	public String getTerId() {
		return terId;
	}

	public void setTerId(String terId) {
		this.terId = terId;
	}
	@ExcelResources(title = "订单类型", order = 5)
	public String getPayType() {
		return payType;
	}

	public void setPayType(String payType) {
		this.payType = payType;
	}

	public Integer getTradeMoney() {
		return tradeMoney;
	}

	public void setTradeMoney(Integer tradeMoney) {
		this.tradeMoney = tradeMoney;
	}

	@ExcelResources(title = "交易金额", order = 6)
	public String getTradeMoneyStr() {
		return tradeMoneyStr;
	}

	public void setTradeMoneyStr(String tradeMoneyStr) {
		this.tradeMoneyStr = tradeMoneyStr;
	}

	public Integer getAuditMoneyToBank() {
		return auditMoneyToBank;
	}

	public void setAuditMoneyToBank(Integer auditMoneyToBank) {
		this.auditMoneyToBank = auditMoneyToBank;
	}

	//@ExcelResources(title = "手续费", order = 6)
	public String getAuditMoneyToBankStr() {
		return auditMoneyToBankStr;
	}

	public void setAuditMoneyToBankStr(String auditMoneyToBankStr) {
		this.auditMoneyToBankStr = auditMoneyToBankStr;
	}

	public Integer getMemberAuditAmount() {
		return memberAuditAmount;
	}

	public void setMemberAuditAmount(Integer memberAuditAmount) {
		this.memberAuditAmount = memberAuditAmount;
	}

	//@ExcelResources(title = "清算金额", order = 7)
	public String getMemberAuditAmountStr() {
		return memberAuditAmountStr;
	}

	public void setMemberAuditAmountStr(String memberAuditAmountStr) {
		this.memberAuditAmountStr = memberAuditAmountStr;
	}

//	@ExcelResources(title = "交易日期", order = 8)
//	public String getTradeDate() {
//		return tradeDate;
//	}
//
//	public void setTradeDate(String tradeDate) {
//		this.tradeDate = tradeDate;
//	}

//	@ExcelResources(title = "交易时间", order = 9)
//	public String getTradeTime() {
//		return tradeTime;
//	}
//
//	public void setTradeTime(String tradeTime) {
//		this.tradeTime = tradeTime;
//	}
	@ExcelResources(title = "订单名称", order = 2)
	public String getOrderName() {
		return orderName;
	}

	public void setOrderName(String orderName) {
		this.orderName = orderName;
	}

	@ExcelResources(title = "订单状态", order = 7)
	public String getOrdidState() {
		return ordidState;
	}

	public void setOrdidState(String ordidState) {
		this.ordidState = ordidState;
	}

	@ExcelResources(title = "渠道结算状态", order = 11)
	public String getAgentAuditState() {
		return agentAuditState;
	}

	public void setAgentAuditState(String agentAuditState) {
		this.agentAuditState = agentAuditState;
	}

	@ExcelResources(title = "渠道利润", order = 12)
	public String getAgentAmount() {
		return agentAmount;
	}

	public void setAgentAmount(String agentAmount) {
		this.agentAmount = agentAmount;
	}

	@ExcelResources(title = "结算扣率", order = 9)
	public String getDeductionRate() {
		return deductionRate;
	}

	public void setDeductionRate(String deductionRate) {
		this.deductionRate = deductionRate;
	}

	@ExcelResources(title = "手续费", order = 10)
	public String getDeductionFee() {
		return deductionFee;
	}

	public void setDeductionFee(String deductionFee) {
		this.deductionFee = deductionFee;
	}

	@ExcelResources(title = "结算金额", order = 10)
	public String getAuditAmount() {
		return auditAmount;
	}

	public void setAuditAmount(String auditAmount) {
		this.auditAmount = auditAmount;
	}

	@ExcelResources(title = "交易时间", order = 7)
	public String getReturnTime() {
		return returnTime;
	}

	public void setReturnTime(String returnTime) {
		this.returnTime = returnTime;
	}

	@ExcelResources(title = "订单创建时间", order = 13)
	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	@ExcelResources(title = "异步通知状态", order = 8)
	public String getAsynSupState() {
		return asynSupState;
	}

	@ExcelResources(title = "充值状态", order = 8)
	public String getRechargeState() {
		return rechargeState;
	}

	public void setRechargeState(String rechargeState) {
		this.rechargeState = rechargeState;
	}

	public void setAsynSupState(String asynSupState) {
		this.asynSupState = asynSupState;
	}

}
