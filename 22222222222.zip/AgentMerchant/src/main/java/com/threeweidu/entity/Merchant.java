package com.threeweidu.entity;

import java.io.Serializable;

public class Merchant implements Serializable{
	private static final long serialVersionUID = 1L;
	private String	merId;	//商户编号
	private String	merName;	//商户名
	private String	withdrawFeeType;	//提现扣费模式1001：扣率 1002：固定手续
	private String	withdrawFeeTypeValue;	//提现扣费金额 最大提现金额不能大于5万
	private String	withdrawMaxfee;		//提现封顶手续费 1001提现扣率模式下封顶手续费
	private String	rechargeFeeType;	//充值扣费模式 1001：扣率 1002：固定手续
	private String	rechargeFeeTypeValue;	//充值扣费金额
	private String	rechargeMaxFee;		//充值封顶手续费 1001充值扣率模式下封顶手续费
	private String	accountBalance;		//商户账户余额
	private String	abCheckCode;		//加密解密串
	private String	abTableKey;			//加密解密串
	private String 	supplierId;
	private String	supplieName;
	private String 	email;
	private String isRealPay; // 是否实时到账 1001:非实时 1002：实时
	private String fatherMerId;//父编号
	private String agentId;
	private String suppliePhone;
	private String payPasswd;//
	
	//添加字段，用于解锁
	private Integer useState;  //商户状态(1001已创建，1002正常使用，1003已禁用,1004已冻结)
	
	private String apiKey;// apikey
	private String publicKey;// 公钥
	private Long marginMoney;// 保证金(分)
	private String sellerLicense;// 营业执照(企业)
	private String sellerPwd;// 登录密码
	private String linkMan;// 联系人
	private String linkTell;// 联系电话
	private String linkPhone;// 手机
	private String linkAddress;// 公司地址
	private String corporationMan;// 商户法人
	private String identificationCard;// 身份证
	private String identificationCardEdit;// 身份证
	private String companyName;// 公司名称
	private String sellerEmail;// 邮箱
	private Integer pwdFlag;// 密码状态(0初始密码、1已修改的密码)
	private String updPwdTime;// 修改密码时间
	private String openBankName;// 开户行（支行名）
	private String acctRecCode;// 银联行行号（支行行号）
	private String cardMan;// 持卡人
	private String bankCard;// 银行账号
	private String registerBank;// 根行名
	private String bankCode;// 根行行号
	private String accBankPro;// 开户行所在的省份
	private String accBankCity;// 开户行所在的城市
	private String freezeTime;// 登录时密码错误5次时间
	private Integer failCount;// 密码输入错误次数
	private Integer sellerType;// 商户级别 1001 一级1002二级
	private String addTime;// 添加时间
	private String addMan;// 添加人
	private String updateTime;// 修改时间
	private String updateMan;// 修改人
	private Integer yield;// 扣率
	private String startTime;// 开始时间
	private String endTime;// 结束时间

	private String sellerId;// 渠道商编号
	private String memberNo;// 主会员账号
	private String appid;// appid
	
	private Integer merchantType; // 商户类型，1001快捷支付对接，1002供应商支付对接

	private String domain ; //商户域名
	private String agentName;
	
	private String merInfoId;
	private String remark;//备注
	private Integer loginIpSet;//1001关闭，1002开启 登录ip绑定
	private String operateIp;//操作IP
	private String merIds;
	private String transferRealWhiteList;//是否实时到账
	
	private String secAgentAccount;
	private String secAgentName;
	private String isRealRecharge;//充值到账方式
	
	private String couCode;
	
	public String getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	
	public String getSupplieName() {
		return supplieName;
	}
	public void setSupplieName(String supplieName) {
		this.supplieName = supplieName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMerId() {
		return merId;
	}
	public void setMerId(String merId) {
		this.merId = merId;
	}
	public String getMerName() {
		return merName;
	}
	public void setMerName(String merName) {
		this.merName = merName;
	}
	public String getWithdrawFeeType() {
		return withdrawFeeType;
	}
	public void setWithdrawFeeType(String withdrawFeeType) {
		this.withdrawFeeType = withdrawFeeType;
	}
	public String getWithdrawFeeTypeValue() {
		return withdrawFeeTypeValue;
	}
	public void setWithdrawFeeTypeValue(String withdrawFeeTypeValue) {
		this.withdrawFeeTypeValue = withdrawFeeTypeValue;
	}
	public String getWithdrawMaxfee() {
		return withdrawMaxfee;
	}
	public void setWithdrawMaxfee(String withdrawMaxfee) {
		this.withdrawMaxfee = withdrawMaxfee;
	}
	public String getRechargeFeeType() {
		return rechargeFeeType;
	}
	public void setRechargeFeeType(String rechargeFeeType) {
		this.rechargeFeeType = rechargeFeeType;
	}
	public String getRechargeFeeTypeValue() {
		return rechargeFeeTypeValue;
	}
	public void setRechargeFeeTypeValue(String rechargeFeeTypeValue) {
		this.rechargeFeeTypeValue = rechargeFeeTypeValue;
	}
	public String getRechargeMaxFee() {
		return rechargeMaxFee;
	}
	public void setRechargeMaxFee(String rechargeMaxFee) {
		this.rechargeMaxFee = rechargeMaxFee;
	}
	public String getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(String accountBalance) {
		this.accountBalance = accountBalance;
	}
	public String getAbCheckCode() {
		return abCheckCode;
	}
	public void setAbCheckCode(String abCheckCode) {
		this.abCheckCode = abCheckCode;
	}
	public String getAbTableKey() {
		return abTableKey;
	}
	public void setAbTableKey(String abTableKey) {
		this.abTableKey = abTableKey;
	}
	public String getIsRealPay() {
		return isRealPay;
	}
	public void setIsRealPay(String isRealPay) {
		this.isRealPay = isRealPay;
	}
	public String getFatherMerId() {
		return fatherMerId;
	}
	public void setFatherMerId(String fatherMerId) {
		this.fatherMerId = fatherMerId;
	}
	public String getAgentId() {
		return agentId;
	}
	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}
	public String getSuppliePhone() {
		return suppliePhone;
	}
	public void setSuppliePhone(String suppliePhone) {
		this.suppliePhone = suppliePhone;
	}
	public String getPayPasswd() {
		return payPasswd;
	}
	public void setPayPasswd(String payPasswd) {
		this.payPasswd = payPasswd;
	}
	public Integer getUseState() {
		return useState;
	}
	public void setUseState(Integer useState) {
		this.useState = useState;
	}
	public String getApiKey() {
		return apiKey;
	}
	public void setApiKey(String apiKey) {
		this.apiKey = apiKey;
	}
	public String getPublicKey() {
		return publicKey;
	}
	public void setPublicKey(String publicKey) {
		this.publicKey = publicKey;
	}
	public Long getMarginMoney() {
		return marginMoney;
	}
	public void setMarginMoney(Long marginMoney) {
		this.marginMoney = marginMoney;
	}
	public String getSellerLicense() {
		return sellerLicense;
	}
	public void setSellerLicense(String sellerLicense) {
		this.sellerLicense = sellerLicense;
	}
	public String getSellerPwd() {
		return sellerPwd;
	}
	public void setSellerPwd(String sellerPwd) {
		this.sellerPwd = sellerPwd;
	}
	public String getLinkMan() {
		return linkMan;
	}
	public void setLinkMan(String linkMan) {
		this.linkMan = linkMan;
	}
	public String getLinkTell() {
		return linkTell;
	}
	public void setLinkTell(String linkTell) {
		this.linkTell = linkTell;
	}
	public String getLinkPhone() {
		return linkPhone;
	}
	public void setLinkPhone(String linkPhone) {
		this.linkPhone = linkPhone;
	}
	public String getLinkAddress() {
		return linkAddress;
	}
	public void setLinkAddress(String linkAddress) {
		this.linkAddress = linkAddress;
	}
	public String getCorporationMan() {
		return corporationMan;
	}
	public void setCorporationMan(String corporationMan) {
		this.corporationMan = corporationMan;
	}
	public String getIdentificationCard() {
		return identificationCard;
	}
	public void setIdentificationCard(String identificationCard) {
		this.identificationCard = identificationCard;
	}
	public String getIdentificationCardEdit() {
		return identificationCardEdit;
	}
	public void setIdentificationCardEdit(String identificationCardEdit) {
		this.identificationCardEdit = identificationCardEdit;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getSellerEmail() {
		return sellerEmail;
	}
	public void setSellerEmail(String sellerEmail) {
		this.sellerEmail = sellerEmail;
	}
	public Integer getPwdFlag() {
		return pwdFlag;
	}
	public void setPwdFlag(Integer pwdFlag) {
		this.pwdFlag = pwdFlag;
	}
	public String getUpdPwdTime() {
		return updPwdTime;
	}
	public void setUpdPwdTime(String updPwdTime) {
		this.updPwdTime = updPwdTime;
	}
	public String getOpenBankName() {
		return openBankName;
	}
	public void setOpenBankName(String openBankName) {
		this.openBankName = openBankName;
	}
	public String getAcctRecCode() {
		return acctRecCode;
	}
	public void setAcctRecCode(String acctRecCode) {
		this.acctRecCode = acctRecCode;
	}
	public String getCardMan() {
		return cardMan;
	}
	public void setCardMan(String cardMan) {
		this.cardMan = cardMan;
	}
	public String getBankCard() {
		return bankCard;
	}
	public void setBankCard(String bankCard) {
		this.bankCard = bankCard;
	}
	public String getRegisterBank() {
		return registerBank;
	}
	public void setRegisterBank(String registerBank) {
		this.registerBank = registerBank;
	}
	public String getBankCode() {
		return bankCode;
	}
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}
	public String getAccBankPro() {
		return accBankPro;
	}
	public void setAccBankPro(String accBankPro) {
		this.accBankPro = accBankPro;
	}
	public String getAccBankCity() {
		return accBankCity;
	}
	public void setAccBankCity(String accBankCity) {
		this.accBankCity = accBankCity;
	}
	public String getFreezeTime() {
		return freezeTime;
	}
	public void setFreezeTime(String freezeTime) {
		this.freezeTime = freezeTime;
	}
	public Integer getFailCount() {
		return failCount;
	}
	public void setFailCount(Integer failCount) {
		this.failCount = failCount;
	}
	public Integer getSellerType() {
		return sellerType;
	}
	public void setSellerType(Integer sellerType) {
		this.sellerType = sellerType;
	}
	public String getAddTime() {
		return addTime;
	}
	public void setAddTime(String addTime) {
		this.addTime = addTime;
	}
	public String getAddMan() {
		return addMan;
	}
	public void setAddMan(String addMan) {
		this.addMan = addMan;
	}
	public String getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}
	public String getUpdateMan() {
		return updateMan;
	}
	public void setUpdateMan(String updateMan) {
		this.updateMan = updateMan;
	}
	public Integer getYield() {
		return yield;
	}
	public void setYield(Integer yield) {
		this.yield = yield;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public String getSellerId() {
		return sellerId;
	}
	public void setSellerId(String sellerId) {
		this.sellerId = sellerId;
	}
	public String getMemberNo() {
		return memberNo;
	}
	public void setMemberNo(String memberNo) {
		this.memberNo = memberNo;
	}
	public String getAppid() {
		return appid;
	}
	public void setAppid(String appid) {
		this.appid = appid;
	}
	public Integer getMerchantType() {
		return merchantType;
	}
	public void setMerchantType(Integer merchantType) {
		this.merchantType = merchantType;
	}
	public String getDomain() {
		return domain;
	}
	public void setDomain(String domain) {
		this.domain = domain;
	}
	public String getAgentName() {
		return agentName;
	}
	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}
	public String getMerInfoId() {
		return merInfoId;
	}
	public void setMerInfoId(String merInfoId) {
		this.merInfoId = merInfoId;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public Integer getLoginIpSet() {
		return loginIpSet;
	}
	public void setLoginIpSet(Integer loginIpSet) {
		this.loginIpSet = loginIpSet;
	}
	public String getOperateIp() {
		return operateIp;
	}
	public void setOperateIp(String operateIp) {
		this.operateIp = operateIp;
	}
	public String getMerIds() {
		return merIds;
	}
	public void setMerIds(String merIds) {
		this.merIds = merIds;
	}
	public String getTransferRealWhiteList() {
		return transferRealWhiteList;
	}
	public void setTransferRealWhiteList(String transferRealWhiteList) {
		this.transferRealWhiteList = transferRealWhiteList;
	}
	public String getSecAgentAccount() {
		return secAgentAccount;
	}
	public void setSecAgentAccount(String secAgentAccount) {
		this.secAgentAccount = secAgentAccount;
	}
	public String getSecAgentName() {
		return secAgentName;
	}
	public void setSecAgentName(String secAgentName) {
		this.secAgentName = secAgentName;
	}
	public String getIsRealRecharge() {
		return isRealRecharge;
	}
	public void setIsRealRecharge(String isRealRecharge) {
		this.isRealRecharge = isRealRecharge;
	}
	public String getCouCode() {
		return couCode;
	}
	public void setCouCode(String couCode) {
		this.couCode = couCode;
	}
	
	
}
