package com.threeweidu.entity;

import java.io.Serializable;

public class GoodsSupplier implements Serializable{
	private static final long serialVersionUID = 1L;
	private String supplierId;
	private String supplieName;
	private String suppliePhone;
	private String supplieAddress;
	private String addTime;
	private String addMan;
	private String editMan;
	private String editTime;
	private String passwd;
	private String verifyState;
	private String verifyRemark;
	private String verifyPassTime;
	private String verifyMan;
	private String supplierState;
	private String levelId;
	private String expireTime;
	private String lastLoginDate;
	private String loginFailureNumber;
	private String nickName;
	private String supplierType;
	private String memberHeadImg;
	private String operateWay;
	private String supplierClass;
	private String billingStyle;
	private String billingCycle;
	private String accountBalance;
	private String freezeAccountBalance;
	private String cooperationMode;
	private String deductionRate;
	private String abCheckCode;
	private String abTableKey;
	private String aabCheckCode;
	private String aabTableKey;
	private String earnestMoney;
	private String emCheckCode;
	private String emTableKey;
	private String isUsing;
	private String memberNo;
	private String email;
	private String fatherSupplierId;
	private String couCode;
	public String getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	public String getSupplieName() {
		return supplieName;
	}
	public void setSupplieName(String supplieName) {
		this.supplieName = supplieName;
	}
	public String getSuppliePhone() {
		return suppliePhone;
	}
	public void setSuppliePhone(String suppliePhone) {
		this.suppliePhone = suppliePhone;
	}
	public String getSupplieAddress() {
		return supplieAddress;
	}
	public void setSupplieAddress(String supplieAddress) {
		this.supplieAddress = supplieAddress;
	}
	public String getAddTime() {
		return addTime;
	}
	public void setAddTime(String addTime) {
		this.addTime = addTime;
	}
	public String getAddMan() {
		return addMan;
	}
	public void setAddMan(String addMan) {
		this.addMan = addMan;
	}
	public String getEditMan() {
		return editMan;
	}
	public void setEditMan(String editMan) {
		this.editMan = editMan;
	}
	public String getEditTime() {
		return editTime;
	}
	public void setEditTime(String editTime) {
		this.editTime = editTime;
	}
	public String getPasswd() {
		return passwd;
	}
	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}
	public String getVerifyState() {
		return verifyState;
	}
	public void setVerifyState(String verifyState) {
		this.verifyState = verifyState;
	}
	public String getVerifyRemark() {
		return verifyRemark;
	}
	public void setVerifyRemark(String verifyRemark) {
		this.verifyRemark = verifyRemark;
	}
	public String getVerifyPassTime() {
		return verifyPassTime;
	}
	public void setVerifyPassTime(String verifyPassTime) {
		this.verifyPassTime = verifyPassTime;
	}
	public String getVerifyMan() {
		return verifyMan;
	}
	public void setVerifyMan(String verifyMan) {
		this.verifyMan = verifyMan;
	}
	public String getSupplierState() {
		return supplierState;
	}
	public void setSupplierState(String supplierState) {
		this.supplierState = supplierState;
	}
	public String getLevelId() {
		return levelId;
	}
	public void setLevelId(String levelId) {
		this.levelId = levelId;
	}
	public String getExpireTime() {
		return expireTime;
	}
	public void setExpireTime(String expireTime) {
		this.expireTime = expireTime;
	}
	public String getLastLoginDate() {
		return lastLoginDate;
	}
	public void setLastLoginDate(String lastLoginDate) {
		this.lastLoginDate = lastLoginDate;
	}
	public String getLoginFailureNumber() {
		return loginFailureNumber;
	}
	public void setLoginFailureNumber(String loginFailureNumber) {
		this.loginFailureNumber = loginFailureNumber;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	public String getSupplierType() {
		return supplierType;
	}
	public void setSupplierType(String supplierType) {
		this.supplierType = supplierType;
	}
	public String getMemberHeadImg() {
		return memberHeadImg;
	}
	public void setMemberHeadImg(String memberHeadImg) {
		this.memberHeadImg = memberHeadImg;
	}
	public String getOperateWay() {
		return operateWay;
	}
	public void setOperateWay(String operateWay) {
		this.operateWay = operateWay;
	}
	public String getSupplierClass() {
		return supplierClass;
	}
	public void setSupplierClass(String supplierClass) {
		this.supplierClass = supplierClass;
	}
	public String getBillingStyle() {
		return billingStyle;
	}
	public void setBillingStyle(String billingStyle) {
		this.billingStyle = billingStyle;
	}
	public String getBillingCycle() {
		return billingCycle;
	}
	public void setBillingCycle(String billingCycle) {
		this.billingCycle = billingCycle;
	}
	public String getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(String accountBalance) {
		this.accountBalance = accountBalance;
	}
	public String getFreezeAccountBalance() {
		return freezeAccountBalance;
	}
	public void setFreezeAccountBalance(String freezeAccountBalance) {
		this.freezeAccountBalance = freezeAccountBalance;
	}
	public String getCooperationMode() {
		return cooperationMode;
	}
	public void setCooperationMode(String cooperationMode) {
		this.cooperationMode = cooperationMode;
	}
	public String getDeductionRate() {
		return deductionRate;
	}
	public void setDeductionRate(String deductionRate) {
		this.deductionRate = deductionRate;
	}
	public String getAbCheckCode() {
		return abCheckCode;
	}
	public void setAbCheckCode(String abCheckCode) {
		this.abCheckCode = abCheckCode;
	}
	public String getAbTableKey() {
		return abTableKey;
	}
	public void setAbTableKey(String abTableKey) {
		this.abTableKey = abTableKey;
	}
	public String getAabCheckCode() {
		return aabCheckCode;
	}
	public void setAabCheckCode(String aabCheckCode) {
		this.aabCheckCode = aabCheckCode;
	}
	public String getAabTableKey() {
		return aabTableKey;
	}
	public void setAabTableKey(String aabTableKey) {
		this.aabTableKey = aabTableKey;
	}
	public String getEarnestMoney() {
		return earnestMoney;
	}
	public void setEarnestMoney(String earnestMoney) {
		this.earnestMoney = earnestMoney;
	}
	public String getEmCheckCode() {
		return emCheckCode;
	}
	public void setEmCheckCode(String emCheckCode) {
		this.emCheckCode = emCheckCode;
	}
	public String getEmTableKey() {
		return emTableKey;
	}
	public void setEmTableKey(String emTableKey) {
		this.emTableKey = emTableKey;
	}
	public String getIsUsing() {
		return isUsing;
	}
	public void setIsUsing(String isUsing) {
		this.isUsing = isUsing;
	}
	public String getMemberNo() {
		return memberNo;
	}
	public void setMemberNo(String memberNo) {
		this.memberNo = memberNo;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getFatherSupplierId() {
		return fatherSupplierId;
	}
	public void setFatherSupplierId(String fatherSupplierId) {
		this.fatherSupplierId = fatherSupplierId;
	}
	public String getCouCode() {
		return couCode;
	}
	public void setCouCode(String couCode) {
		this.couCode = couCode;
	}
}
