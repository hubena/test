package com.threeweidu.entity;

import java.io.Serializable;

public class AgentPaymentWay implements Serializable {
	private static final long serialVersionUID = 1L;
	private String agentId;// 代理商id
	private Integer paymentName;// 支付方式
	private String realRate;// 实时扣率
	private String notRealRate;// 非实时扣率
	private String updateTime;//

	public String getAgentId() {
		return agentId;
	}

	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}

	public Integer getPaymentName() {
		return paymentName;
	}

	public void setPaymentName(Integer paymentName) {
		this.paymentName = paymentName;
	}

	public String getRealRate() {
		return realRate;
	}

	public void setRealRate(String realRate) {
		this.realRate = realRate;
	}

	public String getNotRealRate() {
		return notRealRate;
	}

	public void setNotRealRate(String notRealRate) {
		this.notRealRate = notRealRate;
	}

	public String getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}
}
