package com.threeweidu.dao.mybatis;

import org.apache.ibatis.annotations.Param;

import com.threeweidu.entity.Agent;

public interface AgentMapper {

	Agent findAgentInfoByAgentid(@Param(value="agentId")String agentId);

	int updateAgentInfo(Agent agent);

	int updatePassword(@Param(value="agentId")String agentId, 
			@Param(value="agentNewPassword")String agentNewPassword,@Param(value="editMan")String editMan);

	String findAgentPassword(@Param(value="agentId")String agentId);

	Agent getAgentByAgentid(@Param(value="agentId")String agentId);

	Agent getAgentLogo(String domainName);

	Agent getAgentByIdAndPayPasswd(@Param(value="agentId")String agentId, @Param(value="payPasswd")String payPasswd); 
	
	//查找支付密码
	String findAgentPayPassword(@Param(value="agentId")String agentId); 
	
	//修改支付密码
	int updatePayPassword(@Param(value="agentId")String agentId, 
			@Param(value="agentNewPayPassword")String agentNewPassword1,@Param(value="editMan")String editMan);
	//添加验证码发送记录
	int insertAgentSendCodeRecord(@Param(value="agentId")String agentId, 
			@Param(value="sendType")Integer sendType, @Param(value="sendAccount")String sendAccount, @Param(value="sendMsg")String sendMsg);
	//添加代理商操作日志记录
	int insertAgentOperateLog(@Param(value="agentId")String agentId, 
			@Param(value="operateContent")String operateContent, @Param(value="operateIp")String operateIp);
	//修改代理商IP绑定状态
	int updateAgentIsBindingIP(@Param(value="agentId")String agentId, @Param(value="isBindingIP")Integer isBindingIP);
	
}
