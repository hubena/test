package com.threeweidu.dao.proc;

import java.io.Serializable;
import java.sql.ResultSet;

import org.springframework.stereotype.Repository;

import com.threeweidu.entity.SysException;
import com.threeweidu.pepos.dao.AbstractDaoSupport;


@Repository
public class SysExceptionDao extends AbstractDaoSupport<SysException> implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1844750085315645564L;

	@Override
	protected SysException limitRowMapper(ResultSet arg0, Integer arg1) {
		return null;
	}

	@Override
	protected SysException rowMapper(ResultSet arg0) {
		return null;
	}

	public int addSysException(String callName, Object[] args) throws Exception {
		return this.save(callName, args);
	}

}
