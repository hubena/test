package com.threeweidu.dao.mybatis;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.threeweidu.entity.PaymentRecord;
import com.threeweidu.entity.report.AccountReport;
import com.threeweidu.view.req.page.Page;

public interface PaymentRecordMapper {

	List<PaymentRecord> findList(@Param(value="paymentRecord")PaymentRecord paymentRecord, 
			@Param(value="page")Page page);
	
	Long findListCount(@Param(value="paymentRecord")PaymentRecord paymentRecord);
	
	List<AccountReport> exportExcelOld(@Param(value="paymentRecord")PaymentRecord paymentRecord);
	
	List<PaymentRecord> exportExcel(@Param(value="paymentRecord")PaymentRecord paymentRecord,
			@Param(value="page")Page page);

	void updAsynInfo(@Param(value="ordid")String ordid, @Param(value="asynState")int asynState,
			@Param(value="asynCount")int asynCount, @Param(value="synParam")String synParam);

	PaymentRecord findAsynByOrdId(@Param(value="ordid")String ordid);

	PaymentRecord findRechargeRecordByMerIdAndBusinessOrdid(@Param(value="merId")String merId,
			@Param(value="businessOrdid")String businessOrdid);

	PaymentRecord findSumFooter(@Param(value="paymentRecord")PaymentRecord paymentRecord);

}
