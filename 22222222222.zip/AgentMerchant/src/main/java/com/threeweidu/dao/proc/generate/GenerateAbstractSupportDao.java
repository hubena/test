package com.threeweidu.dao.proc.generate;

import java.lang.reflect.ParameterizedType;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.Collections;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;

import com.threeweidu.pepos.dao.AbstractDaoSupport;
import com.threeweidu.view.req.page.Page;
import com.threeweidu.view.result.EasyUIData;

@SuppressWarnings("unchecked")
public class GenerateAbstractSupportDao<T> extends AbstractDaoSupport<T> {
	
	/**
	 * 通用的查询存储过程
	 */
	private static final String PROC_SELECT = "PUBLIC_TABLE_LIST_SELECT";
	
	/**
	 * 通用的分页存储过程
	 */
	private static final String PROC_PAGE_SELECT = "PUBLIC_TABLE_PAGE_LIST_SELECT";
	
	/**
	 * 通用的统计存储过程
	 */
	private static final String PROC_COUNT_SELECT = "PUBLIC_TABLE_COUNT_SELECT";
	
	/**
	 * 通用的更新存储过程
	 */
	private static final String PROC_TABLE_UPDATE = "SHOP_COMMONTABLE_ALL_UPDATE";
	
	/**
	 * 通用的删除存储过程
	 */
	private static final String PROC_TABLE_DELETE = "SHOP_COMMONTABLE_ALL_DELETE";
	
	
	public Class<T> entityClass;

	public GenerateAbstractSupportDao() {
		ParameterizedType type = (ParameterizedType) getClass().getGenericSuperclass();
		entityClass = (Class<T>) type.getActualTypeArguments()[0];
	}

	@Override
	protected T limitRowMapper(ResultSet rs, Integer arg) throws Exception {
		T t = null;
		synchronized (rs) {
			t = entityClass.newInstance();
			if (rs != null) {
				ResultSetMetaData rsm = rs.getMetaData();
				int col = rsm.getColumnCount();
				for (int i = 1; i <= col; i++) {
					BeanUtils.setProperty(t, rsm.getColumnName(i), rs.getString(rsm.getColumnName(i)));
				}
			}
		}
		return t;
	}

	@Override
	protected T rowMapper(ResultSet rs) throws Exception {
		T t = null;
		synchronized (rs) {
			t = entityClass.newInstance();
			if (rs != null) {
				ResultSetMetaData rsm = rs.getMetaData();
				int col = rsm.getColumnCount();
				for (int i = 1; i <= col; i++) {
					BeanUtils.setProperty(t, rsm.getColumnName(i), rs.getString(rsm.getColumnName(i)));
				}
			}
		}
		return t;
	}

	/**
	 * 根据page对象查询数据,返回EasyUIData对象
	 * 
	 * @author HuangBo
	 * @since 2016-05-04
	 * @param page 分页对象
	 * @return EasyUIData
	 * @throws Exception
	 */
	public EasyUIData queryEasyUIData(Page page) throws Exception {
		if (null == page) {
			return new EasyUIData(false, "page对象为空", 0L, Collections.EMPTY_LIST);
		}
		if (StringUtils.isEmpty(page.getWhereField()) 
				|| null == page.getPageNo() 
				|| null == page.getPageSize() 
				|| StringUtils.isEmpty(page.getSortField()) 
				|| StringUtils.isEmpty(page.getSortType()) 
				|| StringUtils.isEmpty(page.getTableField()) 
				|| StringUtils.isEmpty(page.getValueField())) {
			return new EasyUIData(false, "无效的分页参数", 0L, Collections.EMPTY_LIST);
		}
		Long total = this.count(page);
		if (total.intValue() == 0) {
			return new EasyUIData(true, "未查询到符合条件的数据", 0L, Collections.EMPTY_LIST);
		}
		List<?> rows = this.page(page);
		return new EasyUIData(true, "查询成功", total, rows);
	}

	/**
	 * 根据page对象统计总数
	 * 
	 * @param page
	 * @return
	 * @throws Exception
	 */
	public Long count(Page page) throws Exception {
		return super.totalCount(PROC_COUNT_SELECT, new Object[] { page.getWhereField(), page.getTableField() });
	}

	/**
	 * 根据page对象分页查询某一页数据
	 * 
	 * @param page
	 * @return
	 * @throws Exception
	 */
	public List<T> page(Page page) throws Exception {
		return super.getObjectList(PROC_PAGE_SELECT, 
				new Object[] { 
					page.getWhereField(), 
					page.getPageNo(), 
					page.getPageSize(), 
					page.getSortField(), 
					page.getSortType(), 
					page.getTableField(), 
					page.getValueField() 
				});
	}

	/**
	 * 根据page对象分页查询某一页数据
	 * 
	 * @param page
	 * @return
	 * @throws Exception
	 */
	public List<T> page(Page page, Integer findType) throws Exception {
		return super.getLimitObjectList(PROC_PAGE_SELECT,
				new Object[] { 
					page.getWhereField(), 
					page.getPageNo(), 
					page.getPageSize(), 
					page.getSortField(), 
					page.getSortType(), 
					page.getTableField(), 
					page.getValueField() 
				}, findType);
	}

	/**
	 * 通用查询存储过程
	 * 
	 * @param page
	 * @return
	 * @throws Exception
	 */
	public List<T> query(Page page) throws Exception {
		return super.getObjectList(PROC_SELECT, new Object[] { page.getWhereField(), page.getTableField(), page.getValueField() });
	}

	/**
	 * 通用查询存储过程
	 * 
	 * @param page
	 * @return
	 * @throws Exception
	 */
	public List<T> query(Page page, Integer findType) throws Exception {
		return super.getLimitObjectList(PROC_SELECT, new Object[] { page.getWhereField(), page.getTableField(), page.getValueField() }, findType);
	}

	/**
	 * 通用更新数据
	 * 
	 * @param page
	 * @return
	 * @throws Exception
	 */
	public int update(String tableName, String fieldStr, String whereStr) throws Exception {
		return super.update(PROC_TABLE_UPDATE, new Object[] { tableName, fieldStr, whereStr });
	}

	/**
	 * 通用删除数据
	 * 
	 * @param page
	 * @return
	 * @throws Exception
	 */
	public int delete(String whereStr, String tableStr) throws Exception {
		return super.update(PROC_TABLE_DELETE, new Object[] { whereStr, tableStr });
	}
	
}
