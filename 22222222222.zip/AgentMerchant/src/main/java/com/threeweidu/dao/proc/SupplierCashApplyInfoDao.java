package com.threeweidu.dao.proc;

import java.sql.ResultSet;
import java.util.List;

import org.springframework.stereotype.Repository;
import com.threeweidu.dao.proc.generate.GenerateAbstractSupportDao;
import com.threeweidu.entity.SupplierCashApplyInfo;
import com.threeweidu.pepos.security.EncryptMoney;
import com.threeweidu.view.req.page.Page;
import com.threeweidu.view.result.EasyUIData;

@Repository(value = "supplierCashApplyInfoProcDao")
public class SupplierCashApplyInfoDao extends GenerateAbstractSupportDao<SupplierCashApplyInfo> {

	private static final String MODEL_TABLE_NAME = "SupplierCashApply s left join GoodsSupplier g on s.supplierId=g.supplierId" +
			" left join SupplierCashApplyProfit sp on s.cashId=sp.cashId";
	private static final String MODEL_TABLE_VALUEFIELD = "s.*,g.supplierClass,sp.agentProfit,sp.deductionState"; // 要查询的字段

	@Override
	protected SupplierCashApplyInfo limitRowMapper(ResultSet rs, Integer arg) throws Exception {
		SupplierCashApplyInfo supplierCashApply = super.limitRowMapper(rs, arg);
		String result[] = EncryptMoney.decryptMoney(String.valueOf(supplierCashApply.getCashMoney()), supplierCashApply.getCheckCode(), supplierCashApply.getCashId(), supplierCashApply.getTableKey());
		if (result.length == 2 && result[0] == "1001") {
			supplierCashApply.setCashMoney(result[1]);
		} else {
			supplierCashApply.setCashMoney("0");
		}
		supplierCashApply.setCheckCode(null);
		supplierCashApply.setTableKey(null);
		return supplierCashApply;
	}

	@Override
	protected SupplierCashApplyInfo rowMapper(ResultSet rs) throws Exception {
		SupplierCashApplyInfo supplierCashApply = super.rowMapper(rs);
		String result[] = EncryptMoney.decryptMoney(String.valueOf(supplierCashApply.getCashMoney()), supplierCashApply.getCheckCode(), supplierCashApply.getCashId(), supplierCashApply.getTableKey());
		if (result.length == 2 && result[0] == "1001") {
			supplierCashApply.setCashMoney(result[1]);
		} else {
			supplierCashApply.setCashMoney("0");
		}
		supplierCashApply.setCheckCode(null);
		supplierCashApply.setTableKey(null);
		return supplierCashApply;
	}

	@Override
	public List<SupplierCashApplyInfo> page(Page page) throws Exception {
		page.setTableField(MODEL_TABLE_NAME);
		page.setValueField(MODEL_TABLE_VALUEFIELD);
		return super.page(page);
	}

	public Long countPage(Page page) throws Exception {
		page.setTableField(MODEL_TABLE_NAME);
		page.setValueField(MODEL_TABLE_VALUEFIELD);
		return super.count(page);
	}

	public EasyUIData queryEasyUIData(Page page) throws Exception {
		page.setTableField(MODEL_TABLE_NAME);
		page.setValueField(MODEL_TABLE_VALUEFIELD);
		return super.queryEasyUIData(page);
	}

}