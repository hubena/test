package com.threeweidu.dao.mybatis;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.threeweidu.entity.MerchantTradeCount;
import com.threeweidu.view.req.page.Page;

@Repository
public interface MerchantTradeCountMapper {

	List<MerchantTradeCount> findList(@Param(value="merchant")MerchantTradeCount merchant, 
			@Param(value="page")Page page);
	
	Long findListCount(@Param(value="merchant")MerchantTradeCount merchant);	
	
	List<MerchantTradeCount> findListByToday(@Param(value="merchant")MerchantTradeCount merchant, 
			@Param(value="page")Page page);
	
	Long findListByTodayCount(@Param(value="merchant")MerchantTradeCount merchant);

	MerchantTradeCount findSumFooter(@Param(value="merchant")MerchantTradeCount merchantTradeCount);	

}
