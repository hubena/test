package com.threeweidu.dao.mybatis;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.threeweidu.entity.Announcement;
import com.threeweidu.view.req.page.Page;

public interface AnnouncementMapper {

	List<Announcement> findList(@Param(value="announcement")Announcement announcement, 
			@Param(value="page")Page page);
	
	Long findListCount(@Param(value="announcement")Announcement announcement);
	
	int addAnnouncement(@Param(value="announcement")Announcement announcement);

	int updateAnnouncement(@Param(value="announcement")Announcement announcement);

	int updatePublish(@Param(value="announcement")Announcement announcement);

}
