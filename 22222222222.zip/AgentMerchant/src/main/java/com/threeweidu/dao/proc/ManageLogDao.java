package com.threeweidu.dao.proc;



import java.io.Serializable;
import java.sql.ResultSet;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.threeweidu.entity.ManageLog;
import com.threeweidu.pepos.dao.AbstractDaoSupport;






/**
 * 版权所有(C)2012 公司名称：三维度 公司地址：深圳市福田区中国凤凰大厦2栋20A 网址: www.3weidu.com 版本: 1.0
 * 文件名：com.threeweidu.pepos.dao.ManageLogDao.java 文件描述： 作者: 创建时间:
 * 2012-7-31上午11:37:08 负责人: 修改者： 修改时间：2012-7-31上午11:37:08
 */
@Repository
public class ManageLogDao extends AbstractDaoSupport<ManageLog> implements
		Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2575392810528156461L;
//	private static Logger log = Logger.getLogger(ManageLogDao.class.getName());

	/**
	 * 遍历结果集
	 */
	@Override
	protected ManageLog rowMapper(ResultSet rs) throws Exception {
		ManageLog empLog = null;
		synchronized (rs) {
			if (rs != null) {
				empLog = new ManageLog();
				try {
					// 设置参数
					//empLog.setLogId(rs.getLong("logId"));
					empLog.setEmpNumber(rs.getString("empNumber"));
					empLog.setLogContents(rs.getString("logContents"));

					empLog.setOperateTime(rs.getTimestamp("OperateTime"));
					empLog.setOperateTimeStr(empLog.getOperateTime().toString());

					empLog.setLogIp(rs.getString("logIP"));

					//empLog.setLogTypeParentId(rs.getInt("logTypeParentId"));

					//empLog.setLogTypeChildId(rs.getInt("logTypeChildId"));
				} catch (Exception e) {
					throw new Exception(e);
				}
			}
		}
		return empLog;
	}

	/**
	 * 添加日志信息
	 * 
	 * @param callName
	 * @param emp
	 * @return
	 * @throws Exception
	 */
	public int addManageLog(String callName, Object[] manageLog)
			throws Exception {
		return super.save(callName, manageLog);
	}

	/**
	 * 获取日志列表
	 * 
	 * @param callName
	 * @param emp
	 * @return
	 * @throws Exception
	 */
	public List<ManageLog> findManageLogs(String callName, Object[] manageLog)
			throws Exception {
		return this.getObjectList(callName, manageLog);
	}

	/***
	 * 根据条件查询日志信息
	 * 
	 * @return
	 * @throws Exception
	 */
	public ManageLog findManageLogByEmpNumber(String callName,
			Object[] manageLog) throws Exception {
		ManageLog empNumberLog = this.find(callName, manageLog);
		return empNumberLog;
	}

	/**
	 * 查询日志的所有记录数
	 * 
	 * @param callName
	 * @param args
	 * @return
	 * @throws Exception
	 */
	public long findCounts(String callName, Object[] args)
			throws Exception {
		long count = super.findCount(callName, args);
		return count;
	}

	/**
	 * 更新日志信息
	 * 
	 * @param callName
	 * @param emp
	 * @return
	 * @throws Exception
	 */
	public int updateLogger(String callName, Object[] logInfo)
			throws Exception {
		return super.update(callName, logInfo);
	}

	/***
	 * 根据员工号查询信息
	 * 
	 * @return
	 * @throws Exception
	 */
	public ManageLog findManageLogByLogID(String callName, Object[] manageLog)
			throws Exception {
		ManageLog e = super.find(callName, manageLog);
		return e;
	}

	@Override
	protected ManageLog limitRowMapper(ResultSet arg0, Integer arg1)
			throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * 批量添加日志信息
	 * 
	 * @param callName
	 * @param args
	 * @return
	 * @throws Exception
	 */
	public int batchAddManageLogs(String callName, List<Object[]> args)
			throws Exception {
		return this.batchSave(callName, args);
	}

	/**
	 * 根据条件获取日志列表
	 * 
	 * @param callName
	 * @param emp
	 * @return
	 * @throws Exception
	 */
	public List<ManageLog> findManageLogsByTerm(String callName,
			Object[] manageLog) throws Exception {
		return this.getObjectList(callName, manageLog);
	}

}
