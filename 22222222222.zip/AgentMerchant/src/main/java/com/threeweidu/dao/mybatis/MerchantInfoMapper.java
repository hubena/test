package com.threeweidu.dao.mybatis;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.threeweidu.entity.Merchant;
import com.threeweidu.entity.MerchantInfo;
import com.threeweidu.view.req.page.Page;

public interface MerchantInfoMapper {

	int updateMerchantInfoCount(@Param(value = "merInfoId")String merInfoId);

	MerchantInfo findMerchantInfoById(@Param(value = "merInfoId")String merInfoId);
	
	List<MerchantInfo> findMerchantInfoByAgentId(@Param(value = "agentId")String agentId);

	List<MerchantInfo> findList(@Param(value = "merchantInfo")MerchantInfo merchantInfo, @Param(value = "page")Page page);

	Long findListCount(@Param(value = "merchantInfo")MerchantInfo merchantInfo);

	Merchant findMerchantById(@Param(value = "merInfoId")String merInfoId);

}
