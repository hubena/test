package com.threeweidu.dao.mybatis;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.threeweidu.entity.AssociateMerchant;
import com.threeweidu.entity.SecSWDAgent;
import com.threeweidu.view.req.page.Page;

@Repository
public interface SecSWDAgentMapper {
	
	List<SecSWDAgent> findList(@Param(value="secSWDAgent")SecSWDAgent secSWDAgent, @Param(value="page")Page page);
	
	Long findListCount(@Param(value="secSWDAgent")SecSWDAgent secSWDAgent);
	
	int insertSecSWDAgent(@Param(value="secSWDAgent")SecSWDAgent secSWDAgent);
	
	Long findAccountCount(String secAgentAccount);
	
	List<AssociateMerchant> findAssociateList(@Param(value="associateMerchant")AssociateMerchant associateMerchant, @Param(value="page")Page page);
	
	Long findAssociateCount(@Param(value="associateMerchant")AssociateMerchant associateMerchant);
	
	int updateAssociate(@Param(value="associateMerchant")AssociateMerchant associateMerchant);

	AssociateMerchant selectByAmId(@Param(value="amId")String amId);
	
	Long batchUpdateDisAssociate(@Param(value="associateMerchants")List<AssociateMerchant> associateMerchants);
	
}
