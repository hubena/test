package com.threeweidu.dao.mybatis;

import org.apache.ibatis.annotations.Param;

import com.threeweidu.entity.Agent;

public interface LoginMapper {

	Agent findAgentInfo(String username);

	int updateLoginFailNum(@Param(value="username")String username); 

}
