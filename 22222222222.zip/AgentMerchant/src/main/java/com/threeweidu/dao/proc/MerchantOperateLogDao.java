package com.threeweidu.dao.proc;

import java.io.Serializable;

import org.springframework.stereotype.Repository;

import com.threeweidu.dao.proc.generate.GenerateAbstractSupportDao;
import com.threeweidu.entity.MerchantOperateLog;

@Repository
public class MerchantOperateLogDao extends GenerateAbstractSupportDao<MerchantOperateLog> 
		implements Serializable {

	private static final long serialVersionUID = 2575392810528156461L;

}
