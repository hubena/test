package com.threeweidu.dao.mybatis;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.threeweidu.entity.PaymentRecordProfitStatistics;
import com.threeweidu.view.req.page.Page;

public interface PaymentRecordProfitStatisticsMapper {

	List<PaymentRecordProfitStatistics> findList(@Param(value = "statistics") PaymentRecordProfitStatistics statistics, @Param(value = "page") Page page);

	Long findListCount(@Param(value = "statistics") PaymentRecordProfitStatistics statistics);

	PaymentRecordProfitStatistics findSumFooter(@Param(value = "statistics") PaymentRecordProfitStatistics statistics);

}
