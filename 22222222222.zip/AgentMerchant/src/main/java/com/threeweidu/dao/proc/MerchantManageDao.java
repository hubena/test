package com.threeweidu.dao.proc;

import java.sql.ResultSet;
import org.springframework.stereotype.Repository;

import com.threeweidu.dao.proc.generate.GenerateAbstractSupportDao;
import com.threeweidu.entity.Merchant;



@Repository
public class MerchantManageDao extends GenerateAbstractSupportDao<Merchant> {
	
	@Override
	public Merchant limitRowMapper(ResultSet rs, Integer arg) throws Exception {
		return super.limitRowMapper(rs, arg);
	}

	@Override
	public Merchant rowMapper(ResultSet rs) throws Exception {
		return super.rowMapper(rs);
	}
	
}
