package com.threeweidu.dao.proc;

import java.math.BigDecimal;
import java.sql.ResultSet;

import org.springframework.stereotype.Repository;

import com.threeweidu.dao.proc.generate.GenerateAbstractSupportDao;
import com.threeweidu.entity.Merchant;
import com.threeweidu.pepos.security.EncryptMoney;
import com.threeweidu.utils.Null2;

@Repository
public class MerchantUserDao extends GenerateAbstractSupportDao<Merchant>{
	@Override
	public Merchant limitRowMapper(ResultSet rs, Integer arg) throws Exception {
		return super.limitRowMapper(rs, arg);
	}

	@Override
	public Merchant rowMapper(ResultSet rs) throws Exception {
		Merchant supplier=super.rowMapper(rs);
		
		String[] supAccount = EncryptMoney.decryptMoney(supplier.getAccountBalance(), supplier.getAbCheckCode(), supplier.getSupplierId(), supplier.getAbTableKey());
		if(Null2.isNotNull(supAccount[1].toString())){
			supplier.setAccountBalance(supAccount[1].toString());
		}
		
		String withdrawFeeTypeValue=supplier.getWithdrawFeeTypeValue();
		if(Null2.isNotNull(withdrawFeeTypeValue)){
			BigDecimal big=new BigDecimal(withdrawFeeTypeValue).movePointLeft(2);
			supplier.setWithdrawFeeTypeValue(big.toString());
		}
		String withdrawMaxfee=supplier.getWithdrawMaxfee();
		if(Null2.isNotNull(withdrawMaxfee)){
			BigDecimal big=new BigDecimal(withdrawMaxfee).movePointLeft(2);
			supplier.setWithdrawMaxfee(big.toString());
		}
		
		String rechargeFeeTypeValue=supplier.getRechargeFeeTypeValue();
		if(Null2.isNotNull(rechargeFeeTypeValue)){
			BigDecimal big=new BigDecimal(rechargeFeeTypeValue).movePointLeft(2);
			supplier.setRechargeFeeTypeValue(big.toString());
		}
		String rechargeMaxFee=supplier.getRechargeMaxFee();
		if(Null2.isNotNull(rechargeMaxFee)){
			BigDecimal big=new BigDecimal(rechargeMaxFee).movePointLeft(2);
			supplier.setRechargeMaxFee(big.toString());
		}
		return supplier;
	}
}
