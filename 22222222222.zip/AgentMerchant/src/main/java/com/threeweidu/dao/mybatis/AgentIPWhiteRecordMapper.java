package com.threeweidu.dao.mybatis;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.threeweidu.entity.AgentIPWhiteRecord;
import com.threeweidu.view.req.page.Page;

public interface AgentIPWhiteRecordMapper {

	
	List<AgentIPWhiteRecord> findList(@Param(value = "agentIPWhiteRecord")AgentIPWhiteRecord agentIPWhiteRecord, @Param(value = "page")Page page);
	
	Long findListCount(@Param(value = "agentIPWhiteRecord")AgentIPWhiteRecord agentIPWhiteRecord);

	Integer addAgentIPWhiteRecord(AgentIPWhiteRecord agentIPWhiteRecord);
	
	Long deleteAgentIPWhiteRecord(@Param(value= "agentIPWhiteRecords")List<AgentIPWhiteRecord> agentIPWhiteRecords);
	
	Integer findCountSame(@Param(value = "agentIPWhiteRecord")AgentIPWhiteRecord agentIPWhiteRecord);
	
	Integer updateStateBatch(@Param(value= "agentIPWhiteRecords")List<AgentIPWhiteRecord> agentIPWhiteRecords);
	
	List<String> findAgentIPWhiteRecord(@Param(value = "agentId")String agentId, @Param(value = "state")Integer state);

}
