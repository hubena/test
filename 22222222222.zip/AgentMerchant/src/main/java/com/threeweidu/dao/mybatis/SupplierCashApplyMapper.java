package com.threeweidu.dao.mybatis;

import org.apache.ibatis.annotations.Param;

import com.threeweidu.entity.SupplierCashApply;
import com.threeweidu.view.req.page.Page;

public interface SupplierCashApplyMapper {

	/**
	 * 根据提现订单号查询提现申请记录
	 * 
	 * @param ordId
	 * @return
	 */
	SupplierCashApply findByCashId(@Param(value = "cashId") String cashId);

	SupplierCashApply findSumFooter(@Param(value = "page")Page page);

}