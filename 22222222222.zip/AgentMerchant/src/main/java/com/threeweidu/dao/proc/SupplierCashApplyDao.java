package com.threeweidu.dao.proc;

import java.sql.ResultSet;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Repository;

import com.threeweidu.dao.proc.generate.GenerateAbstractSupportDao;
import com.threeweidu.entity.SupplierCashApply;
import com.threeweidu.pepos.security.EncryptMoney;
import com.threeweidu.view.req.page.Page;
import com.threeweidu.view.result.EasyUIData;

@Repository
public class SupplierCashApplyDao extends GenerateAbstractSupportDao<SupplierCashApply> {

	private static final String MODEL_TABLE_NAME = "SupplierCashApply";
	private static final String MODEL_TABLE_VALUEFIELD = "*"; // 要查询的字段

	@Override
	protected SupplierCashApply rowMapper(ResultSet rs) throws Exception {
		SupplierCashApply cash = super.rowMapper(rs);
		String cashMoney = rs.getString("cashMoney");
		if (StringUtils.isNotEmpty(cashMoney)) {
			String[] deMoney = EncryptMoney.decryptMoney(cashMoney, rs.getString("checkCode"), cash.getCashId(), rs.getString("tableKey"));
			if (deMoney[0].equals("1001")) {
				cash.setCashMoney(Long.parseLong(deMoney[1]));
			}
		}

		return cash;
	}

	public EasyUIData queryEasyUIData(Page page) throws Exception {
		page.setTableField(MODEL_TABLE_NAME);
		page.setValueField(MODEL_TABLE_VALUEFIELD);
		EasyUIData d = super.queryEasyUIData(page);
		return d;
	}

}