package com.threeweidu.dao.proc;

import java.sql.ResultSet;

import org.springframework.stereotype.Repository;

import com.threeweidu.dao.proc.generate.GenerateAbstractSupportDao;
import com.threeweidu.entity.SendCodeRecord;
import com.threeweidu.view.req.page.Page;
import com.threeweidu.view.result.EasyUIData;

@Repository
public class SendCodeRecordDao extends GenerateAbstractSupportDao<SendCodeRecord> {

	private static final String MODEL_TABLE_NAME = "SendCodeRecord s inner join AgentMerchant am on s.fatherMerId=am.merId";
	private static final String MODEL_TABLE_VALUEFIELD = "s.*"; // 要查询的字段

	@Override
	protected SendCodeRecord limitRowMapper(ResultSet rs, Integer arg) throws Exception {
		return super.limitRowMapper(rs, arg);
	}

	@Override
	protected SendCodeRecord rowMapper(ResultSet rs) throws Exception {
		return super.rowMapper(rs);
	}

	public EasyUIData queryEasyUIData(Page page) throws Exception {
		page.setTableField(MODEL_TABLE_NAME);
		page.setValueField(MODEL_TABLE_VALUEFIELD);
		return super.queryEasyUIData(page);
	}
	
}
