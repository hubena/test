package com.threeweidu.dao.mybatis;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.threeweidu.entity.Chancel;
import com.threeweidu.entity.MerAuthorization;
import com.threeweidu.entity.MerKeyInfo;
import com.threeweidu.entity.PaymentWay;
import com.threeweidu.view.req.page.Page;


@Repository
public interface MerAuthorizationInfoMapper {

	/**
	 * 商户授权支付方式
	 */
	int addMerAuthorization(MerAuthorization merAuthorization);

	/**
	 * 批量取消商户授权
	 */
	int deleteMerAuthorization(@Param(value = "merAuthorizations")List<MerAuthorization> merAuthorizations);

	/**
	 * 添加微信商户授权支付方式
	 */
	int addMerKeyInfo(MerKeyInfo merKeyInfo);

	/**
	 * 修改微信商户授权支付方式
	 */
	int updateMerKeyInfo(MerKeyInfo merKeyInfo);

	/**
	 * 查询支付方式
	 */
	PaymentWay getPaymentWayByPaymentId(@Param(value = "paymentId")String paymentId);

	/**
	 * 删除微信商户授权支付方式 
	 */
	int deleteMerKeyInfo(@Param(value = "merId")String merId);

	/**
	 * 更新扣率
	 */
	int updateDeductionRate(@Param(value = "merAuthorization")MerAuthorization merAuthorization);

	/**
	 * 获取微信商户授权支付方式
	 */
	MerKeyInfo getMerKeyInfoByMerid(@Param(value = "merId")String merId);

	/**
	 * 获取授权 by merId and paymentId
	 */
	MerAuthorization getMerAuthorizationByMeridAndPaymentId(@Param(value = "merId")String merId,
			@Param(value = "paymentId")String paymentId);
	/**
	 * 获取支付方式
	 * @param page
	 * @param paymentWay
	 * @return
	 */
	List<PaymentWay> findPaymentWayList(@Param(value="page")Page page, @Param(value="paymentWay")PaymentWay paymentWay);

	/**
	 * 获取支付方式个数
	 */
	Long findPaymentWayCount(@Param(value="paymentWay")PaymentWay paymentWay);
	
	/**
	 * 查询是否方式  by merId and paymentId
	 */
	PaymentWay getPaymentWayByPaymentIdAndMerid(@Param(value = "paymentId")String paymentId, 
			@Param(value = "merId")String merId);

	List<MerAuthorization> getMerAuthorizationByMerid(String merId);
	
	Chancel findChancelByPaymentid(@Param(value = "paymentId")String paymentId);
	
	/*
	 * 解锁
	 */
	public int deblock(HashMap<String, String> deblock);
	
}
