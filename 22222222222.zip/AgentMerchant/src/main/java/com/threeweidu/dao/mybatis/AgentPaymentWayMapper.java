package com.threeweidu.dao.mybatis;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.threeweidu.entity.AgentPaymentWay;

@Repository
public interface AgentPaymentWayMapper {

	/**
	 * 获取该代理商的支付方式
	 */
	List<AgentPaymentWay> findAll(@Param(value = "agentId") String agentId);

	/**
	 * 添加支付方式
	 */
	int addAgentPaymentWay(AgentPaymentWay agentPaymentWay);

	/**
	 * 修改支付方式扣率
	 */
	int updateAgentPaymentWay(AgentPaymentWay agentPaymentWay);

	/**
	 * 获取该代理商的支付方式
	 */
	AgentPaymentWay findByPaymentWay(@Param(value = "agentId") String agentId,
			@Param(value = "paymentName") int paymentName);

}
