package com.threeweidu.dao.mybatis;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.threeweidu.entity.GoodsSupplier;
import com.threeweidu.entity.Merchant;
import com.threeweidu.entity.SupplierCashTransferFee;
import com.threeweidu.entity.Terminal;

public interface MerchantManageMapper {

	int updateMerchantRate(Merchant merchant);

	int updateEmail(Merchant merchant);

	Merchant findSupllierInfo(@Param(value = "supplierId") String supplierId);
	
	Merchant findMerchantByMerId(@Param(value = "merId") String merId);

	Merchant findMerchantByMerId2(@Param(value = "merId")String merId);

	int updatePhone(@Param(value = "supplierId")String supplierId, @Param(value = "suppliePhone")String suppliePhone);
	
	int updatePasswd(@Param(value = "supplierId")String supplierId, @Param(value = "passwd")String encryptPassWd);
	
	int updatePayPasswd(@Param(value = "supplierId")String supplierId, @Param(value = "payPasswd")String encryptPayPassWd);

	List<Merchant> findMerchantByAgentId(@Param(value = "agentId")String agentId);

	int addMerchant(@Param(value = "merchant")Merchant merchant);

	int addAgentMerchant(@Param(value = "merchant")Merchant merchant);

	int addGoodSupplier(@Param(value = "goods")GoodsSupplier goodsSupplier);

	int addSupplierCashTransferFee(@Param(value = "fee")SupplierCashTransferFee fee);

	int addTerminal(@Param(value = "terminal")Terminal terminal);

	List<Merchant> findMerchantBySecAgentId(@Param(value = "secAgentId")String secAgentId);

	int updateRemark(@Param(value = "merchant")Merchant merchant);

	int loginIPUnwrap(Merchant merchant);

	int updateTransferReal(Merchant merchant);

}
