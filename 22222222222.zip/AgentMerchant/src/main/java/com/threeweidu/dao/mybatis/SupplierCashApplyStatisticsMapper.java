package com.threeweidu.dao.mybatis;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.threeweidu.entity.SupplierCashApplyStatistics;
import com.threeweidu.view.req.page.Page;

public interface SupplierCashApplyStatisticsMapper {

	List<SupplierCashApplyStatistics> findList(@Param(value = "statistics") SupplierCashApplyStatistics statistics, @Param(value = "page") Page page);

	Long findListCount(@Param(value = "statistics") SupplierCashApplyStatistics statistics);

	SupplierCashApplyStatistics findSumFooter(@Param(value = "statistics") SupplierCashApplyStatistics statistics);

}
