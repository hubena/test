package com.threeweidu.config;
import com.threeweidu.pepos.util.CodeSetting;

public class DefaultProfile {
	private DefaultProfile(){
		if ("1002".equals(CodeSetting.SCP_ENVIRONMENT)) {
			if ("1002".equals(CodeSetting.IS_ONLIEN_TEST)) {
				NOTICE_URL = "http://192.168.70.27:8620/gateway/findOrderInfoNotice";  
			}
		}
	}
	/**
	 * 前端服务器默认LOGO
	 */
	public static String DEFAULT_LOGOURL = "http://shop.img.3weidu.com/category/d14e57ce-f841-429a-843f-36e39b73fd41.png";
	/**
	 * API充值通知
	 */
	public static String API_RECHARGE_URL = "http://192.168.70.22:8334/r/purchaseOrderFace/updateOrderPayTrade.html";
	/**
	 * 直充通知
	 */
	public static String RECHARGE_URL = "http://192.168.70.22:8334/r/purchaseOrderFace/updateSupplierRechargeInfo";
	/**
	 * 默认原密码
	 */
	public static String DEFAULT_RAW_PASSWORD = "123456";
	/**
	 * 默认密码
	 */
	public static String DEFAULT_PASSWORD = "A3CE1256385388C1366E62FD9EFF87D62C3B61AD";
	/**
	 * 单笔限额(分)
	 */
	public static String ASTRICT_SINGLE_MOENY = "20000000";
	/**
	 * 日限额(分)
	 */
	public static String ASTRICT_DAY_MOENY = "1000000000";
	/**
	 * 通知URL
	 */
	public String NOTICE_URL = "http://192.168.1.51:8080/gateway/findOrderInfoNotice";
	
	public static DefaultProfile getInstance() {
		return Instance.instance;
	}
	
	private static class Instance {
		private static DefaultProfile instance = new DefaultProfile();
	}
}
