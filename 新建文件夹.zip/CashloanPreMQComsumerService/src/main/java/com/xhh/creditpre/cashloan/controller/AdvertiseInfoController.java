package com.xhh.creditpre.cashloan.controller;

import com.janty.core.controller.BaseController;
import com.janty.core.dto.BaseResponse;
import com.janty.core.util.ExceptionUtil;
import com.janty.core.util.ResponseUtil;
import com.xhh.creditpre.cashloan.model.AdvertiseInfoDto;
import com.xhh.creditpre.cashloan.model.AdvertiseInfoRequest;
import com.xhh.creditpre.cashloan.service.AdvertiseInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/advertise")
public class AdvertiseInfoController extends BaseController {

    @Autowired
    private AdvertiseInfoService advertiseInfoService;

    @RequestMapping("/getAdvertise")
    public BaseResponse<List<AdvertiseInfoDto>> getAdvertise(AdvertiseInfoRequest request) {
        logger.info("AdvertiseInfoController-getAdvertise-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);

        BaseResponse<List<AdvertiseInfoDto>> response = ResponseUtil.createDefaultResponse();
        List<AdvertiseInfoDto> result = null;
        try {
            result = advertiseInfoService.getAdvertise(request);
            ResponseUtil.success(response, result);
        } catch (Exception e) {
            logger.error("AdvertiseInfoController-getAdvertise-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            ResponseUtil.handleException(response, e);
        }

        logger.info("AdvertiseInfoController-getInnerMessage-请求结束, reqNo-{}-返回-{}", request.getReqNo(), response);

        return response;
    }
}
