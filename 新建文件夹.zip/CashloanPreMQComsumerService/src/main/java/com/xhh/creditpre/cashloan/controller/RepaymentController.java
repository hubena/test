package com.xhh.creditpre.cashloan.controller;

import java.util.List;

import javax.annotation.Resource;

import com.xhh.creditcore.transaction.dto.TransRepaymentDto;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.janty.core.dto.BaseResponse;
import com.janty.core.util.ExceptionUtil;
import com.janty.core.util.ResponseUtil;
import com.janty.core.util.ValidateUtil;
import com.xhh.creditpre.cashloan.model.*;
import com.xhh.creditpre.cashloan.service.remote.RepaymentRemoteService;

/**
 * 还款相关APP接口
 */
@RestController
@RequestMapping("/repay")
public class RepaymentController extends WrapperController {
    Logger                         logger = LoggerFactory.getLogger(RepaymentController.class);

    @Resource
    private RepaymentRemoteService repaymentRemoteService;

    /**
     * app查询还款计划
     * 
     * @param request
     * @return
     */
    @RequestMapping("/queryRepayPlan")
    public BaseResponse<List<RepayPlanQueryDto>> queryRepayPlan(RepayPlanQueryRequest request) {
        logger.info("RepaymentController-queryRepayPlan-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);
        BaseResponse<List<RepayPlanQueryDto>> response = ResponseUtil.createDefaultResponse();
        try {
            ValidateUtil.validate(request);
            request.setAccountId(queryUserByToken(request).getProdAccountId());
            List<RepayPlanQueryDto> repayPlanQueryDtos = repaymentRemoteService.queryRepayPlan(request);
            ResponseUtil.success(response, repayPlanQueryDtos);
        } catch (Exception e) {
            logger.error("RepaymentController-queryRepayPlan-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            ResponseUtil.handleException(response, e);
        }
        logger.info("RepaymentController-queryRepayPlan-请求结束, reqNo-{}-返回-{}", request.getReqNo(), response);
        return response;
    }

    /**
     * app认证支付还款预还款
     *
     * @param request
     * @return
     */
    @RequestMapping("/certpay/prepay")
    public BaseResponse<PeriodRepayDto> certPayRepayPrePay(final PeriodRepayPreRequest request) {
        logger.info("RepaymentController-certPayRepayPrePay-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);
        BaseResponse<PeriodRepayDto> response = null;
        try {
            ValidateUtil.validate(request);
            response = safeExecute(new SafeExecutor<PeriodRepayDto, PeriodRepayPreRequest>() {
                @Override
                public BaseResponse<PeriodRepayDto> execute() {
                    BaseResponse<PeriodRepayDto> baseResponse = new BaseResponse<>();
                    request.setAccountId(queryUserByToken(request).getProdAccountId());
                    TransRepaymentDto transRepaymentDto = repaymentRemoteService.repayPrePay(request);
                    PeriodRepayDto periodRepayDto = new PeriodRepayDto();
                    return processRepayResult(transRepaymentDto, periodRepayDto, baseResponse);
                }

                @Override
                public PeriodRepayPreRequest getBaseRequest() {
                    return request;
                }
            });

        } catch (Exception e) {
            logger.error("RepaymentController-certPayRepayPrePay-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            response = new BaseResponse<>();
            ResponseUtil.handleException(response, e);
        }

        logger.info("RepaymentController-certPayRepayPrePay-请求结束, reqNo-{}-返回-{}", request.getReqNo(), response);
        return response;
    }

    /**
     * app认证支付还款确认还款
     *
     * @param request
     * @return
     */
    @RequestMapping("/certpay/confirmpay")
    public BaseResponse<PeriodRepayDto> certPayRepayConfirmPay(final PeriodRepayConfirmRequest request) {
        logger.info("RepaymentController-certPayRepayConfirmPay-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);
        BaseResponse<PeriodRepayDto> response;
        try {
            ValidateUtil.validate(request);
            BaseResponse<PeriodRepayDto> baseResponse = new BaseResponse<>();
            TransRepaymentDto transRepaymentDto = repaymentRemoteService.repayConfirmPay(request);
            PeriodRepayDto periodRepayDto = new PeriodRepayDto();
            response = processRepayResult(transRepaymentDto, periodRepayDto, baseResponse);

        } catch (Exception e) {
            logger.error("RepaymentController-certPayRepayConfirmPay-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            response = new BaseResponse<>();
            ResponseUtil.handleException(response, e);
        }
        logger.info("RepaymentController-certPayRepayConfirmPay-请求结束, reqNo-{}-返回-{}", request.getReqNo(), response);
        return response;
    }

    /**
     * app认证支付重发验证码
     *
     * @param request
     * @return
     */
    @RequestMapping("/certpay/sendsms")
    public BaseResponse<PeriodRepayDto> certPayRepaySendSms(final PeriodRepaySendSmsRequest request) {
        logger.info("RepaymentController-certPayRepaySendSms-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);
        BaseResponse<PeriodRepayDto> response = new BaseResponse<>();
        try {
            ValidateUtil.validate(request);
            TransRepaymentDto transRepaymentDto = repaymentRemoteService.repaySendSms(request);
            PeriodRepayDto periodRepayDto = new PeriodRepayDto();
            processRepayResult(transRepaymentDto, periodRepayDto, response);
        } catch (Exception e) {
            logger.error("RepaymentController-certPayRepaySendSms-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            response = new BaseResponse<>();
            ResponseUtil.handleException(response, e);
        }

        logger.info("RepaymentController-certPayRepaySendSms-请求结束, reqNo-{}-返回-{}", request.getReqNo(), response);
        return response;
    }

    public BaseResponse processRepayResult(TransRepaymentDto transRepaymentDto, PeriodRepayDto periodRepayDto, BaseResponse<PeriodRepayDto> baseResponse) {
        if (transRepaymentDto.getRespCode().equals(TransRepaymentDto.SUCCESS_CODE)) {
            periodRepayDto.setRepayOrderNo(transRepaymentDto.getOuterRepayOrderNo());
            ResponseUtil.success(baseResponse, periodRepayDto);
        } else {
            baseResponse.setReturnCode(transRepaymentDto.getRespCode());
            baseResponse.setReturnMsg(transRepaymentDto.getRespMsg());
        }
        return baseResponse;
    }
}
