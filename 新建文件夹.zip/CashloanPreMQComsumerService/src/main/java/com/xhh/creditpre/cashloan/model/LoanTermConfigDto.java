package com.xhh.creditpre.cashloan.model;

import com.janty.core.dto.BaseModel;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author zhangliang
 * @Date:Create in 2018/1/31
 */
public class LoanTermConfigDto extends BaseModel {

    private Integer    termType;

    private Integer    term;

    private Integer    amountType;

    private Integer    status;

    private BigDecimal amountScopeStart;

    private BigDecimal amountScopeEnd;

    public BigDecimal getAmountScopeStart() {
        return amountScopeStart;
    }

    public void setAmountScopeStart(BigDecimal amountScopeStart) {
        this.amountScopeStart = amountScopeStart;
    }

    public BigDecimal getAmountScopeEnd() {
        return amountScopeEnd;
    }

    public void setAmountScopeEnd(BigDecimal amountScopeEnd) {
        this.amountScopeEnd = amountScopeEnd;
    }

    public Integer getTermType() {
        return termType;
    }

    public void setTermType(Integer termType) {
        this.termType = termType;
    }

    public Integer getTerm() {
        return term;
    }

    public void setTerm(Integer term) {
        this.term = term;
    }

    public Integer getAmountType() {
        return amountType;
    }

    public void setAmountType(Integer amountType) {
        this.amountType = amountType;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
}
