package com.xhh.creditpre.cashloan.dao;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.xhh.creditpre.cashloan.model.UserLoginRecord;

import java.util.List;

@Repository
public interface UserLoginRecordMapper {
    int deleteByPrimaryKey(Long id);

    int insert(UserLoginRecord record);

    int insertSelective(UserLoginRecord record);

    UserLoginRecord selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(UserLoginRecord record);

    int updateByPrimaryKey(UserLoginRecord record);

    List<UserLoginRecord> selectAllLoginRecord();

    UserLoginRecord selectByUserId(@Param("userId") Long userId);
}