package com.xhh.creditpre.cashloan.model;

import org.hibernate.validator.constraints.NotBlank;

import lombok.Getter;
import lombok.Setter;

/**
 * 类DeviceInfoRequest.java的实现描述：设备信息上传请求参数
 * 
 * @author xianghh 2018年1月22日 上午11:46:22
 */
@Getter
@Setter
public class AuthDataRequest extends PreBaseRequest {

    /**
     * 
     */
    private static final long serialVersionUID = 7886641897598695483L;

    /**
     * 授信申请ID</br>
     * 必填.
     */
    @NotBlank(message = "creditAwardNo为必填参数")
    private String            creditAwardNo;

    /**
     * 认证数据类型</br>
     * 必填.
     */
    @NotBlank(message = "authDataType为必填参数")
    private String            authDataType;
    /**
     * 数据.</br>
     */
    private String            data;
}
