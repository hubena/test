package com.xhh.creditpre.cashloan.model;

import com.janty.core.dto.BaseModel;

/**
 * author zhangliang
 *
 * @Date:Create in 2018/1/15
 */
public class LoginDto extends BaseModel {

    private Long   userId;

    private Long   accountId;

    private Long   productAccountId;

    private String phone;

    private String token;

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getAccountId() {
        return accountId;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public Long getProductAccountId() {
        return productAccountId;
    }

    public void setProductAccountId(Long productAccountId) {
        this.productAccountId = productAccountId;
    }
}
