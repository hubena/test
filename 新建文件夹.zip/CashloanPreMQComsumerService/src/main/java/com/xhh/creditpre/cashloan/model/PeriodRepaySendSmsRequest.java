package com.xhh.creditpre.cashloan.model;

import javax.validation.constraints.NotNull;

/**
 * author zhangweixin
 *
 * @Date:Create in 2018/1/12
 */
public class PeriodRepaySendSmsRequest extends PreBaseRequest {
    @NotNull(message = "还款订单号不能为空")
    private String repayOrderNo;

    public String getRepayOrderNo() {
        return repayOrderNo;
    }

    public void setRepayOrderNo(String repayOrderNo) {
        this.repayOrderNo = repayOrderNo;
    }
}
