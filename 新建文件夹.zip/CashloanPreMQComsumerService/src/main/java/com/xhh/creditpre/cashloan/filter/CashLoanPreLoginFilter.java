package com.xhh.creditpre.cashloan.filter;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.janty.cached.access.RedisCachedAccess;
import com.janty.core.dto.BaseResponse;
import com.janty.core.spring.ApplicationContextUtil;
import com.janty.core.util.FastJsonUtil;
import com.xhh.creditpre.cashloan.config.PreFilterConfig;
import com.xhh.creditpre.cashloan.constant.CashloanErrorCode;
import com.xhh.creditpre.cashloan.constant.CashloanRedisKey;
import com.xhh.creditpre.cashloan.model.UserInfo;
import com.xhh.creditpre.cashloan.util.TokenUtils;

/**
 * 前置过滤器 2018-01-10 zhangliang
 */
public class CashLoanPreLoginFilter implements Filter {

    private final static Logger         logger = LoggerFactory.getLogger(CashLoanPreLoginFilter.class);

    private RedisCachedAccess<UserInfo> redisCachedAccess;

    private PreFilterConfig             preFilterConfig;

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {

        setBean();

        HttpServletRequest request = (HttpServletRequest) servletRequest;
        HttpServletResponse response = (HttpServletResponse) servletResponse;
        String path = request.getServletPath();
        List<String> list = preFilterConfig.getExcludeUrls();
        if (!CollectionUtils.isEmpty(list)) {
            for (String url : list) {
                if (path.indexOf(url) > -1) {
                    //排除页面,直接跳过
                    filterChain.doFilter(request, response);
                    return;
                }
            }
        }

        if (!checkIsLogin(request)) {
            notLogin(response);
        } else {
            filterChain.doFilter(request, response);
        }

    }

    private boolean checkIsLogin(HttpServletRequest request) {
        String token = request.getParameter("token");
        String userId = request.getParameter("userId");
        if (StringUtils.isEmpty(token) || StringUtils.isEmpty(userId)) {
            return false;
        }
        UserInfo userInfo = redisCachedAccess.hget(token, CashloanRedisKey.login_user);
        if (userInfo == null || TokenUtils.isTokenExpire(token)) {
            return false;
        }
        if (userInfo.getId() != Long.parseLong(userId)) {
            return false;
        }
        return true;

    }

    /**
     * 没有操作权限
     * 
     * @param response
     * @throws Exception
     */
    private void notLogin(HttpServletResponse response) throws IOException {
        //返回给view，没有此操作的权限
        BaseResponse<Void> baseResponse = new BaseResponse<>();
        baseResponse.setReturnCode(CashloanErrorCode.Element.b_user_login_expire.getCode());
        baseResponse.setReturnMsg(CashloanErrorCode.Element.b_user_login_expire.getMessage());

        writeResult(FastJsonUtil.obj2json(baseResponse), response);
    }

    /**
     * 通过servlet输出controller返回结果
     * 
     * @param result
     * @param response
     * @throws IOException
     */
    private void writeResult(String result, HttpServletResponse response) throws IOException {
        response.setContentType("text/xml;charset=utf-8");
        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result);
        out.flush();
        out.close();
    }

    private void setBean() {
        if (redisCachedAccess == null) {
            redisCachedAccess = ApplicationContextUtil.getBeanByType(RedisCachedAccess.class);
        }
        if (preFilterConfig == null) {
            preFilterConfig = ApplicationContextUtil.getBeanByType(PreFilterConfig.class);
        }

    }

    @Override
    public void destroy() {

    }
}
