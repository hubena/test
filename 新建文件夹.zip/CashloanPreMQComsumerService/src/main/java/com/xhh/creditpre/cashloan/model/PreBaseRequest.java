package com.xhh.creditpre.cashloan.model;

import javax.validation.constraints.NotNull;

import com.janty.core.dto.BaseRequest;

/**
 * author zhangliang
 *
 * @Date:Create in 2018/1/13
 */
public class PreBaseRequest extends BaseRequest {

    @NotNull(message = "用户id是必要参数")
    private Long   userId;

    @NotNull(message = "token是必要参数")
    private String token;

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
