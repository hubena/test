package com.xhh.creditpre.cashloan.model;

import org.hibernate.validator.constraints.NotBlank;

import lombok.Getter;
import lombok.Setter;

/**
 * 类DeviceInfoRequest.java的实现描述：设备信息上传请求参数
 * 
 * @author xianghh 2018年1月22日 上午11:46:22
 */
@Getter
@Setter
public class AppDeviceInfoRequest extends PreBaseRequest {

    /**
     * 
     */
    private static final long serialVersionUID = -5074575568569611426L;

    /**
     * 授信申请ID</br>
     * 必填.
     */
    @NotBlank(message = "creditAwardNo为必填参数")
    private String            creditAwardNo;

    /**
     * 数据.</br>
     * 必填
     */
    @NotBlank(message = "deviceInfo为必填参数")
    private String            deviceInfo;
}
