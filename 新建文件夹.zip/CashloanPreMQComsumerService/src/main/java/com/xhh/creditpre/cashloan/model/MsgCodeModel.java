package com.xhh.creditpre.cashloan.model;

/**
 * @author zhangliang
 * @Date:Create in 2018/1/26
 */
public class MsgCodeModel {

    private String phone;

    private String code;

    private Long   cacheTime;

    private Long   expireTime;

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Long getCacheTime() {
        return cacheTime;
    }

    public void setCacheTime(Long nowTime) {
        this.cacheTime = nowTime;
    }

    public Long getExpireTime() {
        return expireTime;
    }

    public void setExpireTime(Long expireTime) {
        this.expireTime = expireTime;
    }
}
