package com.xhh.creditpre.cashloan.enums;

/**
 * @author zhangliang
 * @Date:Create in 2018/2/5
 */
public enum SendType {
    /**
     * 消息推送：全局推送；局部推送
     */
    WHOLE(1, "全局推送"),
    PART_WHOLE(2, "局部推送");

    private Integer key;
    private String  desc;

    public Integer getKey() {
        return key;
    }

    public String getDesc() {
        return desc;
    }

    SendType(Integer key, String desc) {
        this.key = key;
        this.desc = desc;
    }

    public SendType getByKey(Integer key) {
        for (SendType sendType : SendType.values()) {
            if (sendType.key.equals(key)) {
                return sendType;
            }
        }
        return null;
    }
}
