package com.xhh.creditpre.cashloan.enums;

/**
 * 终端类型
 */
public enum BannerTerminalType {
    pc(1, "pc"),

    h5(2, "h5"),

    app(3, "app");

    /**
     * 通过key获取枚举
     *
     * @param key
     * @return
     */
    public static BannerTerminalType getByKey(int key) {
        switch (key) {
            case 1:
                return pc;
            case 2:
                return h5;
            case 3:
                return app;
            default:
                return null;
        }
    }

    private int    key;
    private String desc;

    /**
     * 私有构造
     *
     * @param key
     * @param desc
     */
    private BannerTerminalType(int key, String desc) {
        this.key = key;
        this.desc = desc;
    }

    public int getKey() {
        return key;
    }

    public String getDesc() {
        return desc;
    }
}
