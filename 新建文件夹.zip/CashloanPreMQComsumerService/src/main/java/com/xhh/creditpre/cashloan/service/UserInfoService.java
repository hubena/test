package com.xhh.creditpre.cashloan.service;

import com.janty.cached.access.RedisCachedAccess;
import com.janty.core.dto.PageData;
import com.janty.core.dto.Pager;
import com.janty.core.exception.BusinessException;
import com.janty.core.security.SecurityUtils;
import com.janty.core.util.CommonBeanCopier;
import com.janty.core.util.StringUtil;
import com.janty.mybatis.util.CountHelper;
import com.xhh.creditcore.product.dto.ProductChannelDto;
import com.xhh.creditcore.product.dto.ProductChannelRequest;
import com.xhh.creditpre.cashloan.constant.CashLoanConstant;
import com.xhh.creditpre.cashloan.constant.CashloanErrorCode;
import com.xhh.creditpre.cashloan.constant.CashloanRedisKey;
import com.xhh.creditpre.cashloan.dao.UserInfoMapper;
import com.xhh.creditpre.cashloan.dto.QueryUserInfoRequest;
import com.xhh.creditpre.cashloan.dto.UserInfoDto;
import com.xhh.creditpre.cashloan.enums.AuthType;
import com.xhh.creditpre.cashloan.enums.LockType;
import com.xhh.creditpre.cashloan.enums.StatusType;
import com.xhh.creditpre.cashloan.model.*;
import com.xhh.creditpre.cashloan.service.remote.ProductRemoteService;
import com.xhh.creditpre.cashloan.util.SmsUtils;
import com.xhh.creditpre.cashloan.util.TokenUtils;
import org.apache.ibatis.session.RowBounds;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * UserInfo服务类
 * 
 * @author jan
 * @date 2018-1-8 17:29:47
 */
@Service("userInfoService")
public class UserInfoService {

    @Resource
    private UserInfoMapper              userInfoMapper;

    @Resource
    private RedisCachedAccess<UserInfo> redisCachedAccess;

    @Resource
    private ProductRemoteService        productRemoteService;

    @Resource
    private UserLoginRecordService userLoginRecordService;

    /**
     * 根据id查询数据
     * 
     * @param id 实体id
     * @return 实体
     */
    public UserInfo queryDataById(long id) {
        return null;
    }

    /**
     * 后端pwd 加密
     * @param plainPwd
     * @return
     * @throws UnsupportedEncodingException
     */
    public static String passwordEncrypt(String plainPwd) {
        return SecurityUtils.encryptMD5(plainPwd);
    }
    
    /**
     * 新增数据
     * 
     * @param
     */
    public void addData(RegisterRequest registerRequest) {
        //校验验证码
        SmsUtils.verifyCode(registerRequest.getPhone(), registerRequest.getMsgCode());

        UserInfo userInfo = new UserInfo();
        CommonBeanCopier.copy(registerRequest, userInfo);
        //查询该手机号是否已注册
        if (userInfoMapper.selectByPhone(userInfo.getPhone()) != null) {
            throw new BusinessException(new CashloanErrorCode(CashloanErrorCode.Element.b_user_phone_has_exsit));
        }

        ProductChannelRequest productChannelRequest = new ProductChannelRequest();
        productChannelRequest.setProductCode(CashLoanConstant.product_code);
        String secretCode = null;
        if (StringUtil.isEmpty(registerRequest.getSecretCode())) {
            secretCode = CashLoanConstant.secretCode;
        } else {
            secretCode = registerRequest.getSecretCode();
        }
        productChannelRequest.setSecretCode(secretCode);
        //查询产品渠道
        ProductChannelDto dto = productRemoteService.queryProductChannel(productChannelRequest);
        userInfo.setLoginName(userInfo.getPhone());
        userInfo.setPassword(passwordEncrypt(userInfo.getPassword()));
        userInfo.setChannelCode(dto.getChannelCode());
        userInfo.setChannelName(dto.getChannelName());
        userInfo.setSourceCode(registerRequest.getSourceCode());
        userInfo.setShareCode("");//用户专属邀请码,需要指定生成机制，新生成一个
        userInfo.setShareCodeUsed(registerRequest.getShareCodeUsed());//注册时使用的邀请码
        userInfo.setIsLock(LockType.NOT_LOCK.getKey());
        userInfo.setIsAuth(AuthType.NOT_AUTH.getKey());
        userInfo.setRegisterTime(new Date());
        userInfo.setGmtCreated(new Date());
        userInfo.setStatus(StatusType.EFFECTIVE.getKey());
        userInfoMapper.insertSelective(userInfo);
    }

    /**
     * 修改数据
     * 
     * @param record 实体
     */
    public void modifyData(UserInfo record) {

    }

    /**
     * 删除数据
     * 
     * @param record 实体
     */
    public void deleteData(UserInfo record) {

    }

    /**
     * 用户登录
     * 
     * @param loginRequest
     * @return
     */
    public LoginDto login(LoginRequest loginRequest) {
        UserInfo userInfo = new UserInfo();
        CommonBeanCopier.copy(loginRequest, userInfo);
        userInfo.setPassword(passwordEncrypt(loginRequest.getPassword()));
        //查找用户
        userInfo = userInfoMapper.selectByPhoneAndPasswd(userInfo);
        if (userInfo == null)
            throw new BusinessException(new CashloanErrorCode(CashloanErrorCode.Element.b_user_passwd_not_match));
        LoginDto loginDto = new LoginDto();
        //生成token并缓存
        String token = TokenUtils.getToken();
        redisCachedAccess.hput(token, CashloanRedisKey.login_user, userInfo);

        loginDto.setPhone(userInfo.getPhone());
        loginDto.setToken(token);
        loginDto.setUserId(userInfo.getId());
        loginDto.setAccountId(userInfo.getAccountId());
        loginDto.setProductAccountId(userInfo.getProdAccountId());

        UserLoginRecord userLoginRecord = new UserLoginRecord();
        userLoginRecord.setDeviceId(loginRequest.getDeviceId());
        userLoginRecord.setLoginDeviceType(loginRequest.getDeviceType());
        userLoginRecord.setLastLoginTime(new Date());
        userLoginRecord.setLoginName(userInfo.getPhone());
        userLoginRecord.setUserId(userInfo.getId());
        userLoginRecord.setLoginAddress(loginRequest.getLoginAddress());
        userLoginRecordService.insertLoginRecord(userLoginRecord);
        return loginDto;

    }

    /**
     * 退出登录
     * 
     * @param request
     */
    public void logout(PreBaseRequest request) {
        redisCachedAccess.getRedisObjectTemplate().opsForHash().delete(request.getToken(), CashloanRedisKey.login_user);
    }

    /**
     * 修改密码
     * 
     * @param alterPasswdRequest
     * @param token
     * @param userDto
     */
    public void alterPasswd(AlterPasswdRequest alterPasswdRequest, String token, UserDto userDto) {
        //校验验证码
        SmsUtils.verifyCode(alterPasswdRequest.getPhone(), alterPasswdRequest.getMsgCode());

        UserInfo userInfo = new UserInfo();
        CommonBeanCopier.copy(userDto, userInfo);
        userInfo.setPassword(passwordEncrypt(alterPasswdRequest.getPassword()));
        userInfo.setGmtModified(new Date());

        int index = userInfoMapper.alterPasswd(userInfo);

        if (index == 0)
            throw new BusinessException(new CashloanErrorCode(CashloanErrorCode.Element.b_alter_password_failed));
        //移除缓存
        redisCachedAccess.getRedisObjectTemplate().opsForHash().delete(token, CashloanRedisKey.login_user);

    }

    /**
     * 忘记密码
     * 
     * @param forgetPasswdRequest
     */
    public void forgetPasswd(ForgetPasswdRequest forgetPasswdRequest) {
        //校验验证码
        SmsUtils.verifyCode(forgetPasswdRequest.getPhone(), forgetPasswdRequest.getMsgCode());

        UserInfo userInfo = new UserInfo();
        userInfo.setPhone(forgetPasswdRequest.getPhone());
        userInfo.setPassword(passwordEncrypt(forgetPasswdRequest.getPassword()));

        int index = userInfoMapper.alterPasswd(userInfo);

        if (index == 0)
            throw new BusinessException(new CashloanErrorCode(CashloanErrorCode.Element.b_alter_password_failed));

    }

    /**
     * 更新用户信息
     * 
     * @param userInfo
     */
    public void updateUserInfoById(UserInfo userInfo) {
        userInfoMapper.updateUserInfoById(userInfo);
    }

    /**
     * 用户管理 查询用户列表
     * 
     * @param request
     * @param pager
     * @return
     */
    public PageData<UserInfoDto> queryUserInfoByPage(QueryUserInfoRequest request, Pager pager) {

        UserInfo userInfo = new UserInfo();
        //过滤参数
        userInfo.setName(request.getName());
        userInfo.setPhone(request.getPhone());
        userInfo.setChannelCode(request.getChannelCode());
        userInfo.setSourceCode(request.getSourceCode());

        RowBounds rowBounds = new RowBounds(pager.getOffset(), pager.getPageSize());
        List<UserInfo> userInfoList = userInfoMapper.queryUserByPage(userInfo, rowBounds);
        List<UserInfoDto> data = null;
        if (!CollectionUtils.isEmpty(userInfoList)) {
            data = new ArrayList<>();
            UserInfoDto dto = null;
            for (UserInfo user : userInfoList) {
                dto = new UserInfoDto();
                CommonBeanCopier.copy(user, dto);
                data.add(dto);
            }
        }
        PageData<UserInfoDto> pageData = new PageData<>();
        pageData.assembleResult(pager, data, CountHelper.getTotalRow());
        return pageData;
    }

    /**
     * 根据手机号查询用户
     * 
     * @param phone
     * @return
     */
    public UserInfo selectByPhone(String phone) {
        return userInfoMapper.selectByPhone(phone);
    }

    /**
     * 查询系统所有用户
     * @return
     */
    public List<UserInfo> selectAllUser(){
        return userInfoMapper.selectAllUserInfo();
    }

    public List<UserInfo> queryUserByAccountId(Long accountId) {
        return userInfoMapper.selectByAccountId(accountId);
    }
}
