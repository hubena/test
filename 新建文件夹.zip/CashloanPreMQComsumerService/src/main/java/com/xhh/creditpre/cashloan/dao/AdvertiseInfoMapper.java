package com.xhh.creditpre.cashloan.dao;

import com.xhh.creditpre.cashloan.model.AdvertiseInfo;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * <p>
 * 公告信息表 Mapper 接口
 * </p>
 *
 * @author nathaniel123
 * @since 2018-01-09
 */
@Repository
public interface AdvertiseInfoMapper {

    List<AdvertiseInfo> selectAdvertiseList(AdvertiseInfo advertiseInfo);
}
