package com.xhh.creditpre.cashloan.enums;

/**
 * @author zhangliang
 * @Date:Create in 2018/2/28 10:52
 */
public enum SendStatus {
    NOT_SEND(1,"未发送"),
    SEND_SUCCESS(2,"发送成功"),
    SEND_FAIL(3,"发送失败");

    private Integer key;
    private String desc;

    private SendStatus(Integer key, String desc){
        this.key = key;
        this.desc = desc;
    }

    public Integer getKey() {
        return key;
    }

    public String getDesc() {
        return desc;
    }

    public SendStatus getByKey(Integer key){
        for (SendStatus readType : SendStatus.values()){
            if (readType.getKey().equals(key))
                return readType;
        }
        return null;
    }
}
