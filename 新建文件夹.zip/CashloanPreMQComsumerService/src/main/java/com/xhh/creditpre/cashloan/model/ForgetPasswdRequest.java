package com.xhh.creditpre.cashloan.model;

import com.janty.core.dto.BaseRequest;

import javax.validation.constraints.NotNull;

public class ForgetPasswdRequest extends BaseRequest {

    @NotNull(message = "手机号是必选参数")
    private String phone;
    @NotNull(message = "密码是必选参数")
    private String password;
    @NotNull(message = "短信验证码是必选参数")
    private String msgCode;

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getMsgCode() {
        return msgCode;
    }

    public void setMsgCode(String msgCode) {
        this.msgCode = msgCode;
    }
}
