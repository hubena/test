package com.xhh.creditpre.cashloan.model;

import com.janty.core.dto.BaseModel;

import java.util.Date;

public class AdvertiseInfoDto extends BaseModel {
    /**
     * 主键ID
     */
    private Long    id;
    /**
     * 标题
     */
    private String  title;
    /**
     * 内容
     */
    private String  content;
    /**
     * 请求url
     */
    private String  reqUrl;
    /**
     * 状态：1-有效，2-失效
     */
    private Integer status;
    /**
     * 备注
     */
    private String  remark;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getReqUrl() {
        return reqUrl;
    }

    public void setReqUrl(String reqUrl) {
        this.reqUrl = reqUrl;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

}
