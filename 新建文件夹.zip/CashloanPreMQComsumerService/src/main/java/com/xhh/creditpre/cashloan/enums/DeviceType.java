package com.xhh.creditpre.cashloan.enums;

/**
 * @author zhangliang
 * @Date:Create in 2018/3/2 17:08
 */
public enum DeviceType {
    PC("1", "PC"),

    IOS("2", "IOS"),

    ANDROID("3", "ANDROID"),

    WECHAT("4", "WECHAT"),

    OTHER("9", "OTHER");

    /**
     * 通过key获取枚举
     *
     * @param key
     * @return
     */
    public static DeviceType getByKey(String key) {
        switch (key) {
            case "1":
                return PC;
            case "2":
                return IOS;
            case "3":
                return ANDROID;
            case "4":
                return WECHAT;
            default:
                return OTHER;
        }
    }

    private String key;
    private String desc;

    /**
     * 私有构造
     *
     * @param key
     * @param desc
     */
    private DeviceType(String key, String desc) {
        this.key = key;
        this.desc = desc;
    }

    public String getKey() {
        return key;
    }

    public String getDesc() {
        return desc;
    }
}
