package com.xhh.creditpre.cashloan.model;

import com.janty.core.dto.BaseRequest;

import java.util.Date;

/**
 * author zhangliang
 *
 * @Date:Create in 2018/1/16
 */
public class QueryUserRequest extends BaseRequest {

    private String  name;

    private String  phone;

    private String  channelName;//渠道名称

    private Integer sourceCode; //来源

    private String  idCard;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }

    public Integer getSourceCode() {
        return sourceCode;
    }

    public void setSourceCode(Integer sourceCode) {
        this.sourceCode = sourceCode;
    }

    public String getIdCard() {
        return idCard;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }

}
