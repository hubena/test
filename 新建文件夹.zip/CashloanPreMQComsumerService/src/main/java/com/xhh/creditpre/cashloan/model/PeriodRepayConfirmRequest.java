package com.xhh.creditpre.cashloan.model;

import javax.validation.constraints.NotNull;

/**
 * author zhangweixin
 *
 * @Date:Create in 2018/1/12
 */
public class PeriodRepayConfirmRequest extends PreBaseRequest {
    @NotNull(message = "发起还款流水号不能为空")
    private String repayOrderNo;
    @NotNull(message = "验证码不能为空")
    private String smsCode;

    public String getRepayOrderNo() {
        return repayOrderNo;
    }

    public void setRepayOrderNo(String repayOrderNo) {
        this.repayOrderNo = repayOrderNo;
    }

    public String getSmsCode() {
        return smsCode;
    }

    public void setSmsCode(String smsCode) {
        this.smsCode = smsCode;
    }
}
