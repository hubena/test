package com.xhh.creditpre.cashloan.constant;

public interface OssConstants {

    /**
     * OSS访问域名
     */
    String endpoint    = "oss-cn-shenzhen.aliyuncs.com";

    /**
     * Oss存储空间
     */
    String bucket_name = "xhh-credit";

    /**
     *
     */
    String file_path   = "/common";
}
