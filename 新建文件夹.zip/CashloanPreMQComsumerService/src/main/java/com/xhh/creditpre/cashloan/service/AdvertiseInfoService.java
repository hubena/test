package com.xhh.creditpre.cashloan.service;

import com.janty.core.util.CollectionUtil;
import com.janty.core.util.CommonBeanCopier;
import com.xhh.creditpre.cashloan.model.*;
import com.xhh.creditpre.cashloan.dao.AdvertiseInfoMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * 公告信息表 服务实现类
 * </p>
 *
 * @author nathaniel123
 * @since 2018-01-09
 */
@Service("advertiseInfoService")
public class AdvertiseInfoService {
    @Resource
    private AdvertiseInfoMapper advertiseinfomapper;

    /**
     * 根据id查询数据
     *
     * @param id 实体id
     * @return 实体
     */
    public AdvertiseInfo queryDataById(long id) {
        return null;
    }

    /**
     * 新增数据
     *
     * @param record 实体
     */
    public void addData(AdvertiseInfo record) {

    }

    /**
     * 修改数据
     *
     * @param record 实体
     */
    public void modifyData(AdvertiseInfo record) {

    }

    /**
     * 删除数据
     *
     * @param record 实体
     */
    public void deleteData(AdvertiseInfo record) {

    }

    public List<AdvertiseInfoDto> getAdvertise(AdvertiseInfoRequest request) {
        AdvertiseInfo advertiseInfo = new AdvertiseInfo();
        CommonBeanCopier.copy(request, advertiseInfo);

        List<AdvertiseInfo> list = advertiseinfomapper.selectAdvertiseList(advertiseInfo);

        List<AdvertiseInfoDto> result = null;
        AdvertiseInfoDto dto = null;
        if (CollectionUtil.isListNotNull(list)) {
            result = new ArrayList<>();
            for (AdvertiseInfo advertise : list) {
                dto = new AdvertiseInfoDto();
                CommonBeanCopier.copy(advertise, dto);
                result.add(dto);
            }
        }
        return result;
    }
}
