package com.xhh.creditpre.cashloan.model;

import org.hibernate.validator.constraints.NotBlank;

import lombok.Getter;
import lombok.Setter;

/**
 * 类CreditZmxyAuthRequest.java的实现描述：芝麻信用认证请求参数
 * 
 * @author xianghh 2018年1月22日 上午11:46:22
 */
@Getter
@Setter
public class CreditZmxyAuthRequest extends PreBaseRequest {

    /**
     * 
     */
    private static final long serialVersionUID = 7886641897598695483L;

    /**
     * 授信申请ID</br>
     * 必填.
     */
    @NotBlank(message = "creditAwardNo为必填参数")
    private String            creditAwardNo;

    /**
     * 姓名
     */
    @NotBlank(message = "name必填")
    private String            name;

    /**
     * 身份证号
     */
    @NotBlank(message = "idCardNo必填")
    private String            idCardNo;
}
