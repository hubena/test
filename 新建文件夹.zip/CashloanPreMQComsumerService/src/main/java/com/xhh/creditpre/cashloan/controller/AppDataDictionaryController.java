package com.xhh.creditpre.cashloan.controller;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.janty.core.controller.BaseController;
import com.janty.core.dto.BaseResponse;
import com.janty.core.util.ExceptionUtil;
import com.janty.core.util.ResponseUtil;
import com.janty.datadictionary.DataDictionaryAccess;
import com.janty.system.model.DataDictionary;

/**
 * zhangweixin 2018-01-22
 */
@RestController
@RequestMapping(value = "/dataDict")
public class AppDataDictionaryController extends BaseController {
    private static Logger logger = LoggerFactory.getLogger(AppDataDictionaryController.class);

    @RequestMapping("/queryAllDictionary")
    public BaseResponse<Map<String, List<DataDictionary>>> queryAllDictionary() {
        logger.info("AppDataDictionaryController-queryAllDictionary-请求开始");
        BaseResponse<Map<String, List<DataDictionary>>> baseResponse = ResponseUtil.createDefaultResponse();
        try {
            Map<String, List<DataDictionary>> listMap = DataDictionaryAccess.getAllEnum();
            ResponseUtil.success(baseResponse, listMap);
        } catch (Exception e) {
            logger.error("AppDataDictionaryController-queryAllDictionary-请求异常", ExceptionUtil.getType(e), e);
            ResponseUtil.handleException(baseResponse, e);
        }
        logger.info("AppDataDictionaryController-queryAllDictionary-请求结束");
        return baseResponse;
    }
}
