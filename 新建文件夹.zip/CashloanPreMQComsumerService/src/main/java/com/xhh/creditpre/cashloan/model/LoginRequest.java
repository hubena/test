package com.xhh.creditpre.cashloan.model;

import com.janty.core.dto.BaseRequest;

import javax.validation.constraints.NotNull;

public class LoginRequest extends BaseRequest {

    @NotNull(message = "手机号是必选参数")
    private String phone;

    @NotNull(message = "密码是必选参数")
    private String password;

    @NotNull(message = "deviceId是必选参数")
    private String deviceId;

    @NotNull(message = "登录设备类型不能为空")
    private String deviceType;//登录设备类型：1-PC 2-APP-IOS, 3-APP-ANDROID，4-WeChat,9-其他

    private String loginAddress;//登录地理位置

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    public String getLoginAddress() {
        return loginAddress;
    }

    public void setLoginAddress(String loginAddress) {
        this.loginAddress = loginAddress;
    }
}
