package com.xhh.creditpre.cashloan.api;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.janty.core.util.CommonBeanCopier;
import com.janty.core.util.ExceptionUtil;
import com.janty.core.util.ValidateUtil;
import com.xhh.creditpre.cashloan.dto.CreditApplyRecordQueryDto;
import com.xhh.creditpre.cashloan.dto.OpCreditApplyRecordQueryRequest;
import com.xhh.creditpre.cashloan.model.CreditApplyRecord;
import com.xhh.creditpre.cashloan.service.CreditApplyRecordService;

@Service
public class CreditApplyRecordApi implements ICreditApplyRecordApi {
    Logger                           logger = LoggerFactory.getLogger(CreditApplyRecordApi.class);
    @Resource
    private CreditApplyRecordService applyRecordService;

    @Override
    public CreditApplyRecordQueryDto queryCreditApplyRecord(OpCreditApplyRecordQueryRequest request) {
        logger.info("CreditRecordApi-queryCreditApplyRecord-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);
        CreditApplyRecordQueryDto result = new CreditApplyRecordQueryDto();
        try {
            ValidateUtil.validate(request);
            CreditApplyRecord creditApplyRecord = applyRecordService.queryDataByCreditAwardNo(request.getCreditAwardNo());
            if (creditApplyRecord != null) {
                CommonBeanCopier.copy(creditApplyRecord, result);
            } else {
                result = null;
            }
        } catch (Exception e) {
            logger.error("CreditRecordApi-queryCreditApplyRecord-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            throw e;
        }

        logger.info("CreditRecordApi-queryCreditApplyRecord-请求结束, reqNo-{}-返回-{}", request.getReqNo(), result);
        return result;
    }
}
