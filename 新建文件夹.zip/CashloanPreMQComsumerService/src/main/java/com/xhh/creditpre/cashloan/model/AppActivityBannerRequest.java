package com.xhh.creditpre.cashloan.model;

import com.janty.core.dto.BaseRequest;
import com.janty.core.validation.InRange;
import com.xhh.creditpre.cashloan.enums.BannerTerminalType;
import com.xhh.creditpre.cashloan.enums.PicType;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotNull;

@Getter
@Setter
public class AppActivityBannerRequest extends BaseRequest {

    /**
     * 产品id
     */
    private Long productId;

    /**
     * 终端类型
     */
    @NotNull(message = "终端类型不能为空")
    @InRange(enumType = BannerTerminalType.class, message = "终端类型非法", fieldMethodName = "getKey")
    private int  terminalType;

    /**
     * 图片类型
     */
    @NotNull(message = "图片类型不能为空")
    @InRange(enumType = PicType.class, message = "图片类型类型非法", fieldMethodName = "getKey")
    private int  picType;
}
