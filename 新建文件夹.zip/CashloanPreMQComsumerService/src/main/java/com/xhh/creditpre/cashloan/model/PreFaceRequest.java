package com.xhh.creditpre.cashloan.model;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.annotation.JSONField;
import com.janty.core.dto.BaseRequest;

import javax.validation.constraints.NotNull;

/**
 * author zhangliang
 *
 * @Date:Create in 2018/1/11
 */
public class PreFaceRequest extends BaseRequest {

    @NotNull(message = "授信号不能为空")
    private String  creditAwardNo;
    @JSONField(serialize = false)
    @NotNull(message = "人脸识别参数不能为空")
    private String  faceBase64;

    @NotNull(message = "人脸识别参数类型不能为空")
    private Integer type;         //类型：1-眨眼，2张嘴，3-上下摇头，4左右摇头

    public String getCreditAwardNo() {
        return creditAwardNo;
    }

    public void setCreditAwardNo(String creditAwardNo) {
        this.creditAwardNo = creditAwardNo;
    }

    public String getFaceBase64() {
        return faceBase64;
    }

    public void setFaceBase64(String faceBase64) {
        this.faceBase64 = faceBase64;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return JSON.toJSONString(this);
    }
}
