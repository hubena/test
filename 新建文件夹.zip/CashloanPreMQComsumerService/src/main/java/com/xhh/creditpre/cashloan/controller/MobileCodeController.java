package com.xhh.creditpre.cashloan.controller;

import com.janty.core.controller.BaseController;
import com.janty.core.dto.BaseResponse;
import com.janty.core.util.ExceptionUtil;
import com.janty.core.util.ResponseUtil;
import com.janty.core.util.ValidateUtil;
import com.xhh.creditpre.cashloan.model.MsgCodeRequest;
import com.xhh.creditpre.cashloan.service.MobileCodeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/user")
public class MobileCodeController extends BaseController {

    @Autowired
    private MobileCodeService mobileCodeService;

    @RequestMapping("/getCode")
    @ResponseBody
    public BaseResponse<Void> getCode(MsgCodeRequest request) {
        logger.info("MobileCodeController-getCode-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);

        BaseResponse<Void> response = ResponseUtil.createDefaultResponse();
        try {
            ValidateUtil.validate(request);
            //TODO:发短信
            mobileCodeService.getCode(request);
            ResponseUtil.success(response, null);
        } catch (Exception e) {
            logger.error("MobileCodeController-getCode-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            ResponseUtil.handleException(response, e);
        }

        logger.info("MobileCodeController-getCode-请求结束, reqNo-{}-返回-{}", request.getReqNo(), response);

        return response;
    }

}
