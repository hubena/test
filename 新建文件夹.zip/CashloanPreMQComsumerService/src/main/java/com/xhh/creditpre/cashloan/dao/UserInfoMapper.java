package com.xhh.creditpre.cashloan.dao;

import com.xhh.creditpre.cashloan.model.UserInfo;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserInfoMapper {
    int deleteByPrimaryKey(Long id);

    int insert(UserInfo record);

    int insertSelective(UserInfo record);

    UserInfo selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(UserInfo record);

    int updateByPrimaryKey(UserInfo record);

    UserInfo selectByPhone(@Param("phone") String phone);

    UserInfo selectByPhoneAndPasswd(UserInfo userInfo);

    int alterPasswd(UserInfo userInfo);

    void updateUserInfoById(UserInfo userInfo);

    List<UserInfo> queryUserByPage(UserInfo userInfo, RowBounds rowBounds);

    List<UserInfo> selectAllUserInfo();

    List<UserInfo> selectByAccountId(@Param("accountId") Long accountId);
}
