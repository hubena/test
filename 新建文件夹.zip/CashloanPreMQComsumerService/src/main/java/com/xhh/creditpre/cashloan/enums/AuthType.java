package com.xhh.creditpre.cashloan.enums;

/**
 * @author zhangliang
 * @Date:Create in 2018/2/5
 */
public enum AuthType {

    /**
     * 实名状态
     */
    AUTH(1, "已实名"),
    NOT_AUTH(2, "未实名");

    private Integer key;
    private String  desc;

    public Integer getKey() {
        return key;
    }

    public String getDesc() {
        return desc;
    }

    AuthType(Integer key, String desc) {
        this.key = key;
        this.desc = desc;
    }

    public AuthType getByKey(Integer key) {
        for (AuthType authType : AuthType.values()) {
            if (authType.key.equals(key)) {
                return authType;
            }
        }
        return null;
    }
}
