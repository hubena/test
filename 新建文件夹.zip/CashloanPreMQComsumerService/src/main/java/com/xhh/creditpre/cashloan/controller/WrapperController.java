package com.xhh.creditpre.cashloan.controller;

import javax.annotation.Resource;

import com.janty.cached.access.RedisCachedAccess;
import com.janty.core.controller.BaseController;
import com.janty.core.dto.BaseRequest;
import com.janty.core.dto.BaseResponse;
import com.janty.core.exception.BusinessException;
import com.janty.core.exception.SystemException;
import com.janty.core.util.CommonBeanCopier;
import com.xhh.creditpre.cashloan.constant.CashloanErrorCode;
import com.xhh.creditpre.cashloan.constant.CashloanRedisKey;
import com.xhh.creditpre.cashloan.model.PreBaseRequest;
import com.xhh.creditpre.cashloan.model.UserDto;
import com.xhh.creditpre.cashloan.model.UserInfo;
import org.springframework.util.StringUtils;

/**
 * 锁请求处理逻辑 zhangweixin 2017-01-13
 */
public class WrapperController extends BaseController {
    @Resource
    private RedisCachedAccess<Object>   cachedAccess;
    @Resource
    private RedisCachedAccess<UserInfo> redisCachedAccess;

    private final String                REQ_ID_LOCK_PREFIX    = "app_req_id_lock_prefix_";
    private final String                APP_REQ_RESULT_PREFIX = "app_req_result_prefix_";

    public <T, S extends BaseRequest> BaseResponse<T> safeExecute(SafeExecutor<T, S> executor) throws Exception {
        BaseRequest baseRequest = executor.getBaseRequest();
        if (StringUtils.isEmpty(baseRequest.getReqId())) {
            throw new SystemException("reqId不能为空");
        }

        String key = REQ_ID_LOCK_PREFIX + baseRequest.getReqId();
        String resultKey = APP_REQ_RESULT_PREFIX + baseRequest.getReqId();
        try {
            cachedAccess.tryLock(key, 60 * 1000L);
            Object value = cachedAccess.get(resultKey);
            if (value != null) {
                return (BaseResponse<T>) value;
            } else {
                BaseResponse<T> result = executor.execute();
                cachedAccess.put(resultKey, result, 60);
                return result;
            }
        } finally {
            cachedAccess.releaseLock(key);
        }
    }

    public interface SafeExecutor<T, S extends BaseRequest> {
        /**
         * 安全的执行业务逻辑
         *
         * @return 返回controller要返回的baseResponse
         * @throws Exception
         */
        BaseResponse<T> execute() throws Exception;

        /**
         * 返回基于{@link BaseRequest}的请求
         *
         * @return
         */
        S getBaseRequest();
    }

    /**
     * 根据token获取user
     *
     * @param request
     * @return
     */
    public UserDto queryUserByToken(PreBaseRequest request) {

        UserInfo userInfo = redisCachedAccess.hget(request.getToken(), CashloanRedisKey.login_user);

        if (userInfo == null)
            throw new BusinessException(new CashloanErrorCode(CashloanErrorCode.Element.b_user_login_expire));

        UserDto userDto = new UserDto();
        CommonBeanCopier.copy(userInfo, userDto);

        return userDto;
    }
}
