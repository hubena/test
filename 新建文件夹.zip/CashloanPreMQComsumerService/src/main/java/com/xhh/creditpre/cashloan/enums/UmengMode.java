package com.xhh.creditpre.cashloan.enums;

/**
 * @author zhangliang
 * @Date:Create in 2018/3/2 17:36
 */
public enum UmengMode {
    /**
     * 状态
     */
    PRODUCTION(1, "生产环境"),
    TEST(2, "测试环境");

    private Integer key;
    private String  desc;

    public Integer getKey() {
        return key;
    }

    public String getDesc() {
        return desc;
    }

    UmengMode(Integer key, String desc) {
        this.key = key;
        this.desc = desc;
    }

    public UmengMode getByKey(Integer key) {
        for (UmengMode umengMode : UmengMode.values()) {
            if (umengMode.key.equals(key)) {
                return umengMode;
            }
        }
        return null;
    }
}
