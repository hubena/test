package com.xhh.creditpre.cashloan.api;

import com.xhh.creditpre.cashloan.dto.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.janty.core.dto.PageData;
import com.janty.core.dto.Pager;
import com.janty.core.util.ExceptionUtil;
import com.janty.core.util.ValidateUtil;
import com.xhh.creditpre.cashloan.service.InnerMessageService;

/**
 * @author zhangliang
 * @Date:Create in 2018/2/27 15:48
 */
@Service("innerMessageApi")
public class InnerMessageApi implements IInnerMessageApi {
    Logger                  logger = LoggerFactory.getLogger(InnerMessageApi.class);

    @Autowired
    private InnerMessageService innerMessageService;

    /**
     * 查询系统消息和营销消息
     * @param request
     * @param pager
     * @return
     */
    @Override
    public PageData<InnerMessageDto> queryInnerMessageByPage(InnerMessageRequest request, Pager pager) {
        logger.info("InnerMessageApi-queryInnerMessageByPage-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);
        PageData<InnerMessageDto> result = null;
        try {
            ValidateUtil.validate(request);
            result = innerMessageService.queryInnerMessageByPage(request, pager);
        } catch (Exception e) {
            logger.error("InnerMessageApi-queryInnerMessageByPage-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            throw e;
        }

        logger.info("InnerMessageApi-queryInnerMessageByPage-请求结束, reqNo-{}-返回-{}", request.getReqNo(), result);
        return result;
    }

    /**
     * 插入营销消息
     * @param request
     */
    @Override
    public void insertInnerMessage(InnerMessageAddRequest request) {
        logger.info("InnerMessageApi-insertInnerMessage-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);
        try {
            ValidateUtil.validate(request);
            innerMessageService.insertInnerMessage(request);
        } catch (Exception e) {
            logger.error("InnerMessageApi-insertInnerMessage-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            throw e;
        }

        logger.info("InnerMessageApi-insertInnerMessage-请求结束, reqNo-{}-返回-{}", request.getReqNo());
    }

    /**
     * 更新营销消息
     * @param request
     */
    @Override
    public void updateMarketInnerMessage(MarketInnerMessageUpdateRequest request) {
        logger.info("InnerMessageApi-updateMarketInnerMessage-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);
        try {
            ValidateUtil.validate(request);
            innerMessageService.updateInnerMessage(request);
        } catch (Exception e) {
            logger.error("InnerMessageApi-updateMarketInnerMessage-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            throw e;
        }

        logger.info("InnerMessageApi-updateMarketInnerMessage-请求结束, reqNo-{}-返回-{}", request.getReqNo());
    }


    /**
     * 更新业务消息
     * @param request
     */
    @Override
    public void updateBusinessInnerMessage(BusinessInnerMessageUpdateRequest request) {
        logger.info("InnerMessageApi-updateBusinessInnerMessage-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);
        try {
            ValidateUtil.validate(request);
            innerMessageService.updateInnerMessage(request);
        } catch (Exception e) {
            logger.error("InnerMessageApi-updateBusinessInnerMessage-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            throw e;
        }

        logger.info("InnerMessageApi-updateBusinessInnerMessage-请求结束, reqNo-{}-返回-{}", request.getReqNo());
    }
}
