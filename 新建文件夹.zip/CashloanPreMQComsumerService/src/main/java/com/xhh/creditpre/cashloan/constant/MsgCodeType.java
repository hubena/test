package com.xhh.creditpre.cashloan.constant;

/**
 * author zhangliang
 *
 * @Date:Create in 2018/1/23
 */
public enum MsgCodeType {

    REGISTER(1, "注册"),
    ALTERPASSWD(2, "修改密码"),
    FORGETPASSWD(3, "忘记密码");

    private Integer key;
    private String  desc;

    public Integer getKey() {
        return key;
    }

    public void setKey(Integer key) {
        this.key = key;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    MsgCodeType(Integer key, String desc) {
        this.key = key;
        this.desc = desc;
    }

    public static MsgCodeType getByKey(Integer key) {
        for (MsgCodeType msgCodeType : MsgCodeType.values()) {
            if (msgCodeType.key.equals(key)) {
                return msgCodeType;
            }
        }
        return null;
    }
}
