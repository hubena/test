package com.xhh.creditpre.cashloan.api;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.janty.core.dto.PageData;
import com.janty.core.dto.Pager;
import com.janty.core.util.ExceptionUtil;
import com.janty.core.util.ValidateUtil;
import com.xhh.creditpre.cashloan.dto.QueryUserInfoRequest;
import com.xhh.creditpre.cashloan.dto.UserInfoDto;
import com.xhh.creditpre.cashloan.service.UserInfoService;

/**
 * author zhangliang
 *
 * @Date:Create in 2018/1/18
 */
@Service("userApi")
public class UserApi implements IUserApi {
    Logger                  logger = LoggerFactory.getLogger(UserApi.class);

    @Autowired
    private UserInfoService userInfoService;

    @Override
    public PageData<UserInfoDto> queryUserInfoByPage(QueryUserInfoRequest request, Pager pager) {

        logger.info("UserApi-queryUserInfoByPage-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);
        PageData<UserInfoDto> result = null;
        try {
            ValidateUtil.validate(request);
            result = userInfoService.queryUserInfoByPage(request, pager);
        } catch (Exception e) {
            logger.error("UserApi-queryUserInfoByPage-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            throw e;
        }

        logger.info("UserApi-queryUserInfoByPage-请求结束, reqNo-{}-返回-{}", request.getReqNo(), result);
        return result;
    }
}
