package com.xhh.creditpre.cashloan.dao;

import org.springframework.stereotype.Repository;

import com.xhh.creditpre.cashloan.model.CreditApplyRecord;

@Repository
public interface CreditApplyRecordMapper {
    int deleteByPrimaryKey(Long id);

    int insert(CreditApplyRecord record);

    int insertSelective(CreditApplyRecord record);

    CreditApplyRecord selectByPrimaryKey(Long id);

    /**
     * 更新认证状态
     * 
     * @param record
     * @return
     */
    int updateAuthStatus(CreditApplyRecord record);

    int updateByPrimaryKey(CreditApplyRecord record);

    CreditApplyRecord queryDataByCreditAwardNo(String creditAwardNo);

    void updateByCreditAwardNo(CreditApplyRecord creditApplyRecord);

    int updateZmxyStatusByCreditAwardNo(CreditApplyRecord creditApplyRecord);
}
