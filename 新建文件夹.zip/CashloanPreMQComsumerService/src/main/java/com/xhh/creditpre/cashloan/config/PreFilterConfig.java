package com.xhh.creditpre.cashloan.config;

import java.util.List;

public class PreFilterConfig {

    private List<String> excludeUrls;

    public List<String> getExcludeUrls() {
        return excludeUrls;
    }

    public void setExcludeUrls(List<String> excludeUrls) {
        this.excludeUrls = excludeUrls;
    }

}
