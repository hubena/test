package com.xhh.creditpre.cashloan.service;

import com.google.common.collect.Lists;
import com.janty.core.dto.PageData;
import com.janty.core.dto.Pager;
import com.janty.core.util.CollectionUtil;
import com.janty.core.util.CommonBeanCopier;
import com.janty.mybatis.util.CountHelper;
import com.xhh.creditpre.cashloan.constant.CashLoanConstant;
import com.xhh.creditpre.cashloan.converter.AppConverter;
import com.xhh.creditpre.cashloan.dao.ActivityBannerMapper;
import com.xhh.creditpre.cashloan.dto.ActivityBannerDto;
import com.xhh.creditpre.cashloan.dto.ActivityBannerRequest;
import com.xhh.creditpre.cashloan.model.AppActivityBanner;
import com.xhh.creditpre.cashloan.model.AppActivityBannerDto;
import com.xhh.creditpre.cashloan.model.AppActivityBannerRequest;
import org.apache.commons.collections.CollectionUtils;
import org.apache.ibatis.session.RowBounds;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * ActivityBanner服务类
 *
 * @author jan
 * @date 2018-1-9 14:23:16
 */
@Service
public class AppActivityBannerService {
    @Resource
    private ActivityBannerMapper activityBannerMapper;

    /**
     * 查询图片列表
     *
     * @param request
     * @return
     */
    public List<AppActivityBannerDto> getActivityPic(AppActivityBannerRequest request) {
        AppActivityBanner appActivityBanner = new AppActivityBanner();
        appActivityBanner.setProductId(new Long(CashLoanConstant.product_code));
        appActivityBanner.setTerminalType(request.getTerminalType());
        appActivityBanner.setPicType(request.getPicType());
        List<AppActivityBanner> list = activityBannerMapper.list(appActivityBanner);
        if (CollectionUtil.isListNotNull(list)) {
            List<AppActivityBannerDto> activitylist = AppConverter.toAppActivityBannerDto(list);
            return activitylist;
        }
        return null;
    }

    /**
     * 分页查询活动图片
     *
     * @param request
     * @return 实体
     */
    public PageData<ActivityBannerDto> queryActivityBannerByPage(ActivityBannerRequest request, Pager pager) {
        RowBounds rowBounds = new RowBounds(pager.getOffset(), pager.getPageSize());
        List<AppActivityBanner> list = activityBannerMapper.queryActivityBannerByPage(request, rowBounds);
        List<ActivityBannerDto> data = null;
        if (!CollectionUtils.isEmpty(list)) {
            data = Lists.newArrayList();
            ActivityBannerDto dto = null;
            for (AppActivityBanner element : list) {
                dto = new ActivityBannerDto();
                BeanUtils.copyProperties(element, dto);
                CommonBeanCopier.copy(element, dto);
                data.add(dto);
            }
        }
        PageData<ActivityBannerDto> page = new PageData<ActivityBannerDto>();
        page.assembleResult(pager, data, CountHelper.getTotalRow());
        return page;
    }

    /**
     * 新增数据
     *
     * @param record 实体
     */
    public void addData(AppActivityBanner record) {
        activityBannerMapper.insertSelective(record);
    }

    /**
     * 修改数据
     *
     * @param record 实体
     */
    public void modifyData(AppActivityBanner record) {
        activityBannerMapper.updateByPrimaryKeySelective(record);
    }

    /**
     * 删除数据
     *
     * @param id 主键id
     */
    public void deleteData(Long id) {
        activityBannerMapper.deleteByPrimaryKey(id);
    }
}
