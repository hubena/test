package com.xhh.creditpre.cashloan.service.remote;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.janty.core.util.BaseRemoteService;
import com.xhh.creditcore.transaction.constant.TransactionErrorCode;
import com.xhh.creditpre.cashloan.constant.CashloanErrorCode;
import com.xhh.infrastructure.messagecenter.api.IMessageCenterApi;
import com.xhh.infrastructure.messagecenter.dto.SendSmsMessageRequest;

/**
 * @author xh
 */
@Service("messageCenterRemoteService")
public class MessageCenterRemoteService extends BaseRemoteService {
    @Resource
    private IMessageCenterApi messageCenterApi;

    public void sendSms(SendSmsMessageRequest request) {
        try {
            messageCenterApi.sendSms(request);
        } catch (Exception e) {
            processException(e, new CashloanErrorCode(CashloanErrorCode.Element.r_send_message_remote_fail));
        }
    }

}
