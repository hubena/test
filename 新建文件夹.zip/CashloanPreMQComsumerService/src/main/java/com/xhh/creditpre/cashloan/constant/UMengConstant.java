package com.xhh.creditpre.cashloan.constant;

import com.janty.core.spring.ApplicationContextUtil;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * @author zhangliang
 * @Date:Create in 2018/3/1 10:52
 */
@Component
public class UMengConstant {

    @Value("${umeng.android.appkey}")
    public  String androidAppkey;
    @Value("${umeng.android.mastersecret}")
    public  String androidMastersecret;
    @Value("${umeng.android.goactivityafteropeny}")
    public  String androidGoactivityafteropen;
    @Value("${umeng.ios.appkey}")
    public  String iosAppkey;
    @Value("${umeng.ios.mastersecret}")
    public  String iosMastersecret;
    @Value("${umeng.app.productionmode}")
    public  String appProductionmode;

    public static UMengConstant getInstance(){
        return ApplicationContextUtil.getBeanByType(UMengConstant.class);
    }
}
