package com.xhh.creditpre.cashloan.model;

import java.util.Date;

public class APPInnerMessageInfoRequest extends PreBaseRequest {

    /**
     * 主键ID
     */
    private Long    id;
    /**
     * 用户ID
     */
    private Long    userId;
    /**
     * 消息类型：1-，2-
     */
    private Integer msgType;

    /**
     * 状态：1-有效，2-失效
     */
    private Integer status;

    /**
     * 创建时间
     */
    private Date    gmtCreated;

    /**
     * 是否删除 Y/N
     */
    private String  isDeleted;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Integer getMsgType() {
        return msgType;
    }

    public void setMsgType(Integer msgType) {
        this.msgType = msgType;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Date getGmtCreated() {
        return gmtCreated;
    }

    public void setGmtCreated(Date gmtCreated) {
        this.gmtCreated = gmtCreated;
    }

    public String getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(String isDeleted) {
        this.isDeleted = isDeleted;
    }
}
