package com.xhh.creditpre.cashloan.enums;

/**
 * 客户端设备类型
 */
public enum AppIdType {
    ios("1", "IOS"),

    android("2", "Android");

    /**
     * 通过key获取枚举
     *
     * @param key
     * @return
     */
    public static AppIdType getByKey(String key) {
        switch (key) {
            case "1":
                return ios;
            case "2":
                return android;
            default:
                return null;
        }
    }

    private String key;
    private String desc;

    /**
     * 私有构造
     *
     * @param key
     * @param desc
     */
    private AppIdType(String key, String desc) {
        this.key = key;
        this.desc = desc;
    }

    public String getKey() {
        return key;
    }

    public String getDesc() {
        return desc;
    }
}
