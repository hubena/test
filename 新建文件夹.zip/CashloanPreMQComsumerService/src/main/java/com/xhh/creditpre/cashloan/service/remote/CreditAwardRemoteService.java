package com.xhh.creditpre.cashloan.service.remote;

import com.janty.core.dto.StringRequest;
import com.janty.core.util.BaseRemoteService;
import com.janty.core.util.StringUtil;
import com.xhh.creditcore.transaction.api.ICreditAwardApi;
import com.xhh.creditcore.transaction.dto.*;
import com.xhh.creditpre.cashloan.constant.CashloanErrorCode;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * author zhangliang
 *
 * @Date:Create in 2018/1/12
 */
@Service("creditAwardRemoteService")
public class CreditAwardRemoteService extends BaseRemoteService {

    @Resource
    private ICreditAwardApi creditAwardApi;

    /**
     * 人脸识别
     * 
     * @param request
     * @return
     */
    public void faceRecognize(FaceRequest request) {
        try {
            creditAwardApi.faceRecognize(request);
        } catch (Exception e) {
            processException(e, new CashloanErrorCode(CashloanErrorCode.Element.r_face_recognize_remote_fail));
        }
    }

    /**
     * 鉴权绑卡
     * 
     * @param request
     * @return
     */
    public void bindBank(BindBankRequest request) {
        try {
            creditAwardApi.bindBank(request);
        } catch (Exception e) {
            processException(e, new CashloanErrorCode(CashloanErrorCode.Element.r_bind_bank_remote_fail));
        }
    }

    /**
     * 上传附件
     *
     * @param request
     * @return
     */
    public void uploadAttachment(CreditAwardAttachmentRequest request) {
        try {
            creditAwardApi.uploadAttachment(request);

        } catch (Exception e) {
            processException(e, new CashloanErrorCode(CashloanErrorCode.Element.r_upload_file_remote_fail));

        }
    }

    /**
     * 更新个人信息
     *
     * @param request
     * @return
     */
    public void updateCreditAwardInfo(CreditAwardInfoRequest request) {
        try {
            creditAwardApi.updateCreditAwardInfo(request);
        } catch (Exception e) {
            processException(e, new CashloanErrorCode(CashloanErrorCode.Element.r_update_creditAwardInfo_remote_fail));
        }
    }

    /**
     * 查询最新额度
     * 
     * @param request
     * @return
     */
    public CreditAwardDto queryLatestCreditAward(LatestCreditAwardRequest request) {
        try {
            return creditAwardApi.queryLatestCreditAward(request);
        } catch (Exception e) {
            return processException(e, new CashloanErrorCode(CashloanErrorCode.Element.r_query_latest_credit_award_remote_fail));
        }
    }

    /**
     * 授信申请
     * 
     * @param request
     * @return
     */
    public CreditAwardApplyDto creditAwardApply(CreditAwardApplyRequest request) {
        try {
            return creditAwardApi.creditAwardApply(request);

        } catch (Exception e) {
            return processException(e, new CashloanErrorCode(CashloanErrorCode.Element.r_transaction_remote_fail));
        }
    }

    /**
     * 授信
     * 
     * @param request
     * @return
     */
    public CreditAwardDto creditAward(CreditAwardRequest request) {
        try {
            return creditAwardApi.creditAward(request);
        } catch (Exception e) {
            return processException(e, new CashloanErrorCode(CashloanErrorCode.Element.r_transaction_remote_fail));
        }
    }
    
    /**
     * 提额
     */
    public void raiseQuota(CreditAwardRaiseQuotaRequest request) {
        try {
            creditAwardApi.raiseQuota(request);
        } catch (Exception e) {
            processException(e, new CashloanErrorCode(CashloanErrorCode.Element.r_transaction_remote_fail));
        }
    }

    /**
     * 查询授信信息
     *
     * @param request
     * @return
     */
    public CreditAwardInfoDto queryCreditAwardInfo(CreditAwardRequest request) {
        try {
            if(!StringUtil.isNotNull(request.getCreditAwardNo()))
                return null;
            return creditAwardApi.queryCreditAwardInfo(request);
        } catch (Exception e) {
            return processException(e, new CashloanErrorCode(CashloanErrorCode.Element.r_transaction_remote_fail));
        }
    }

    /**
     * 根据授信号查询附件信息
     *
     * @param request
     * @return
     */
    public List<CreditAwardAttachmentDto> queryAttachmentByCreditAwardNo(StringRequest request) {
        try {
            if(!StringUtil.isNotNull(request.getParam()))
                return null;
            return creditAwardApi.queryAttachmentByCreditAwardNo(request);

        } catch (Exception e) {
            return processException(e, new CashloanErrorCode(CashloanErrorCode.Element.r_upload_file_remote_fail));

        }
    }

    /**
     * 根据授信号查询联系人信息
     *
     * @param request
     * @return
     */
    public List<ContactsInfoDto> queryContactsByCreditAwardNo(CreditAwardRequest request) {
        try {
            if(!StringUtil.isNotNull(request.getCreditAwardNo()))
                return null;
            return creditAwardApi.queryCreditAwardContactsByCreditAwardNo(request);

        } catch (Exception e) {
            return processException(e, new CashloanErrorCode(CashloanErrorCode.Element.r_upload_file_remote_fail));

        }
    }

}
