package com.xhh.creditpre.cashloan.model;

import javax.validation.constraints.NotNull;

import com.janty.core.dto.BaseRequest;

/**
 * author zhangweixin
 *
 * @Date:Create in 2018/1/12
 */
public class CreditApplyRecordQueryRequest extends PreBaseRequest {
    @NotNull(message = "授信号不能为空")
    private String creditAwardNo;

    public String getCreditAwardNo() {
        return creditAwardNo;
    }

    public void setCreditAwardNo(String creditAwardNo) {
        this.creditAwardNo = creditAwardNo;
    }
}
