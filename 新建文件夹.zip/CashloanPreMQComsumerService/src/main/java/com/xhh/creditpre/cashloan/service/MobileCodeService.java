package com.xhh.creditpre.cashloan.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.janty.core.exception.BusinessException;
import com.xhh.creditpre.cashloan.constant.CashLoanConstant;
import com.xhh.creditpre.cashloan.constant.CashloanErrorCode;
import com.xhh.creditpre.cashloan.constant.MsgCodeType;
import com.xhh.creditpre.cashloan.model.MsgCodeRequest;
import com.xhh.creditpre.cashloan.model.UserInfo;
import com.xhh.creditpre.cashloan.util.SmsUtils;
import com.xhh.infrastructure.messagecenter.dto.SendSmsMessageRequest;

/**
 * author zhangliang
 *
 * @Date:Create in 2018/1/23
 */
@Service("mobileCodeService")
public class MobileCodeService {

    @Autowired
    private UserInfoService    userInfoService;

    @Autowired
    private SendMessageService sendMessageService;

    public void getCode(MsgCodeRequest request) {

        SendSmsMessageRequest sendSmsMessageRequest = SmsUtils.sendMsg(request.getPhone(), request.getReqNo());
        //校验手机号是否已注册
        UserInfo userInfo = userInfoService.selectByPhone(request.getPhone());

        switch (MsgCodeType.getByKey(request.getType())) {
            //注册
            case REGISTER:
                if (userInfo != null)
                    throw new BusinessException(new CashloanErrorCode(CashloanErrorCode.Element.b_user_phone_has_exsit));
                sendMessageService.sendMessageWhenRegister(sendSmsMessageRequest);
                break;
            //忘记密码
            case FORGETPASSWD:
                if (userInfo == null)
                    throw new BusinessException(new CashloanErrorCode(CashloanErrorCode.Element.b_user_phone_has_not_exsit));
                sendMessageService.sendMessageWhenModifyPassword(sendSmsMessageRequest);
                break;
            //修改密码
            case ALTERPASSWD:
                sendMessageService.sendMessageWhenModifyPassword(sendSmsMessageRequest);
                break;
        }
        //缓存短信验证码
        SmsUtils.cacheCode(sendSmsMessageRequest.getUserPhone(), sendSmsMessageRequest.getParamMap().get(CashLoanConstant.msg_code));
    }

}
