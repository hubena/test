package com.xhh.creditpre.cashloan.model;

import com.janty.core.dto.BaseRequest;

import javax.validation.constraints.NotNull;

/**
 * @author zhangliang
 * @Date:Create in 2018/1/31
 */
public class PreBindBankRequest extends BaseRequest {

    @NotNull(message = "授信号不能为空")
    private String creditAwardNo;

    @NotNull(message = "姓名不能为空")
    private String accountName;

    @NotNull(message = "身份证号不能为空")
    private String accountCardNo;

    @NotNull(message = "手机号不能为空")
    private String accountMobile;

    @NotNull(message = "银行卡号不能为空")
    private String bankCardNo;

    public String getCreditAwardNo() {
        return creditAwardNo;
    }

    public void setCreditAwardNo(String creditAwardNo) {
        this.creditAwardNo = creditAwardNo;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public String getAccountCardNo() {
        return accountCardNo;
    }

    public void setAccountCardNo(String accountCardNo) {
        this.accountCardNo = accountCardNo;
    }

    public String getAccountMobile() {
        return accountMobile;
    }

    public void setAccountMobile(String accountMobile) {
        this.accountMobile = accountMobile;
    }

    public String getBankCardNo() {
        return bankCardNo;
    }

    public void setBankCardNo(String bankCardNo) {
        this.bankCardNo = bankCardNo;
    }
}
