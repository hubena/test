package com.xhh.creditpre.cashloan.service.remote;

import com.janty.core.dto.StringRequest;
import com.janty.core.util.BaseRemoteService;
import com.xhh.creditcore.product.api.IProductApi;
import com.xhh.creditcore.product.dto.ProductChannelDto;
import com.xhh.creditcore.product.dto.ProductSupportBanksDto;
import com.xhh.creditcore.transaction.constant.TransactionErrorCode;
import com.xhh.creditpre.cashloan.constant.CashLoanConstant;
import com.xhh.creditpre.cashloan.constant.CashloanErrorCode;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 类ProductRemoteService.java的实现描述：TODO 类实现描述
 * 
 * @author xiehuang 2018年1月18日 下午8:29:27
 */
@Service("productRemoteService")
public class ProductRemoteService extends BaseRemoteService {
    @Resource
    private IProductApi productApi;

    /**
     * 查询产品渠道
     * 
     * @param request
     * @return
     */
    public ProductChannelDto queryProductChannel(com.xhh.creditcore.product.dto.ProductChannelRequest request) {
        try {
            return productApi.queryProductChannel(request);
        } catch (Exception e) {
            return processException(e, new CashloanErrorCode(CashloanErrorCode.Element.r_product_remote_fail));

        }
    }

    public List<ProductSupportBanksDto> getSupportBanksByProductCode() {
        try {
            StringRequest request = new StringRequest();
            request.setParam(CashLoanConstant.product_code);
            return productApi.getSupportBanksByProductCode(request);
        } catch (Exception e) {
            return processException(e, new CashloanErrorCode(CashloanErrorCode.Element.r_support_banks_remote_fail));
        }
    }

    /**
     * 根据产品编码查询产品所有配置
     * 
     * @param productCode
     * @return
     */
    public Map<String, String> queryByConfigsProductCode(String reqNo, String productCode) {
        try {
            StringRequest productRequest = new StringRequest();
            productRequest.setParam(productCode);
            productRequest.setReqNo(reqNo);
            Map<String, String> map = productApi.queryByConfigsProductCode(productRequest);
            if (map == null) {
                map = new HashMap<String, String>();
            }
            return map;

        } catch (Exception e) {
            return processException(e, new CashloanErrorCode(CashloanErrorCode.Element.r_product_remote_fail));
        }
    }
}
