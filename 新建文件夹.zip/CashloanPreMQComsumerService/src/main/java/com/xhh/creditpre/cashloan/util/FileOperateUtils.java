package com.xhh.creditpre.cashloan.util;

import org.springframework.util.Base64Utils;

import com.janty.core.exception.SystemException;
import com.janty.core.util.FileUtil;
import com.janty.core.util.ObjectId;
import com.xhh.creditpre.cashloan.constant.CashLoanConstant;
import com.xhh.creditpre.cashloan.enums.FilePathType;

/**
 * 类FileOperateUtils.java的实现描述：文件操作类
 * 
 * @author xianghh 2018年1月30日 下午12:04:55
 */
public class FileOperateUtils {
    /**
     * 图片上传
     * 
     * @param pathType
     * @param imgBase64
     */
    public static String uploadPic(FilePathType pathType, String imgBase64) {
        String fileUrl = "";
        try {
            byte[] imgByte = Base64Utils.decodeFromString(imgBase64);
            String name = ObjectId.getId();
            String fileName = name + CashLoanConstant.default_img_suffix;
            //相对目录
            String relativeDir = "/" + CashLoanConstant.project_name + CashLoanConstant.file_upload_dir + "/" + pathType.getKey();
            String targetDir = CashLoanConstant.file_root_dir + relativeDir;
            FileUtil.uploadFile(imgByte, fileName, targetDir);
            fileUrl = relativeDir + "/" + fileName;
        } catch (Exception e) {
            throw new SystemException("文件上传失败!");
        }

        return fileUrl;
    }
}
