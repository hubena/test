package com.xhh.creditpre.cashloan.dao;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.xhh.creditpre.cashloan.model.LoanTermConfig;

import java.util.List;

@Repository
public interface LoanTermConfigMapper {
    int deleteByPrimaryKey(Long id);

    int insert(LoanTermConfig record);

    int insertSelective(LoanTermConfig record);

    LoanTermConfig selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(LoanTermConfig record);

    int updateByPrimaryKey(LoanTermConfig record);

    List<LoanTermConfig> queryByAmountType(@Param("amountType") Integer amountType);
}
