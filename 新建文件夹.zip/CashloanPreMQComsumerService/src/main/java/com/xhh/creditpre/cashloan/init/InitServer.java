package com.xhh.creditpre.cashloan.init;

import org.springframework.stereotype.Service;

import com.janty.core.spring.SpringInitFinishedListener;
import com.janty.system.thread.DBCachedRefreshThread;

/**
 * 本地缓存初始化
 * 
 * @author jan
 */
@Service
public class InitServer extends SpringInitFinishedListener {

    @Override
    public void doBussiness() {
        //加载DB基础数据缓存
        new Thread(new DBCachedRefreshThread()).start();

    }

}
