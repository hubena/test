package com.xhh.creditpre.cashloan.controller;

import com.janty.cached.access.RedisCachedAccess;
import com.janty.core.dto.BaseResponse;
import com.janty.core.util.ExceptionUtil;
import com.janty.core.util.ResponseUtil;
import com.janty.core.util.ValidateUtil;
import com.xhh.creditpre.cashloan.constant.CashloanRedisKey;
import com.xhh.creditpre.cashloan.model.*;
import com.xhh.creditpre.cashloan.service.UserInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;

@Controller
@RequestMapping("/user")
public class UserController extends WrapperController {

    @Autowired
    private UserInfoService userInfoService;

    /**
     * 注册
     *
     * @param registerRequest
     * @return
     */
    @RequestMapping("/register")
    @ResponseBody
    public BaseResponse<Void> register(final RegisterRequest registerRequest) {
        logger.info("UserController-register-请求开始, reqNo-{}-请求参数-{}", registerRequest.getReqNo(), registerRequest);

        BaseResponse<Void> response = ResponseUtil.createDefaultResponse();
        try {
            ValidateUtil.validate(registerRequest);
            response = safeExecute(new SafeExecutor<Void, RegisterRequest>() {
                BaseResponse<Void> baseResponse = ResponseUtil.createDefaultResponse();

                @Override
                public BaseResponse<Void> execute() throws Exception {
                    userInfoService.addData(registerRequest);
                    ResponseUtil.success(baseResponse, null);
                    return baseResponse;
                }

                @Override
                public RegisterRequest getBaseRequest() {
                    return registerRequest;
                }
            });

        } catch (Exception e) {
            logger.error("UserController-register-请求异常, reqNo-{}-{}", registerRequest.getReqNo(), ExceptionUtil.getType(e), e);
            ResponseUtil.handleException(response, e);
        }

        logger.info("UserController-register-请求结束, reqNo-{}-返回-{}", registerRequest.getReqNo(), response);

        return response;
    }

    /**
     * 登录
     *
     * @param loginRequest
     * @return
     */
    @RequestMapping("/login")
    @ResponseBody
    public BaseResponse<LoginDto> login(LoginRequest loginRequest) {
        logger.info("UserController-login-请求开始, reqNo-{}-请求参数-{}", loginRequest.getReqNo(), loginRequest);

        BaseResponse<LoginDto> response = ResponseUtil.createDefaultResponse();
        LoginDto loginDto = null;
        try {
            ValidateUtil.validate(loginRequest);
            loginDto = userInfoService.login(loginRequest);
            ResponseUtil.success(response, loginDto);
        } catch (Exception e) {
            logger.error("UserController-login-请求异常, reqNo-{}-{}", loginRequest.getReqNo(), ExceptionUtil.getType(e), e);
            ResponseUtil.handleException(response, e);
        }

        logger.info("UserController-login-请求结束, reqNo-{}-返回-{}", loginRequest.getReqNo(), response);

        return response;
    }

    @RequestMapping("/logout")
    @ResponseBody
    public BaseResponse<Void> logout(PreBaseRequest request) {
        logger.info("UserController-logout-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);

        BaseResponse<Void> response = ResponseUtil.createDefaultResponse();

        try {
            ValidateUtil.validate(request);
            userInfoService.logout(request);
            ResponseUtil.success(response, null);
        } catch (Exception e) {
            logger.error("UserController-logout-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            ResponseUtil.handleException(response, e);
        }

        logger.info("UserController-logout-请求结束, reqNo-{}-返回-{}", request.getReqNo(), response);

        return response;
    }

    /**
     * 修改密码
     *
     * @param alterPasswdRequest
     * @return
     */
    @RequestMapping("/alterPasswd")
    @ResponseBody
    public BaseResponse<Void> alterPasswd(AlterPasswdRequest alterPasswdRequest, PreBaseRequest request) {
        logger.info("UserController-alterPasswd-请求开始, reqNo-{}-请求参数-{}", alterPasswdRequest.getReqNo(), alterPasswdRequest);

        BaseResponse<Void> response = ResponseUtil.createDefaultResponse();

        try {
            ValidateUtil.validate(request);
            ValidateUtil.validate(alterPasswdRequest);
            UserDto userDto = queryUserByToken(request);
            userInfoService.alterPasswd(alterPasswdRequest, request.getToken(), userDto);
            ResponseUtil.success(response, null);
        } catch (Exception e) {
            logger.error("UserController-alterPasswd-请求异常, reqNo-{}-{}", alterPasswdRequest.getReqNo(), ExceptionUtil.getType(e), e);
            ResponseUtil.handleException(response, e);
        }

        logger.info("UserController-alterPasswd-请求结束, reqNo-{}-返回-{}", alterPasswdRequest.getReqNo(), response);

        return response;
    }

    /**
     * 忘记密码
     *
     * @param forgetPasswdRequest
     * @return
     */
    @RequestMapping("/forgetPasswd")
    @ResponseBody
    public BaseResponse<Void> forgetPasswd(ForgetPasswdRequest forgetPasswdRequest) {
        logger.info("UserController-forgetPasswd-请求开始, reqNo-{}-请求参数-{}", forgetPasswdRequest.getReqNo(), forgetPasswdRequest);

        BaseResponse<Void> response = ResponseUtil.createDefaultResponse();

        try {
            ValidateUtil.validate(forgetPasswdRequest);
            userInfoService.forgetPasswd(forgetPasswdRequest);
            ResponseUtil.success(response, null);
        } catch (Exception e) {
            logger.error("UserController-forgetPasswd-请求异常, reqNo-{}-{}", forgetPasswdRequest.getReqNo(), ExceptionUtil.getType(e), e);
            ResponseUtil.handleException(response, e);
        }

        logger.info("UserController-forgetPasswd-请求结束, reqNo-{}-返回-{}", forgetPasswdRequest.getReqNo(), response);

        return response;
    }

}
