package com.xhh.creditpre.cashloan.enums;

/**
 * @author zhangliang
 * @Date:Create in 2018/2/28 10:52
 */
public enum ReadType {
    NOT_READ(1,"未读"),
    READ(2,"已读");

    private Integer key;
    private String desc;

    private ReadType(Integer key,String desc){
        this.key = key;
        this.desc = desc;
    }

    public Integer getKey() {
        return key;
    }

    public String getDesc() {
        return desc;
    }

    public ReadType getByKey(Integer key){
        for (ReadType readType : ReadType.values()){
            if (readType.getKey().equals(key))
                return readType;
        }
        return null;
    }
}
