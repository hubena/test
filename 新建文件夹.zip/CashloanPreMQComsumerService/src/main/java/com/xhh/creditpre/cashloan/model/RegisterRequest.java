package com.xhh.creditpre.cashloan.model;

import com.janty.core.dto.BaseRequest;

import javax.validation.constraints.NotNull;

public class RegisterRequest extends BaseRequest {

    /**
     * 用户名
     */
    private String  loginName;

    /**
     * 手机号
     */
    @NotNull(message = "手机号是必选参数")
    private String  phone;

    /**
     * 密码,此处密码为密文
     */
    @NotNull(message = "密码是必选参数")
    private String  password;

    /**
     * 渠道编码密文
     */
    @NotNull(message = "渠道编码密文是必选参数")
    private String  secretCode;

    /**
     * 来源 1-PC 2-APP-IOS, 3-APP-ANDROID，4-WeChat,9-其他
     */
    @NotNull(message = "来源是必选参数")
    private Integer sourceCode;

    /**
     * 邀请码
     */
    private String  shareCodeUsed;

    /**
     * 短信码
     */
    @NotNull(message = "短信验证码是必选参数")
    private String  msgCode;

    public String getLoginName() {

        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getSecretCode() {
        return secretCode;
    }

    public void setSecretCode(String secretCode) {
        this.secretCode = secretCode;
    }

    public Integer getSourceCode() {
        return sourceCode;
    }

    public void setSourceCode(Integer sourceCode) {
        this.sourceCode = sourceCode;
    }

    public String getShareCodeUsed() {
        return shareCodeUsed;
    }

    public void setShareCodeUsed(String shareCodeUsed) {
        this.shareCodeUsed = shareCodeUsed;
    }

    public String getMsgCode() {
        return msgCode;
    }

    public void setMsgCode(String msgCode) {
        this.msgCode = msgCode;
    }
}
