package com.xhh.creditpre.cashloan.model;

import com.janty.core.dto.BaseModel;

import java.util.Date;

public class UserDto extends BaseModel {

    private Long    id;

    private String  loginName;

    private String  password;

    private Long    accountId;    //主账户id

    private Long    prodAccountId;//产品账户id

    private String  nickName;

    private String  gender;

    private String  name;         //姓名

    private String  phone;        //电话

    private String  email;

    private String  photoUrl;

    private String  channelCode;  //渠道编码

    private String  channelName;  //渠道名字

    private Integer sourceCode;   //来源

    private String  shareCode;    //用户专属邀请码

    private String  shareCodeUsed;//注册时使用的邀请码

    private Integer isLock;

    private Integer isAuth;

    private Integer status;       //客户状态

    private Date    registerTime; //注册时间

    private Date    loginFailTime;

    private String  remark;

    private Date    gmtCreated;

    private Date    gmtModified;

    private String  creator;

    private String  modifier;

    private String  isDeleted;

    private String  idCard;       //身份证号

    private String  birthday;     //出生日期

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Long getAccountId() {
        return accountId;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public Long getProdAccountId() {
        return prodAccountId;
    }

    public void setProdAccountId(Long prodAccountId) {
        this.prodAccountId = prodAccountId;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhotoUrl() {
        return photoUrl;
    }

    public void setPhotoUrl(String photoUrl) {
        this.photoUrl = photoUrl;
    }

    public String getChannelCode() {
        return channelCode;
    }

    public void setChannelCode(String channelCode) {
        this.channelCode = channelCode;
    }

    public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }

    public Integer getSourceCode() {
        return sourceCode;
    }

    public void setSourceCode(Integer sourceCode) {
        this.sourceCode = sourceCode;
    }

    public String getShareCode() {
        return shareCode;
    }

    public void setShareCode(String shareCode) {
        this.shareCode = shareCode;
    }

    public String getShareCodeUsed() {
        return shareCodeUsed;
    }

    public void setShareCodeUsed(String shareCodeUsed) {
        this.shareCodeUsed = shareCodeUsed;
    }

    public Integer getIsLock() {
        return isLock;
    }

    public void setIsLock(Integer isLock) {
        this.isLock = isLock;
    }

    public Integer getIsAuth() {
        return isAuth;
    }

    public void setIsAuth(Integer isAuth) {
        this.isAuth = isAuth;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Date getRegisterTime() {
        return registerTime;
    }

    public void setRegisterTime(Date registerTime) {
        this.registerTime = registerTime;
    }

    public Date getLoginFailTime() {
        return loginFailTime;
    }

    public void setLoginFailTime(Date loginFailTime) {
        this.loginFailTime = loginFailTime;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Date getGmtCreated() {
        return gmtCreated;
    }

    public void setGmtCreated(Date gmtCreated) {
        this.gmtCreated = gmtCreated;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public String getModifier() {
        return modifier;
    }

    public void setModifier(String modifier) {
        this.modifier = modifier;
    }

    public String getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(String isDeleted) {
        this.isDeleted = isDeleted;
    }

    public String getIdCard() {
        return idCard;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }
}
