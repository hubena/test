package com.xhh.creditpre.cashloan.model;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 公告信息表
 * </p>
 *
 * @author nathaniel123
 * @since 2018-01-09
 */

public class AdvertiseInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
    private Long              id;
    /**
     * 标题
     */
    private String            title;
    /**
     * 内容
     */
    private String            content;
    /**
     * 请求url
     */
    private String            reqUrl;
    /**
     * 状态：1-有效，2-失效
     */
    private Integer           status;
    /**
     * 备注
     */
    private String            remark;
    /**
     * 创建时间
     */
    private Date              gmtCreated;
    /**
     * 修改时间
     */
    private Date              gmtModified;
    /**
     * 创建人
     */
    private String            creator;
    /**
     * 修改人
     */
    private String            modifier;
    /**
     * 是否删除 Y/N
     */
    private String            isDeleted;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getReqUrl() {
        return reqUrl;
    }

    public void setReqUrl(String reqUrl) {
        this.reqUrl = reqUrl;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Date getGmtCreated() {
        return gmtCreated;
    }

    public void setGmtCreated(Date gmtCreated) {
        this.gmtCreated = gmtCreated;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public String getModifier() {
        return modifier;
    }

    public void setModifier(String modifier) {
        this.modifier = modifier;
    }

    public String getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(String isDeleted) {
        this.isDeleted = isDeleted;
    }

    @Override
    public String toString() {
        return "AdvertiseInfo{" + "id=" + id + ", title=" + title + ", content=" + content + ", reqUrl=" + reqUrl + ", status=" + status + ", remark=" + remark
                + ", gmtCreated=" + gmtCreated + ", gmtModified=" + gmtModified + ", creator=" + creator + ", modifier=" + modifier + ", isDeleted=" + isDeleted
                + "}";
    }
}
