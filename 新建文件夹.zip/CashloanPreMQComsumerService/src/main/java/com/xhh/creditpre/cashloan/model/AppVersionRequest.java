package com.xhh.creditpre.cashloan.model;

import com.janty.core.dto.BaseRequest;
import com.janty.core.validation.InRange;
import com.xhh.creditpre.cashloan.enums.AppIdType;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotNull;

@Getter
@Setter
public class AppVersionRequest extends BaseRequest {

    /**
     *
     */
    private static final long serialVersionUID = -1419663557922829703L;

    /**
     * 客户端设备id</br>
     * 必填.
     */
    @NotNull(message = "appId为必填参数")
    @InRange(enumType = AppIdType.class, message = "客户端设备类型非法", fieldMethodName = "getKey")
    private String            appId;

    /**
     * 版本号</br>
     * 必填
     */
    @NotNull(message = "version为必填参数")
    private String            version;
}
