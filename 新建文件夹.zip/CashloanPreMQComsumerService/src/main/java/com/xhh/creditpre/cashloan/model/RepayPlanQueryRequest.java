package com.xhh.creditpre.cashloan.model;

import javax.validation.constraints.NotNull;

/**
 * author zhangweixin
 *
 * @Date:Create in 2018/1/12
 */
public class RepayPlanQueryRequest extends PreBaseRequest {
    @NotNull(message = "借款订单号不能为空")
    private String loanOrderNo;

    private Long   accountId;

    public String getLoanOrderNo() {
        return loanOrderNo;
    }

    public void setLoanOrderNo(String loanOrderNo) {
        this.loanOrderNo = loanOrderNo;
    }

    public Long getAccountId() {
        return accountId;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }
}
