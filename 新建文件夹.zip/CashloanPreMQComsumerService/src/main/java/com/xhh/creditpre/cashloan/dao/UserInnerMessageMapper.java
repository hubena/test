package com.xhh.creditpre.cashloan.dao;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;
import org.springframework.stereotype.Repository;

import com.xhh.creditpre.cashloan.model.UserInnerMessage;

import java.util.List;

@Repository
public interface UserInnerMessageMapper {
    int deleteByPrimaryKey(Long id);

    int insert(UserInnerMessage record);

    int insertSelective(UserInnerMessage record);

    UserInnerMessage selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(UserInnerMessage record);

    int updateByPrimaryKey(UserInnerMessage record);

    List<UserInnerMessage> selectByInnerMessgeId(@Param("innerMessageId") Long innerMessageId);

    void updateStatusById(UserInnerMessage userInnerMessage);

    Long selectCountByUserId(@Param("isRead")Integer isRead, @Param("userId") Long userId);

    List<UserInnerMessage> selectMessagesByUserId(@Param("userId") Long userId, RowBounds rowBounds);
}