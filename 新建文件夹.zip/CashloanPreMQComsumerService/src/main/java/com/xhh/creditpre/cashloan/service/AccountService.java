package com.xhh.creditpre.cashloan.service;

import com.janty.cached.access.RedisCachedAccess;
import com.janty.core.dto.StringRequest;
import com.janty.core.util.CollectionUtil;
import com.janty.core.util.CommonBeanCopier;
import com.xhh.creditcore.capital.dto.AccountBankCardDto;
import com.xhh.creditcore.capital.dto.AccountBankCardRequest;
import com.xhh.creditcore.capital.dto.BankCardbinDto;
import com.xhh.creditcore.capital.dto.QueryBankCardbinRequest;
import com.xhh.creditcore.transaction.dto.CreditAwardAttachmentDto;
import com.xhh.creditcore.transaction.dto.MainAccountDto;
import com.xhh.creditcore.transaction.dto.OpenAccountDto;
import com.xhh.creditcore.transaction.dto.QueryMainAccountRequest;
import com.xhh.creditpre.cashloan.constant.CashLoanConstant;
import com.xhh.creditpre.cashloan.constant.CashloanRedisKey;
import com.xhh.creditpre.cashloan.enums.AttachmentType;
import com.xhh.creditpre.cashloan.enums.AuthType;
import com.xhh.creditpre.cashloan.model.*;
import com.xhh.creditpre.cashloan.service.remote.AccountRemoteService;
import com.xhh.creditpre.cashloan.service.remote.CapitalRemoteService;
import com.xhh.creditpre.cashloan.service.remote.CreditAwardRemoteService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

/**
 * author zhangliang
 *
 * @Date:Create in 2018/1/19
 */
@Service("accountService")
public class AccountService {
    private final Logger                logger = LoggerFactory.getLogger(getClass());

    @Resource
    private RedisCachedAccess<UserInfo> redisCachedAccess;

    @Resource
    private AccountRemoteService        accountRemoteService;

    @Resource
    private CapitalRemoteService        capitalRemoteService;

    @Autowired
    private UserInfoService             userInfoService;

    @Resource
    private CreditAwardRemoteService    creditAwardRemoteService;

    /**
     * 通过产品编码、身份证、姓名开户
     *
     * @param
     * @return
     */
    public OpenAccountDto openAccount(OpenAccountRequest request, UserDto userDto, String token) {
        request.setRegisterChannelCode(userDto.getChannelCode());
        com.xhh.creditcore.transaction.dto.OpenAccountRequest openAccountRequest = new com.xhh.creditcore.transaction.dto.OpenAccountRequest();
        CommonBeanCopier.copy(request, openAccountRequest);

        openAccountRequest.setProductCode(CashLoanConstant.product_code);
        //请求核心开户
        OpenAccountDto dto = accountRemoteService.openAccount(openAccountRequest);

        //开户成功更新用户信息
        UserInfo userInfo = new UserInfo();
        CommonBeanCopier.copy(userDto, userInfo);
        userInfo.setAccountId(dto.getAccountId());
        userInfo.setProdAccountId(dto.getProdAccountId());
        userInfo.setGmtModified(new Date());
        userInfo.setName(request.getRealName());
        userInfo.setGender(request.getGender());
        userInfo.setIsAuth(AuthType.AUTH.getKey());
        userInfoService.updateUserInfoById(userInfo);
        //更新用户缓存
        redisCachedAccess.hput(token, CashloanRedisKey.login_user, userInfo);
        return dto;
    }

    /**
     * 获取主账户
     * 
     * @param request
     * @param userDto
     * @return
     */
    public MainAccountDto getMainAccount(PreBaseRequest request, UserDto userDto) {
        QueryMainAccountRequest queryMainAccountRequest = new QueryMainAccountRequest();
        queryMainAccountRequest.setReqNo(request.getReqNo());
        queryMainAccountRequest.setMainAccountId(userDto.getAccountId());
        //调用核心查询主账户
        return accountRemoteService.getMainAccount(queryMainAccountRequest);
    }

    /**
     * 查询账户绑定银行卡
     * 
     * @param request
     * @param userDto
     * @return
     */
    public AccountBankCardDto getAccountBankCard(PreBaseRequest request, UserDto userDto) {

        if(userDto.getProdAccountId() == null)
            return null;
        AccountBankCardRequest accountBankCardRequest = new AccountBankCardRequest();
        accountBankCardRequest.setReqNo(request.getReqNo());
        accountBankCardRequest.setAccountId(userDto.getProdAccountId());
        AccountBankCardDto accountBankCardDto = capitalRemoteService.queryAccountBankCardBind(accountBankCardRequest);
        if(accountBankCardDto != null){
            QueryBankCardbinRequest queryBankCardbinRequest = new QueryBankCardbinRequest();
            queryBankCardbinRequest.setCardNo(accountBankCardDto.getBankCardNo());
            BankCardbinDto bankCardbinDto = capitalRemoteService.queryBankCardbin(queryBankCardbinRequest);
            accountBankCardDto.setBankName(bankCardbinDto.getBankName());
        }
        return accountBankCardDto;
    }

    /**
     * 查询账户信息（包括身份证图片）
     *
     * @param request
     * @return
     */
    public CredentialInfoDto getCredentialInfo(StringRequest request, UserDto userDto){
        if(userDto.getAccountId() == null)
            return null;
        CredentialInfoDto credentialInfoDto = new CredentialInfoDto();
        QueryMainAccountRequest queryMainAccountRequest = new QueryMainAccountRequest();
        queryMainAccountRequest.setReqNo(request.getReqNo());
        queryMainAccountRequest.setMainAccountId(userDto.getAccountId());
        //调用核心查询主账户
        MainAccountDto mainAccountDto = accountRemoteService.getMainAccount(queryMainAccountRequest);
        if(mainAccountDto == null)
            return null;
        CommonBeanCopier.copy(mainAccountDto, credentialInfoDto);
        //查询身份证附件信息
        List<CreditAwardAttachmentDto> list = creditAwardRemoteService.queryAttachmentByCreditAwardNo(request);
        if(CollectionUtil.isListNotNull(list)){
            for(CreditAwardAttachmentDto attachmentDto : list){
                if(attachmentDto.getAttachmentType() == AttachmentType.IDENTITY_CARD_F.getKey()){
                    credentialInfoDto.setCredentialFrontUrl(attachmentDto.getAttachmentUrl());
                }else if(attachmentDto.getAttachmentType() == AttachmentType.IDENTITY_CARD_B.getKey()){
                    credentialInfoDto.setCredentialBackUrl(attachmentDto.getAttachmentUrl());
                }
            }
        }
        return credentialInfoDto;
    }
}
