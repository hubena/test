package com.xhh.creditpre.cashloan.dao;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;
import org.springframework.stereotype.Repository;

import com.xhh.creditpre.cashloan.model.InnerMessage;

import java.util.List;

@Repository
public interface InnerMessageMapper {
    int deleteByPrimaryKey(Long id);

    int insert(InnerMessage record);

    int insertSelective(InnerMessage record);

    InnerMessage selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(InnerMessage record);

    int updateByPrimaryKey(InnerMessage record);

    List<InnerMessage> queryInnerMessageByPage(@Param("msgType") Integer msgType, RowBounds rowBounds);

    List<InnerMessage> selectByMsgType(InnerMessage innerMessage);

    void updateStatusById(InnerMessage message);

    InnerMessage selectByMsgSubtype(@Param("msgSubtype")Integer msgSubtype);
}