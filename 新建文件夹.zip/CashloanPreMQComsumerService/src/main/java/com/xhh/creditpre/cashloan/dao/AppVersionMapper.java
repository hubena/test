package com.xhh.creditpre.cashloan.dao;

import com.xhh.creditpre.cashloan.dto.AppVersionQueryRequest;
import com.xhh.creditpre.cashloan.model.AppVersion;
import org.apache.ibatis.session.RowBounds;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AppVersionMapper {
    int deleteByPrimaryKey(Long id);

    int insert(AppVersion record);

    int insertSelective(AppVersion record);

    AppVersion selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(AppVersion record);

    int updateByPrimaryKey(AppVersion record);

    List<AppVersion> list(String appid);

    List<AppVersion> queryAPPVersionByPage(AppVersionQueryRequest request, RowBounds rowBounds);
}
