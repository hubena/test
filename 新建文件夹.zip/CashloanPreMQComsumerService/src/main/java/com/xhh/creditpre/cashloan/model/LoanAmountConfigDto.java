package com.xhh.creditpre.cashloan.model;

import com.janty.core.dto.BaseModel;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author zhangliang
 * @Date:Create in 2018/1/31
 */
public class LoanAmountConfigDto extends BaseModel {

    private BigDecimal amount;

    private BigDecimal minAmount;

    private BigDecimal maxAmount;

    private BigDecimal amountSection;

    private Integer    amountType;

    private Integer    status;

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public BigDecimal getMinAmount() {
        return minAmount;
    }

    public void setMinAmount(BigDecimal minAmount) {
        this.minAmount = minAmount;
    }

    public BigDecimal getMaxAmount() {
        return maxAmount;
    }

    public void setMaxAmount(BigDecimal maxAmount) {
        this.maxAmount = maxAmount;
    }

    public BigDecimal getAmountSection() {
        return amountSection;
    }

    public void setAmountSection(BigDecimal amountSection) {
        this.amountSection = amountSection;
    }

    public Integer getAmountType() {
        return amountType;
    }

    public void setAmountType(Integer amountType) {
        this.amountType = amountType;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
}
