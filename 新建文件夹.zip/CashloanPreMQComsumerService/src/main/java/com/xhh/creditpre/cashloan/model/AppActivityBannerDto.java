package com.xhh.creditpre.cashloan.model;

import com.janty.core.dto.BaseModel;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AppActivityBannerDto extends BaseModel {
    private Long    productId;

    private String  productName;

    private Integer terminalType;

    private Integer picType;

    private String  picName;

    private String  directUrl;

    private String  reqUrl;

    private Integer status;

    private Integer sort;

    private String  remark;

    private String  isDeleted;
}
