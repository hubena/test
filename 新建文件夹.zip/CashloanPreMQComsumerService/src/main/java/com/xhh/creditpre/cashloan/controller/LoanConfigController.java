package com.xhh.creditpre.cashloan.controller;

import com.janty.core.controller.BaseController;
import com.janty.core.dto.BaseResponse;
import com.janty.core.util.ExceptionUtil;
import com.janty.core.util.ResponseUtil;
import com.janty.core.util.ValidateUtil;
import com.xhh.creditpre.cashloan.model.LoanConfigDto;
import com.xhh.creditpre.cashloan.model.LoanConfigRequest;
import com.xhh.creditpre.cashloan.service.LoanConfigService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @author zhangliang
 * @Date:Create in 2018/1/31
 */
@RestController
@RequestMapping("/loanConfig")
public class LoanConfigController extends BaseController {

    @Resource
    private LoanConfigService loanConfigService;

    @RequestMapping("/queryLoanConfig")
    public BaseResponse<LoanConfigDto> queryLoanConfig(LoanConfigRequest request) {
        logger.info("LoanConfigController-queryLoanConfig-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);

        BaseResponse<LoanConfigDto> response = ResponseUtil.createDefaultResponse();
        LoanConfigDto loanConfigDto = null;
        try {
            ValidateUtil.validate(request);
            loanConfigDto = loanConfigService.queryLoanConfig(request);
            ResponseUtil.success(response, loanConfigDto);
        } catch (Exception e) {
            logger.error("LoanConfigController-queryLoanConfig-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            ResponseUtil.handleException(response, e);
        }

        logger.info("LoanConfigController-queryLoanConfig-请求结束, reqNo-{}-返回-{}", request.getReqNo(), response);

        return response;
    }
}
