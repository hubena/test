package com.xhh.creditpre.cashloan.model;

import com.janty.core.dto.BaseRequest;

import javax.validation.constraints.NotNull;
import java.util.Date;

public class OpenAccountRequest extends BaseRequest {

    @NotNull(message = "身份证号不能为空")
    private String credentialNo;

    @NotNull(message = "姓名不能为空")
    private String realName;

    //注册时渠道编码
    private String registerChannelCode;

    private Date   credentialExpireDate;//证件过期日

    private String credentialDepartment;//签发机关

    private String gender;              //性别

    private String birthday;            //生日

    private String birthPlace;          //出生地

    private String householdPlace;      //户口所在地

    public String getCredentialNo() {
        return credentialNo;
    }

    public void setCredentialNo(String credentialNo) {
        this.credentialNo = credentialNo;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public String getRegisterChannelCode() {
        return registerChannelCode;
    }

    public void setRegisterChannelCode(String registerChannelCode) {
        this.registerChannelCode = registerChannelCode;
    }

    public Date getCredentialExpireDate() {
        return credentialExpireDate;
    }

    public void setCredentialExpireDate(Date credentialExpireDate) {
        this.credentialExpireDate = credentialExpireDate;
    }

    public String getCredentialDepartment() {
        return credentialDepartment;
    }

    public void setCredentialDepartment(String credentialDepartment) {
        this.credentialDepartment = credentialDepartment;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getBirthPlace() {
        return birthPlace;
    }

    public void setBirthPlace(String birthPlace) {
        this.birthPlace = birthPlace;
    }

    public String getHouseholdPlace() {
        return householdPlace;
    }

    public void setHouseholdPlace(String householdPlace) {
        this.householdPlace = householdPlace;
    }
}
