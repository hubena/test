package com.xhh.creditpre.cashloan.util;

import com.janty.cached.access.RedisCachedAccess;
import com.janty.core.exception.BusinessException;
import com.janty.core.exception.SystemException;
import com.janty.core.spring.ApplicationContextUtil;
import com.xhh.creditpre.cashloan.constant.CashLoanConstant;
import com.xhh.creditpre.cashloan.constant.CashloanErrorCode;
import com.xhh.creditpre.cashloan.constant.CashloanRedisKey;
import com.xhh.creditpre.cashloan.model.MsgCodeModel;
import com.xhh.infrastructure.messagecenter.dto.SendSmsMessageRequest;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Map;

/**
 * @author zhangliang
 * @Date:Create in 2018/1/26
 */
public class SmsUtils {

    private static RedisCachedAccess<MsgCodeModel> redisCachedAccess;
    //过期时间 5分钟
    private static Long                            expireTime = 5 * 60 * 1000L;

    private static void setBean() {
        if (redisCachedAccess == null) {
            redisCachedAccess = (RedisCachedAccess<MsgCodeModel>) ApplicationContextUtil.getBeanByType(RedisCachedAccess.class);
        }

    }

    /**
     * 封装发短信参数
     * 
     * @param phone
     * @return
     */
    public static SendSmsMessageRequest sendMsg(String phone, String reqNo) {
        SendSmsMessageRequest sendSmsMessageRequest = new SendSmsMessageRequest();
        Map<String, String> paramMap = new HashMap<>();
        paramMap.put(CashLoanConstant.msg_code, createRandomVcode(6));
        sendSmsMessageRequest.setUserPhone(phone);
        try {
            sendSmsMessageRequest.setSystemIp(InetAddress.getLocalHost().getHostAddress());
        } catch (UnknownHostException e) {
            throw new SystemException(new CashloanErrorCode(CashloanErrorCode.Element.s_get_local_host_address));
        }
        sendSmsMessageRequest.setParamMap(paramMap);
        sendSmsMessageRequest.setSmsOrder(reqNo);
        return sendSmsMessageRequest;

    }

    /**
     * 校验短信验证码
     * 
     * @param phone
     * @param code
     * @return
     */
    public static void verifyCode(String phone, String code) {
        setBean();
        MsgCodeModel msgCodeModel = redisCachedAccess.hget(phone, CashloanRedisKey.send_sms_cache);
        if (msgCodeModel != null && msgCodeModel.getPhone().equals(phone) && msgCodeModel.getCode().equals(code)) {
            if (getCurrentTime() > msgCodeModel.getCacheTime() + msgCodeModel.getExpireTime())
                throw new BusinessException(new CashloanErrorCode(CashloanErrorCode.Element.b_msg_code_expire));
            redisCachedAccess.getRedisObjectTemplate().opsForHash().delete(phone, CashloanRedisKey.send_sms_cache);
        } else {
            throw new BusinessException(new CashloanErrorCode(CashloanErrorCode.Element.b_msg_phone_code_not_match));
        }
    }

    /**
     * 缓存验证码
     * 
     * @param phone
     * @param code
     */
    public static void cacheCode(String phone, String code) {
        setBean();
        MsgCodeModel msgCodeModel = new MsgCodeModel();
        msgCodeModel.setPhone(phone);
        msgCodeModel.setCode(code);
        msgCodeModel.setExpireTime(expireTime);
        msgCodeModel.setCacheTime(getCurrentTime());
        redisCachedAccess.hput(phone, CashloanRedisKey.send_sms_cache, msgCodeModel);
    }

    /**
     * 获取当前时间
     * 
     * @return
     */
    private static long getCurrentTime() {
        return System.currentTimeMillis();
    }

    /**
     * 随机生成N位短信验证码
     * 
     * @return
     */
    public static String createRandomVcode(int n) {
        //验证码
        String vcode = "";
        for (int i = 0; i < n; i++) {
            vcode = vcode + (int) (Math.random() * 9);
        }
        return vcode;
    }

}
