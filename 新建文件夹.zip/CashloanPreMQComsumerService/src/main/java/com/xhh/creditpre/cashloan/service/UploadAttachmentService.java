package com.xhh.creditpre.cashloan.service;

import com.janty.core.exception.SystemException;
import com.janty.core.util.StringUtil;
import com.janty.core.util.ValidateUtil;
import com.xhh.creditcore.transaction.dto.CreditAwardAttachmentDto;
import com.xhh.creditcore.transaction.dto.CreditAwardAttachmentRequest;
import com.xhh.creditpre.cashloan.constant.CashLoanConstant;
import com.xhh.creditpre.cashloan.enums.FilePathType;
import com.xhh.creditpre.cashloan.model.CreditApplyRecord;
import com.xhh.creditpre.cashloan.service.remote.CreditAwardRemoteService;
import com.xhh.creditpre.cashloan.util.FileOperateUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;

@Service
public class UploadAttachmentService {
    @Resource
    private CreditAwardRemoteService creditAwardRemoteService;

    @Resource
    private CreditApplyRecordService creditApplyRecordService;

    public void uploadAttachment(CreditAwardAttachmentRequest request) {
        //上传图片到服务器
        for (CreditAwardAttachmentDto attachment : request.getAttachmentList()) {
            ValidateUtil.validate(attachment);
            if (StringUtil.isNotNull(attachment.getImgBase64())) {
                //String filePath = getFileName(request.getCreditAwardNo(), attachment.getAttachmentType(), attachment.getFileSuffix());
                //ossService.uploadFile(OssConstants.endpoint, OssConstants.bucket_name, filePath, attachment.getImgBase64().getBytes());
                String image;
                if (attachment.getImgBase64().contains(CashLoanConstant.base64_index)) {
                    image = attachment.getImgBase64().substring(CashLoanConstant.base64_index.length());
                }
                if (attachment.getImgBase64().contains("\\")) {//处理base64字符串中转译符
                    image = attachment.getImgBase64().replace("\\", "");
                } else {
                    image = attachment.getImgBase64();
                }
                String fileuplodPath = FileOperateUtils.uploadPic(FilePathType.CREDIT, image);
                if (StringUtil.isEmpty(fileuplodPath)) {
                    throw new SystemException("文件上传失败!");
                }
                attachment.setAttachmentUrl(fileuplodPath);
            }
        }

        //附件信息存放本地
        creditAwardRemoteService.uploadAttachment(request);
        //更新成功，修改身份证图片是否提交标志
        CreditApplyRecord record = new CreditApplyRecord();
        record.setCreditAwardNo(request.getCreditAwardNo());
        record.setIsCardSubmit(1);
        record.setCardSubmitTime(new Date());
        record.setGmtModified(new Date());
        creditApplyRecordService.modifyAuthStatus(record);
    }
}
