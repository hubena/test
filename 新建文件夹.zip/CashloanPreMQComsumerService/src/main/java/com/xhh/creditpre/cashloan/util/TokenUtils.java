package com.xhh.creditpre.cashloan.util;

import com.janty.core.util.ObjectId;

public class TokenUtils {

    /**
     * token过期时间半个月
     */
    private static final long expireTime = 15 * 24 * 60 * 60 * 1000L;

    /**
     * 获取token
     * 
     * @return
     */
    public static String getToken() {
        String prefix = ObjectId.getIdentityId();
        long suffix = currentTime();
        return prefix + suffix;
    }

    /**
     * 判断token是否过期
     * 
     * @param token
     * @return
     */
    public static boolean isTokenExpire(String token) {
        int length = token.length();
        long time = Long.parseLong(token.substring(length - 13, length));

        long now = currentTime();

        if ((now - time) > expireTime)
            return true;
        return false;
    }

    public static Long currentTime() {
        return System.currentTimeMillis();
    }
}
