package com.xhh.creditpre.cashloan.enums;

/**
 * author zhangliang
 *
 * @Date:Create in 2018/1/20
 */
public enum CreditAwardRecordStatus {

    /**
     * 鉴权绑卡 人脸识别
     */
    auth_success(1, "已认证"),
    auth_fail(2, "未认证");

    private Integer key;
    private String  desc;

    public Integer getKey() {
        return key;
    }

    public String getDesc() {
        return desc;
    }

    CreditAwardRecordStatus(Integer key, String desc) {
        this.key = key;
        this.desc = desc;
    }

    public CreditAwardRecordStatus getInstance(Integer key) {
        for (CreditAwardRecordStatus creditAwardStatus : CreditAwardRecordStatus.values()) {
            if (creditAwardStatus.key.equals(key)) {
                return creditAwardStatus;
            }
        }
        return null;
    }

}
