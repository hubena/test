package com.xhh.creditpre.cashloan.service;

import java.util.Date;
import java.util.Optional;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.xhh.creditpre.cashloan.dao.CreditApplyRecordMapper;
import com.xhh.creditpre.cashloan.model.CreditApplyRecord;
import com.xhh.creditpre.cashloan.service.remote.CreditAwardRemoteService;
import com.xhh.creditpre.cashloan.service.remote.PolarisRemoteService;
import com.xhh.polaris.enums.AuthDataType;

/**
 * CreditApplyRecord服务类
 *
 * @author jan
 * @date 2018-1-15 13:48:10
 */
@Service("creditApplyRecordService")
public class CreditApplyRecordService {
    @Resource
    private CreditApplyRecordMapper  creditApplyRecordMapper;

    @Resource
    private CreditAwardRemoteService creditAwardRemoteService;
    @Resource
    private PolarisRemoteService     polarisRemoteService;

    /**
     * 根据id查询数据
     * 
     * @param id 实体id
     * @return 实体
     */
    public CreditApplyRecord queryDataById(long id) {
        return null;
    }

    /**
     * 新增数据
     * 
     * @param record 实体
     */
    public void addData(CreditApplyRecord record) {

        creditApplyRecordMapper.insertSelective(record);
    }

    /**
     * 修改数据认证数据
     * 
     * @param record 实体
     */
    public void modifyAuthStatus(CreditApplyRecord record) {
        creditApplyRecordMapper.updateAuthStatus(record);
    }

    /**
     * 删除数据
     * 
     * @param record 实体
     */
    public void deleteData(CreditApplyRecord record) {

    }

    /**
     * 根据授信号查询授信记录
     *
     * @param creditAwardNo
     * @return
     */
    public CreditApplyRecord queryDataByCreditAwardNo(String creditAwardNo) {
        CreditApplyRecord queryRecord = new CreditApplyRecord();
        queryRecord.setCreditAwardNo(creditAwardNo);
        return Optional.ofNullable(creditApplyRecordMapper.queryDataByCreditAwardNo(creditAwardNo)).map(applyRecord -> {
            if (applyRecord.getIsZmxyAuth() == 2) {
                Optional.ofNullable(polarisRemoteService.queryDataAuth(AuthDataType.ZMXY, creditAwardNo)).ifPresent(authResultDto -> {
                    if (authResultDto.getCode() == 1) {
                        updateZmxyStatusByCreditAwardNo(creditAwardNo, 1);
                        applyRecord.setIsZmxyAuth(1);
                    }
                });
            }
            return applyRecord;
        }).orElse(null);
    }

    @Transactional(rollbackFor = Exception.class, timeout = 30)
    public void updateByCreditAwardNo(CreditApplyRecord creditApplyRecord) {
        creditApplyRecordMapper.updateByCreditAwardNo(creditApplyRecord);
    }

    public void updateZmxyStatusByCreditAwardNo(String creditAwardNo, Integer status) {
        CreditApplyRecord record = new CreditApplyRecord();
        record.setIsZmxyAuth(status);
        record.setZmxyAuthTime(new Date());
        record.setGmtModified(new Date());
        record.setCreditAwardNo(creditAwardNo);
        creditApplyRecordMapper.updateZmxyStatusByCreditAwardNo(record);
    }

}
