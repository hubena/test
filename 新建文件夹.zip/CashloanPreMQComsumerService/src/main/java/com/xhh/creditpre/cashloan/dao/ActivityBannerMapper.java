package com.xhh.creditpre.cashloan.dao;

import com.xhh.creditpre.cashloan.dto.ActivityBannerRequest;
import com.xhh.creditpre.cashloan.model.AppActivityBanner;
import org.apache.ibatis.session.RowBounds;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ActivityBannerMapper {
    int deleteByPrimaryKey(Long id);

    int insert(AppActivityBanner record);

    int insertSelective(AppActivityBanner record);

    AppActivityBanner selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(AppActivityBanner record);

    int updateByPrimaryKey(AppActivityBanner record);

    List<AppActivityBanner> list(AppActivityBanner appActivityBanner);

    List<AppActivityBanner> queryActivityBannerByPage(ActivityBannerRequest request, RowBounds rowBounds);
}
