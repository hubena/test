package com.xhh.creditpre.cashloan.api;

import com.janty.core.dto.PageData;
import com.janty.core.dto.Pager;
import com.janty.core.util.CommonBeanCopier;
import com.janty.core.util.ExceptionUtil;
import com.janty.core.util.ValidateUtil;
import com.xhh.creditpre.cashloan.dto.ActivityBannerAddRequest;
import com.xhh.creditpre.cashloan.dto.ActivityBannerDto;
import com.xhh.creditpre.cashloan.dto.ActivityBannerRequest;
import com.xhh.creditpre.cashloan.dto.ActivityBannerUpdateRequest;
import com.xhh.creditpre.cashloan.model.AppActivityBanner;
import com.xhh.creditpre.cashloan.service.AppActivityBannerService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;

@Service
public class ActivityBannerApi implements IActivityBannerApi {
    Logger                   logger = LoggerFactory.getLogger(ActivityBannerApi.class);
    @Resource
    AppActivityBannerService appActivityBannerService;

    @Override
    public PageData<ActivityBannerDto> queryActivityBannerByPage(ActivityBannerRequest request, Pager pager) {
        logger.info("ActivityBannerApi-queryActivityBannerByPage-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);
        PageData<ActivityBannerDto> result = null;
        try {
            ValidateUtil.validate(request);
            result = appActivityBannerService.queryActivityBannerByPage(request, pager);
        } catch (Exception e) {
            logger.error("ActivityBannerApi-queryActivityBannerByPage-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            throw e;
        }
        logger.info("ActivityBannerApi-queryActivityBannerByPage-请求结束, reqNo-{}-返回-{}", request.getReqNo(), result);
        return result;
    }

    @Override
    public Boolean addActivityBanner(ActivityBannerAddRequest request) {
        logger.info("ActivityBannerApi-addActivityBanner-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);
        AppActivityBanner activityBanner = new AppActivityBanner();
        Boolean result = false;
        try {
            CommonBeanCopier.copy(request, activityBanner);
            Date date = new Date();
            activityBanner.setGmtCreated(date);
            activityBanner.setGmtModified(date);
            appActivityBannerService.addData(activityBanner);
            result = true;
        } catch (Exception e) {
            logger.error("ActivityBannerApi-addActivityBanner-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            throw e;
        }
        logger.info("ActivityBannerApi-addActivityBanner-请求结束, reqNo-{}-返回-{}", request.getReqNo(), result);
        return result;
    }

    @Override
    public Boolean updateActivityBanner(ActivityBannerUpdateRequest request) {
        logger.info("ActivityBannerApi-updateActivityBanner-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);
        AppActivityBanner activityBanner = new AppActivityBanner();
        Boolean result = false;
        try {
            CommonBeanCopier.copy(request, activityBanner);
            Date date = new Date();
            activityBanner.setGmtModified(date);
            appActivityBannerService.modifyData(activityBanner);
            result = true;
        } catch (Exception e) {
            logger.error("ActivityBannerApi-updateActivityBanner-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            throw e;
        }
        logger.info("ActivityBannerApi-updateActivityBanner-请求结束, reqNo-{}-返回-{}", request.getReqNo(), result);
        return result;
    }

    @Override
    public Boolean removeActivityBanner(Long id) {
        logger.info("ActivityBannerApi-removeActivityBanner-请求开始, 请求参数-{}", id);
        Boolean result = false;
        try {
            appActivityBannerService.deleteData(id);
            result = true;
        } catch (Exception e) {
            logger.error("ActivityBannerApi-updateActivityBanner-请求异常, {}", ExceptionUtil.getType(e), e);
            throw e;
        }
        logger.info("ActivityBannerApi-updateActivityBanner-请求结束, 返回-{}", result);
        return result;
    }
}
