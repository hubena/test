package com.xhh.creditpre.cashloan.model;

import com.janty.core.dto.BaseRequest;

import javax.validation.constraints.NotNull;

/**
 * @author zhangliang
 * @Date:Create in 2018/2/7
 */
public class BankCardbinRequest extends BaseRequest {

    @NotNull(message = "银行卡号不能为空")
    private String cardNo;

    public String getCardNo() {
        return cardNo;
    }

    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }
}
