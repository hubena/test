package com.xhh.creditpre.cashloan.model;

import com.janty.core.dto.BaseModel;

public class ZmAuthResultDto extends BaseModel {
    /**
     * 
     */
    private static final long serialVersionUID = 7321841594066550299L;
    /**
     * 链接
     */
    private String            authUrl;

    public String getAuthUrl() {
        return authUrl;
    }

    public void setAuthUrl(String authUrl) {
        this.authUrl = authUrl;
    }

}
