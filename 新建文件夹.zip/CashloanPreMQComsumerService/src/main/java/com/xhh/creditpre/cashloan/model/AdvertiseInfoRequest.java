package com.xhh.creditpre.cashloan.model;

import com.janty.core.dto.BaseRequest;

import java.util.Date;

public class AdvertiseInfoRequest extends BaseRequest {

    /**
     * 主键ID
     */
    private Long id;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
