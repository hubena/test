package com.xhh.creditpre.cashloan.constant;

/**
 * redis key
 */
public interface CashloanRedisKey {

    /**
     * 用户（hash）
     */
    String login_user                = "creditloan_cashloan_login_user";

    /**
     * 判断发短信前缀
     */
    String judge_send_message_prefix = "creditpre_cashloan_judge_send_message_";

    /**
     * 注册发送验证码短信
     */
    String send_sms_register         = "send_sms_register";

    /**
     * 修改密码发送验证码短信
     */
    String send_sms_modify_password  = "send_sms_modify_password";

    /**
     * 缓存短信验证码信息
     */
    String send_sms_cache            = "send_sms_cache";
}
