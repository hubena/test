package com.xhh.creditpre.cashloan.model;

import com.janty.core.dto.BaseModel;

import java.util.List;

/**
 * @author zhangliang
 * @Date:Create in 2018/1/31
 */
public class LoanConfigDto extends BaseModel {

    private List<LoanAmountConfigDto> loanAmountConfigDtoList;

    private List<LoanTermConfigDto>   loanTermConfigDtoList;

    public List<LoanAmountConfigDto> getLoanAmountConfigDtoList() {
        return loanAmountConfigDtoList;
    }

    public void setLoanAmountConfigDtoList(List<LoanAmountConfigDto> loanAmountConfigDtoList) {
        this.loanAmountConfigDtoList = loanAmountConfigDtoList;
    }

    public List<LoanTermConfigDto> getLoanTermConfigDtoList() {
        return loanTermConfigDtoList;
    }

    public void setLoanTermConfigDtoList(List<LoanTermConfigDto> loanTermConfigDtoList) {
        this.loanTermConfigDtoList = loanTermConfigDtoList;
    }
}
