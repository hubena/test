package com.xhh.creditpre.cashloan.converter;

import com.janty.core.util.CommonBeanCopier;
import com.xhh.creditpre.cashloan.dto.AppVersionDto;
import com.xhh.creditpre.cashloan.model.AppActivityBanner;
import com.xhh.creditpre.cashloan.model.AppActivityBannerDto;
import com.xhh.creditpre.cashloan.model.AppVersion;

import java.util.ArrayList;
import java.util.List;

public class AppConverter {
    /**
     * to AppVersionDto
     *
     * @param appVersionList
     * @return
     */
    public static List<AppVersionDto> toAppVerNoDto(List<AppVersion> appVersionList) {
        List<AppVersionDto> appVersionDtoList = new ArrayList<AppVersionDto>();
        for (AppVersion appVersion : appVersionList) {
            AppVersionDto obj = new AppVersionDto();
            CommonBeanCopier.copy(appVersion, obj);
            appVersionDtoList.add(obj);
        }
        return appVersionDtoList;
    }

    /**
     * to ActivityPicDTO
     *
     * @param appActivityPicList
     * @return
     */
    public static List<AppActivityBannerDto> toAppActivityBannerDto(List<AppActivityBanner> appActivityPicList) {
        List<AppActivityBannerDto> activityPicDTOList = new ArrayList<AppActivityBannerDto>();
        for (AppActivityBanner appActivityPic : appActivityPicList) {
            AppActivityBannerDto obj = new AppActivityBannerDto();
            CommonBeanCopier.copy(appActivityPic, obj);
            activityPicDTOList.add(obj);
        }

        return activityPicDTOList;
    }
}
