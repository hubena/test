package com.xhh.creditpre.cashloan.service;

import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.janty.core.exception.SystemException;
import com.xhh.creditpre.cashloan.bean.JudgeSendMessage;
import com.xhh.creditpre.cashloan.constant.CashLoanConstant;
import com.xhh.creditpre.cashloan.constant.CashloanErrorCode;
import com.xhh.creditpre.cashloan.constant.CashloanRedisKey;
import com.xhh.creditpre.cashloan.service.remote.MessageCenterRemoteService;
import com.xhh.creditpre.cashloan.service.remote.ProductRemoteService;
import com.xhh.infrastructure.messagecenter.dto.SendSmsMessageRequest;

import net.sf.json.JSONObject;

@Service("sendMessageService")
public class SendMessageService {

    @Resource
    private ProductRemoteService       productRemoteService;

    @Resource
    private MessageCenterRemoteService messageCenterRemoteService;

    public void sendMessageWhenRegister(SendSmsMessageRequest request) {
        String productCode = CashLoanConstant.product_code;
        String configKey = CashloanRedisKey.send_sms_register;
        JudgeSendMessage judge = getJudge(request.getReqNo(), configKey, productCode);
        sendMessage(judge, request, false);
    }

    public void sendMessageWhenModifyPassword(SendSmsMessageRequest request) {
        String productCode = CashLoanConstant.product_code;
        String configKey = CashloanRedisKey.send_sms_modify_password;
        JudgeSendMessage judge = getJudge(request.getReqNo(), configKey, productCode);
        sendMessage(judge, request, false);
    }

    private void sendMessage(JudgeSendMessage judge, SendSmsMessageRequest request, boolean needJudge) {
        if (needJudge && (!judge.isNeedSend())) {
            return;
        }
        request.setSmsTemplateId(new Long(judge.getTemplateId()));
        messageCenterRemoteService.sendSms(request);
    }

    private JudgeSendMessage getJudge(String reqNo, String configKey, String productCode) {
        JudgeSendMessage judge = null;
        Map<String, String> map = productRemoteService.queryByConfigsProductCode(reqNo, productCode);
        String configValue = null;
        for (Map.Entry<String, String> entry : map.entrySet()) {
            if (configKey.equals(entry.getKey())) {
                configValue = entry.getValue();
            }
        }
        if (configValue == null || configValue == "") {
            throw new SystemException(CashloanErrorCode.Element.s_product_config_send_message_no_not_exist.getMessage());
        }
        judge = assembleJudge(configValue);
        if (judge == null || judge.getTemplateId() == null) {
            throw new SystemException(CashloanErrorCode.Element.s_product_config_send_message_data_exception.getMessage());
        }
        return judge;
    }

    private JudgeSendMessage assembleJudge(String configValue) {
        JSONObject jsonObject = JSONObject.fromObject(configValue);
        JudgeSendMessage judge = (JudgeSendMessage) JSONObject.toBean(jsonObject, JudgeSendMessage.class);
        return judge;
    }

    /*
     * private void sendMessage(JudgeSendMessage judge, SendSmsMessageRequest
     * request) { sendMessage(judge, request, true); }
     */

}
