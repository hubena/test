package com.xhh.creditpre.cashloan.service;

import com.xhh.creditpre.cashloan.dao.UserLoginRecordMapper;
import com.xhh.creditpre.cashloan.model.UserLoginRecord;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * UserLoginRecord服务类
 * 
 * @author jan
 * @date 2018-2-28 16:30:17
 */
@Service("userLoginRecordService")
public class UserLoginRecordService {
    @Resource
    private UserLoginRecordMapper userLoginRecordMapper;
    
    
    /**
	 * 根据id查询数据
	 * @param id         实体id
	 * @return           实体
	 */
    public UserLoginRecord queryDataById(long id){
    	return null;    
    }
    /**
	 * 新增数据
	 * @param record  实体
	 */
    public void addData(UserLoginRecord record){
    
    }
    /**
	 * 修改数据
	 * @param record  实体
	 */
    public void modifyData(UserLoginRecord record){
    
    }
    /**
	 * 删除数据
	 * @param record  实体
	 */
    public void deleteData(UserLoginRecord record){
    
    }

    public List<UserLoginRecord> selectAllLoginRecord(){
        return userLoginRecordMapper.selectAllLoginRecord();
    }

    public void insertLoginRecord(UserLoginRecord userLoginRecord) {
        UserLoginRecord loginRecord = userLoginRecordMapper.selectByUserId(userLoginRecord.getUserId());
        if(loginRecord == null){
            userLoginRecordMapper.insertSelective(userLoginRecord);
        }else {
            userLoginRecord.setId(loginRecord.getId());
            userLoginRecordMapper.updateByPrimaryKeySelective(userLoginRecord);
        }
    }

    public UserLoginRecord selectByUserId(Long userId) {
        return userLoginRecordMapper.selectByUserId(userId);
    }
}
