package com.xhh.creditpre.cashloan.service;

import java.util.Date;

import javax.annotation.Resource;

import com.janty.core.exception.BusinessException;
import com.xhh.creditcore.transaction.dto.*;
import com.xhh.creditpre.cashloan.constant.CashloanErrorCode;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.janty.core.util.CommonBeanCopier;
import com.xhh.creditcore.capital.dto.BankCardbinDto;
import com.xhh.creditcore.capital.dto.QueryBankCardbinRequest;
import com.xhh.creditpre.cashloan.constant.CashLoanConstant;
import com.xhh.creditpre.cashloan.enums.CreditAwardRecordStatus;
import com.xhh.creditpre.cashloan.model.AuthDataRequest;
import com.xhh.creditpre.cashloan.model.CreditApplyRecord;
import com.xhh.creditpre.cashloan.model.CreditZmxyAuthRequest;
import com.xhh.creditpre.cashloan.model.PreBindBankRequest;
import com.xhh.creditpre.cashloan.model.PreFaceRequest;
import com.xhh.creditpre.cashloan.model.PreOcrRecognizeRequest;
import com.xhh.creditpre.cashloan.model.UserDto;
import com.xhh.creditpre.cashloan.service.remote.CapitalRemoteService;
import com.xhh.creditpre.cashloan.service.remote.CreditAwardRemoteService;
import com.xhh.creditpre.cashloan.service.remote.PolarisRemoteService;
import com.xhh.polaris.dto.CreditDataAuthResultDto;
import com.xhh.polaris.dto.OCRRecognizeRequest;
import com.xhh.polaris.dto.OCRResultDto;
import com.xhh.polaris.enums.AuthDataType;
import com.xhh.polaris.enums.OCRType;

/**
 * author zhangliang 授信service
 * 
 * @Date:Create in 2018/1/19
 */
@Service("creditAwardService")
public class CreditAwardService {

    @Resource
    private CreditAwardRemoteService creditAwardRemoteService;

    @Resource
    private CreditApplyRecordService creditApplyRecordService;

    @Resource
    private PolarisRemoteService     polarisRemoteService;

    @Resource
    private CapitalRemoteService     capitalRemoteService;

    /**
     * 鉴权绑卡
     * 
     * @param request
     * @return
     */
    public void bindBank(PreBindBankRequest request, UserDto userDto) {
        BindBankRequest bindBankRequest = new BindBankRequest();
        CommonBeanCopier.copy(request, bindBankRequest);
        bindBankRequest.setAccountId(userDto.getProdAccountId());
        bindBankRequest.setProductCode(CashLoanConstant.product_code);
        creditAwardRemoteService.bindBank(bindBankRequest);
        CreditApplyRecord creditApplyRecord = new CreditApplyRecord();
        creditApplyRecord.setCreditAwardNo(request.getCreditAwardNo());
        creditApplyRecord.setBindBankTime(new Date());
        creditApplyRecord.setGmtModified(new Date());
        creditApplyRecord.setIsBindBank(CreditAwardRecordStatus.auth_success.getKey());
        creditApplyRecordService.updateByCreditAwardNo(creditApplyRecord);
    }

    /**
     * 人脸识别
     * 
     * @param request
     * @return
     */
    public void faceRecognize(PreFaceRequest request, UserDto userDto) {
        com.xhh.creditcore.transaction.dto.FaceRequest faceRequest = new com.xhh.creditcore.transaction.dto.FaceRequest();
        CommonBeanCopier.copy(request, faceRequest);
        faceRequest.setAccountId(userDto.getProdAccountId());
        faceRequest.setProductCode(CashLoanConstant.product_code);
        //调用人脸识别服务
        creditAwardRemoteService.faceRecognize(faceRequest);
        CreditApplyRecord creditApplyRecord = new CreditApplyRecord();
        creditApplyRecord.setIsFaceAuth(CreditAwardRecordStatus.auth_success.getKey());
        creditApplyRecord.setCreditAwardNo(request.getCreditAwardNo());
        creditApplyRecord.setFaceAuthTime(new Date());
        creditApplyRecord.setGmtModified(new Date());
        //更新授信记录
        creditApplyRecordService.updateByCreditAwardNo(creditApplyRecord);
    }

    /**
     * 授信申请
     * 
     * @param userDto
     * @return
     */
    public CreditAwardApplyDto creditAwardApply(UserDto userDto) {
        CreditAwardApplyRequest request = new CreditAwardApplyRequest();
        request.setAccountId(userDto.getProdAccountId());
        request.setProductCode(CashLoanConstant.product_code);
        CreditAwardApplyDto creditAwardApplyDto = creditAwardRemoteService.creditAwardApply(request);
        if (creditAwardApplyDto != null && !StringUtils.isEmpty(creditAwardApplyDto.getCreditAwardNo())) {
            //判断记录是否存在
            CreditApplyRecord existData = creditApplyRecordService.queryDataByCreditAwardNo(creditAwardApplyDto.getCreditAwardNo());
            if (existData == null) {
                CreditApplyRecord record = new CreditApplyRecord();
                record.setUserId(userDto.getId());
                record.setProdAccountId(userDto.getProdAccountId());
                record.setCreditAwardNo(creditAwardApplyDto.getCreditAwardNo());
                record.setGmtCreated(new Date());
                creditApplyRecordService.addData(record);
            }
        }
        return creditAwardApplyDto;

    }

    /**
     * 授信
     * 
     * @param request
     * @param userDto
     * @return
     */
    public CreditAwardDto creditAward(CreditAwardRequest request, UserDto userDto) {
        request.setAccountId(userDto.getProdAccountId());
        return creditAwardRemoteService.creditAward(request);
    }
    
    /**
     * 提额
     * 
     * @param request
     * @param userDto
     * @return
     */
    public void raiseQuota(CreditAwardRaiseQuotaRequest request, UserDto userDto) {
        request.setAccountId(userDto.getProdAccountId());
        creditAwardRemoteService.raiseQuota(request);
    }

    /**
     * 授信数据认证
     * 
     * @param request
     */
    public void creditDataAuth(AuthDataRequest request) {
        CreditDataAuthResultDto result = polarisRemoteService.creditDataAuth(request);
        CreditApplyRecord record = new CreditApplyRecord();
        record.setCreditAwardNo(request.getCreditAwardNo());
        if (result != null && 1 == result.getCode()) {
            // 认证成功 1-成功，2-失败
            AuthDataType authType = AuthDataType.getByKey(request.getAuthDataType());
            switch (authType) {
                case ALIPAY:
                    record.setIsAlipayAuth(1);
                    record.setAlipayAuthTime(new Date());
                    break;
                case JD:
                    record.setIsJdAuth(1);
                    record.setJdAuthTime(new Date());
                    break;
                case HFUND:
                    record.setIsReservedFundsAuth(1);
                    record.setReservedFundsAuthTime(new Date());
                    break;
                case MOBILE:
                    record.setIsMobileAuth(1);
                    record.setMobileAuthTime(new Date());
                    break;
                case TB:
                    record.setIsTbAuth(1);
                    record.setTbAuthTime(new Date());
                    break;
                case SHEBAO:
                    record.setIsSocialSecurityAuth(1);
                    record.setSocialSecurityAuthTime(new Date());
                    break;
                case ZMXY:
                    record.setIsZmxyAuth(1);
                    record.setZmxyAuthTime(new Date());
                    break;
                case TXL:
                    record.setIsAdsbookAuth(1);
                    record.setAdsbookAuthTime(new Date());
                    break;
                case CHSI:
                    record.setIsChsiAuth(1);
                    record.setChsiAuthTime(new Date());
                    break;
                default:
                    break;
            }
        }
        creditApplyRecordService.modifyAuthStatus(record);
    }

    /**
     * 芝麻信用认证
     *
     * @param request
     * @return
     */
    public String creditZmxyAuth(CreditZmxyAuthRequest request) {
        return polarisRemoteService.zmxyAuth(request);
    }

    /**
     * ocr识别（身份证/银行卡）
     * 
     * @param request
     * @return
     */
    public OCRResultDto ocrRecognize(PreOcrRecognizeRequest request) {
        OCRRecognizeRequest ocrRecognizeRequest = new OCRRecognizeRequest();
        ocrRecognizeRequest.setReqNo(request.getReqNo());
        ocrRecognizeRequest.setImgBase64(request.getImgBase64());
        //判断传的是哪种图片的值
        if (request.getOcrType().equals(OCRType.IDCARD_F.getCode())) {
            ocrRecognizeRequest.setOcrType(OCRType.IDCARD_F);
        } else if (request.getOcrType().equals(OCRType.IDCARD_B.getCode())) {
            ocrRecognizeRequest.setOcrType(OCRType.IDCARD_B);
        } else if (request.getOcrType().equals(OCRType.BANKCARD.getCode())) {
            ocrRecognizeRequest.setOcrType(OCRType.BANKCARD);
        }
        //调用远程ocr
        OCRResultDto ocrResultDto = polarisRemoteService.ocrRecognize(ocrRecognizeRequest);
        if (request.getOcrType().equals(OCRType.BANKCARD.getCode())) {
            //查询卡bin
            QueryBankCardbinRequest queryBankCardbinRequest = new QueryBankCardbinRequest();
            queryBankCardbinRequest.setReqNo(request.getReqNo());
            queryBankCardbinRequest.setCardNo(ocrResultDto.getBankInfoDto().getCardNo());
            BankCardbinDto bankCardbinDto = capitalRemoteService.queryBankCardbin(queryBankCardbinRequest);
            if (bankCardbinDto == null)
                throw new BusinessException(new CashloanErrorCode(CashloanErrorCode.Element.b_ocr_recognize_bank_fail));
            ocrResultDto.getBankInfoDto().setBankName(bankCardbinDto.getBankName());
            ocrResultDto.getBankInfoDto().setBankCode(bankCardbinDto.getBankCode());
            ocrResultDto.getBankInfoDto().setCardType(bankCardbinDto.getCardType());
        }
        return ocrResultDto;
    }

    public void updateCreditAwardInfo(CreditAwardInfoRequest request) {
        //更新个人信息
        creditAwardRemoteService.updateCreditAwardInfo(request);
        //更新成功，修改个人信息认证标志
        CreditApplyRecord record = new CreditApplyRecord();
        record.setCreditAwardNo(request.getCreditAwardNo());
        record.setIsPersonInfoSubmit(1);
        record.setPersonInfoSubmitTime(new Date());
        record.setGmtModified(new Date());
        creditApplyRecordService.modifyAuthStatus(record);
    }
}
