package com.xhh.creditpre.cashloan.service;

import javax.annotation.Resource;

import com.janty.core.util.CommonBeanCopier;
import com.xhh.creditpre.cashloan.model.LoanTermConfigDto;
import org.springframework.stereotype.Service;

import com.xhh.creditpre.cashloan.dao.LoanTermConfigMapper;
import com.xhh.creditpre.cashloan.model.LoanTermConfig;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * LoanTermConfig服务类
 * 
 * @author jan
 * @date 2018-1-31 17:01:59
 */
@Service("loanTermConfigService")
public class LoanTermConfigService {
    @Resource
    private LoanTermConfigMapper loanTermConfigMapper;

    /**
     * 根据id查询数据
     * 
     * @param id 实体id
     * @return 实体
     */
    public LoanTermConfig queryDataById(long id) {
        return null;
    }

    /**
     * 新增数据
     * 
     * @param record 实体
     */
    public void addData(LoanTermConfig record) {

    }

    /**
     * 修改数据
     * 
     * @param record 实体
     */
    public void modifyData(LoanTermConfig record) {

    }

    /**
     * 删除数据
     * 
     * @param record 实体
     */
    public void deleteData(LoanTermConfig record) {

    }

    public List<LoanTermConfigDto> queryByAmountType(Integer amountType) {
        List<LoanTermConfig> list = loanTermConfigMapper.queryByAmountType(amountType);
        List<LoanTermConfigDto> loanAmountConfigDtolist = null;
        LoanTermConfigDto dto = null;
        if (!CollectionUtils.isEmpty(list)) {
            loanAmountConfigDtolist = new ArrayList<>();
            for (LoanTermConfig loanAmountConfig : list) {
                dto = new LoanTermConfigDto();
                CommonBeanCopier.copy(loanAmountConfig, dto);
                loanAmountConfigDtolist.add(dto);
            }
        }
        return loanAmountConfigDtolist;
    }
}
