package com.xhh.creditpre.cashloan.model;

import javax.validation.constraints.NotNull;

/**
 * author zhangliang
 *
 * @Date:Create in 2018/1/12
 */
public class RealNameAuthRequest extends PreBaseRequest {

    @NotNull(message = "产品账户不能为空")
    private String accountId;

    @NotNull(message = "授信号不能为空")
    private String creditAwardNo;

    @NotNull(message = "真实姓名不能为空")
    private String realName;

    @NotNull(message = "身份证号不能为空")
    private String credentialNo;

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getCreditAwardNo() {
        return creditAwardNo;
    }

    public void setCreditAwardNo(String creditAwardNo) {
        this.creditAwardNo = creditAwardNo;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public String getCredentialNo() {
        return credentialNo;
    }

    public void setCredentialNo(String credentialNo) {
        this.credentialNo = credentialNo;
    }
}
