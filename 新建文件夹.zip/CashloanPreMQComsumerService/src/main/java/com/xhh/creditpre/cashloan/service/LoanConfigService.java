package com.xhh.creditpre.cashloan.service;

import com.janty.core.exception.SystemException;
import com.xhh.creditpre.cashloan.constant.CashloanErrorCode;
import com.xhh.creditpre.cashloan.model.LoanAmountConfigDto;
import com.xhh.creditpre.cashloan.model.LoanConfigDto;
import com.xhh.creditpre.cashloan.model.LoanConfigRequest;
import com.xhh.creditpre.cashloan.model.LoanTermConfigDto;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author zhangliang
 * @Date:Create in 2018/1/31
 */
@Service("loanConfigService")
public class LoanConfigService {

    @Resource
    private LoanAmountConfigService loanAmountConfigService;

    @Resource
    private LoanTermConfigService   loanTermConfigService;

    public LoanConfigDto queryLoanConfig(LoanConfigRequest request) {
        //查询金额配置
        List<LoanAmountConfigDto> loanAmountConfigDtoList = loanAmountConfigService.queryByAmountType(request.getAmountType());
        //查询期限配置
        List<LoanTermConfigDto> loanTermConfigDtoList = loanTermConfigService.queryByAmountType(request.getAmountType());
        //二者其一为空则抛异常
        if (CollectionUtils.isEmpty(loanAmountConfigDtoList) || CollectionUtils.isEmpty(loanTermConfigDtoList))
            throw new SystemException(new CashloanErrorCode(CashloanErrorCode.Element.s_loan_config_not_exist));
        LoanConfigDto result = new LoanConfigDto();
        result.setLoanAmountConfigDtoList(loanAmountConfigDtoList);
        result.setLoanTermConfigDtoList(loanTermConfigDtoList);
        return result;
    }
}
