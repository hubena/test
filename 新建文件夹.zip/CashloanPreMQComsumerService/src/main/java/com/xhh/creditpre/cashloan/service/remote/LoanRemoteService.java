package com.xhh.creditpre.cashloan.service.remote;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.janty.core.dto.PageData;
import com.janty.core.dto.Pager;
import com.janty.core.util.BaseRemoteService;
import com.xhh.creditcore.capital.api.ILoanTrialApi;
import com.xhh.creditcore.capital.dto.CapitalLoanRequest;
import com.xhh.creditcore.capital.dto.LoanTrialDto;
import com.xhh.creditcore.transaction.api.ILoanApi;
import com.xhh.creditcore.transaction.dto.LoanOrderDto;
import com.xhh.creditcore.transaction.dto.LoanQueryRequest;
import com.xhh.creditcore.transaction.dto.LoanRequest;
import com.xhh.creditpre.cashloan.constant.CashloanErrorCode;

/**
 * 类LoanTrialRemoteService.java的实现描述：TODO 类实现描述
 * 
 * @author xiehuang 2018年1月19日 上午11:01:56
 */
@Service("loanRemoteService")
public class LoanRemoteService extends BaseRemoteService {
    @Resource
    private ILoanTrialApi loanTrialApi;
    @Resource
    private ILoanApi      loanApi;

    /**
     * 借款试算
     * 
     * @param request
     * @return
     */
    public LoanTrialDto loanTrail(CapitalLoanRequest request) {
        try {
            return loanTrialApi.loanTrail(request);
        } catch (Exception e) {
            return processException(e, new CashloanErrorCode(CashloanErrorCode.Element.r_loan_trail_remote_fail));
        }
    }

    /**
     * 借款
     * 
     * @param request
     * @return
     */
    public LoanOrderDto loan(LoanRequest request) {
        try {
            return loanApi.loan(request);
        } catch (Exception e) {
            return processException(e, new CashloanErrorCode(CashloanErrorCode.Element.r_transaction_remote_fail));
        }
    }
    /**
     * 借款
     * 
     * @param request
     * @return
     */
    public void advanceLoan(LoanRequest request) {
        try {
            loanApi.advanceLoan(request);
        } catch (Exception e) {
            processException(e, new CashloanErrorCode(CashloanErrorCode.Element.r_transaction_remote_fail));
        }
    }

    /**
     * 根据条件分页查询借款
     * 
     * @param request
     * @param pager
     * @return
     */
    public PageData<LoanOrderDto> queryByConditionOfPage(LoanQueryRequest request, Pager pager) {
        try {
            return loanApi.queryByConditionOfPage(request, pager);
        } catch (Exception e) {
            return processException(e, new CashloanErrorCode(CashloanErrorCode.Element.r_transaction_remote_fail));
        }
    }
}
