package com.xhh.creditpre.cashloan.service.remote;

import com.google.common.collect.Lists;
import com.janty.core.util.BaseRemoteService;
import com.janty.core.util.CommonBeanCopier;
import com.xhh.creditcore.transaction.api.IRepaymentApi;
import com.xhh.creditcore.transaction.dto.*;
import com.xhh.creditpre.cashloan.constant.CashLoanConstant;
import com.xhh.creditpre.cashloan.constant.CashloanErrorCode;
import com.xhh.creditpre.cashloan.model.*;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * author zhangweixin
 *
 * @Date:Create in 2018/1/12
 */
@Service("repaymentRemoteService")
public class RepaymentRemoteService extends BaseRemoteService {

    @Resource
    private IRepaymentApi repaymentApi;

    /**
     * 查询还款计划
     * 
     * @param request
     * @return
     */
    public List<RepayPlanQueryDto> queryRepayPlan(RepayPlanQueryRequest request) {
        try {
            AccountRepayPlanQueryRequest transQueryRequest = new AccountRepayPlanQueryRequest();
            transQueryRequest.setAccountId(request.getAccountId());
            transQueryRequest.setLoanOrderNo(request.getLoanOrderNo());
            transQueryRequest.setProductCode(CashLoanConstant.product_code);
            transQueryRequest.setReqNo(request.getReqNo());
            List<AccountRepayPlanQueryDto> transQueryDtos = repaymentApi.queryAccountRepayPlan(transQueryRequest);
            List<RepayPlanQueryDto> repayPlanQueryDtos = Lists.newArrayList();
            for (AccountRepayPlanQueryDto transQueryDto : transQueryDtos) {
                RepayPlanQueryDto repayPlanQueryDto = new RepayPlanQueryDto();
                CommonBeanCopier.copy(transQueryDto, repayPlanQueryDto);
                repayPlanQueryDto.setLoanTransNo(request.getLoanOrderNo());
                repayPlanQueryDtos.add(repayPlanQueryDto);
            }
            return repayPlanQueryDtos;
        } catch (Exception e) {
            return processException(e, new CashloanErrorCode(CashloanErrorCode.Element.r_repayment_remote_fail));

        }
    }

    /**
     * 认证支付还款预还款(发送验证码)
     * 
     * @param request
     * @return
     */
    public TransRepaymentDto repayPrePay(PeriodRepayPreRequest request) {
        try {
            TransRepaymentPreRequest repaymentPreRequest = new TransRepaymentPreRequest();
            CommonBeanCopier.copy(request, repaymentPreRequest);
            repaymentPreRequest.setProductCode(CashLoanConstant.product_code);
            return repaymentApi.certPayRepaymentPrePay(repaymentPreRequest);
        } catch (Exception e) {
            return processException(e, new CashloanErrorCode(CashloanErrorCode.Element.r_repayment_remote_fail));
        }
    }

    /**
     * 认证支付确认还款
     * 
     * @param request
     * @return
     */
    public TransRepaymentDto repayConfirmPay(PeriodRepayConfirmRequest request) {
        try {
            TransRepaymentConfirmRequest repaymentConfirmRequest = new TransRepaymentConfirmRequest();
            CommonBeanCopier.copy(request, repaymentConfirmRequest);
            return repaymentApi.certPayRepaymentConfirmPay(repaymentConfirmRequest);
        } catch (Exception e) {
            return processException(e, new CashloanErrorCode(CashloanErrorCode.Element.r_repayment_remote_fail));
        }
    }

    /**
     * 认证支付重发短信验证码
     * 
     * @param request
     * @return
     */
    public TransRepaymentDto repaySendSms(PeriodRepaySendSmsRequest request) {
        try {
            TransRepaymentSendSmsRequest repaymentSendSmsRequest = new TransRepaymentSendSmsRequest();
            CommonBeanCopier.copy(request, repaymentSendSmsRequest);
            return repaymentApi.certPayRepaymentSendSms(repaymentSendSmsRequest);
        } catch (Exception e) {
            return processException(e, new CashloanErrorCode(CashloanErrorCode.Element.r_repayment_remote_fail));
        }
    }

}
