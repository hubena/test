package com.xhh.creditpre.cashloan.model;

import com.janty.core.dto.BaseRequest;

/**
 * author zhangliang
 *
 * @Date:Create in 2018/1/16
 */
public class ProductChannelRequest extends BaseRequest {

    private String productCode;

    private String channelCode;

    private String channelName;

    private String remark;

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getChannelCode() {
        return channelCode;
    }

    public void setChannelCode(String channelCode) {
        this.channelCode = channelCode;
    }

    public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
}
