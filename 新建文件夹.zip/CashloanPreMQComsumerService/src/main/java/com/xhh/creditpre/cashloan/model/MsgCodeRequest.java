package com.xhh.creditpre.cashloan.model;

import com.janty.core.dto.BaseRequest;

import javax.validation.constraints.NotNull;

/**
 * author zhangliang
 *
 * @Date:Create in 2018/1/23
 */
public class MsgCodeRequest extends BaseRequest {

    @NotNull(message = "手机号是必选参数")
    private String  phone;
    @NotNull(message = "短信类型是必选参数")
    private Integer type; //1：注册2.修改密码3、忘记密码

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }
}
