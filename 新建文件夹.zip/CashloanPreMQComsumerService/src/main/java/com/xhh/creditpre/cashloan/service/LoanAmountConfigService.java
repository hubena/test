package com.xhh.creditpre.cashloan.service;

import javax.annotation.Resource;

import com.janty.core.util.CollectionUtil;
import com.janty.core.util.CommonBeanCopier;
import com.xhh.creditpre.cashloan.model.LoanAmountConfigDto;
import org.springframework.stereotype.Service;

import com.xhh.creditpre.cashloan.dao.LoanAmountConfigMapper;
import com.xhh.creditpre.cashloan.model.LoanAmountConfig;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * LoanAmountConfig服务类
 * 
 * @author jan
 * @date 2018-1-31 17:19:31
 */
@Service("loanAmountConfigService")
public class LoanAmountConfigService {
    @Resource
    private LoanAmountConfigMapper loanAmountConfigMapper;

    /**
     * 根据id查询数据
     * 
     * @param id 实体id
     * @return 实体
     */
    public LoanAmountConfig queryDataById(long id) {
        return null;
    }

    /**
     * 新增数据
     * 
     * @param record 实体
     */
    public void addData(LoanAmountConfig record) {

    }

    /**
     * 修改数据
     * 
     * @param record 实体
     */
    public void modifyData(LoanAmountConfig record) {

    }

    /**
     * 删除数据
     * 
     * @param record 实体
     */
    public void deleteData(LoanAmountConfig record) {

    }

    public List<LoanAmountConfigDto> queryByAmountType(Integer amountType) {
        List<LoanAmountConfig> list = loanAmountConfigMapper.queryByAmountType(amountType);
        List<LoanAmountConfigDto> loanAmountConfigDtolist = null;
        LoanAmountConfigDto dto = null;
        if (!CollectionUtils.isEmpty(list)) {
            loanAmountConfigDtolist = new ArrayList<>();
            for (LoanAmountConfig loanAmountConfig : list) {
                dto = new LoanAmountConfigDto();
                CommonBeanCopier.copy(loanAmountConfig, dto);
                loanAmountConfigDtolist.add(dto);
            }
        }
        return loanAmountConfigDtolist;
    }
}
