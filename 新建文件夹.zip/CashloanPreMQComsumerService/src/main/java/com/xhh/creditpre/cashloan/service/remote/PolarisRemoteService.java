package com.xhh.creditpre.cashloan.service.remote;

import java.net.URLDecoder;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.junit.Test;
import org.springframework.stereotype.Service;

import com.janty.core.util.BaseRemoteService;
import com.janty.core.util.CommonBeanCopier;
import com.xhh.creditpre.cashloan.constant.CashloanErrorCode;
import com.xhh.creditpre.cashloan.model.AppDeviceInfoRequest;
import com.xhh.creditpre.cashloan.model.AuthDataRequest;
import com.xhh.creditpre.cashloan.model.CreditZmxyAuthRequest;
import com.xhh.polaris.api.IAuthInfoApi;
import com.xhh.polaris.api.ICollectInfoApi;
import com.xhh.polaris.dto.CreditDataAuthRequest;
import com.xhh.polaris.dto.CreditDataAuthResultDto;
import com.xhh.polaris.dto.DeviceInfoRequest;
import com.xhh.polaris.dto.OCRRecognizeRequest;
import com.xhh.polaris.dto.OCRResultDto;
import com.xhh.polaris.dto.QueryDataAuthRequest;
import com.xhh.polaris.dto.ZmxyAuthRequest;
import com.xhh.polaris.enums.AuthDataType;

/**
 * 类PolarisRemoteService.java的实现描述：polaris远程服务
 * 
 * @author xianghh 2018年1月22日 下午2:18:56
 */
@Service
public class PolarisRemoteService extends BaseRemoteService {

    @Resource
    private IAuthInfoApi    authInfoApi;
    @Resource
    private ICollectInfoApi collectInfoApi;

    /**
     * 授信数据认证
     * 
     * @param request
     * @return
     */
    @Test
    public CreditDataAuthResultDto creditDataAuth(AuthDataRequest request) {
        CreditDataAuthResultDto result = null;
        try {
            // 参数封装
            CreditDataAuthRequest req = new CreditDataAuthRequest();
            req.setReqNo(request.getReqNo());
            req.setAuthDataType(AuthDataType.getByKey(request.getAuthDataType()));
            req.setCreditAwardNo(request.getCreditAwardNo());
            if (StringUtils.isNotBlank(request.getData())) {
                req.setData(URLDecoder.decode(request.getData(), "UTF-8"));
            }
            result = authInfoApi.creditDataAuth(req);
        } catch (Exception e) {
            return processException(e, new CashloanErrorCode(CashloanErrorCode.Element.r_auth_data_remote_fail));
        }

        return result;
    }

    /**
     * 设备信息上传
     * 
     * @param request
     */
    public void uploadDeviceInfo(AppDeviceInfoRequest request) {
        try {
            // 参数转换
            DeviceInfoRequest req = new DeviceInfoRequest();
            req.setReqNo(request.getReqNo());
            req.setCreditAwardNo(request.getCreditAwardNo());
            req.setDeviceInfo(URLDecoder.decode(request.getDeviceInfo(), "UTF-8"));
            collectInfoApi.uploadDeviceInfo(req);
        } catch (Exception e) {
            processException(e, new CashloanErrorCode(CashloanErrorCode.Element.r_upload_deviceinfo_remote_fail));

        }

    }

    /**
     * 芝麻信用认证
     * 
     * @param request
     * @return
     */
    public String zmxyAuth(CreditZmxyAuthRequest request) {
        try {
            // 参数转换
            ZmxyAuthRequest req = new ZmxyAuthRequest();
            CommonBeanCopier.copy(request, req);
            return authInfoApi.zmxyAuth(req);
        } catch (Exception e) {
            return processException(e, new CashloanErrorCode(CashloanErrorCode.Element.r_auth_data_remote_fail));
        }

    }

    public CreditDataAuthResultDto queryDataAuth(AuthDataType dataType, String creditAwardNo) {
        try {
            QueryDataAuthRequest req = new QueryDataAuthRequest();
            req.setAuthDataType(dataType);
            req.setCreditAwardNo(creditAwardNo);
            return authInfoApi.queryCreditDataAuth(req);
        } catch (Exception e) {
            return processException(e, new CashloanErrorCode(CashloanErrorCode.Element.r_auth_data_remote_fail));

        }
    }

    public OCRResultDto ocrRecognize(OCRRecognizeRequest request) {

        try {
            return authInfoApi.ocrRecognize(request);
        } catch (Exception e) {
            return processException(e, new CashloanErrorCode(CashloanErrorCode.Element.r_auth_data_remote_fail));
        }
    }
}
