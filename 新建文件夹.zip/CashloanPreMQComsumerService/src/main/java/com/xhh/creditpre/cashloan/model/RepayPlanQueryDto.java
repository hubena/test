package com.xhh.creditpre.cashloan.model;

import com.alibaba.fastjson.annotation.JSONField;
import com.janty.core.dto.BaseModel;

import java.math.BigDecimal;
import java.util.Date;

public class RepayPlanQueryDto extends BaseModel {
    private Long       accountId;
    private String     loanTransNo;
    private Integer    status;
    private Integer    termNo;
    private Long       id;
    @JSONField(format = "yyyy-MM-dd")
    private Date       agreedRepayDate;
    private Integer    overDueDays;
    private BigDecimal overDuePenalty;
    private BigDecimal originalTotalRepay;
    private BigDecimal remainTotalRepay;

    public Long getAccountId() {
        return accountId;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public String getLoanTransNo() {
        return loanTransNo;
    }

    public void setLoanTransNo(String loanTransNo) {
        this.loanTransNo = loanTransNo;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getTermNo() {
        return termNo;
    }

    public void setTermNo(Integer termNo) {
        this.termNo = termNo;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getAgreedRepayDate() {
        return agreedRepayDate;
    }

    public void setAgreedRepayDate(Date agreedRepayDate) {
        this.agreedRepayDate = agreedRepayDate;
    }

    public Integer getOverDueDays() {
        return overDueDays;
    }

    public void setOverDueDays(Integer overDueDays) {
        this.overDueDays = overDueDays;
    }

    public BigDecimal getOverDuePenalty() {
        return overDuePenalty;
    }

    public void setOverDuePenalty(BigDecimal overDuePenalty) {
        this.overDuePenalty = overDuePenalty;
    }

    public BigDecimal getRemainTotalRepay() {
        return remainTotalRepay;
    }

    public void setRemainTotalRepay(BigDecimal remainTotalRepay) {
        this.remainTotalRepay = remainTotalRepay;
    }

    public BigDecimal getOriginalTotalRepay() {
        return originalTotalRepay;
    }

    public void setOriginalTotalRepay(BigDecimal originalTotalRepay) {
        this.originalTotalRepay = originalTotalRepay;
    }

    @Override
    public String toString() {
        return "RepayPlanQueryDto{" + "accountId=" + accountId + ", loanTransNo='" + loanTransNo + '\'' + ", status=" + status + ", termNo=" + termNo + ", id="
                + id + ", agreedRepayDate=" + agreedRepayDate + ", overDueDays=" + overDueDays + ", overDuePenalty=" + overDuePenalty + ", originalTotalRepay="
                + originalTotalRepay + ", remainTotalRepay=" + remainTotalRepay + '}';
    }
}
