package com.xhh.creditpre.cashloan.model;

import com.janty.core.dto.BaseRequest;

import javax.validation.constraints.NotNull;

/**
 * @author zhangliang
 * @Date:Create in 2018/1/31
 */
public class LoanConfigRequest extends BaseRequest {

    @NotNull(message = "额度类型是必选参数")
    private Integer amountType;

    public Integer getAmountType() {
        return amountType;
    }

    public void setAmountType(Integer amountType) {
        this.amountType = amountType;
    }
}
