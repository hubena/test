package com.xhh.creditpre.cashloan.model;

import javax.validation.constraints.NotNull;

/**
 * author zhangweixin
 *
 * @Date:Create in 2018/1/12
 */
public class PeriodRepayPreRequest extends PreBaseRequest {
    @NotNull(message = "借款订单号不能为空")
    private String  loanOrderNo;
    @NotNull(message = "期数不能为空")
    private Integer termNo;
    private Long    accountId;

    public String getLoanOrderNo() {
        return loanOrderNo;
    }

    public void setLoanOrderNo(String loanOrderNo) {
        this.loanOrderNo = loanOrderNo;
    }

    public Integer getTermNo() {
        return termNo;
    }

    public void setTermNo(Integer termNo) {
        this.termNo = termNo;
    }

    public Long getAccountId() {
        return accountId;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }
}
