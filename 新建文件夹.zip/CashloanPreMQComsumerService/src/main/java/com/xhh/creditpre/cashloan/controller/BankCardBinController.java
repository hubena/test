package com.xhh.creditpre.cashloan.controller;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.janty.core.controller.BaseController;
import com.janty.core.dto.BaseResponse;
import com.janty.core.util.ExceptionUtil;
import com.janty.core.util.ResponseUtil;
import com.janty.core.util.ValidateUtil;
import com.xhh.creditcore.capital.dto.BankCardbinDto;
import com.xhh.creditcore.capital.dto.QueryBankCardbinRequest;
import com.xhh.creditpre.cashloan.model.BankCardbinRequest;
import com.xhh.creditpre.cashloan.service.remote.CapitalRemoteService;

/**
 * @author zhangliang
 * @Date:Create in 2018/2/7
 */
@Controller
@RequestMapping("/bankCardBin")
public class BankCardBinController extends BaseController{

    @Resource
    private CapitalRemoteService capitalRemoteService;
    /**
     * 查询卡bin信息    *
     * @param request
     * @return
     */
    @RequestMapping("/getBankCardBin")
    @ResponseBody
    public BaseResponse<BankCardbinDto> getBankCardBin(BankCardbinRequest request) {
        logger.info("BankCardBinController-getBankCardBin-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);

        BaseResponse<BankCardbinDto> response = ResponseUtil.createDefaultResponse();
        BankCardbinDto dto = null;
        try {
            ValidateUtil.validate(request);
            QueryBankCardbinRequest queryBankCardbinRequest = new QueryBankCardbinRequest();
            queryBankCardbinRequest.setCardNo(request.getCardNo());
            queryBankCardbinRequest.setReqNo(request.getReqNo());
            dto = capitalRemoteService.queryBankCardbin(queryBankCardbinRequest);
            ResponseUtil.success(response, dto);
        } catch (Exception e) {
            logger.error("BankCardBinController-getBankCardBin-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            ResponseUtil.handleException(response, e);
        }

        logger.info("BankCardBinController-getBankCardBin-请求结束, reqNo-{}-返回-{}", request.getReqNo(), response);

        return response;
    }
}
