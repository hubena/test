package com.xhh.creditpre.cashloan.model;

import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
public class AppActivityBanner {
    private Long    id;

    private Long    productId;

    private String  productName;

    private Integer terminalType;

    private Integer picType;

    private String  picName;

    private String  directUrl;

    private String  reqUrl;

    private Integer status;

    private Integer sort;

    private Date    effectTime;

    private Date    invalidTime;

    private String  remark;

    private Date    gmtCreated;

    private Date    gmtModified;

    private String  creator;

    private String  modifier;

    private String  isDeleted;
}
