package com.xhh.creditpre.cashloan.model;

import com.janty.core.dto.BaseRequest;

import javax.validation.constraints.NotNull;

/**
 * author zhangliang
 *
 * @Date:Create in 2018/1/15
 */
public class VerifyCodeRequest extends BaseRequest {

    @NotNull(message = "手机号是必选参数")
    private String phone;

    @NotNull(message = "验证码是必选参数")
    private String code;

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
