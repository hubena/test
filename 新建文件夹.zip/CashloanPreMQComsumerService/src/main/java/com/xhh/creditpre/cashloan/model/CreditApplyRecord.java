package com.xhh.creditpre.cashloan.model;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 额度申请记录表
 * </p>
 *
 * @author nathaniel123
 * @since 2018-01-15
 */

public class CreditApplyRecord implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
    private Long              id;
    /**
     * 用户ID
     */
    private Long              userId;
    /**
     * 产品子账户ID
     */
    private Long              prodAccountId;
    /**
     * 额度申请流水号
     */
    private String            creditAwardNo;
    /**
     * 是否鉴权绑卡:1-是，2-否
     */
    private Integer           isBindBank;
    /**
     * 鉴权绑卡时间
     */
    private Date              bindBankTime;
    /**
     * 是否人脸识别：1-是 2-否
     */
    private Integer           isFaceAuth;
    /**
     * 人脸识别时间
     */
    private Date              faceAuthTime;
    /**
     * 运营商是否验证：1-是 2-否
     */
    private Integer           isMobileAuth;
    /**
     * 认证时间
     */
    private Date              mobileAuthTime;
    /**
     * 通讯录是否验证：1-是 2-否
     */
    private Integer           isAdsbookAuth;
    /**
     * 认证时间
     */
    private Date              adsbookAuthTime;
    /**
     * 芝麻信用是否验证：1-是 2-否
     */
    private Integer           isZmxyAuth;
    /**
     * 认证时间
     */
    private Date              zmxyAuthTime;
    /**
     * 身份证图片是否提交 1-是 2-否
     */
    private Integer           isCardSubmit;
    /**
     * 身份证图片提交时间
     */
    private Date              cardSubmitTime;
    /**
     * 个人信息提交状态 1-是 2-否
     */
    private Integer           isPersonInfoSubmit;
    /**
     * 个人信息提交时间
     */
    private Date              personInfoSubmitTime;
    /**
     * 社保认证 1-是 2-否
     */
    private Integer           isSocialSecurityAuth;
    /**
     * 社保认证时间
     */
    private Date              socialSecurityAuthTime;
    /**
     * 公积金认证 1-是 2-否
     */
    private Integer           isReservedFundsAuth;
    /**
     * 公积金认证时间
     */
    private Date              reservedFundsAuthTime;
    /**
     * 京东认证 1-是 2-否
     */
    private Integer           isJdAuth;
    /**
     * 京东认证时间
     */
    private Date              jdAuthTime;
    /**
     * 淘宝认证 1-是 2-否
     */
    private Integer           isTbAuth;
    /**
     * 淘宝认证时间
     */
    private Date              tbAuthTime;
    /**
     * 支付宝认证 1-是 2-否
     */
    private Integer           isAlipayAuth;
    /**
     * 支付宝认证时间
     */
    private Date              alipayAuthTime;

    /**
     * 学信网认证
     */
    private Integer           isChsiAuth;

    /**
     * 学信网认证时间
     */
    private Date              chsiAuthTime;
    /**
     * 创建时间
     */
    private Date              gmtCreated;
    /**
     * 修改时间
     */
    private Date              gmtModified;
    /**
     * 创建人
     */
    private String            creator;
    /**
     * 修改人
     */
    private String            modifier;
    /**
     * 是否删除 Y/N
     */
    private String            isDeleted;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getProdAccountId() {
        return prodAccountId;
    }

    public void setProdAccountId(Long prodAccountId) {
        this.prodAccountId = prodAccountId;
    }

    public String getCreditAwardNo() {
        return creditAwardNo;
    }

    public void setCreditAwardNo(String creditAwardNo) {
        this.creditAwardNo = creditAwardNo;
    }

    public Integer getIsBindBank() {
        return isBindBank;
    }

    public void setIsBindBank(Integer isBindBank) {
        this.isBindBank = isBindBank;
    }

    public Date getBindBankTime() {
        return bindBankTime;
    }

    public void setBindBankTime(Date bindBankTime) {
        this.bindBankTime = bindBankTime;
    }

    public Integer getIsFaceAuth() {
        return isFaceAuth;
    }

    public void setIsFaceAuth(Integer isFaceAuth) {
        this.isFaceAuth = isFaceAuth;
    }

    public Date getFaceAuthTime() {
        return faceAuthTime;
    }

    public void setFaceAuthTime(Date faceAuthTime) {
        this.faceAuthTime = faceAuthTime;
    }

    public Integer getIsMobileAuth() {
        return isMobileAuth;
    }

    public void setIsMobileAuth(Integer isMobileAuth) {
        this.isMobileAuth = isMobileAuth;
    }

    public Date getMobileAuthTime() {
        return mobileAuthTime;
    }

    public void setMobileAuthTime(Date mobileAuthTime) {
        this.mobileAuthTime = mobileAuthTime;
    }

    public Integer getIsAdsbookAuth() {
        return isAdsbookAuth;
    }

    public void setIsAdsbookAuth(Integer isAdsbookAuth) {
        this.isAdsbookAuth = isAdsbookAuth;
    }

    public Date getAdsbookAuthTime() {
        return adsbookAuthTime;
    }

    public void setAdsbookAuthTime(Date adsbookAuthTime) {
        this.adsbookAuthTime = adsbookAuthTime;
    }

    public Integer getIsChsiAuth() {
        return isChsiAuth;
    }

    public void setIsChsiAuth(Integer isChsiAuth) {
        this.isChsiAuth = isChsiAuth;
    }

    public Date getChsiAuthTime() {
        return chsiAuthTime;
    }

    public void setChsiAuthTime(Date chsiAuthTime) {
        this.chsiAuthTime = chsiAuthTime;
    }

    public Integer getIsZmxyAuth() {
        return isZmxyAuth;
    }

    public void setIsZmxyAuth(Integer isZmxyAuth) {
        this.isZmxyAuth = isZmxyAuth;
    }

    public Date getZmxyAuthTime() {
        return zmxyAuthTime;
    }

    public void setZmxyAuthTime(Date zmxyAuthTime) {
        this.zmxyAuthTime = zmxyAuthTime;
    }

    public Integer getIsCardSubmit() {
        return isCardSubmit;
    }

    public void setIsCardSubmit(Integer isCardSubmit) {
        this.isCardSubmit = isCardSubmit;
    }

    public Date getCardSubmitTime() {
        return cardSubmitTime;
    }

    public void setCardSubmitTime(Date cardSubmitTime) {
        this.cardSubmitTime = cardSubmitTime;
    }

    public Integer getIsPersonInfoSubmit() {
        return isPersonInfoSubmit;
    }

    public void setIsPersonInfoSubmit(Integer isPersonInfoSubmit) {
        this.isPersonInfoSubmit = isPersonInfoSubmit;
    }

    public Date getPersonInfoSubmitTime() {
        return personInfoSubmitTime;
    }

    public void setPersonInfoSubmitTime(Date personInfoSubmitTime) {
        this.personInfoSubmitTime = personInfoSubmitTime;
    }

    public Integer getIsSocialSecurityAuth() {
        return isSocialSecurityAuth;
    }

    public void setIsSocialSecurityAuth(Integer isSocialSecurityAuth) {
        this.isSocialSecurityAuth = isSocialSecurityAuth;
    }

    public Date getSocialSecurityAuthTime() {
        return socialSecurityAuthTime;
    }

    public void setSocialSecurityAuthTime(Date socialSecurityAuthTime) {
        this.socialSecurityAuthTime = socialSecurityAuthTime;
    }

    public Integer getIsReservedFundsAuth() {
        return isReservedFundsAuth;
    }

    public void setIsReservedFundsAuth(Integer isReservedFundsAuth) {
        this.isReservedFundsAuth = isReservedFundsAuth;
    }

    public Date getReservedFundsAuthTime() {
        return reservedFundsAuthTime;
    }

    public void setReservedFundsAuthTime(Date reservedFundsAuthTime) {
        this.reservedFundsAuthTime = reservedFundsAuthTime;
    }

    public Integer getIsJdAuth() {
        return isJdAuth;
    }

    public void setIsJdAuth(Integer isJdAuth) {
        this.isJdAuth = isJdAuth;
    }

    public Date getJdAuthTime() {
        return jdAuthTime;
    }

    public void setJdAuthTime(Date jdAuthTime) {
        this.jdAuthTime = jdAuthTime;
    }

    public Integer getIsAlipayAuth() {
        return isAlipayAuth;
    }

    public void setIsAlipayAuth(Integer isAlipayAuth) {
        this.isAlipayAuth = isAlipayAuth;
    }

    public Date getAlipayAuthTime() {
        return alipayAuthTime;
    }

    public void setAlipayAuthTime(Date alipayAuthTime) {
        this.alipayAuthTime = alipayAuthTime;
    }

    public Integer getIsTbAuth() {
        return isTbAuth;
    }

    public void setIsTbAuth(Integer isTbAuth) {
        this.isTbAuth = isTbAuth;
    }

    public Date getTbAuthTime() {
        return tbAuthTime;
    }

    public void setTbAuthTime(Date tbAuthTime) {
        this.tbAuthTime = tbAuthTime;
    }

    public Date getGmtCreated() {
        return gmtCreated;
    }

    public void setGmtCreated(Date gmtCreated) {
        this.gmtCreated = gmtCreated;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public String getModifier() {
        return modifier;
    }

    public void setModifier(String modifier) {
        this.modifier = modifier;
    }

    public String getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(String isDeleted) {
        this.isDeleted = isDeleted;
    }

    @Override
    public String toString() {
        return "CreditApplyRecord{" + "id=" + id + ", userId=" + userId + ", prodAccountId=" + prodAccountId + ", creditAwardNo=" + creditAwardNo
                + ", isBindBank=" + isBindBank + ", bindBankTime=" + bindBankTime + ", isFaceAuth=" + isFaceAuth + ", faceAuthTime=" + faceAuthTime
                + ", isMobileAuth=" + isMobileAuth + ", mobileAuthTime=" + mobileAuthTime + ", isAdsbookAuth=" + isAdsbookAuth + ", adsbookAuthTime="
                + adsbookAuthTime + ", isZmxyAuth=" + isZmxyAuth + ", zmxyAuthTime=" + zmxyAuthTime + ", isCardSubmit=" + isCardSubmit + ", cardSubmitTime="
                + cardSubmitTime + ", isPersonInfoSubmit=" + isPersonInfoSubmit + ", personInfoSubmitTime=" + personInfoSubmitTime + ", isSocialSecurityAuth="
                + isSocialSecurityAuth + ", socialSecurityAuthTime=" + socialSecurityAuthTime + ", isReservedFundsAuth=" + isReservedFundsAuth
                + ", reservedFundsAuthTime=" + reservedFundsAuthTime + ", isJdAuth=" + isJdAuth + ", jdAuthTime=" + jdAuthTime + ", isTbAuth=" + isTbAuth
                + ", tbAuthTime=" + tbAuthTime + ", gmtCreated=" + gmtCreated + ", gmtModified=" + gmtModified + ", creator=" + creator + ", modifier="
                + modifier + ", isDeleted=" + isDeleted + "}";
    }
}
