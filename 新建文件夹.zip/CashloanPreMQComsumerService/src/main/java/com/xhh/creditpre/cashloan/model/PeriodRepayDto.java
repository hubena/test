package com.xhh.creditpre.cashloan.model;

import com.janty.core.dto.BaseModel;

public class PeriodRepayDto extends BaseModel {
    private String repayOrderNo;

    public String getRepayOrderNo() {
        return repayOrderNo;
    }

    public void setRepayOrderNo(String repayOrderNo) {
        this.repayOrderNo = repayOrderNo;
    }
}
