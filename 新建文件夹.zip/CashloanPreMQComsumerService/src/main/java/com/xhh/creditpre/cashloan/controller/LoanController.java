package com.xhh.creditpre.cashloan.controller;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.janty.core.dto.BaseResponse;
import com.janty.core.dto.PageData;
import com.janty.core.dto.Pager;
import com.janty.core.util.ExceptionUtil;
import com.janty.core.util.ResponseUtil;
import com.janty.core.util.ValidateUtil;
import com.xhh.creditcore.capital.dto.CapitalLoanRequest;
import com.xhh.creditcore.capital.dto.LoanTrialDto;
import com.xhh.creditcore.transaction.dto.LoanOrderDto;
import com.xhh.creditcore.transaction.dto.LoanQueryRequest;
import com.xhh.creditcore.transaction.dto.LoanRequest;
import com.xhh.creditcore.transaction.enums.LoanStatus;
import com.xhh.creditpre.cashloan.constant.CashLoanConstant;
import com.xhh.creditpre.cashloan.enums.LoanPreStatus;
import com.xhh.creditpre.cashloan.model.PreBaseRequest;
import com.xhh.creditpre.cashloan.model.UserDto;
import com.xhh.creditpre.cashloan.service.remote.LoanRemoteService;

@RestController
@RequestMapping("/loan")
public class LoanController extends WrapperController {

    @Resource
    private LoanRemoteService loanRemoteService;

    /**
     * 借款试算
     * 
     * @param request
     * @param preBaseRequest
     * @return
     */
    @RequestMapping("/loanTrial")
    public BaseResponse<LoanTrialDto> loanTrial(CapitalLoanRequest request, PreBaseRequest preBaseRequest) {
        logger.info("LoanController-loanTrial-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);
        BaseResponse<LoanTrialDto> response = ResponseUtil.createDefaultResponse();
        try {
            ValidateUtil.validate(preBaseRequest);
            UserDto userDto = queryUserByToken(preBaseRequest);
            request.setAccountId(userDto.getProdAccountId());
            request.setProductCode(CashLoanConstant.product_code);
            ValidateUtil.validate(request);
            LoanTrialDto result = loanRemoteService.loanTrail(request);
            ResponseUtil.success(response, result);
        } catch (Exception e) {
            logger.error("LoanController-loanTrial-请求异常,reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            ResponseUtil.handleException(response, e);
        }
        logger.info("LoanController-loanTrial-请求结束, reqNo-{}-返回-{}", request.getReqNo(), response);
        return response;
    }

    /**
     * 借款
     * 
     * @param request
     * @param preBaseRequest
     * @return
     */
    @RequestMapping("/loan")
    public BaseResponse<LoanOrderDto> loan(LoanRequest request, PreBaseRequest preBaseRequest) {
        logger.info("LoanController-loan-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);

        BaseResponse<LoanOrderDto> response = ResponseUtil.createDefaultResponse();
        try {
            UserDto userDto = queryUserByToken(preBaseRequest);
            request.setAccountId(userDto.getProdAccountId());
            request.setProductCode(CashLoanConstant.product_code);
            LoanOrderDto loanOrderDto = loanRemoteService.loan(request);
            ResponseUtil.success(response, loanOrderDto);
        } catch (Exception e) {
            logger.error("LoanController-loan-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            ResponseUtil.handleException(response, e);
        }

        logger.info("LoanController-loan-请求结束, reqNo-{}-返回-{}", request.getReqNo(), response);

        return response;
    }
    /**
     * 预借款(未授信成功前借款)
     * @param request
     * @param preBaseRequest
     * @return
     */
    @RequestMapping("/advanceLoan")
    public BaseResponse<Void> advanceLoan(LoanRequest request, PreBaseRequest preBaseRequest) {
        logger.info("LoanController-advanceLoan-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);

        BaseResponse<Void> response = ResponseUtil.createDefaultResponse();
        try {
            UserDto userDto = queryUserByToken(preBaseRequest);
            request.setAccountId(userDto.getProdAccountId());
            request.setProductCode(CashLoanConstant.product_code);
            loanRemoteService.advanceLoan(request);
            ResponseUtil.success(response, null);
        } catch (Exception e) {
            logger.error("LoanController-advanceLoan-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            ResponseUtil.handleException(response, e);
        }

        logger.info("LoanController-advanceLoan-请求结束, reqNo-{}", request.getReqNo());

        return response;
    }

    /**
     * 分页查询借款订单
     * 
     * @param preBaseRequest
     * @param pager
     * @return
     */
    @RequestMapping("/queryLoanByPage")
    @ResponseBody
    public BaseResponse<PageData<LoanOrderDto>> queryLoanByPage(PreBaseRequest preBaseRequest, Pager pager) {
        logger.info("LoanController-queryLoansByPage-请求开始, reqNo-{}-请求参数-{}", preBaseRequest.getReqNo(), preBaseRequest);

        BaseResponse<PageData<LoanOrderDto>> response = ResponseUtil.createDefaultResponse();

        try {
            ValidateUtil.validate(preBaseRequest);
            UserDto userDto = queryUserByToken(preBaseRequest);
            LoanQueryRequest request = new LoanQueryRequest();
            request.setAccountId(userDto.getProdAccountId());
            PageData<LoanOrderDto> pageData = loanRemoteService.queryByConditionOfPage(request, pager);
            //转换状态
            transferStatus(pageData);
            ResponseUtil.success(response, pageData);
        } catch (Exception e) {
            logger.error("LoanController-queryLoansByPage-请求异常, reqNo-{}-{}", preBaseRequest.getReqNo(), ExceptionUtil.getType(e), e);
            ResponseUtil.handleException(response, e);
        }

        logger.info("LoanController-queryLoansByPage-请求结束, reqNo-{}-返回-{}", preBaseRequest.getReqNo(), response);

        return response;

    }

    /**
     * 转换借款状态
     * 
     * @param pageData
     */
    private void transferStatus(PageData<LoanOrderDto> pageData) {
        List<LoanOrderDto> list = pageData.getData();
        if (CollectionUtils.isEmpty(list)) {
            return;
        }
        for (LoanOrderDto loanOrderDto : list) {
            LoanStatus status = LoanStatus.getByKey(loanOrderDto.getStatus());
            if (status == LoanStatus.init || status == LoanStatus.decisioning || status == LoanStatus.decision_success || status == LoanStatus.waiting_loan
                    || status == LoanStatus.loaning) {
                loanOrderDto.setStatus(LoanPreStatus.approving.getKey());//审核中
            } else if (status == LoanStatus.trans_failed || status == LoanStatus.loan_failed) {
                loanOrderDto.setStatus(LoanPreStatus.reject.getKey());//已拒绝
            } else if (status == LoanStatus.loan_success) {
                loanOrderDto.setStatus(LoanPreStatus.repaying.getKey());//还款中
            } else if (status == LoanStatus.overdue) {
                loanOrderDto.setStatus(LoanPreStatus.overdue.getKey());//已逾期
            } else if (status == LoanStatus.settle) {
                loanOrderDto.setStatus(LoanPreStatus.settle.getKey());//已结清
            }
        }
    }

}
