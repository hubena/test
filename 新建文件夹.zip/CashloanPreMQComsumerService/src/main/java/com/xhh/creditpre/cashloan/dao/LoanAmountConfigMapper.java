package com.xhh.creditpre.cashloan.dao;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.xhh.creditpre.cashloan.model.LoanAmountConfig;

import java.util.List;

@Repository
public interface LoanAmountConfigMapper {
    int deleteByPrimaryKey(Long id);

    int insert(LoanAmountConfig record);

    int insertSelective(LoanAmountConfig record);

    LoanAmountConfig selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(LoanAmountConfig record);

    int updateByPrimaryKey(LoanAmountConfig record);

    List<LoanAmountConfig> queryByAmountType(@Param("amountType") Integer amountType);
}
