package com.xhh.creditpre.cashloan.model;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.annotation.JSONField;
import com.janty.core.dto.BaseRequest;
import org.hibernate.validator.constraints.NotBlank;

import javax.validation.constraints.NotNull;

public class PreOcrRecognizeRequest extends BaseRequest {

    @NotNull(message = "ocrType必填")
    private String ocrType;
    @JSONField(serialize = false)
    @NotBlank(message = "imgBase64必填")
    private String imgBase64;

    public String getOcrType() {
        return this.ocrType;
    }

    public String getImgBase64() {
        return this.imgBase64;
    }

    public void setOcrType(String ocrType) {
        this.ocrType = ocrType;
    }

    public void setImgBase64(String imgBase64) {
        this.imgBase64 = imgBase64;
    }

    @Override
    public String toString() {
        return JSON.toJSONString(this);
    }
}
