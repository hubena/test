package com.xhh.creditpre.cashloan.service.remote;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.janty.core.util.BaseRemoteService;
import com.xhh.creditcore.capital.api.ICapitalApi;
import com.xhh.creditcore.capital.dto.AccountBankCardDto;
import com.xhh.creditcore.capital.dto.AccountBankCardRequest;
import com.xhh.creditcore.capital.dto.BankCardbinDto;
import com.xhh.creditcore.capital.dto.QueryBankCardbinRequest;
import com.xhh.creditpre.cashloan.constant.CashloanErrorCode;

/**
 * author zhangliang
 *
 * @Date:Create in 2018/1/22
 */
@Service("capitalRemoteService")
public class CapitalRemoteService extends BaseRemoteService {

    @Resource
    private ICapitalApi capitalApi;

    /**
     * 查询卡bin信息
     * 
     * @param
     * @return
     */
    public BankCardbinDto queryBankCardbin(QueryBankCardbinRequest request) {
        try {
            return capitalApi.queryBankCardbin(request);
        } catch (Exception e) {
            return processException(e, new CashloanErrorCode(CashloanErrorCode.Element.r_query_bank_card_bin_remote_fail));
        }
    }

    /**
     * 查询账户绑卡信息
     * 
     * @param request
     * @return
     */
    public AccountBankCardDto queryAccountBankCardBind(AccountBankCardRequest request) {
        try {
            return capitalApi.queryAccountBankCardInfo(request);
        } catch (Exception e) {
            return processException(e, new CashloanErrorCode(CashloanErrorCode.Element.r_query_bank_card_bin_remote_fail));
        }
    }
}
