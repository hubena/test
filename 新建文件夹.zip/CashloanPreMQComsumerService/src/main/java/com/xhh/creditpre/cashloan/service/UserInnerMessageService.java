package com.xhh.creditpre.cashloan.service;

import com.janty.core.dto.PageData;
import com.janty.core.dto.Pager;
import com.janty.mybatis.util.CountHelper;
import com.xhh.creditpre.cashloan.dao.UserInnerMessageMapper;
import com.xhh.creditpre.cashloan.dto.MessageCountDto;
import com.xhh.creditpre.cashloan.dto.NoticeBusinessMessageDto;
import com.xhh.creditpre.cashloan.dto.UserInnerMessageDto;
import com.xhh.creditpre.cashloan.enums.DeviceType;
import com.xhh.creditpre.cashloan.enums.ReadType;
import com.xhh.creditpre.cashloan.enums.SendStatus;
import com.xhh.creditpre.cashloan.model.InnerMessage;
import com.xhh.creditpre.cashloan.model.UserInfo;
import com.xhh.creditpre.cashloan.model.UserInnerMessage;
import com.xhh.creditpre.cashloan.model.UserLoginRecord;
import org.apache.ibatis.session.RowBounds;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.*;

/**
 * UserInnerMessage服务类
 * 
 * @author jan
 * @date 2018-2-27 15:43:15
 */
@Service("userInnerMessageService")
public class UserInnerMessageService {
    @Resource
    private UserInnerMessageMapper userInnerMessageMapper;
    @Resource
    private InnerMessageService innerMessageService;
    @Resource
    private UserInfoService userInfoService;
    @Resource
    private UserLoginRecordService userLoginRecordService;
    @Resource
    private UMengService uMengService;
    
    /**
	 * 根据id查询数据
	 * @param id         实体id
	 * @return           实体
	 */
    public UserInnerMessage queryDataById(long id){
    	return null;    
    }
    /**
	 * 新增数据
	 * @param record  实体
	 */
    public void addData(UserInnerMessage record){
    
    }
    /**
	 * 修改数据
	 * @param record  实体
	 */
    public void modifyData(UserInnerMessage record){
    
    }
    /**
	 * 删除数据
	 * @param record  实体
	 */
    public void deleteData(UserInnerMessage record){
    
    }

    /**
     * 插入业务消息
     * @param
     */
    public void insertBusinessMessage(NoticeBusinessMessageDto dto) throws Exception {
        //查询消息模板
        InnerMessage innerMessage = innerMessageService.queryByMsgSubtype(dto.getMsgSubtype());
        if (innerMessage == null)
            return ;
        String content = innerMessage.getContentTemplate();
        String title = innerMessage.getTitle();
        for (Map.Entry<String,String> entry: dto.getMap().entrySet()){
            System.out.println(entry.getKey()+":"+entry.getValue());
            title = title.replace(entry.getKey(),entry.getValue());
            content = content.replace(entry.getKey(),entry.getValue());
        }

        List<UserLoginRecord> userLoginRecords = acquireUserLoginRecord(dto.getAccountId());
        if (!CollectionUtils.isEmpty(userLoginRecords)){
            for (UserLoginRecord userLoginRecord : userLoginRecords){
                UserInnerMessage userInnerMessage = new UserInnerMessage();
                userInnerMessage.setInnerMessageId(innerMessage.getId());
                userInnerMessage.setUserId(userLoginRecord.getUserId());
                userInnerMessage.setTitle(title);
                userInnerMessage.setContent(content);
                userInnerMessage.setDeviceId(userLoginRecord.getDeviceId());
                userInnerMessage.setStatus(SendStatus.NOT_SEND.getKey());
                userInnerMessage.setIsRead(ReadType.NOT_READ.getKey());
                userInnerMessage.setMsgType(innerMessage.getMsgType());
                userInnerMessage.setGmtCreated(new Date());
                userInnerMessageMapper.insertSelective(userInnerMessage);

                boolean flag = false;
                if (userLoginRecord.getLoginDeviceType().equals(DeviceType.IOS.getKey())){
                    flag = uMengService.sendIOSUnicast(title,content,userLoginRecord.getDeviceId());
                }
                if (userLoginRecord.getLoginDeviceType().equals(DeviceType.ANDROID.getKey())){
                    //应android的需求，将通知标题的签名去掉
                    title = title.substring(title.indexOf("】")+1);
                    flag = uMengService.sendAndroidUnicast(title,content,userLoginRecord.getDeviceId());
                }
                userInnerMessage.setStatus(flag ? SendStatus.SEND_SUCCESS.getKey() : SendStatus.SEND_FAIL.getKey());
                userInnerMessage.setGmtModified(new Date());
                userInnerMessage.setSendTime(new Date());
                userInnerMessageMapper.updateStatusById(userInnerMessage);
            }
        }



    }

    /**
     * 获取用户accountId对应的用户登录的记录
     * @param accountId
     * @return
     */
    private List<UserLoginRecord> acquireUserLoginRecord(Long accountId) {
        List<UserInfo> userInfos = userInfoService.queryUserByAccountId(accountId);
        List<UserLoginRecord> userLoginRecords = null;
        if (!CollectionUtils.isEmpty(userInfos)){
            userLoginRecords = new ArrayList<>();
            for (UserInfo userInfo :userInfos){
                UserLoginRecord userLoginRecord = userLoginRecordService.selectByUserId(userInfo.getId());
                if (userLoginRecord != null){
                    userLoginRecords.add(userLoginRecord);
                }
            }
        }
//        Collections.sort(userLoginRecords, new Comparator<UserLoginRecord>() {
//            @Override
//            public int compare(UserLoginRecord o1, UserLoginRecord o2) {
//                return o1.getLastLoginTime().toString().compareTo(o2.getLastLoginTime().toString());
//            }
//        });

        return userLoginRecords;
    }

    /**
     * 对象转字符串
     * @param object
     * @return
     */
    private String convertToString(Object object){
        if (object == null)
            return "";
        return object.toString();
    }

    /**
     * 批量插入消息附表
     * @param innerMessage
     * @param userLoginRecords
     */
    public void batchInsert(InnerMessage innerMessage, List<UserLoginRecord> userLoginRecords) {
        UserInnerMessage userInnerMessage = null;
        if (!CollectionUtils.isEmpty(userLoginRecords)){
            for (UserLoginRecord userLoginRecord : userLoginRecords){
                userInnerMessage = new UserInnerMessage();
                userInnerMessage.setInnerMessageId(innerMessage.getId());
                userInnerMessage.setIsRead(ReadType.NOT_READ.getKey());
                userInnerMessage.setMsgType(innerMessage.getMsgType());
                userInnerMessage.setTitle(innerMessage.getTitle());
                userInnerMessage.setContent(innerMessage.getContent());
                userInnerMessage.setStatus(SendStatus.NOT_SEND.getKey());
                userInnerMessage.setUserId(userLoginRecord.getUserId());
                userInnerMessage.setDeviceId(userLoginRecord.getDeviceId());
                userInnerMessage.setGmtCreated(new Date());
                userInnerMessage.setGmtModified(new Date());
                userInnerMessageMapper.insertSelective(userInnerMessage);
            }
        }
    }

    /**
     * 根据消息主表id匹配消息附表list
     * @param innerMessageId
     * @return
     */
    public List<UserInnerMessage> selectByInnerMessgeId(Long innerMessageId) {
        return userInnerMessageMapper.selectByInnerMessgeId(innerMessageId);
    }

    public void updateStatusById(UserInnerMessage userInnerMessage) {
        userInnerMessage.setGmtModified(new Date());
        userInnerMessageMapper.updateStatusById(userInnerMessage);
    }

    public MessageCountDto selectCountByUserId(Integer isRead, Long userId) {
        Long count = userInnerMessageMapper.selectCountByUserId(isRead,userId);
        MessageCountDto messageCountDto = new MessageCountDto();
        messageCountDto.setCount(count);
        return messageCountDto;
    }

    public PageData<UserInnerMessageDto> selectMessagesByUserId(Long userId, Pager pager) {
        RowBounds rowBounds = new RowBounds(pager.getOffset(),pager.getPageSize());
        List<UserInnerMessage> list = userInnerMessageMapper.selectMessagesByUserId(userId,rowBounds);
        List<UserInnerMessageDto> result = null;
        UserInnerMessageDto dto = null;
        if (!CollectionUtils.isEmpty(list)){
            result = new ArrayList<>();
            for (UserInnerMessage userInnerMessage : list){
                dto = new UserInnerMessageDto();
                InnerMessage innerMessage = innerMessageService.selectByPrimaryKey(userInnerMessage.getInnerMessageId());
                if (innerMessage == null)
                    continue;
                //TODO
                dto.setId(userInnerMessage.getId());
                dto.setContent(userInnerMessage.getContent());
                dto.setDirectUrl(innerMessage.getDirectUrl());
                dto.setSendTime(userInnerMessage.getSendTime());
                dto.setTitle(userInnerMessage.getTitle());
                dto.setIsRead(userInnerMessage.getIsRead());
                dto.setMsgType(userInnerMessage.getMsgType());
                result.add(dto);
            }
        }
        PageData<UserInnerMessageDto> pageData = new PageData<>();
        pageData.assembleResult(pager,result, CountHelper.getTotalRow());
        return pageData;
    }
}
