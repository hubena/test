package com.xhh.creditpre.cashloan.api;

import java.util.Date;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.janty.core.dto.PageData;
import com.janty.core.dto.Pager;
import com.janty.core.util.CommonBeanCopier;
import com.janty.core.util.ExceptionUtil;
import com.xhh.creditpre.cashloan.dto.AppVersionAddRequest;
import com.xhh.creditpre.cashloan.dto.AppVersionDto;
import com.xhh.creditpre.cashloan.dto.AppVersionQueryRequest;
import com.xhh.creditpre.cashloan.dto.AppVersionUpdateRequest;
import com.xhh.creditpre.cashloan.model.AppVersion;
import com.xhh.creditpre.cashloan.service.AppVersionService;

@Service("appVersionApi")
public class AppVersionApi implements IAppVersionApi {
    Logger            logger = LoggerFactory.getLogger(this.getClass());

    @Resource
    AppVersionService appVersionService;

    @Override
    public PageData<AppVersionDto> queryAppVersionByPage(AppVersionQueryRequest request, Pager pager) {
        logger.info("AppVersionApi-queryAppVersionByPage-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);
        PageData<AppVersionDto> result = null;
        try {
            result = appVersionService.queryAppVersionByPage(request, pager);
        } catch (Exception e) {
            logger.error("AppVersionApi-queryAppVersionByPage-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            throw e;
        }
        logger.info("AppVersionApi-queryAppVersionByPage-请求结束, reqNo-{}-返回-{}", request.getReqNo(), result);
        return result;
    }

    @Override
    public Boolean addAppVersion(AppVersionAddRequest request) {
        logger.info("AppVersionApi-addAppVersion-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);
        AppVersion appVersion = new AppVersion();
        Boolean result = false;
        try {
            Date date = new Date();
            CommonBeanCopier.copy(request, appVersion);
            appVersion.setGmtCreated(date);
            appVersion.setGmtModified(date);
            appVersionService.addData(appVersion);
            result = true;
        } catch (Exception e) {
            logger.error("AppVersionApi-addAppVersion-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            throw e;
        }
        logger.info("AppVersionApi-addAppVersion-请求结束, reqNo-{}-返回-{}", request.getReqNo(), result);
        return result;
    }

    @Override
    public Boolean updateAppVersion(AppVersionUpdateRequest request) {
        logger.info("AppVersionApi-updateAppVersion-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);
        AppVersion appVersion = new AppVersion();
        Boolean result = false;
        try {
            Date date = new Date();
            CommonBeanCopier.copy(request, appVersion);
            appVersion.setGmtModified(date);
            appVersionService.modifyData(appVersion);
            result = true;
        } catch (Exception e) {
            logger.error("AppVersionApi-updateAppVersion-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            throw e;
        }
        logger.info("AppVersionApi-updateAppVersion-请求结束, reqNo-{}-返回-{}", request.getReqNo(), result);
        return result;
    }

    @Override
    public Boolean removeAppVersion(Long id) {
        logger.info("AppVersionApi-removeAppVersion-请求开始, 请求参数-{}", id);
        Boolean result = false;
        try {
            appVersionService.deleteData(id);
            result = true;
        } catch (Exception e) {
            logger.error("AppVersionApi-removeAppVersion-请求异常, {}", ExceptionUtil.getType(e), e);
            throw e;
        }
        logger.info("AppVersionApi-removeAppVersion-请求结束, 返回-{}", result);
        return result;
    }
}
