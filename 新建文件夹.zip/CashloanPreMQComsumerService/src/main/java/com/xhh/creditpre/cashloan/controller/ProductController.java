package com.xhh.creditpre.cashloan.controller;

import com.janty.core.controller.BaseController;
import com.janty.core.dto.BaseResponse;
import com.janty.core.util.ExceptionUtil;
import com.janty.core.util.ResponseUtil;
import com.xhh.creditcore.product.dto.ProductSupportBanksDto;
import com.xhh.creditpre.cashloan.service.remote.ProductRemoteService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

/**
 * author zhangliang
 *
 * @Date:Create in 2018/1/16
 */
@RestController
@RequestMapping("/product")
public class ProductController extends BaseController {

    @Resource
    private ProductRemoteService productRemoteService;

    @RequestMapping("/querySupportBanks")
    public BaseResponse<List<ProductSupportBanksDto>> querySupportBanks() {
        logger.info("ProductController-querySupportBanks-请求开始");

        BaseResponse<List<ProductSupportBanksDto>> response = ResponseUtil.createDefaultResponse();
        try {
            List<ProductSupportBanksDto> result = productRemoteService.getSupportBanksByProductCode();
            ResponseUtil.success(response, result);
        } catch (Exception e) {
            logger.error("ProductController-querySupportBanks-请求异常, {}", ExceptionUtil.getType(e), e);
            ResponseUtil.handleException(response, e);
        }
        logger.info("ProductController-querySupportBanks-请求结束, 返回-{}", response);
        return response;
    }

}
