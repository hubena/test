package com.xhh.creditpre.cashloan.service;

import com.janty.core.dto.PageData;
import com.janty.core.dto.Pager;
import com.janty.core.util.CommonBeanCopier;
import com.janty.core.util.DateUtil;
import com.janty.mybatis.util.CountHelper;
import com.xhh.creditpre.cashloan.dao.InnerMessageMapper;
import com.xhh.creditpre.cashloan.dto.*;
import com.xhh.creditpre.cashloan.enums.DeviceType;
import com.xhh.creditpre.cashloan.enums.SendStatus;
import com.xhh.creditpre.cashloan.model.InnerMessage;
import com.xhh.creditpre.cashloan.model.UserInnerMessage;
import com.xhh.creditpre.cashloan.model.UserLoginRecord;
import org.apache.ibatis.session.RowBounds;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * InnerMessage服务类
 * 
 * @author jan
 * @date 2018-2-27 15:41:42
 */
@Service("innerMessageService")
public class InnerMessageService {
    @Resource
    private InnerMessageMapper innerMessageMapper;

    @Autowired
    private UserLoginRecordService userLoginRecordService;

    @Autowired
    private UserInnerMessageService userInnerMessageService;

    @Autowired
    private UMengService uMengService;
    /**
	 * 根据id查询数据
	 * @param id         实体id
	 * @return           实体
	 */
    public InnerMessage queryDataById(long id){
    	return null;    
    }
    /**
	 * 新增数据
	 * @param record  实体
	 */
    public void addData(InnerMessage record){
    
    }
    /**
	 * 修改数据
	 * @param record  实体
	 */
    public void modifyData(InnerMessage record){
    
    }
    /**
	 * 删除数据
	 * @param record  实体
	 */
    public void deleteData(InnerMessage record){
    
    }

    /**
     * 查询系统消息和营销消息
     * @param request
     * @param pager
     * @return
     */
    public PageData<InnerMessageDto> queryInnerMessageByPage(InnerMessageRequest request, Pager pager) {
        RowBounds rowBounds = new RowBounds(pager.getOffset(), pager.getPageSize());
        List<InnerMessage> list = innerMessageMapper.queryInnerMessageByPage(request.getMsgType(),rowBounds);
        List<InnerMessageDto> result = null;
        if (!CollectionUtils.isEmpty(list)){
            result = new ArrayList<>();
            InnerMessageDto innerMessageDto = null;
            for (InnerMessage innerMessage : list){
                innerMessageDto = new InnerMessageDto();
                CommonBeanCopier.copy(innerMessage,innerMessageDto);
                result.add(innerMessageDto);
            }
        }
        PageData<InnerMessageDto> pageData = new PageData<InnerMessageDto>();
        pageData.assembleResult(pager,result, CountHelper.getTotalRow());
        return pageData;
    }

    /**
     * 插入营销消息-目前只支持全局发送
     * @param request
     */
    @Transactional(rollbackFor = Exception.class,timeout = 30)
    public void insertInnerMessage(InnerMessageAddRequest request) {
        InnerMessage innerMessage = new InnerMessage();
        CommonBeanCopier.copy(request,innerMessage);
        innerMessage.setPlanSendTime(DateUtil.stringToDate(request.getPlanSendTime()));
        innerMessage.setGmtCreated(new Date());
        innerMessage.setGmtModified(new Date());
        innerMessage.setStatus(SendStatus.NOT_SEND.getKey());
        innerMessageMapper.insertSelective(innerMessage);

        List<UserLoginRecord> userLoginRecords = userLoginRecordService.selectAllLoginRecord();

        userInnerMessageService.batchInsert(innerMessage,userLoginRecords);

    }

    /**
     * 编辑营销消息
     * @param request
     */
    public <T> void updateInnerMessage(T request){
        InnerMessage innerMessage = new InnerMessage();
        CommonBeanCopier.copy(request,innerMessage);
        if (request instanceof MarketInnerMessageUpdateRequest){
            innerMessage.setPlanSendTime(DateUtil.stringToDate(((MarketInnerMessageUpdateRequest)request).getPlanSendTime()));
        }
        innerMessage.setGmtModified(new Date());
        innerMessageMapper.updateByPrimaryKeySelective(innerMessage);
    }
    /**
     * 扫描营销消息-并发送
     */
    public void sendInnerMessage() throws Exception {
        //TODO 查询需要群发的营销消息
        boolean flag = false;
        InnerMessage innerMessage = new InnerMessage();
        innerMessage.setMsgType(2);
        List<InnerMessage> innerMessages = innerMessageMapper.selectByMsgType(innerMessage);
        //TODO
        if (!CollectionUtils.isEmpty(innerMessages)){
            List<UserInnerMessage> userInnerMessages = null;
            for (InnerMessage message : innerMessages){
                userInnerMessages = userInnerMessageService.selectByInnerMessgeId(message.getId());
                if (!CollectionUtils.isEmpty(userInnerMessages)){
                    for (UserInnerMessage userInnerMessage : userInnerMessages){
                        UserLoginRecord userLoginRecord = userLoginRecordService.selectByUserId(userInnerMessage.getUserId());
                        if (userLoginRecord.getLoginDeviceType().equals(DeviceType.IOS.getKey())){
                            flag = uMengService.sendIOSUnicast(message.getTitle(),message.getContent(),userLoginRecord.getDeviceId());
                        }
                        if (userLoginRecord.getLoginDeviceType().equals(DeviceType.ANDROID.getKey())){
                            flag = uMengService.sendAndroidUnicast(message.getTitle(),message.getContent(),userLoginRecord.getDeviceId());
                        }
                        userInnerMessage.setStatus(flag ? SendStatus.SEND_SUCCESS.getKey() : SendStatus.SEND_FAIL.getKey());
                        userInnerMessage.setGmtModified(new Date());
                        userInnerMessage.setSendTime(new Date());
                        userInnerMessageService.updateStatusById(userInnerMessage);
                    }
                }
                message.setStatus(flag ? SendStatus.SEND_SUCCESS.getKey() : SendStatus.SEND_FAIL.getKey());
                message.setGmtModified(new Date());
                message.setSendTime(new Date());
                innerMessageMapper.updateStatusById(message);
            }
        }
    }

    public InnerMessage selectByPrimaryKey(Long msgId) {
        return innerMessageMapper.selectByPrimaryKey(msgId);
    }

    public InnerMessage queryByMsgSubtype(Integer msgSubtype) {
        return innerMessageMapper.selectByMsgSubtype(msgSubtype);
    }
}
