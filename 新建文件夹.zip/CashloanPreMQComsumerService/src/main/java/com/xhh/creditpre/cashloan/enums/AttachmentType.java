package com.xhh.creditpre.cashloan.enums;

public enum AttachmentType {
    IDENTITY_CARD_F(1, "身份证正面"),
    IDENTITY_CARD_B(2, "身份证反面"),
    IDENTITY_CARD_HAND(3, "手持身份证"),
    BANK_CARD(4, "银行卡");

    private Integer key;
    private String  desc;

    public Integer getKey() {
        return key;
    }

    public String getDesc() {
        return desc;
    }

    AttachmentType(Integer key, String desc) {
        this.key = key;
        this.desc = desc;
    }

    public static AttachmentType getInstance(Integer key) {
        for (AttachmentType attachmentType : AttachmentType.values()) {
            if (attachmentType.key.equals(key)) {
                return attachmentType;
            }
        }
        return null;
    }
}
