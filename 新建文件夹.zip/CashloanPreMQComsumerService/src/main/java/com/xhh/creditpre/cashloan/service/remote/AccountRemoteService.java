package com.xhh.creditpre.cashloan.service.remote;

import com.janty.core.util.BaseRemoteService;
import com.xhh.creditcore.transaction.api.IAccountApi;
import com.xhh.creditcore.transaction.dto.MainAccountDto;
import com.xhh.creditcore.transaction.dto.OpenAccountDto;
import com.xhh.creditcore.transaction.dto.OpenAccountRequest;
import com.xhh.creditcore.transaction.dto.QueryMainAccountRequest;
import com.xhh.creditpre.cashloan.constant.CashloanErrorCode;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * @author liangz
 */
@Service("accountRemoteService")
public class AccountRemoteService extends BaseRemoteService {
    @Resource
    private IAccountApi accountApi;

    /**
     * 通过产品编码、身份证、姓名开户
     *
     * @param
     * @return
     */
    public OpenAccountDto openAccount(OpenAccountRequest request) {
        try {
            return accountApi.openAccount(request);
        } catch (Exception e) {
            return processException(e, new CashloanErrorCode(CashloanErrorCode.Element.r_account_remote_fail));
        }
    }

    /**
     * 获取主账户
     *
     * @param
     * @return
     */
    public MainAccountDto getMainAccount(QueryMainAccountRequest request) {
        try {
            return accountApi.queryMainAccountById(request);
        } catch (Exception e) {
            return processException(e, new CashloanErrorCode(CashloanErrorCode.Element.r_product_remote_fail));
        }
    }

}
