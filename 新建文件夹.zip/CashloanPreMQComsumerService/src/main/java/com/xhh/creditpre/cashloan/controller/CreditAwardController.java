package com.xhh.creditpre.cashloan.controller;

import com.janty.cached.access.RedisCachedAccess;
import com.janty.core.dto.BaseResponse;
import com.janty.core.util.*;
import com.xhh.creditcore.transaction.dto.*;
import com.xhh.creditcore.transaction.dto.CreditAwardInfoDto;
import com.xhh.creditpre.cashloan.api.CreditApplyRecordApi;
import com.xhh.creditpre.cashloan.constant.CashLoanConstant;
import com.xhh.creditpre.cashloan.dto.CreditApplyRecordQueryDto;
import com.xhh.creditpre.cashloan.model.*;
import com.xhh.creditpre.cashloan.service.CreditApplyRecordService;
import com.xhh.creditpre.cashloan.service.CreditAwardService;
import com.xhh.creditpre.cashloan.service.UploadAttachmentService;
import com.xhh.creditpre.cashloan.service.remote.CreditAwardRemoteService;
import com.xhh.polaris.dto.OCRResultDto;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.List;

@Controller
@RequestMapping("/creditAward")
public class CreditAwardController extends WrapperController {

    @Resource
    private CreditAwardRemoteService    creditAwardRemoteService;

    @Resource
    private RedisCachedAccess<UserInfo> redisCachedAccess;

    @Resource
    private RedisCachedAccess<Object>   redisAccess;

    @Resource
    private CreditAwardService          creditAwardService;

    @Resource
    private UploadAttachmentService     uploadAttachmentService;

    @Resource
    private CreditApplyRecordApi        applyRecordApi;

    @Resource
    private CreditApplyRecordService    applyRecordService;

    /**
     * 个人信息录入
     *
     * @param request
     * @return
     */
    @RequestMapping("/creatCreditAwardInfo")
    @ResponseBody
    public BaseResponse<Void> creatCreditAwardInfo(CreditAwardInfoRequest request, PreBaseRequest preBaseRequest) {
        logger.info("CreditAwardController-creatCreditAwardInfo-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);

        BaseResponse<Void> response = ResponseUtil.createDefaultResponse();
        try {

            ValidateUtil.validate(request);
            UserDto userDto = queryUserByToken(preBaseRequest);
            request.setAccountId(userDto.getProdAccountId());
            request.setProductCode(CashLoanConstant.product_code);
            creditAwardService.updateCreditAwardInfo(request);
            ResponseUtil.success(response, null);

        } catch (Exception e) {
            logger.error("CreditAwardController-creatCreditAwardInfo-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            ResponseUtil.handleException(response, e);
        }

        logger.info("CreditAwardController-creatCreditAwardInfo-请求结束, reqNo-{}-返回-{}", request.getReqNo(), response);

        return response;
    }

    /**
     * 查询最新额度
     *
     * @param request
     * @return
     */
    @RequestMapping("/queryLatestCreditAward")
    @ResponseBody
    public BaseResponse<CreditAwardDto> queryLatestCreditAward(PreBaseRequest request) {
        logger.info("CreditAwardController-queryLatestCreditAward-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);

        BaseResponse<CreditAwardDto> response = ResponseUtil.createDefaultResponse();
        CreditAwardDto result = null;
        try {
            UserDto userDto = queryUserByToken(request);
            if (userDto.getProdAccountId() != null) {
                LatestCreditAwardRequest latestCreditAwardRequest = new LatestCreditAwardRequest();
                latestCreditAwardRequest.setReqNo(request.getReqNo());
                latestCreditAwardRequest.setAccountId(userDto.getProdAccountId());
                latestCreditAwardRequest.setProductCode(CashLoanConstant.product_code);
                result = creditAwardRemoteService.queryLatestCreditAward(latestCreditAwardRequest);
            }

            ResponseUtil.success(response, result);
        } catch (Exception e) {
            logger.error("CreditAwardController-queryLatestCreditAward-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            ResponseUtil.handleException(response, e);
        }

        logger.info("CreditAwardController-queryLatestCreditAward-请求结束, reqNo-{}-返回-{}", request.getReqNo(), response);

        return response;
    }

    /**
     * 上传附件
     *
     * @param request
     * @return
     */
    @RequestMapping("/uploadAttachment")
    @ResponseBody
    public BaseResponse<Void> uploadAttachment(CreditAwardAttachmentRequest request, PreBaseRequest preBaseRequest) {
        String log = FastJsonUtil.obj2json(request);
        logger.info("CreditAwardApi-uploadAttachment-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), log);

        BaseResponse<Void> response = ResponseUtil.createDefaultResponse();
        try {
            ValidateUtil.validate(request);
            UserDto userDto = queryUserByToken(preBaseRequest);
            request.setAccountId(userDto.getProdAccountId());
            request.setProductCode(CashLoanConstant.product_code);
            //上传附件
            uploadAttachmentService.uploadAttachment(request);

            ResponseUtil.success(response, null);
        } catch (Exception e) {
            logger.error("CreditAwardController-uploadAttachment-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            ResponseUtil.handleException(response, e);
        }

        logger.info("CreditAwardController-uploadAttachment-请求结束, reqNo-{}-返回-{}", request.getReqNo(), response);

        return response;
    }

    /**
     * 人脸识别
     *
     * @param request
     * @return
     */
    @RequestMapping("/faceRecognize")
    @ResponseBody
    public BaseResponse<Void> faceRecognize(PreFaceRequest request, PreBaseRequest preBaseRequest) {
        logger.info("CreditAwardController-faceRecognize-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);

        BaseResponse<Void> response = ResponseUtil.createDefaultResponse();
        try {
            ValidateUtil.validate(request);
            UserDto userDto = queryUserByToken(preBaseRequest);
            creditAwardService.faceRecognize(request, userDto);
            ResponseUtil.success(response, null);
        } catch (Exception e) {
            logger.error("CreditAwardController-faceRecognize-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            ResponseUtil.handleException(response, e);
        }

        logger.info("CreditAwardController-faceRecognize-请求结束, reqNo-{}-返回-{}", request.getReqNo(), response);

        return response;
    }

    /**
     * 鉴权绑卡
     *
     * @param request
     * @return
     */
    @RequestMapping("/bindBank")
    @ResponseBody
    public BaseResponse<Void> bindBank(PreBindBankRequest request, PreBaseRequest preBaseRequest) {
        logger.info("CreditAwardController-bindBank-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);

        UserDto userDto = queryUserByToken(preBaseRequest);
        BaseResponse<Void> response = ResponseUtil.createDefaultResponse();
        try {
            ValidateUtil.validate(request);
            creditAwardService.bindBank(request, userDto);
            ResponseUtil.success(response, null);
        } catch (Exception e) {
            logger.error("CreditAwardController-bindBank-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            ResponseUtil.handleException(response, e);
        }

        logger.info("CreditAwardController-bindBank-请求结束, reqNo-{}-返回-{}", request.getReqNo(), response);

        return response;
    }

    /**
     * ocr识别
     *
     * @param request
     * @return
     */
    @RequestMapping("/ocrRecognize")
    @ResponseBody
    public BaseResponse<OCRResultDto> ocrRecognize(PreOcrRecognizeRequest request, PreBaseRequest preBaseRequest) {
        logger.info("CreditAwardController-ocrRecognize-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);

        BaseResponse<OCRResultDto> response = ResponseUtil.createDefaultResponse();
        OCRResultDto result = null;
        try {
            ValidateUtil.validate(request);
            result = creditAwardService.ocrRecognize(request);
            ResponseUtil.success(response, result);
        } catch (Exception e) {
            logger.error("CreditAwardController-ocrRecognize-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            ResponseUtil.handleException(response, e);
        }

        logger.info("CreditAwardController-ocrRecognize-请求结束, reqNo-{}-返回-{}", request.getReqNo(), response);

        return response;
    }

    /**
     * 授信申请
     *
     * @param preBaseRequest
     * @return
     */
    @RequestMapping("/creditAwardApply")
    @ResponseBody
    public BaseResponse<CreditAwardApplyDto> creditAwardApply(PreBaseRequest preBaseRequest) {
        logger.info("CreditAwardController-creditAwardApply-请求开始, reqNo-{}-请求参数-{}", preBaseRequest.getReqNo(), preBaseRequest);

        BaseResponse<CreditAwardApplyDto> response = ResponseUtil.createDefaultResponse();
        UserDto userDto = queryUserByToken(preBaseRequest);
        try {
            CreditAwardApplyDto creditAwardApplyDto = creditAwardService.creditAwardApply(userDto);
            ResponseUtil.success(response, creditAwardApplyDto);
        } catch (Exception e) {
            logger.error("CreditAwardController-creditAwardApply-请求异常, reqNo-{}-{}", preBaseRequest.getReqNo(), ExceptionUtil.getType(e), e);
            ResponseUtil.handleException(response, e);
        } finally {
            redisAccess.releaseLock(preBaseRequest.getReqId());
        }

        logger.info("CreditAwardController-creditAwardApply-请求结束, reqNo-{}-返回-{}", preBaseRequest.getReqNo(), response);

        return response;
    }

    /**
     * 授信
     * 
     * @param request
     * @param preBaseRequest
     * @return
     */
    @RequestMapping("/creditAward")
    @ResponseBody
    public BaseResponse<CreditAwardDto> creditAward(CreditAwardRequest request, PreBaseRequest preBaseRequest) {
        logger.info("CreditAwardController-creditAward-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);

        BaseResponse<CreditAwardDto> response = ResponseUtil.createDefaultResponse();
        try {
            ValidateUtil.validate(request);
            UserDto userDto = queryUserByToken(preBaseRequest);
            CreditAwardDto creditAwardDto = creditAwardService.creditAward(request, userDto);
            ResponseUtil.success(response, creditAwardDto);
        } catch (Exception e) {
            logger.error("CreditAwardController-creditAward-请求异常, reqNo-{}-{}", preBaseRequest.getReqNo(), ExceptionUtil.getType(e), e);
            ResponseUtil.handleException(response, e);
        }

        logger.info("CreditAwardController-creditAward-请求结束, reqNo-{}-返回-{}", preBaseRequest.getReqNo(), response);

        return response;
    }
    
    /**
     * 提额
     * 
     * @param request
     * @param preBaseRequest
     * @return
     */
    @RequestMapping("/raiseQuota")
    @ResponseBody
    public BaseResponse<Void> raiseQuota(CreditAwardRaiseQuotaRequest request, PreBaseRequest preBaseRequest) {
        logger.info("CreditAwardController-raiseQuota-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);

        BaseResponse<Void> response = ResponseUtil.createDefaultResponse();
        try {
            ValidateUtil.validate(request);
            UserDto userDto = queryUserByToken(preBaseRequest);
            creditAwardService.raiseQuota(request, userDto);
            ResponseUtil.success(response, null);
        } catch (Exception e) {
            logger.error("CreditAwardController-raiseQuota-请求异常, reqNo-{}-{}", preBaseRequest.getReqNo(), ExceptionUtil.getType(e), e);
            ResponseUtil.handleException(response, e);
        }

        logger.info("CreditAwardController-raiseQuota-请求结束, reqNo-{}-返回-{}", preBaseRequest.getReqNo(), response);

        return response;
    }

    /**
     * 授信数据认证
     * 
     * @param request
     * @param
     * @return
     */
    @RequestMapping("/creditDataAuth")
    @ResponseBody
    public BaseResponse<Void> creditDataAuth(AuthDataRequest request) {
        logger.info("CreditAwardController-creditDataAuth-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);

        BaseResponse<Void> response = ResponseUtil.createDefaultResponse();
        try {
            ValidateUtil.validate(request);
            creditAwardService.creditDataAuth(request);
            ResponseUtil.success(response, null);
        } catch (Exception e) {
            logger.error("CreditAwardController-creditDataAuth-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            ResponseUtil.handleException(response, e);
        }

        logger.info("CreditAwardController-creditDataAuth-请求结束, reqNo-{}-返回-{}", request.getReqNo(), response);

        return response;
    }

    /**
     * 芝麻认证
     * 
     * @param request
     * @param
     * @return
     */
    @RequestMapping("/zmxyAuth")
    @ResponseBody
    public BaseResponse<ZmAuthResultDto> creditZmxyAuth(CreditZmxyAuthRequest request) {
        logger.info("CreditAwardController-creditZmxyAuth-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);

        BaseResponse<ZmAuthResultDto> response = ResponseUtil.createDefaultResponse();
        try {
            ValidateUtil.validate(request);
            String authUrl = creditAwardService.creditZmxyAuth(request);
            ZmAuthResultDto result = new ZmAuthResultDto();
            result.setAuthUrl(authUrl);
            ResponseUtil.success(response, result);
        } catch (Exception e) {
            logger.error("CreditAwardController-creditZmxyAuth-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            ResponseUtil.handleException(response, e);
        }

        logger.info("CreditAwardController-creditZmxyAuth-请求结束, reqNo-{}-返回-{}", request.getReqNo(), response);

        return response;
    }

    /**
     * 根据授信号查询授信各种状态
     *
     * @param request
     * @return
     */
    @RequestMapping("/queryCreditApplyStatus")
    @ResponseBody
    public BaseResponse<CreditApplyRecordQueryDto> queryCreditApplyStatus(CreditApplyRecordQueryRequest request) {
        logger.info("CreditApplyRecordController-creditApplyRecordQuery-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);

        BaseResponse<CreditApplyRecordQueryDto> baseResponse = ResponseUtil.createDefaultResponse();
        CreditApplyRecordQueryDto recordQueryDto = new CreditApplyRecordQueryDto();
        try {
            CreditApplyRecord record = applyRecordService.queryDataByCreditAwardNo(request.getCreditAwardNo());
            if (record == null) {
                recordQueryDto = null;
            } else {
                CommonBeanCopier.copy(record, recordQueryDto);
            }
            ResponseUtil.success(baseResponse, recordQueryDto);
        } catch (Exception e) {
            logger.error("CreditApplyRecordController-creditApplyRecordQuery-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            ResponseUtil.handleException(baseResponse, e);
        }

        logger.info("CreditApplyRecordController-creditApplyRecordQuery-请求结束, reqNo-{}-返回-{}", request.getReqNo(), baseResponse);
        return baseResponse;
    }

    /**
     * 根据授信号查询授信信息
     *
     * @param request
     * @return
     */
    @RequestMapping("/queryCreditAwardInfo")
    @ResponseBody
    public BaseResponse<CreditAwardInfoDto> queryCreditAwardInfo(CreditAwardRequest request, PreBaseRequest preBaseRequest){
        logger.info("CreditAwardController-queryCreditAwardInfo-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);

        BaseResponse<CreditAwardInfoDto> response = ResponseUtil.createDefaultResponse();
        try {
            UserDto userDto = queryUserByToken(preBaseRequest);
            request.setAccountId(userDto.getProdAccountId());
            request.setProductCode(CashLoanConstant.product_code);
            CreditAwardInfoDto creditAwardInfo = creditAwardRemoteService.queryCreditAwardInfo(request);
            ResponseUtil.success(response, creditAwardInfo);

        }catch(Exception e){
            logger.error("CreditAwardController-queryCreditAwardInfo-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            ResponseUtil.handleException(response, e);
        }
        logger.info("CreditAwardController-queryCreditAwardInfo-请求结束, reqNo-{}-返回-{}", request.getReqNo(), response);
        return response;
    }

    /**
     * 根据授信号查询授信联系人信息
     *
     * @param request
     * @return
     */
    @RequestMapping("/queryCreditAwardContacts")
    @ResponseBody
    public BaseResponse<List<ContactsInfoDto>> queryCreditAwardContacts(CreditAwardRequest request, PreBaseRequest preBaseRequest){
        logger.info("CreditAwardController-queryCreditAwardContacts-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);

        BaseResponse<List<ContactsInfoDto>> response = ResponseUtil.createDefaultResponse();
        try {
            UserDto userDto = queryUserByToken(preBaseRequest);
            request.setAccountId(userDto.getProdAccountId());
            request.setProductCode(CashLoanConstant.product_code);
            List<ContactsInfoDto> contactsInfoDtoList = creditAwardRemoteService.queryContactsByCreditAwardNo(request);
            ResponseUtil.success(response, contactsInfoDtoList);

        }catch(Exception e){
            logger.error("CreditAwardController-queryCreditAwardContacts-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            ResponseUtil.handleException(response, e);
        }
        logger.info("CreditAwardController-queryCreditAwardContacts-请求结束, reqNo-{}-返回-{}", request.getReqNo(), response);
        return response;
    }

}
