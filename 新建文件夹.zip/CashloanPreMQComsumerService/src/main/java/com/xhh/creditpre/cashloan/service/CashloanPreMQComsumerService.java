package com.xhh.creditpre.cashloan.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Service;

import com.janty.core.util.FastJsonUtil;
import com.xhh.creditpre.cashloan.dto.NoticeBusinessMessageDto;

import javax.annotation.Resource;


@Service("cashloanPreMQComsumerService")
public class CashloanPreMQComsumerService{
    
    private final Logger logger = LoggerFactory.getLogger(getClass());

    @Resource
    private UserInnerMessageService userInnerMessageService;

    @RabbitListener(queues = {"topic.queue.loan_result.clpre","topic.queue.bizname.systemname"})
    public void businessMessage(Message message) {
        logger.info("CashloanPreMQComsumerService-businessMessage-请求开始,请求参数-{}", message);
        if(message == null || message.getBody() == null) {
            return;
        }
        try {
            String jsonStr = new String(message.getBody(),message.getMessageProperties().getContentEncoding());
            NoticeBusinessMessageDto noticeBusinessMessageDto = FastJsonUtil.json2obj(jsonStr, NoticeBusinessMessageDto.class);
            logger.info("输出对象{}",noticeBusinessMessageDto);
            userInnerMessageService.insertBusinessMessage(noticeBusinessMessageDto);
        }catch(Exception e) {
            logger.error("CashloanPreMQComsumerService-businessMessage-请求异常", e);
        }
        logger.info("CashloanPreMQComsumerService-businessMessage-请求结束");

    }

}
