package com.xhh.creditpre.cashloan.model;

import com.janty.core.dto.BaseModel;

import java.util.Date;

public class CredentialInfoDto extends BaseModel {

    private String  realName;

    private String  credentialNo;

    private String  credentialDepartment;

    private Date credentialExpireDate;

    private String  credentialFrontUrl;

    private String  credentialBackUrl;

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public String getCredentialNo() {
        return credentialNo;
    }

    public void setCredentialNo(String credentialNo) {
        this.credentialNo = credentialNo;
    }

    public String getCredentialDepartment() {
        return credentialDepartment;
    }

    public void setCredentialDepartment(String credentialDepartment) {
        this.credentialDepartment = credentialDepartment;
    }

    public Date getCredentialExpireDate() {
        return credentialExpireDate;
    }

    public void setCredentialExpireDate(Date credentialExpireDate) {
        this.credentialExpireDate = credentialExpireDate;
    }

    public String getCredentialFrontUrl() {
        return credentialFrontUrl;
    }

    public void setCredentialFrontUrl(String credentialFrontUrl) {
        this.credentialFrontUrl = credentialFrontUrl;
    }

    public String getCredentialBackUrl() {
        return credentialBackUrl;
    }

    public void setCredentialBackUrl(String credentialBackUrl) {
        this.credentialBackUrl = credentialBackUrl;
    }
}
