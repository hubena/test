package com.xhh.creditpre.cashloan.controller;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.janty.core.controller.BaseController;
import com.janty.core.dto.BaseResponse;
import com.janty.core.util.ExceptionUtil;
import com.janty.core.util.ResponseUtil;
import com.janty.core.util.ValidateUtil;
import com.xhh.creditpre.cashloan.dto.AppVersionDto;
import com.xhh.creditpre.cashloan.model.AppActivityBannerDto;
import com.xhh.creditpre.cashloan.model.AppActivityBannerRequest;
import com.xhh.creditpre.cashloan.model.AppDeviceInfoRequest;
import com.xhh.creditpre.cashloan.model.AppVersionRequest;
import com.xhh.creditpre.cashloan.service.AppActivityBannerService;
import com.xhh.creditpre.cashloan.service.AppVersionService;
import com.xhh.creditpre.cashloan.service.remote.PolarisRemoteService;

@RequestMapping("/app")
@Controller
public class AppController extends BaseController {

    @Resource
    private AppVersionService        appVersionService;

    @Resource
    private AppActivityBannerService appActivityBannerService;

    @Resource
    private PolarisRemoteService     polarisRemoteService;

    /**
     * 获取app升级信息
     * 
     * @param request
     * @return
     */
    @RequestMapping("/getAppVersionNo")
    @ResponseBody
    public BaseResponse<AppVersionDto> getAppVersionNo(AppVersionRequest request) {
        logger.info("AppController-getAppVerNo-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);

        BaseResponse<AppVersionDto> response = ResponseUtil.createDefaultResponse();
        try {
            // 参数校验
            ValidateUtil.validate(request);
            AppVersionDto result = appVersionService.getAppConfig(request);
            ResponseUtil.success(response, result);
        } catch (Exception e) {
            logger.error("AppController-getAppVerNo-请求异常, reqNo-{}-{}", "具体请求流水号", ExceptionUtil.getType(e), e);
            ResponseUtil.handleException(response, e);
        }
        logger.info("AppController-getAppVersionNo-请求结束, reqNo-{}-返回-{}", "", response);
        return response;
    }

    /**
     * 获取活动图片、首页banner
     *
     * @param request
     * @return
     */
    @RequestMapping("/getActivityPic")
    @ResponseBody
    public BaseResponse<List<AppActivityBannerDto>> getActivityPic(AppActivityBannerRequest request) {
        logger.info("AppController-getActivityPic-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);

        BaseResponse<List<AppActivityBannerDto>> response = ResponseUtil.createDefaultResponse();

        try {
            // 参数校验
            ValidateUtil.validate(request);
            List<AppActivityBannerDto> result = appActivityBannerService.getActivityPic(request);
            ResponseUtil.success(response, result);
        } catch (Exception e) {
            logger.error("AppController-getActivityPic-请求异常, reqNo-{}-{}", "具体请求流水号", ExceptionUtil.getType(e), e);
            ResponseUtil.handleException(response, e);
        }

        logger.info("AppController-getActivityPic-请求结束, reqNo-{}-返回-{}", "", response);

        return response;
    }

    /**
     * 设备信息上传
     * 
     * @param request
     * @return
     */
    @RequestMapping("/uploadDeviceInfo")
    @ResponseBody
    public BaseResponse<Void> uploadDeviceInfo(AppDeviceInfoRequest request) {
        logger.info("AppController-uploadDeviceInfo-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);

        BaseResponse<Void> response = ResponseUtil.createDefaultResponse();
        try {
            // 参数校验
            ValidateUtil.validate(request);
            polarisRemoteService.uploadDeviceInfo(request);
            ResponseUtil.success(response, null);
        } catch (Exception e) {
            logger.error("AppController-uploadDeviceInfo-请求异常, reqNo-{}-{}", "具体请求流水号", ExceptionUtil.getType(e), e);
            ResponseUtil.handleException(response, e);
        }
        return response;
    }

}
