package com.xhh.creditpre.cashloan.enums;

/**
 * @author zhangliang
 * @Date:Create in 2018/2/5
 */
public enum StatusType {
    /**
     * 状态
     */
    EFFECTIVE(1, "有效"),
    NOT_EFFECTIVE(2, "失效");

    private Integer key;
    private String  desc;

    public Integer getKey() {
        return key;
    }

    public String getDesc() {
        return desc;
    }

    StatusType(Integer key, String desc) {
        this.key = key;
        this.desc = desc;
    }

    public StatusType getByKey(Integer key) {
        for (StatusType statusType : StatusType.values()) {
            if (statusType.key.equals(key)) {
                return statusType;
            }
        }
        return null;
    }
}
