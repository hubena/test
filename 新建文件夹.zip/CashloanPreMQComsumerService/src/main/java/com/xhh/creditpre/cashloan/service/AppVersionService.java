package com.xhh.creditpre.cashloan.service;

import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.collections.CollectionUtils;
import org.apache.ibatis.session.RowBounds;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;
import com.janty.core.dto.PageData;
import com.janty.core.dto.Pager;
import com.janty.core.util.CommonBeanCopier;
import com.janty.mybatis.util.CountHelper;
import com.xhh.creditpre.cashloan.converter.AppConverter;
import com.xhh.creditpre.cashloan.dao.AppVersionMapper;
import com.xhh.creditpre.cashloan.dto.AppVersionDto;
import com.xhh.creditpre.cashloan.dto.AppVersionQueryRequest;
import com.xhh.creditpre.cashloan.model.AppVersion;
import com.xhh.creditpre.cashloan.model.AppVersionRequest;

/**
 * AppVersion服务类
 *
 * @author jan
 * @date 2018-1-9 11:06:59
 */
@Service
public class AppVersionService {
    @Resource
    private AppVersionMapper appVersionMapper;

    public AppVersionDto getAppConfig(AppVersionRequest request) {
        List<AppVersionDto> appVersionDtoList = AppConverter.toAppVerNoDto(appVersionMapper.list(request.getAppId()));

        //遍历比较两个版本号大小
        for (AppVersionDto appVersionDto : appVersionDtoList) {
            if (compareVersion(appVersionDto.getVersion(), request.getVersion()) > 0) {
                return appVersionDto;
            }
        }
        return null;
    }

    /**
     * 比较两个版本号大小
     *
     * @param version1
     * @param version2
     * @return version1-version2
     */
    public static int compareVersion(String version1, String version2) {

        //注意此处为正则匹配，不能用.；
        String[] versionArray1 = version1.split("\\.");
        String[] versionArray2 = version2.split("\\.");
        int idx = 0;
        //取最小长度值
        int minLength = Math.min(versionArray1.length, versionArray2.length);
        int diff = 0;
        while (idx < minLength && (diff = versionArray1[idx].length() - versionArray2[idx].length()) == 0//先比较长度
                && (diff = versionArray1[idx].compareTo(versionArray2[idx])) == 0) {//再比较字符
            ++idx;
        }
        //如果已经分出大小，则直接返回，如果未分出大小，则再比较位数，有子版本的为大；
        diff = (diff != 0) ? diff : versionArray1.length - versionArray2.length;
        return diff;
    }

    /**
     * 分页查询版本信息
     * 
     * @param request
     * @return
     */
    public PageData<AppVersionDto> queryAppVersionByPage(AppVersionQueryRequest request, Pager pager) {
        RowBounds rowBounds = new RowBounds(pager.getOffset(), pager.getPageSize());
        List<AppVersion> list = appVersionMapper.queryAPPVersionByPage(request, rowBounds);
        List<AppVersionDto> data = null;
        if (!CollectionUtils.isEmpty(list)) {
            data = Lists.newArrayList();
            AppVersionDto dto = null;
            for (AppVersion element : list) {
                dto = new AppVersionDto();
                BeanUtils.copyProperties(element, dto);
                CommonBeanCopier.copy(element, dto);
                data.add(dto);
            }
        }
        PageData<AppVersionDto> page = new PageData<AppVersionDto>();
        page.assembleResult(pager, data, CountHelper.getTotalRow());
        return page;
    }

    /**
     * 新增数据
     * 
     * @param record 实体
     */
    public void addData(AppVersion record) {
        appVersionMapper.insertSelective(record);
    }

    /**
     * 修改数据
     * 
     * @param record 实体
     */
    public void modifyData(AppVersion record) {
        appVersionMapper.updateByPrimaryKeySelective(record);
    }

    /**
     * 删除数据
     * 
     * @param id 主键id
     */
    public void deleteData(Long id) {
        appVersionMapper.deleteByPrimaryKey(id);
    }
}
