package com.xhh.creditpre.cashloan.enums;

/**
 * 活动图片类型
 */
public enum PicType {
    startPic(1, "启动广告页"),

    banner(2, "首页banner"),

    popPic(3, "弹出广告页");

    /**
     * 通过key获取枚举
     *
     * @param key
     * @return
     */
    public static PicType getByKey(int key) {
        switch (key) {
            case 1:
                return startPic;
            case 2:
                return banner;
            case 3:
                return popPic;
            default:
                return null;
        }
    }

    private int    key;
    private String desc;

    /**
     * 私有构造
     *
     * @param key
     * @param desc
     */
    private PicType(int key, String desc) {
        this.key = key;
        this.desc = desc;
    }

    public int getKey() {
        return key;
    }

    public String getDesc() {
        return desc;
    }
}
