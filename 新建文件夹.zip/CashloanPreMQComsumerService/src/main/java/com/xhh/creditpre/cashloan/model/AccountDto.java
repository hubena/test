package com.xhh.creditpre.cashloan.model;

import com.janty.core.dto.BaseModel;

/**
 * author zhangliang
 *
 * @Date:Create in 2018/1/15
 */
public class AccountDto extends BaseModel {
    //产品账户id
    private Long accountId;

    public Long getAccountId() {
        return accountId;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }
}
