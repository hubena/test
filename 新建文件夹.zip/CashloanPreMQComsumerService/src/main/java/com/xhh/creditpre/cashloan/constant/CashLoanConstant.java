package com.xhh.creditpre.cashloan.constant;

public interface CashLoanConstant {
    String product_code          = "100001";

    /**
     * 防重复锁,锁定时间
     */
    long   repeat_lock_time_long = 60 * 1000L;

    /**
     * 默认渠道编码密文
     */
    String secretCode            = "7d5563f495e525dedb0b69d4a53e6bf7";

    /**
     * 短信模板的参数
     */
    String msg_code              = "code";
    /**
     * 项目名称
     */
    String project_name          = "xhh_cashloan";
    /**
     * 默认图片文件后缀
     */
    String default_img_suffix    = ".jpg";
    /**
     * 文件根目录
     */
    String file_root_dir         = "/data/file";

    /**
     * 上传根目录
     */
    String file_upload_dir       = "/upload";

    /**
     * base64字符串含有的字符
     */
    String base64_index          = "data:image/jpeg;base64,";
}
