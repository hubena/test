package com.xhh.creditpre.cashloan.controller;

import com.janty.core.dto.BaseResponse;
import com.janty.core.dto.StringRequest;
import com.janty.core.util.ExceptionUtil;
import com.janty.core.util.ResponseUtil;
import com.janty.core.util.ValidateUtil;
import com.xhh.creditcore.capital.dto.AccountBankCardDto;
import com.xhh.creditcore.transaction.dto.MainAccountDto;
import com.xhh.creditcore.transaction.dto.OpenAccountDto;
import com.xhh.creditpre.cashloan.model.*;
import com.xhh.creditpre.cashloan.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * author zhangliang
 *
 * @Date:Create in 2018/1/11
 */
@Controller
@RequestMapping("/account")
public class AccountController extends WrapperController {

    @Autowired
    private AccountService accountService;

    /**
     * 开户
     *
     * @param request
     * @return
     */
    @RequestMapping("/openAccount")
    @ResponseBody
    public BaseResponse<OpenAccountDto> openAccount(final OpenAccountRequest request, final PreBaseRequest preBaseRequest) {
        logger.info("AccountController-openAccount-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);

        BaseResponse<OpenAccountDto> response = ResponseUtil.createDefaultResponse();

        try {
            ValidateUtil.validate(request);
            ValidateUtil.validate(preBaseRequest);
            response = safeExecute(new SafeExecutor<OpenAccountDto, OpenAccountRequest>() {
                BaseResponse<OpenAccountDto> baseResponse = ResponseUtil.createDefaultResponse();
                OpenAccountDto               dto          = null;

                @Override
                public BaseResponse<OpenAccountDto> execute() throws Exception {
                    UserDto userDto = queryUserByToken(preBaseRequest);
                    dto = accountService.openAccount(request, userDto, preBaseRequest.getToken());
                    ResponseUtil.success(baseResponse, dto);
                    return baseResponse;
                }

                @Override
                public OpenAccountRequest getBaseRequest() {
                    return request;
                }
            });

        } catch (Exception e) {
            logger.error("AccountController-openAccount-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            ResponseUtil.handleException(response, e);
        }

        logger.info("AccountController-openAccount-请求结束, reqNo-{}-返回-{}", request.getReqNo(), response);

        return response;
    }

    /**
     * 获取产品子账户id
     *
     * @param request
     * @return
     */
    @RequestMapping("/getAccountId")
    @ResponseBody
    public BaseResponse<AccountDto> getAccountId(PreBaseRequest request) {
        logger.info("AccountController-getAccountId-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);

        BaseResponse<AccountDto> response = ResponseUtil.createDefaultResponse();
        AccountDto dto = new AccountDto();
        try {
            ValidateUtil.validate(request);
            UserDto userDto = queryUserByToken(request);
            dto.setAccountId(userDto.getProdAccountId());
            ResponseUtil.success(response, dto);
        } catch (Exception e) {
            logger.error("AccountController-getAccountId-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            ResponseUtil.handleException(response, e);
        }

        logger.info("AccountController-getAccountId-请求结束, reqNo-{}-返回-{}", request.getReqNo(), response);

        return response;
    }

    /**
     * 查询主账户
     *
     * @param request
     * @return
     */
    @RequestMapping("/getMainAccount")
    @ResponseBody
    public BaseResponse<MainAccountDto> getMainAccount(PreBaseRequest request) {
        logger.info("AccountController-getMainAccount-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);

        BaseResponse<MainAccountDto> response = ResponseUtil.createDefaultResponse();
        MainAccountDto dto = null;
        try {
            ValidateUtil.validate(request);
            UserDto userDto = queryUserByToken(request);
            dto = accountService.getMainAccount(request, userDto);
            if (dto != null)
                dto.setPhone(userDto.getPhone());
            ResponseUtil.success(response, dto);
        } catch (Exception e) {
            logger.error("AccountController-getMainAccount-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            ResponseUtil.handleException(response, e);
        }

        logger.info("AccountController-getMainAccount-请求结束, reqNo-{}-返回-{}", request.getReqNo(), response);

        return response;
    }

    /**
     * 查询账户绑卡信息     *
     * @param request
     * @return
     */
    @RequestMapping("/getAccountBankCard")
    @ResponseBody
    public BaseResponse<AccountBankCardDto> getAccountBankCard(PreBaseRequest request) {
        logger.info("AccountController-getAccountBankCard-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);

        BaseResponse<AccountBankCardDto> response = ResponseUtil.createDefaultResponse();
        AccountBankCardDto dto = null;
        try {
            ValidateUtil.validate(request);
            UserDto userDto = queryUserByToken(request);
            dto = accountService.getAccountBankCard(request, userDto);
            ResponseUtil.success(response, dto);
        } catch (Exception e) {
            logger.error("AccountController-getAccountBankCard-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            ResponseUtil.handleException(response, e);
        }

        logger.info("AccountController-getAccountBankCard-请求结束, reqNo-{}-返回-{}", request.getReqNo(), response);

        return response;
    }

    /**
     * 查询主账户和身份证图片信息
     *
     * @param creditAwardNo
     * @return
     */
    @RequestMapping("/getCredentialInfo")
    @ResponseBody
    public BaseResponse<CredentialInfoDto> getCredentialInfo(String creditAwardNo, PreBaseRequest preBaseRequest){
        logger.info("AccountController-getCredentialInfo-请求开始, reqNo-{}-请求参数-{}", preBaseRequest.getReqNo(), creditAwardNo);

        BaseResponse<CredentialInfoDto> response = ResponseUtil.createDefaultResponse();
        CredentialInfoDto dto = null;
        try {
            UserDto userDto = queryUserByToken(preBaseRequest);
            StringRequest request = new StringRequest();
            request.setParam(creditAwardNo);
            request.setReqNo(preBaseRequest.getReqNo());
            dto = accountService.getCredentialInfo(request, userDto);
            ResponseUtil.success(response, dto);
        } catch (Exception e) {
            logger.error("AccountController-getMainAccount-请求异常, reqNo-{}-{}", preBaseRequest.getReqNo(), ExceptionUtil.getType(e), e);
            ResponseUtil.handleException(response, e);
        }

        logger.info("AccountController-getMainAccount-请求结束, reqNo-{}-返回-{}", preBaseRequest.getReqNo(), response);

        return response;
    }
}
