package com.xhh.creditpre.cashloan.controller;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.janty.core.controller.BaseController;
import com.janty.core.dto.BaseResponse;
import com.janty.core.util.ExceptionUtil;
import com.janty.core.util.ResponseUtil;
import com.xhh.creditpre.cashloan.service.InnerMessageService;

/**
 * @author zhangliang
 * @Date:Create in 2018/2/28 14:03
 */
@RestController
@RequestMapping("/task")
public class TaskController extends BaseController{

    @Resource
    private InnerMessageService innerMessageService;

    @RequestMapping("/sendInnerMessage")
    public BaseResponse<Void> sendInnerMessage(){
        logger.info("TaskController-sendInnerMessage-请求开始");

        BaseResponse<Void> response = ResponseUtil.createDefaultResponse();
        try {
            innerMessageService.sendInnerMessage();
            ResponseUtil.success(response, null);
        } catch (Exception e) {
            logger.error("TaskController-sendInnerMessage-请求异常, reqNo-{}-{}", ExceptionUtil.getType(e), e);
            ResponseUtil.handleException(response, e);
        }

        logger.info("TaskController-sendInnerMessage-请求结束, 返回-{}", response);

        return response;
    }
}
