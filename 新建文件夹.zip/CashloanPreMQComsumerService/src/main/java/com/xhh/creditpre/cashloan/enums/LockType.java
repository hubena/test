package com.xhh.creditpre.cashloan.enums;

/**
 * @author zhangliang
 * @Date:Create in 2018/2/5
 */
public enum LockType {
    /**
     * 是否被锁
     */
    LOCK(1, "已锁"),
    NOT_LOCK(2, "未锁");

    private Integer key;
    private String  desc;

    public Integer getKey() {
        return key;
    }

    public String getDesc() {
        return desc;
    }

    LockType(Integer key, String desc) {
        this.key = key;
        this.desc = desc;
    }

    public LockType getByKey(Integer key) {
        for (LockType lockType : LockType.values()) {
            if (lockType.key.equals(key)) {
                return lockType;
            }
        }
        return null;
    }
}
