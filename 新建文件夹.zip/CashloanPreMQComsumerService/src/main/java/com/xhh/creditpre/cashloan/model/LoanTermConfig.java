package com.xhh.creditpre.cashloan.model;

import java.math.BigDecimal;
import java.util.Date;

public class LoanTermConfig {
    private Long       id;

    private Integer    termType;

    private Integer    term;

    private Integer    amountType;

    private Integer    status;

    private Date       gmtCreated;

    private Date       gmtModified;

    private String     creator;

    private String     modifier;

    private String     isDeleted;

    private BigDecimal amountScopeStart;

    private BigDecimal amountScopeEnd;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getTermType() {
        return termType;
    }

    public void setTermType(Integer termType) {
        this.termType = termType;
    }

    public Integer getTerm() {
        return term;
    }

    public void setTerm(Integer term) {
        this.term = term;
    }

    public Integer getAmountType() {
        return amountType;
    }

    public void setAmountType(Integer amountType) {
        this.amountType = amountType;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Date getGmtCreated() {
        return gmtCreated;
    }

    public void setGmtCreated(Date gmtCreated) {
        this.gmtCreated = gmtCreated;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator == null ? null : creator.trim();
    }

    public String getModifier() {
        return modifier;
    }

    public void setModifier(String modifier) {
        this.modifier = modifier == null ? null : modifier.trim();
    }

    public String getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(String isDeleted) {
        this.isDeleted = isDeleted == null ? null : isDeleted.trim();
    }

    public BigDecimal getAmountScopeStart() {
        return amountScopeStart;
    }

    public void setAmountScopeStart(BigDecimal amountScopeStart) {
        this.amountScopeStart = amountScopeStart;
    }

    public BigDecimal getAmountScopeEnd() {
        return amountScopeEnd;
    }

    public void setAmountScopeEnd(BigDecimal amountScopeEnd) {
        this.amountScopeEnd = amountScopeEnd;
    }
}
