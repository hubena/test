package com.xhh.creditpre.cashloan.service;

import java.util.Date;

import org.springframework.stereotype.Service;

import com.janty.core.util.DateUtil;
import com.xhh.creditpre.cashloan.constant.UMengConstant;
import com.xhh.creditpre.cashloan.enums.UmengMode;

import net.sf.json.JSONObject;
import umeng.push.AndroidNotification;
import umeng.push.PushClient;
import umeng.push.android.AndroidBroadcast;
import umeng.push.android.AndroidFilecast;
import umeng.push.android.AndroidUnicast;
import umeng.push.ios.IOSBroadcast;
import umeng.push.ios.IOSFilecast;
import umeng.push.ios.IOSUnicast;

/**
 * @author zhangliang
 * @Date:Create in 2018/3/1 10:28
 */
@Service("uMengService")
public class UMengService {

    private PushClient client = new PushClient();

    /**
     * 安卓广播信息
     * @throws Exception
     */
    public boolean sendAndroidBroadcast(String title,String content) throws Exception {
        AndroidBroadcast broadcast = new AndroidBroadcast(UMengConstant.getInstance().androidAppkey,UMengConstant.getInstance().iosMastersecret);
        broadcast.setTicker(title);
        broadcast.setTitle(title);
        broadcast.setText(content);
        broadcast.goAppAfterOpen();
        broadcast.setDisplayType(AndroidNotification.DisplayType.NOTIFICATION);
        // TODO Set 'production_mode' to 'false' if it's a test device.
        // For how to register a test device, please see the developer doc.
        if (UMengConstant.getInstance().appProductionmode.equals(UmengMode.PRODUCTION.getDesc())){
            broadcast.setProductionMode();
        }else {
            broadcast.setTestMode();
        }
        // Set customized fields
        broadcast.setExtraField("test", "helloworld");
        return client.send(broadcast);
    }

    /**
     * 安卓单播信息
     * @throws Exception
     */
    public boolean sendAndroidUnicast(String title,String content,String deviceId) throws Exception {
        AndroidUnicast unicast = new AndroidUnicast(UMengConstant.getInstance().androidAppkey,UMengConstant.getInstance().androidMastersecret);
        // TODO Set your device token
        unicast.setDeviceToken(deviceId);
        unicast.setTicker(title);
        unicast.setTitle(title);
        unicast.setText(content);
        unicast.goAppAfterOpen();
        unicast.setDisplayType(AndroidNotification.DisplayType.NOTIFICATION);
        // TODO Set 'production_mode' to 'false' if it's a test device.
        if (UMengConstant.getInstance().appProductionmode.equals(UmengMode.PRODUCTION.getDesc())){
            unicast.setProductionMode();
        }else {
            unicast.setTestMode();
        }
        // Set customized fields
        unicast.setExtraField("test", "helloworld");
        return client.send(unicast);
    }

    /**
     * 安卓-文件播
     * @throws Exception
     */
    public boolean sendAndroidFilecast(String title,String content,String deviceIds) throws Exception {
        AndroidFilecast filecast = new AndroidFilecast(UMengConstant.getInstance().androidAppkey,UMengConstant.getInstance().androidMastersecret);
        // TODO upload your device tokens, and use '\n' to split them if there are multiple tokens
        String fileId = client.uploadContents(UMengConstant.getInstance().androidAppkey,UMengConstant.getInstance().iosMastersecret,deviceIds);
        filecast.setFileId( fileId);
        filecast.setTicker(title);
        filecast.setTitle(title);
        filecast.setText(content);
        filecast.goAppAfterOpen();
        filecast.setDisplayType(AndroidNotification.DisplayType.NOTIFICATION);
        if (UMengConstant.getInstance().appProductionmode.equals(UmengMode.PRODUCTION.getDesc())){
            filecast.setProductionMode();
        }else {
            filecast.setTestMode();
        }
        return client.send(filecast);
    }

    /**
     * ios 广播
     * @throws Exception
     */
    public boolean sendIOSBroadcast(String title,String content) throws Exception {
        IOSBroadcast broadcast = new IOSBroadcast(UMengConstant.getInstance().iosAppkey,UMengConstant.getInstance().iosMastersecret);
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("title",title);
//        jsonObject.put("subtitle",title);
        jsonObject.put("body",content);
        broadcast.setAlert(content);
        broadcast.setBadge(0);
        broadcast.setSound("default");
        broadcast.setExpireTime(DateUtil.dateToStringDefault(DateUtil.addDays(new Date(),3)));
        // TODO set 'production_mode' to 'true' if your app is under production mode
        if (UMengConstant.getInstance().appProductionmode.equals(UmengMode.PRODUCTION.getDesc())){
            broadcast.setProductionMode();
        }else {
            broadcast.setTestMode();
        }
        broadcast.setCustomizedField("test", "helloworld");
        return client.send(broadcast);
    }

    /**
     * ios-单播信息
     * @throws Exception
     */
    public boolean sendIOSUnicast(String title,String content,String deviceId) throws Exception {
        IOSUnicast unicast = new IOSUnicast(UMengConstant.getInstance().iosAppkey,UMengConstant.getInstance().iosMastersecret);
        // TODO Set your device token
        unicast.setDeviceToken(deviceId);
//        JSONObject jsonObject = new JSONObject();
//        jsonObject.put("title",title);
//        jsonObject.put("subtitle",title);
//        jsonObject.put("body",content);
        unicast.setAlert(content);
        unicast.setBadge(0);
        unicast.setSound("default");
        unicast.setExpireTime(DateUtil.dateToStringDefault(DateUtil.addDays(new Date(),3)));
        // TODO set 'production_mode' to 'true' if your app is under production mode
        if (UMengConstant.getInstance().appProductionmode.equals(UmengMode.PRODUCTION.getDesc())){
            unicast.setProductionMode();
        }else {
            unicast.setTestMode();
        }
        // Set customized fields
        unicast.setCustomizedField("test", "helloworld");
        return client.send(unicast);
    }

    /**
     * ios-文件播
     * @throws Exception
     */
    public boolean sendIOSFilecast(String title,String content,String deviceIds) throws Exception {
        IOSFilecast filecast = new IOSFilecast(UMengConstant.getInstance().iosAppkey,UMengConstant.getInstance().iosMastersecret);
        // TODO upload your device tokens, and use '\n' to split them if there are multiple tokens
        String fileId = client.uploadContents(UMengConstant.getInstance().iosAppkey,UMengConstant.getInstance().iosMastersecret,deviceIds);
        filecast.setFileId( fileId);
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("title",title);
//        jsonObject.put("subtitle",title);
        jsonObject.put("body",content);
        filecast.setAlert(content);
        filecast.setBadge(0);
        filecast.setSound("default");
        filecast.setExpireTime(DateUtil.dateToStringDefault(DateUtil.addDays(new Date(),3)));
        // TODO set 'production_mode' to 'true' if your app is under production mode
        if (UMengConstant.getInstance().appProductionmode.equals(UmengMode.PRODUCTION.getDesc())){
            filecast.setProductionMode();
        }else {
            filecast.setTestMode();
        }
        return client.send(filecast);
    }
}
