package test;

import base.BaseJUnitTest;
import com.xhh.creditpre.cashloan.controller.BankCardBinController;
import com.xhh.creditpre.cashloan.model.BankCardbinRequest;
import org.junit.Test;

import javax.annotation.Resource;

/**
 * @author zhangliang
 * @Date:Create in 2018/2/7
 */
public class CardBinTest extends BaseJUnitTest{

    @Resource
    private BankCardBinController bankCardBinController;
    @Test
    public void test(){

        BankCardbinRequest bankCardbinRequest = new BankCardbinRequest();
        bankCardbinRequest.setCardNo("6217000010081047295");
        bankCardBinController.getBankCardBin(bankCardbinRequest);
    }
}
