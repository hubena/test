package test;

import base.BaseJUnitTest;
import com.janty.core.dto.PageData;
import com.janty.core.dto.Pager;
import com.janty.core.util.CommonBeanCopier;
import com.janty.core.util.DateUtil;
import com.xhh.creditpre.cashloan.dto.*;
import com.xhh.creditpre.cashloan.enums.MessagePushType;
import com.xhh.creditpre.cashloan.model.InnerMessage;
import com.xhh.creditpre.cashloan.model.UserLoginRecord;
import com.xhh.creditpre.cashloan.service.InnerMessageService;
import com.xhh.creditpre.cashloan.service.UserInnerMessageService;
import org.junit.Test;
import scala.collection.immutable.Page;

import javax.annotation.Resource;
import java.util.*;

/**
 * @author zhangliang
 * @Date:Create in 2018/2/28 17:49
 */
public class InnerMessageTest extends BaseJUnitTest{

    @Resource
    private InnerMessageService innerMessageService;
    @Resource
    private UserInnerMessageService userInnerMessageService;

    @Test
    public void testQueryByPage(){
        InnerMessageRequest innerMessageRequest = new InnerMessageRequest();
        innerMessageRequest.setMsgType(1);
        Pager pager = new Pager();
        pager.setPageSize(10);
        pager.setPageNum(1);
        PageData<InnerMessageDto> pageData = innerMessageService.queryInnerMessageByPage(innerMessageRequest,pager);
        System.out.println(pageData);
    }

    @Test
    public void testInsertInnerMessage(){
        InnerMessageAddRequest innerMessageAddRequest = new InnerMessageAddRequest();
        innerMessageAddRequest.setMsgType(2);
        innerMessageAddRequest.setContent("营销信息内容");
        innerMessageAddRequest.setDirectUrl("www.baidu.com");
        innerMessageAddRequest.setPlanSendTime(DateUtil.getDateAfter(new Date(),3).toString());
        innerMessageAddRequest.setTitle("营销消息标题");
        innerMessageAddRequest.setSendType(1);
        innerMessageService.insertInnerMessage(innerMessageAddRequest);
    }

    @Test
    public void testUpdateInnerMessage(){
        MarketInnerMessageUpdateRequest marketInnerMessageUpdateRequest = new MarketInnerMessageUpdateRequest();
        marketInnerMessageUpdateRequest.setId(9l);
        marketInnerMessageUpdateRequest.setMsgType(2);
        marketInnerMessageUpdateRequest.setContent("营销信息内容");
        marketInnerMessageUpdateRequest.setDirectUrl("www.baidu.com");
        marketInnerMessageUpdateRequest.setPlanSendTime(DateUtil.getDateAfter(new Date(),11).toString());
        marketInnerMessageUpdateRequest.setTitle("营销消息标题");
        marketInnerMessageUpdateRequest.setSendType(1);
        innerMessageService.updateInnerMessage(marketInnerMessageUpdateRequest);
    }

    @Test
    public void testSend() throws Exception {
        String a = "http:\\/\\/www.google.com";
        System.out.println(a);
        a.replaceAll("\\\\","");
        System.out.println(a);
        a.replace("\\","");
        System.out.println(a);

    }

    @Test
    public void testSort(){
        List<UserLoginRecord> userLoginRecords = new ArrayList<>();
        UserLoginRecord u = new UserLoginRecord();
        u.setLastLoginTime(new Date());
        userLoginRecords.add(u);
        UserLoginRecord u2 = new UserLoginRecord();
        u2.setLastLoginTime(DateUtil.addDays(new Date(),-3));
        userLoginRecords.add(u2);
        Collections.sort(userLoginRecords, new Comparator<UserLoginRecord>() {
            @Override
            public int compare(UserLoginRecord o1, UserLoginRecord o2) {
                return o1.getLastLoginTime().toString().compareTo(o2.getLastLoginTime().toString());
            }
        });
        System.out.println(userLoginRecords.size());
        System.out.println(userLoginRecords.get(userLoginRecords.size()-1).getLastLoginTime());
    }

    @Test
    public void testMqMessagePush() throws Exception {
        NoticeBusinessMessageDto dto = new NoticeBusinessMessageDto();
        Map<String,String> map = new HashMap<>();
        dto.setAccountId(48l);
        dto.setMsgSubtype(MessagePushType.INCREASE_LIMIT_APPLY_SUBMIT_SUCCESS.getKey());
        dto.setMap(map);
        userInnerMessageService.insertBusinessMessage(dto);
    }

    @Test
    public void testAppQueryMessage(){
        Pager pager = new Pager();
        userInnerMessageService.selectMessagesByUserId(84l, pager);
//        MessageCountDto dto = userInnerMessageService.selectCountByUserId(1,84l);
//        List<UserInnerMessageDto> list = userInnerMessageService.selectMessagesByUserId(84l);
//        UserInnerMessage userInnerMessage = new UserInnerMessage();
//        userInnerMessage.setId(4l);
//        userInnerMessage.setIsRead(2);
//        userInnerMessageService.updateStatusById(userInnerMessage);
//        System.out.println(list);
    }
    @Test
    public void testCopy(){
        InnerMessageAddRequest innerMessageAddRequest = new InnerMessageAddRequest();
        innerMessageAddRequest.setPlanSendTime("2018-09-08 12:44:00");
        InnerMessage innerMessage = new InnerMessage();
        CommonBeanCopier.copy(innerMessageAddRequest,innerMessage);
        innerMessage.setPlanSendTime(DateUtil.stringToDate(innerMessageAddRequest.getPlanSendTime()));
        System.out.println(innerMessage.getPlanSendTime());
    }
}
