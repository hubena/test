package test;

import base.BaseJUnitTest;
import com.xhh.creditpre.cashloan.util.SmsUtils;
import org.junit.Test;

/**
 * @author zhangliang
 * @Date:Create in 2018/1/26
 */
public class MsgTest extends BaseJUnitTest {

    @Test
    public void test() {
        SmsUtils.cacheCode("15914112496", "123456");
        //        SmsUtils.getInstance().verifyCode("15914112496","123456");
    }

}
