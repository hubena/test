package test;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.junit.Test;

import com.xhh.creditpre.cashloan.service.SendMessageService;
import com.xhh.infrastructure.messagecenter.dto.SendSmsMessageRequest;

import base.BaseJUnitTest;

/**
 * 类SendMessageTest.java的实现描述：TODO 类实现描述
 * 
 * @author xiehuang 2018年1月27日 下午1:48:19
 */
public class SendMessageTest extends BaseJUnitTest {

    @Resource
    private SendMessageService sendMessageService;

    @Test
    public void testSendMessageWhenRegister() {
        SendSmsMessageRequest request = new SendSmsMessageRequest();
        request.setSystemIp("127.0.0.1");
        request.setUserPhone("18898653106");
        request.setReqId("sdfs124112sd");
        request.setSmsOrder("sdfasdfws234ew3223sdca");
        Map<String, String> paramMap = new HashMap<>();
        paramMap.put("code", "123456");
        request.setParamMap(paramMap);
        sendMessageService.sendMessageWhenRegister(request);
    }

}
