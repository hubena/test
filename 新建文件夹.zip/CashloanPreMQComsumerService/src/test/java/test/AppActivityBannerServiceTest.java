package test;

import base.BaseJUnitTest;
import com.xhh.creditpre.cashloan.model.AppActivityBannerDto;
import com.xhh.creditpre.cashloan.model.AppActivityBannerRequest;
import com.xhh.creditpre.cashloan.service.AppActivityBannerService;
import org.junit.Test;

import javax.annotation.Resource;
import java.util.List;

public class AppActivityBannerServiceTest extends BaseJUnitTest {

    @Resource
    private AppActivityBannerService bannerService;

    @Test
    public void test() {
        AppActivityBannerRequest request = new AppActivityBannerRequest();
        request.setPicType(1);
        request.setTerminalType(1);
        request.setProductId(123456L);
        List<AppActivityBannerDto> bannerList = bannerService.getActivityPic(request);
        for (AppActivityBannerDto banner : bannerList) {
            System.out.println("ooooooooooooooooooooooooooo-------------" + banner.getTerminalType());
        }
    }
}
