package test;

import javax.annotation.Resource;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.xhh.creditcore.capital.dto.QueryBankCardbinRequest;
import com.xhh.creditpre.cashloan.api.CreditApplyRecordApi;
import com.xhh.creditpre.cashloan.controller.CreditAwardController;
import com.xhh.creditpre.cashloan.dto.CreditApplyRecordQueryDto;
import com.xhh.creditpre.cashloan.model.*;
import com.xhh.creditpre.cashloan.service.CreditApplyRecordService;
import com.xhh.creditpre.cashloan.service.CreditAwardService;
import com.xhh.creditpre.cashloan.service.remote.CapitalRemoteService;

import base.BaseJUnitTest;

/**
 * 交易查询服务测试
 *
 * @author qiujianfeng
 * @date 2014年12月26日
 */
public class CreditAwardTest extends BaseJUnitTest {
    @Resource
    CreditAwardService               creditAwardService;
    @Resource
    private CreditAwardController    creditAwardController;

    @Resource
    public CreditApplyRecordApi      applyRecordApi;

    @Resource
    public CreditAwardController     awardController;

    @Autowired
    private CapitalRemoteService     capitalRemoteService;
    @Resource
    private CreditApplyRecordService applyRecordService;

    @Test
    public void testCreditAwardApply() {

        UserDto userDto = new UserDto();
        userDto.setAccountId(2L);
        userDto.setId(22L);
        creditAwardService.creditAwardApply(userDto);
    }

    @Test
    public void testQueryLatestCreditAward() {
        PreBaseRequest preBaseRequest = new PreBaseRequest();
        preBaseRequest.setUserId(25L);
        preBaseRequest.setToken("201801291359467641305a6eb85294b68b3104bd28681517205586056");

        creditAwardController.queryLatestCreditAward(preBaseRequest);

    }

    @Test
    public void testOcr() {

        PreOcrRecognizeRequest preOcrRecognizeRequest = new PreOcrRecognizeRequest();
        preOcrRecognizeRequest.setImgBase64("hsdkfadgsjkgfhdgfhasghkdjaskldhkjasgdjhgashhasdhsg");
        PreBaseRequest preBaseRequest = new PreBaseRequest();
        preOcrRecognizeRequest.setOcrType("bank");
        creditAwardController.ocrRecognize(preOcrRecognizeRequest, preBaseRequest);
    }

    @Test
    public void testFaceRecognize() {
        PreFaceRequest preFaceRequest = new PreFaceRequest();
        PreBaseRequest preBaseRequest = new PreBaseRequest();
        preFaceRequest.setCreditAwardNo("2");
        preFaceRequest.setFaceBase64("asd");
        preFaceRequest.setType(1);
        preBaseRequest.setUserId(1L);
        preBaseRequest.setToken("201801231646337510045a66f669ccd1611af85927081516697193284");
        creditAwardController.faceRecognize(preFaceRequest, preBaseRequest);
    }

    @Test
    public void testBindCard() {
        PreBindBankRequest bindBankRequest = new PreBindBankRequest();
        bindBankRequest.setAccountCardNo("341281199302111611");
        bindBankRequest.setAccountMobile("15914112496");
        bindBankRequest.setAccountName("张亮");
        bindBankRequest.setCreditAwardNo("2");
        bindBankRequest.setBankCardNo("6216602000000327013");
        PreBaseRequest preBaseRequest = new PreBaseRequest();
        preBaseRequest.setUserId(1L);
        preBaseRequest.setToken("201801231646337510045a66f669ccd1611af85927081516697193284");
        creditAwardController.bindBank(bindBankRequest, preBaseRequest);
    }

    @Test
    public void testCardBin() {
        QueryBankCardbinRequest queryBankCardbinRequest = new QueryBankCardbinRequest();
        queryBankCardbinRequest.setCardNo("6216602000000327013");
        capitalRemoteService.queryBankCardbin(queryBankCardbinRequest);//BankCardbinDto bankCardbinDto =
    }

    @Test
    public void queryCreditAwardRecord() {
        /*
         * CreditApplyRecord creditApplyRecord =
         * applyRecordService.queryDataByCreditAwardNo("123456");
         * System.out.println(creditApplyRecord);
         */
        CreditApplyRecordQueryRequest queryRequest = new CreditApplyRecordQueryRequest();
        queryRequest.setCreditAwardNo("1086324592018012514420786360");
        CreditApplyRecordQueryDto queryDto = applyRecordApi.queryCreditApplyRecord(null);
        System.out.println(queryDto);
        System.out.println(awardController.queryCreditApplyStatus(queryRequest));
    }
}
