package test;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.xhh.creditcore.capital.dto.AccountBankCardDto;
import com.xhh.creditpre.cashloan.model.OpenAccountRequest;
import com.xhh.creditpre.cashloan.model.PreBaseRequest;
import com.xhh.creditpre.cashloan.model.UserDto;
import com.xhh.creditpre.cashloan.service.AccountService;

import base.BaseJUnitTest;

/**
 * author zhangliang
 *
 * @Date:Create in 2018/1/23
 */
public class AccountTest extends BaseJUnitTest {

    //    @Autowired
    //    private AccountController accountController;
    @Autowired
    private AccountService accountService;

    @Test
    public void testOpenAccount() {
        final OpenAccountRequest request = new OpenAccountRequest();
        final PreBaseRequest preBaseRequest = new PreBaseRequest();
        request.setCredentialNo("341281199302111611");
        request.setRealName("张亮");
        preBaseRequest.setToken("201801231646337510045a66f669ccd1611af85927081516697193284");
        preBaseRequest.setUserId(1L);
        //        accountController.openAccount(request,preBaseRequest);
    }

    @Test
    public void testGetAccount() {
        PreBaseRequest preBaseRequest = new PreBaseRequest();
        preBaseRequest.setUserId(1L);
        preBaseRequest.setToken("201801231646337510045a66f669ccd1611af85927081516697193284");
        //        accountController.getAccountId(preBaseRequest);
    }

    @Test
    public void testGetMainAccount() {
        UserDto userDto = new UserDto();
        userDto.setAccountId(12l);
        userDto.setProdAccountId(12l);
        PreBaseRequest preBaseRequest = new PreBaseRequest();
        preBaseRequest.setUserId(32L);
        //        accountController.getMainAccount(preBaseRequest);

        AccountBankCardDto mainAccountDto = accountService.getAccountBankCard(preBaseRequest, userDto);
        System.out.println(mainAccountDto);
    }
}
