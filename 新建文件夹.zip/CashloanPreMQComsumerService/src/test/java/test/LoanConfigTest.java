package test;

import javax.annotation.Resource;

import org.junit.Test;

import com.xhh.creditpre.cashloan.controller.LoanConfigController;
import com.xhh.creditpre.cashloan.model.LoanConfigRequest;

import base.BaseJUnitTest;

/**
 * @author zhangliang
 * @Date:Create in 2018/1/31
 */
public class LoanConfigTest extends BaseJUnitTest {

    @Resource
    private LoanConfigController loanConfigController;

    @Test
    public void testQuery() {

        LoanConfigRequest loanConfigRequest = new LoanConfigRequest();
        loanConfigRequest.setAmountType(2);
        loanConfigController.queryLoanConfig(loanConfigRequest);
    }
}
