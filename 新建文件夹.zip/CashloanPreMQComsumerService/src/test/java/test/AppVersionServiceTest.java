package test;

import base.BaseJUnitTest;

import com.xhh.creditpre.cashloan.dto.AppVersionDto;
import com.xhh.creditpre.cashloan.model.AppVersionRequest;
import com.xhh.creditpre.cashloan.service.AppVersionService;
import org.junit.Test;

import javax.annotation.Resource;

public class AppVersionServiceTest extends BaseJUnitTest {
    @Resource
    AppVersionService appVersionService;

    @Test
    public void test() {
        AppVersionRequest request = new AppVersionRequest();
        request.setAppId("1");
        request.setVersion("1.0.0");
        AppVersionDto appVersionDto = appVersionService.getAppConfig(request);
        System.out.println(appVersionDto.getAppId());
    }
}
