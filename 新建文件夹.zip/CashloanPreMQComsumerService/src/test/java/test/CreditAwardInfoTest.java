package test;

import base.BaseJUnitTest;
import com.xhh.creditcore.transaction.dto.CreditAwardContactsDto;
import com.xhh.creditcore.transaction.dto.CreditAwardInfoRequest;
import com.xhh.creditpre.cashloan.service.remote.CreditAwardRemoteService;
import org.junit.Test;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

public class CreditAwardInfoTest extends BaseJUnitTest {

    @Resource
    CreditAwardRemoteService creditAwardRemoteService;

    @Test
    public void test() {
        CreditAwardInfoRequest request = new CreditAwardInfoRequest();
        List<CreditAwardContactsDto> list = new ArrayList<CreditAwardContactsDto>();
        CreditAwardContactsDto contacts1 = new CreditAwardContactsDto();
        contacts1.setCredentialType("1");
        contacts1.setRelationship("3");
        contacts1.setMobileNo("12345678912");
        contacts1.setCredentialNo("3410202121541223541");
        contacts1.setRealName("小红");
        CreditAwardContactsDto contacts2 = new CreditAwardContactsDto();
        contacts2.setCredentialType("1");
        contacts2.setRelationship("4");
        contacts2.setCredentialNo("88545151122555");
        contacts2.setMobileNo("15112311231");
        contacts2.setRealName("小强");
        list.add(contacts1);
        list.add(contacts2);

        request.setAccountId(1L);
        request.setProductCode("100001");
        request.setCreditAwardNo("1");
        request.setFullAddress("特别详细的地址");
        request.setCityCode("123456");
        request.setAddressDetail("深圳市南山区");
        request.setChildNums(4);
        request.setContactsList(list);

        creditAwardRemoteService.updateCreditAwardInfo(request);
    }
}
