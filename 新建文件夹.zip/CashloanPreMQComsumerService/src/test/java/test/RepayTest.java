package test;

import javax.annotation.Resource;

import com.xhh.creditpre.cashloan.model.PeriodRepayConfirmRequest;
import com.xhh.creditpre.cashloan.model.PeriodRepayPreRequest;
import com.xhh.creditpre.cashloan.model.PeriodRepaySendSmsRequest;
import org.junit.Test;

import com.xhh.creditpre.cashloan.service.remote.RepaymentRemoteService;

import base.BaseJUnitTest;

public class RepayTest extends BaseJUnitTest {

    @Resource
    RepaymentRemoteService remoteService;

    @Test
    public void testRepayPreRequest() {
        PeriodRepayPreRequest repayPreRequest = new PeriodRepayPreRequest();
        repayPreRequest.setAccountId(12L);
        repayPreRequest.setLoanOrderNo("1145242132018030514201271176");
        repayPreRequest.setTermNo(1);
        System.out.println(remoteService.repayPrePay(repayPreRequest));
    }

    @Test
    public void testRepayConfirmRequest() {
        PeriodRepayConfirmRequest periodRepayConfirmRequest = new PeriodRepayConfirmRequest();
        periodRepayConfirmRequest.setRepayOrderNo("1436533152018030515211381550");
        periodRepayConfirmRequest.setSmsCode("999999");
        System.out.println(remoteService.repayConfirmPay(periodRepayConfirmRequest));
    }

    @Test
    public void testRepaySmsRequest() {
        PeriodRepaySendSmsRequest periodRepaySendSmsRequest = new PeriodRepaySendSmsRequest();
        periodRepaySendSmsRequest.setRepayOrderNo("1436533152018030515211381550");
        System.out.println(remoteService.repaySendSms(periodRepaySendSmsRequest));
    }
}
