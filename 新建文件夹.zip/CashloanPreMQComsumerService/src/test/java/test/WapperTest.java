package test;

import javax.annotation.Resource;

import org.junit.Test;

import com.janty.cached.access.RedisCachedAccess;
import com.janty.core.dto.BaseResponse;
import com.janty.core.util.ResponseUtil;
import com.xhh.creditcore.transaction.dto.CreditAwardApplyDto;
import com.xhh.creditpre.cashloan.controller.AccountController;
import com.xhh.creditpre.cashloan.model.OpenAccountRequest;

import base.BaseJUnitTest;

public class WapperTest extends BaseJUnitTest {
    @Resource
    RedisCachedAccess<Object> cachedAccess;
    AccountController         accountController;

    @Test
    public void test() {
        Object result_prefix_111111 = cachedAccess.get("app_req_result_prefix_111112");
        System.out.println(result_prefix_111111);
    }

    @Test
    public void test2() {

        OpenAccountRequest accountRequest = new OpenAccountRequest();
        accountRequest.setReqId("111112");
        //        accountController.openAccount(accountRequest);

    }
    @Test
    public void test3() {
        BaseResponse<CreditAwardApplyDto> response = ResponseUtil.createDefaultResponse();
        cachedAccess.put("123456789", response, 60);
        Object value = cachedAccess.get("123456789");
        BaseResponse<CreditAwardApplyDto> result = null;
        if (value != null) {
            result =  (BaseResponse<CreditAwardApplyDto>) value;
        }
        System.out.println(result);
    }


}
