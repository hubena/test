package test;

import base.BaseJUnitTest;
import com.xhh.creditpre.cashloan.constant.UMengConstant;
import com.xhh.creditpre.cashloan.dto.NoticeBusinessMessageDto;
import com.xhh.creditpre.cashloan.enums.MessagePushType;
import com.xhh.creditpre.cashloan.service.UMengService;
import com.xhh.creditpre.cashloan.service.UserInnerMessageService;
import net.sf.json.JSONObject;
import org.junit.Test;
import umeng.push.ios.IOSUnicast;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;

/**
 * @author zhangliang
 * @Date:Create in 2018/3/1 14:28
 */
public class UMengTest extends BaseJUnitTest{

    @Resource
    private UMengService uMengService;
    @Resource
    private UserInnerMessageService userInnerMessageService;

    @Test
    public void testSend(){
        try {
//            uMengService.sendIOSUnicast("【审核】提额申请提交成功","【喜花花】尊敬的用户：您的提额申请已提交成功，新的授信预计将在5分钟内生效，您可稍后申请借款。","6372a597af4162379dcbf4d905b9a5e26aeb9a4a196d52639ca739afee2f5506");
//            uMengService.sendIOSBroadcast("nicai","hahahha");
            uMengService.sendAndroidUnicast("提额申请提交成功","尊敬的用户：您的提额申请已提交成功，新的授信预计将在5分钟内生效，您可稍后申请借款。","Akx-Hij_fCMGrAotEoBMDRzuOI_cEylodGGZ9SMOkaBL");
//            StringBuffer sb = new StringBuffer();
//            sb.append("28e14f0f3f63134165229903c50378a89ebc1e6eca8790271d6d152ee0dc00c2");
//            sb.append("\n");
//            uMengService.sendIOSFilecast("shadkha","askldaskl",sb.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    @Test
    public void testSub(){
        String title = "【审核】提额申请提交成功";
        System.out.println(title.substring(title.indexOf("】")+1));
    }
    @Test
    public void testMq() throws Exception {
        String content = "尊敬的用户，您申请的借款将于3天后还款，合计Amtt元，请您在（date-1）日24时前存入足额至尾号Pltno的银行卡中，或于还款日当天前往App借款列表中自主操作还款，感谢您的支持与配合。";

        NoticeBusinessMessageDto noticeBusinessMessageDto = new NoticeBusinessMessageDto();
        noticeBusinessMessageDto.setAccountId(48l);
        noticeBusinessMessageDto.setMsgSubtype(MessagePushType.REPAYMENT_NOTICE_THREE_DAYS.getKey());
        Map<String, String> paramMap = new HashMap<>();
        paramMap.put("Amtt", "1000");
        paramMap.put("date", "12");
        noticeBusinessMessageDto.setMap(paramMap);
        userInnerMessageService.insertBusinessMessage(noticeBusinessMessageDto);
    }

    @Test
    public void test() throws Exception {
        IOSUnicast unicast = new IOSUnicast(UMengConstant.getInstance().iosAppkey,UMengConstant.getInstance().iosMastersecret);
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("title","1111");
//        jsonObject.put("subtitle",title);
        jsonObject.put("body","2222");
        System.out.println(jsonObject.toString());
//        unicast.setAlert(jsonObject);
        System.out.println(unicast.getPostBody());
    }
}
