package test;

import base.BaseJUnitTest;
import com.janty.core.dto.BaseResponse;
import com.janty.core.dto.PageData;
import com.janty.core.dto.Pager;
import com.xhh.creditpre.cashloan.api.UserApi;
import com.xhh.creditpre.cashloan.controller.UserController;
import com.xhh.creditpre.cashloan.dto.QueryUserInfoRequest;
import com.xhh.creditpre.cashloan.dto.UserInfoDto;
import com.xhh.creditpre.cashloan.model.*;
import com.xhh.creditpre.cashloan.service.MobileCodeService;
import com.xhh.creditpre.cashloan.service.UserInfoService;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import javax.annotation.Resource;
import java.util.List;

public class UserTest extends BaseJUnitTest {
    @Resource
    private UserInfoService   userInfoService;

    @Autowired
    private MobileCodeService mobileCodeService;

    @Autowired
    private UserApi           userApi;

    @Test
    public void testSendCode() {
        MsgCodeRequest msgCodeRequest = new MsgCodeRequest();
        msgCodeRequest.setPhone("15914112495");
        msgCodeRequest.setType(1);
        mobileCodeService.getCode(msgCodeRequest);

        //        RegisterRequest request = new RegisterRequest();
        //        request.setLoginName("zhangliang");
        //        request.setPassword("000000");
        //        request.setPhone("15914112496");
        //        request.setMsgCode("5432");
        //        request.setSourceCode(1);
        //        userController.register(request);

    }

    @Test
    public void testRegister() {
        RegisterRequest request = new RegisterRequest();
        request.setLoginName("zhangliang");
        request.setPassword("000000");
        request.setPhone("15914112496");
        request.setMsgCode("5432");
        request.setSourceCode(1);
        userInfoService.addData(request);
    }

    @Test
    public void testLogin() {
        LoginRequest request = new LoginRequest();
        request.setPassword("117C074F3B05A66216DB11F6AFFCABBB0C903B57F24770DD5B1EB674673432AC");
        request.setPhone("18274065051");
    }

    @Test
    public void testAlterPasswd() {
        AlterPasswdRequest alterPasswdRequest = new AlterPasswdRequest();
        alterPasswdRequest.setPassword("333333");
        alterPasswdRequest.setPhone("15914112496");
        alterPasswdRequest.setMsgCode("2323");
        PreBaseRequest preBaseRequest = new PreBaseRequest();
        preBaseRequest.setToken("201801231611311332505a66ee33ccd161096c2dc80c1516695091882");
        preBaseRequest.setUserId(new Long(1));
    }

    @Test
    public void testQueryUserByPage() {
        QueryUserInfoRequest queryUserInfoRequest = new QueryUserInfoRequest();
        queryUserInfoRequest.setName("亮");
        Pager pager = new Pager();
        //        pager.setOffset(0);
        pager.setPageNum(1);
        pager.setPageSize(5);
        PageData<UserInfoDto> pageData = userApi.queryUserInfoByPage(queryUserInfoRequest, pager);
        System.out.println(pageData);
    }

    @Test
    public void testLogout() {
        PreBaseRequest preBaseRequest = new PreBaseRequest();
        preBaseRequest.setToken("201801221626523199585a65a04cccd1611738faac4e1516609612057");
        userInfoService.logout(preBaseRequest);
    }
}
