package test;

import base.BaseJUnitTest;
import com.janty.datadictionary.DataDictionaryAccess;
import com.janty.system.model.DataDictionary;
import org.junit.Test;

import java.util.List;
import java.util.Map;

public class DataDictTest extends BaseJUnitTest {
    @Test
    public void queryDitc() {
        System.out.println("123");
        Map<String, List<DataDictionary>> allEnum = DataDictionaryAccess.getAllEnum();
        System.out.println(allEnum);
    }
}
