package com.xhh.creditcore.capital.service.payimpl.xianfeng;

import java.util.HashMap;
import java.util.Map;

import com.xhh.creditcore.capital.pay.ConfigurableNoticeUrl;
import com.xhh.creditcore.capital.pay.MerchantInfo;

/**
 * 单笔代扣请求对象
 *
 * @author zhangweixin
 */
public class SingleDeductRequest extends BaseRequest implements ConfigurableNoticeUrl {

    private Map<String, String> businessData = new HashMap<>();
    private XianFengConfig      config       = XianFengConfig.getXianFengConfig();

    public SingleDeductRequest(MerchantInfo merchantInfo) {
        super("REQ_WITHOIDING", "4.0.0", merchantInfo);
        // 币种
        businessData.put("transCur", "156");
        // 用户类型
        businessData.put("userType", "1");
        // 账户类型
        businessData.put("accountType", "1");
        // 证件类型
        businessData.put("certificateType", "0");
        businessData.put("productName", "消费金融");
        String url = config.NOTICE_PREFIX + config.SIGNLE_WITHHOLD_NOTICE_PATH;
        businessData.put("noticeUrl", url);
    }

    /**
     * 设置商户订单号
     *
     * @param merchantNo
     */
    public void setMerchantNo(String merchantNo) {
        businessData.put("merchantNo", merchantNo);
    }

    /**
     * 设置代付金额单位元,小数点后最小到分
     *
     * @param amount
     */
    public void setAmount(Double amount) {
        amount = amount * 100;
        businessData.put("amount", String.valueOf(amount.longValue()));
    }

    /**
     * 设置代付银行卡号
     *
     * @param accountNo
     */
    public void setAccountNo(String accountNo) {
        businessData.put("accountNo", accountNo);
    }

    /**
     * 设置收款人姓名
     *
     * @param accountName
     */
    public void setAccountName(String accountName) {
        businessData.put("accountName", accountName);
    }

    /**
     * 设置收款银行代码
     *
     * @param bankId
     */
    public void setBankId(String bankId) {
        businessData.put("bankId", bankId);
    }

    /**
     * 设置身份证号
     *
     * @param certificateNo
     */
    public void setCertificateNo(String certificateNo) {
        businessData.put("certificateNo", certificateNo);
    }

    /**
     * 设置附加信息
     *
     * @param memo
     */
    public void setMemo(String memo) {
        businessData.put("memo", memo);
    }

    @Override
    public Map<String, String> getBusinessData() {
        return businessData;
    }

    @Override
    protected Map<String, String> getSubClassSignData() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getRawNoticeUrl() {
        return businessData.get("noticeUrl");
    }

    @Override
    public void setNewNoticeUrl(String newNoticeUrl) {
        businessData.put("noticeUrl", newNoticeUrl);
    }
}
