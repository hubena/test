package com.xhh.creditcore.capital.service.payimpl.xianfeng;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.janty.core.exception.SystemException;
import com.ucf.sdk.UcfForOnline;
import com.ucf.sdk.util.AESCoder;
import com.xhh.creditcore.capital.constant.CapitalErrorCode;
import com.xhh.creditcore.capital.enums.CertificateType;
import com.xhh.creditcore.capital.enums.PayChannel;
import com.xhh.creditcore.capital.enums.PayType;
import com.xhh.creditcore.capital.pay.*;
import com.xhh.creditcore.capital.service.payimpl.PayServiceAdaptor;

/**
 * zhangweixin 2018-01-10
 */
@Service("xianFengPayService")
public class XianFengPayService extends PayServiceAdaptor {

    Logger               logger       = LoggerFactory.getLogger(XianFengPayService.class);
    private ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public boolean supportPayType(PayType payType) {
        return PayType.THIRD_PAY.equals(payType);
    }

    @Override
    public boolean supportPayChannel(PayChannel payChannel) {
        return PayChannel.XIAN_FENG.equals(payChannel);
    }

    @Override
    public boolean isDefaultPayChannel() {
        return true;
    }

    {
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

    @Override
    public PayResult singlePay(PayRequest request) {
        SinglePayRequest payRequest = new SinglePayRequest(request.getMerchantInfo());
        PayResult payResult = new PayResult();
        try {
            payRequest.setBankNo(request.getBankCode());
            payRequest.setAccountName(request.getAccountName());
            payRequest.setAccountNo(request.getBankCardNo());
            payRequest.setMerchantNo(request.getCapitalOrderNo());
            payRequest.setAmount(request.getAmount().doubleValue());
            payRequest.setMemo(objectMapper.writeValueAsString(request.getAppendData()));
            String rawNoticeUrl = payRequest.getRawNoticeUrl();
            rawNoticeUrl += "/" + request.getProductCode();
            rawNoticeUrl += "/" + request.getPayMerchantType().getKey();
            payRequest.setNewNoticeUrl(rawNoticeUrl);

            PayBaseResponse payResponse;
            payResponse = XianFengRequestExecutor.execute(payRequest, new TypeReference<PayBaseResponse>() {
            });
            payResult.setThirdOrderNo(payResponse.getTradeNo());
            payResult.setOrderNo(payResponse.getMerchantNo());
            payResult.setResMsg(payResponse.getResMessage());
            processResult(payResult, payResponse);
        } catch (Exception e) {
            processException(e, payResult);
        }
        return payResult;
    }

    /**
     * 单笔对公代付
     *
     * @param request {@link PayRequest}
     * @return
     */
    public PayResult singPayOfPublic(PayRequest request) {
        SinglePublicPayRequest payPublicRequest = new SinglePublicPayRequest(request.getMerchantInfo());
        PayResult payResult = new PayResult();
        try {
            payPublicRequest.setBankNo(request.getBankCode());
            payPublicRequest.setAccountName(request.getAccountName());
            payPublicRequest.setAccountNo(request.getBankCardNo());
            payPublicRequest.setMerchantNo(request.getCapitalOrderNo());
            payPublicRequest.setAmount(request.getAmount().doubleValue());
            payPublicRequest.setIssuer(request.getIssuer());
            payPublicRequest.setMemo(objectMapper.writeValueAsString(request.getAppendData()));

            BaseResponse baseResponse;
            baseResponse = XianFengRequestExecutor.execute(payPublicRequest, new TypeReference<BaseResponse>() {
            });
            payResult.setOrderNo(request.getCapitalOrderNo());
            payResult.setThirdOrderNo(baseResponse.getMemo());
            processResult(payResult, baseResponse);
        } catch (Exception e) {
            processException(e, payResult);
        }
        return payResult;
    }

    public PayResult singleDeduct(PayRequest request) {

        SingleDeductRequest deductRequest = new SingleDeductRequest(request.getMerchantInfo());
        PayResult serviceResult = new PayResult();
        try {
            deductRequest.setBankId(request.getBankCode());
            deductRequest.setAccountName(request.getAccountName());
            deductRequest.setAccountNo(request.getBankCardNo());
            deductRequest.setCertificateNo(request.getCertNo());
            deductRequest.setMerchantNo(request.getCapitalOrderNo());
            deductRequest.setAmount(request.getAmount().doubleValue());
            deductRequest.setMemo(objectMapper.writeValueAsString(request.getAppendData()));
            //自定义通知URL
            String rawNoticeUrl = deductRequest.getRawNoticeUrl();
            rawNoticeUrl += "/" + request.getProductCode();
            rawNoticeUrl += "/" + request.getPayMerchantType().getKey();
            deductRequest.setNewNoticeUrl(rawNoticeUrl);

            PayBaseResponse deductResponse;
            deductResponse = XianFengRequestExecutor.execute(deductRequest, new TypeReference<PayBaseResponse>() {
            });
            serviceResult.setOrderNo(deductResponse.getMerchantNo());
            serviceResult.setThirdOrderNo(deductResponse.getTradeNo());
            serviceResult.setResMsg(deductResponse.getResMessage());
            processResult(serviceResult, deductResponse);
        } catch (Exception e) {
            processException(e, serviceResult);
        }
        return serviceResult;
    }

    @Override
    public PayResult singlePayQuery(PayRequest request) {
        logger.info("执行先锋支付代付查单,订单号-{}", request.getCapitalOrderNo());
        PayResult serviceResult = new PayResult();
        try {
            SinglePayNoticeResponse queryResponse;
            SinglePayQueryRequest queryRequest = new SinglePayQueryRequest(request.getMerchantInfo());
            queryRequest.setMerchantNo(request.getCapitalOrderNo());
            queryResponse = XianFengRequestExecutor.execute(queryRequest, new TypeReference<SinglePayNoticeResponse>() {
            });

            serviceResult.setOrderNo(queryResponse.getMerchantNo());
            serviceResult.setThirdOrderNo(queryResponse.getTradeNo());
            serviceResult.setResMsg(queryResponse.getResMessage());
            if (queryResponse.getResCode().equals("10009")) {
                serviceResult.setResCode(PayResult.THIRD_UNCOMMIT);
            } else {
                processResult(serviceResult, queryResponse);
            }
        } catch (Exception e) {
            throw new SystemException("先锋代付查单异常", e);
        }
        return serviceResult;
    }

    @Override
    public PayResult singleDeductOrderQuery(PayRequest request) {
        logger.info("执行先锋支付代扣查单,订单号-{}", request.getCapitalOrderNo());
        PayResult serviceResult = new PayResult();
        try {
            SingleDeductNotifyResponse queryResponse;
            SingleDeductQueryRequest queryRequest = new SingleDeductQueryRequest(request.getMerchantInfo());
            queryRequest.setMerchantNo(request.getCapitalOrderNo());
            queryResponse = XianFengRequestExecutor.execute(queryRequest, new TypeReference<SingleDeductNotifyResponse>() {
            });

            serviceResult.setOrderNo(queryResponse.getMerchantNo());
            serviceResult.setThirdOrderNo(queryResponse.getTradeNo());
            serviceResult.setResMsg(queryResponse.getResMessage());
            if (queryResponse.getResCode().equals("10009")) {
                serviceResult.setResCode(PayResult.THIRD_UNCOMMIT);
            } else {
                processResult(serviceResult, queryResponse);
            }
        } catch (Exception e) {
            throw new SystemException("先锋代扣查单异常", e);
        }
        return serviceResult;
    }

    @Override
    public void singlePayNotice(PayNoticeRequest noticeRequest) {
        Object responseData = noticeRequest.getResponseData();
        callBackProcess(noticeRequest.getMerchantInfo(), (String) responseData, decryptStr -> {
            logger.info("先锋代付接口回调处理......报文:{}", decryptStr);
            SinglePayNoticeResponse payNoticeResponse;
            Class<SinglePayNoticeResponse> clazz = SinglePayNoticeResponse.class;
            payNoticeResponse = objectMapper.readValue(decryptStr, clazz);

            doNotice(payNoticeResponse, new NoticeHandlerWrapper() {
                @Override
                public void noticeForSuccess(PayNoticeHandlerRequest handlerRequest) {
                    noticeRequest.getHandlerDelegate().paySuccessHandle(handlerRequest);
                }

                @Override
                public void noticeForFail(PayNoticeHandlerRequest handlerRequest) {
                    noticeRequest.getHandlerDelegate().payFailHandle(handlerRequest);
                }
            });
        });

    }

    @Override
    public void singleDeductNotice(PayNoticeRequest noticeRequest) {
        Object responseData = noticeRequest.getResponseData();
        callBackProcess(noticeRequest.getMerchantInfo(), (String) responseData, decryptStr -> {
            logger.info("先锋代扣接口回调处理......报文:{}", decryptStr);
            SingleDeductNotifyResponse deductNotifyResponse;
            Class<SingleDeductNotifyResponse> clazz = SingleDeductNotifyResponse.class;
            deductNotifyResponse = objectMapper.readValue(decryptStr, clazz);

            doNotice(deductNotifyResponse, new NoticeHandlerWrapper() {
                @Override
                public void noticeForSuccess(PayNoticeHandlerRequest handlerRequest) {
                    noticeRequest.getHandlerDelegate().deductSuccessHandle(handlerRequest);
                }

                @Override
                public void noticeForFail(PayNoticeHandlerRequest handlerRequest) {
                    noticeRequest.getHandlerDelegate().deductFailHandle(handlerRequest);
                }
            });
        });
    }

    @Override
    public void certPayNotice(PayNoticeRequest noticeRequest) {
        Object responseData = noticeRequest.getResponseData();
        callBackProcess(noticeRequest.getMerchantInfo(), (String) responseData, decryptStr -> {
            logger.info("先锋认证支付接口回调处理......报文:{}", decryptStr);
            CertPayNotifyResponse certPayNotifyResponse;
            Class<CertPayNotifyResponse> clazz = CertPayNotifyResponse.class;
            certPayNotifyResponse = objectMapper.readValue(decryptStr, clazz);

            doNotice(certPayNotifyResponse, new NoticeHandlerWrapper() {
                @Override
                public void noticeForSuccess(PayNoticeHandlerRequest handlerRequest) {
                    noticeRequest.getHandlerDelegate().certPaySuccessHandle(handlerRequest);
                }

                @Override
                public void noticeForFail(PayNoticeHandlerRequest handlerRequest) {
                    noticeRequest.getHandlerDelegate().certPaySuccessHandle(handlerRequest);
                }
            });
        });
    }

    @Override
    public PayResult bankCardAuth(PayRequest request) throws Exception {
        PayResult serviceResult = new PayResult();
        SignRequest xianFengSignRequest = new SignRequest(request.getMerchantInfo());
        SignResponse response;
        try {
            xianFengSignRequest.setMerchantNo(request.getCapitalOrderNo());
            xianFengSignRequest.setAccountName(request.getAccountName());
            xianFengSignRequest.setAccountNo(request.getBankCardNo());
            xianFengSignRequest.setCertificateNo(request.getCertNo());
            xianFengSignRequest.setCertificateType(CertificateType.IDENTITY_CARD.getKey());
            xianFengSignRequest.setMobileNo(request.getMobile());
            xianFengSignRequest.setMemo("先锋签约");
            response = XianFengRequestExecutor.execute(xianFengSignRequest, new TypeReference<SignResponse>() {
            });
        } catch (Exception e) {
            throw new SystemException(new CapitalErrorCode(CapitalErrorCode.Element.s_bind_card_fail));
        }

        if (response.isSuccess()) {
            serviceResult.setResCode(PayResult.THIRD_SYNC_SUCCESS);
            serviceResult.setOrderNo(response.getResMessage());
        }
        return serviceResult;
    }

    @Override
    public PayResult certPayPrePay(PayRequest request) {
        PayResult payResult = new PayResult();
        try {
            CertPayPrePayRequest prePayRequest = new CertPayPrePayRequest(request.getMerchantInfo());
            prePayRequest.setBankCardNo(request.getBankCardNo());
            prePayRequest.setCertNo(request.getCertNo());
            prePayRequest.setMobileNo(request.getMobile());
            prePayRequest.setRealName(request.getAccountName());
            prePayRequest.setOutOrderId(request.getCapitalOrderNo());
            prePayRequest.setAmount(request.getAmount().doubleValue());
            prePayRequest.setUserId(request.getAccountId());

            String rawNoticeUrl = prePayRequest.getRawNoticeUrl();
            rawNoticeUrl += "/" + request.getProductCode();
            rawNoticeUrl += "/" + request.getPayMerchantType().getKey();
            prePayRequest.setNoticeUrl(rawNoticeUrl);

            CertPayBaseResponse response = XianFengRequestExecutor.execute(prePayRequest, new TypeReference<CertPayBaseResponse>() {
            });
            payResult.setResMsg(response.getRespMsg());
            payResult.setOrderNo(request.getCapitalOrderNo());
            if (response.isRequestSuccess()) {
                payResult.setResCode(PayResult.THIRD_SYNC_SUCCESS);
            } else {
                payResult.setResCode(PayResult.THIRD_SYNC_FAIL);
            }
        } catch (Exception e) {
            processException(e, payResult);
        }
        return payResult;
    }

    @Override
    public PayResult certPayConfirmPay(PayRequest request) {
        PayResult payResult = new PayResult();
        try {
            CertPayConfirmPayRequest confirmPayRequest = new CertPayConfirmPayRequest(request.getMerchantInfo());
            confirmPayRequest.setSmsCode(request.getSmsCode());
            confirmPayRequest.setOutOrderId(request.getCapitalOrderNo());

            CertPayConfirmPayResponse response;
            response = XianFengRequestExecutor.execute(confirmPayRequest, new TypeReference<CertPayConfirmPayResponse>() {
            });
            payResult.setResMsg(response.getRespMsg());
            payResult.setOrderNo(request.getCapitalOrderNo());
            if (response.isRequestSuccess()) {
                processResult(payResult, response);
            } else {
                payResult.setResCode(PayResult.THIRD_SYNC_FAIL);
            }
        } catch (Exception e) {
            processException(e, payResult);
        }
        return payResult;
    }

    @Override
    public PayResult certPayOrderQuery(PayRequest request) {
        PayResult payResult = new PayResult();
        try {
            CertPayOrderQueryRequest queryRequest = new CertPayOrderQueryRequest(request.getMerchantInfo());
            queryRequest.setOutOrderId(request.getCapitalOrderNo());

            CertPayQueryResponse response;
            response = XianFengRequestExecutor.execute(queryRequest, new TypeReference<CertPayQueryResponse>() {
            });
            payResult.setOrderNo(request.getCapitalOrderNo());
            if (response.isUncommit()) {
                payResult.setResCode(PayResult.THIRD_UNCOMMIT);
            } else {
                processResult(payResult, response);
            }
        } catch (Exception e) {
            throw new SystemException("先锋认证支付查单调用失败", e);
        }
        return payResult;
    }

    @Override
    public PayResult repeatSendSms(PayRequest request) throws UnsupportedOperationException {
        PayResult payResult = new PayResult();
        try {
            CertPaySmsRequest smsRequest = new CertPaySmsRequest(request.getMerchantInfo());
            smsRequest.setMobileNo(request.getMobile());
            smsRequest.setOutOrderId(request.getCapitalOrderNo());

            CertPayConfirmPayResponse response;
            response = XianFengRequestExecutor.execute(smsRequest, new TypeReference<CertPayConfirmPayResponse>() {
            });
            payResult.setResMsg(response.getRespMsg());
            payResult.setOrderNo(request.getCapitalOrderNo());
            if (response.isRequestSuccess()) {
                payResult.setResCode(PayResult.THIRD_SYNC_SUCCESS);
            } else {
                payResult.setResCode(PayResult.THIRD_SYNC_FAIL);
            }
        } catch (Exception e) {
            throw new SystemException("先锋认证支付发送短信调用失败", e);
        }
        return payResult;
    }

    /**
     * 具体执行回调处理逻辑方法
     *
     * @param notifyResponse {@link NoticeBaseResponse}
     * @throws Exception
     */
    private void doNotice(NoticeBaseResponse notifyResponse, NoticeHandlerWrapper handlerWrapper) {
        PayNoticeHandlerRequest notcieHandlerRequest = new PayNoticeHandlerRequest();
        notcieHandlerRequest.setOrderNo(notifyResponse.getMerchantNo());
        notcieHandlerRequest.setThirdOrderNo(notifyResponse.getTradeNo());
        try {
            if (notifyResponse.isOrderSuccess()) {
                handlerWrapper.noticeForSuccess(notcieHandlerRequest);
            } else if (notifyResponse.isOrderFail()) {
                handlerWrapper.noticeForFail(notcieHandlerRequest);
            }

        } catch (Exception e) {
            throw new SystemException("先锋执行支付业务回调处理失败", e);
        }
    }

    public final void callBackProcess(MerchantInfo merchantInfo, String noticeBody, XianFengCallBackProcessor processor) {

        try {
            String decryptStr = AESCoder.decrypt(noticeBody, merchantInfo.getSecretKey());
            logger.info("开始处理先锋支付通知回调........回调报文-{}", decryptStr);
            ObjectMapper objectMapper = new ObjectMapper();
            Map<String, String> jsonMap = objectMapper.readValue(decryptStr, new TypeReference<Map<String, String>>() {
            });

            String signValue = jsonMap.get("sign");
            String secId = XianFengConfig.getXianFengConfig().SEC_ID;
            boolean signStatus = UcfForOnline.verify(merchantInfo.getSecretKey(), "sign", signValue, jsonMap, secId);
            if (signStatus) {
                processor.doProcess(decryptStr);
            } else {
                throw new SystemException("先锋支付异步通知验签失败");
            }
        } catch (Exception e) {
            throw new SystemException("先锋支付异步通知处理失败", e);
        }
    }

    private void processResult(PayResult serviceResult, OrderStatus orderStatus) {
        if (orderStatus.isOrderSuccess()) {
            serviceResult.setResCode(PayResult.THIRD_SYNC_SUCCESS);
        } else if (orderStatus.isOrderPending()) {
            serviceResult.setResCode(PayResult.THIRD_SYNC_PENDING);
        } else {
            serviceResult.setResCode(PayResult.THIRD_SYNC_FAIL);
        }
    }

    private void processException(Exception e, PayResult serviceResult) {
        if (e instanceof SystemException) {
            throw (SystemException) e;
        } else {
            logger.error("先锋支付调用异常", e);
            serviceResult.setResCode(PayResult.THIRD_INVOKE_EXCEPTION);
            serviceResult.setResMsg(e.getMessage());
        }
    }

}
