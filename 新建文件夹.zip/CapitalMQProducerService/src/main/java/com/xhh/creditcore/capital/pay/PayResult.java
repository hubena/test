package com.xhh.creditcore.capital.pay;

/**
 * 具体支付服务请求 zhangweixin 2018-01-17
 */
public class PayResult {

    /**
     * 第三方同步调用返回成功
     */
    public static String THIRD_SYNC_SUCCESS     = "0";
    /**
     * 第三方同步调用返回失败
     */
    public static String THIRD_SYNC_FAIL        = "1";
    /**
     * 第三方同步调用返回处理中
     */
    public static String THIRD_SYNC_PENDING     = "2";
    /**
     * 第三方同步调用出现异常
     */
    public static String THIRD_INVOKE_EXCEPTION = "3";

    /**
     * 订单未提交第三方查单的时候才会用到
     */
    public static String THIRD_UNCOMMIT         = "4";

    //订单号
    private String       orderNo;
    //支付平台订单号
    private String       thirdOrderNo;
    //本地响应码
    private String       resCode;
    //第三方响应消息
    private String       resMsg;

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getThirdOrderNo() {
        return thirdOrderNo;
    }

    public void setThirdOrderNo(String platformOrderNo) {
        this.thirdOrderNo = platformOrderNo;
    }

    public String getResCode() {
        return resCode;
    }

    public void setResCode(String resCode) {
        this.resCode = resCode;
    }

    public String getResMsg() {
        return resMsg;
    }

    public void setResMsg(String resMsg) {
        this.resMsg = resMsg;
    }

    @Override
    public String toString() {
        return "PayResult{" +
                "orderNo='" + orderNo + '\'' +
                ", thirdOrderNo='" + thirdOrderNo + '\'' +
                ", resCode='" + resCode + '\'' +
                ", resMsg='" + resMsg + '\'' +
                '}';
    }
}
