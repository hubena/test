package com.xhh.creditcore.capital.api;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.janty.core.util.ExceptionUtil;
import com.xhh.creditcore.capital.dto.CapitalLoanRequest;
import com.xhh.creditcore.capital.dto.LoanTrialDto;
import com.xhh.creditcore.capital.service.LoanTrialService;

@Service("loanTrialApi")
public class LoanTrialApi implements ILoanTrialApi {

    private final Logger     logger = LoggerFactory.getLogger(getClass());

    @Resource
    private LoanTrialService loanTrialService;

    @Override
    public LoanTrialDto loanTrail(CapitalLoanRequest request) {
        logger.info("LoanApi-calcLoan-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);
        LoanTrialDto result = new LoanTrialDto();
        try {
            result = loanTrialService.calcLoan(request);
        } catch (Exception e) {
            logger.error("LoanApi-calcLoan-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            throw e;
        }
        logger.info("LoanApi-calcLoan-请求结束, reqNo-{}-返回-{}", request.getReqNo(), result);

        return result;
    }

}
