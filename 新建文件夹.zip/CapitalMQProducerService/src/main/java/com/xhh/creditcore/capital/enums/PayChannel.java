package com.xhh.creditcore.capital.enums;

/**
 * zhangweixin 2018-01-10
 */
public enum PayChannel {
    XIAN_FENG("XIANFENG", "先锋支付");

    private String key;
    private String desc;

    public String getKey() {
        return key;
    }

    public String getDesc() {
        return desc;
    }

    PayChannel(String key, String desc) {
        this.key = key;
        this.desc = desc;
    }

    public static PayChannel getInstance(String key) {
        for (PayChannel payType : PayChannel.values()) {
            if (payType.key.equals(key)) {
                return payType;
            }
        }
        return null;
    }
}
