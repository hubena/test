package com.xhh.creditcore.capital.dao;

import com.xhh.creditcore.capital.model.OrderLog;
import org.springframework.stereotype.Repository;

/**
 * <p>
 * 订单日志表 Mapper 接口
 * </p>
 *
 * @author nathaniel123
 * @since 2018-01-09
 */
@Repository
public interface OrderLogMapper {
    int insert(OrderLog orderLog);
}
