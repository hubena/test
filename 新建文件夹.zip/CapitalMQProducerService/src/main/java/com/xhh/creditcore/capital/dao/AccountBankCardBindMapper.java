package com.xhh.creditcore.capital.dao;

import com.xhh.creditcore.capital.model.AccountBankCardBind;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * <p>
 * 产品账户绑卡表，账户系统 Mapper 接口
 * </p>
 *
 * @author nathaniel123
 * @since 2018-01-09
 */
@Repository
public interface AccountBankCardBindMapper {
    int insert(AccountBankCardBind bankCardBind);

    AccountBankCardBind selectById(@Param("id") Long id);

    List<AccountBankCardBind> selectByCondition(AccountBankCardBind bankCardBind);

    int deleteById(@Param("id") Long id);

    int deleteByConditon(AccountBankCardBind bankCardBind);

    int updateNoNullColumnById(AccountBankCardBind bankCardBind);

    int updateAllColumnById(AccountBankCardBind bankCardBind);

    void updateBankCardBindById(AccountBankCardBind accountBankCardBind);
}
