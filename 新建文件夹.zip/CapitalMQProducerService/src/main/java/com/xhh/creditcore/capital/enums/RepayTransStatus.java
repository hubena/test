package com.xhh.creditcore.capital.enums;

/**
 * 还款交易记录表状态 zhangweixin 2018-01-10
 */
public enum RepayTransStatus {
    //认证支付状态转化,代扣没有预支付状态从1状态开始
    //5->1->2->3
    //5->1->2->4
    INIT(1, "初始化"),
    PROCESSING(2, "还款中"),
    SUCCESS(3, "还款成功"),
    FAIL(4, "还款失败"),
    PRE_PAY(5, "预支付");
    private Integer key;
    private String  desc;

    public Integer getKey() {
        return key;
    }

    public String getDesc() {
        return desc;
    }

    RepayTransStatus(Integer key, String desc) {
        this.key = key;
        this.desc = desc;
    }

    public static RepayTransStatus getInstance(Integer key) {
        for (RepayTransStatus repayTransStatus : RepayTransStatus.values()) {
            if (repayTransStatus.key.equals(key)) {
                return repayTransStatus;
            }
        }
        return null;
    }
}
