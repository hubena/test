package com.xhh.creditcore.capital.service.payimpl.xianfeng;

import com.xhh.creditcore.capital.pay.MerchantInfo;

import java.util.HashMap;
import java.util.Map;

/**
 * 2017-12-29
 *
 * @author zhangweixin
 */
public class SingleDeductQueryRequest extends BaseRequest {
    private Map<String, String> signData = new HashMap<>();

    public SingleDeductQueryRequest(MerchantInfo merchantInfo) {
        super("REQ_WITHOIDING_QUERY", "4.0.0", merchantInfo);
    }

    /**
     * 设置商户订单号
     *
     * @param merchantNo
     */
    public void setMerchantNo(String merchantNo) {
        signData.put("merchantNo", merchantNo);
    }

    @Override
    public Map<String, String> getBusinessData() {
        return null;
    }

    @Override
    protected Map<String, String> getSubClassSignData() {
        // TODO Auto-generated method stub
        return signData;
    }
}
