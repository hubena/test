package com.xhh.creditcore.capital.service.payimpl.xianfeng;

import com.xhh.creditcore.capital.pay.MerchantInfo;

/**
 * 单笔对公代付请求对象
 *
 * @author zhangweixin
 */
public class SinglePublicPayRequest extends SinglePayRequest {

    public SinglePublicPayRequest(MerchantInfo merchantInfo) {
        super(merchantInfo);
        getBusinessData().put("userType", "2");
    }

    /**
     * 设置联行号
     * 
     * @param issuer
     */
    public void setIssuer(String issuer) {
        getBusinessData().put("issuer", issuer);
    }

}
