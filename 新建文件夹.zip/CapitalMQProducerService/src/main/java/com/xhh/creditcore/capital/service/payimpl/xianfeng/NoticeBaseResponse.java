package com.xhh.creditcore.capital.service.payimpl.xianfeng;

/**
 * @author zhangweixin
 */
public class NoticeBaseResponse extends BaseResponse {
    /*
     * 平台订单号
     */
    private String merchantNo;

    /**
     * 先锋订单号
     */
    private String tradeNo;

    public String getMerchantNo() {
        return merchantNo;
    }

    public void setMerchantNo(String merchantNo) {
        this.merchantNo = merchantNo;
    }

    public String getTradeNo() {
        return tradeNo;
    }

    public void setTradeNo(String tradeNo) {
        this.tradeNo = tradeNo;
    }
}
