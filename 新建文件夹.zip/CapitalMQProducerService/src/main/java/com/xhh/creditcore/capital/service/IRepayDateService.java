package com.xhh.creditcore.capital.service;

import java.util.Date;

public interface IRepayDateService {

    Date getMonthAfter(Date date, int monthNum);

}
