package com.xhh.creditcore.capital.model;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 产品账户绑卡表，账户系统
 * </p>
 *
 * @author nathaniel123
 * @since 2018-01-09
 */

public class AccountBankCardBind implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long              id;
    /**
     * 产品账户id
     */
    private Long              accountId;

    /**
     * 放款账户姓名
     */
    private String            accountName;
    /**
     * 放款账户证件号
     */
    private String            accountIdCard;
    /**
     * 账户对应手机号
     */
    private String            accountMobile;
    /**
     * 银行编码
     */
    private String            bankCode;
    /**
     * 银行卡号
     */
    private String            bankCardNo;
    /**
     * 创建时间
     */
    private Date              gmtCreated;
    /**
     * 最后修改时间
     */
    private Date              gmtModified;
    /**
     * 创建人
     */
    private String            creator;
    /**
     * 最后修改人
     */
    private String            modifier;
    /**
     * 删除标志位 N-未删除 Y-已删除
     */
    private String            isDeleted;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getAccountId() {
        return accountId;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public String getBankCode() {
        return bankCode;
    }

    public void setBankCode(String bankCode) {
        this.bankCode = bankCode;
    }

    public String getBankCardNo() {
        return bankCardNo;
    }

    public void setBankCardNo(String bankCardNo) {
        this.bankCardNo = bankCardNo;
    }

    public Date getGmtCreated() {
        return gmtCreated;
    }

    public void setGmtCreated(Date gmtCreated) {
        this.gmtCreated = gmtCreated;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public String getModifier() {
        return modifier;
    }

    public void setModifier(String modifier) {
        this.modifier = modifier;
    }

    public String getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(String isDeleted) {
        this.isDeleted = isDeleted;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public String getAccountIdCard() {
        return accountIdCard;
    }

    public void setAccountIdCard(String accountIdCard) {
        this.accountIdCard = accountIdCard;
    }

    public String getAccountMobile() {
        return accountMobile;
    }

    public void setAccountMobile(String accountMobile) {
        this.accountMobile = accountMobile;
    }

    @Override
    public String toString() {
        return "AccountBankCardBind{" + "id=" + id + ", accountId=" + accountId + ", accountName='" + accountName + '\'' + ", accountCardNo='" + accountIdCard
                + '\'' + ", accountMobile='" + accountMobile + '\'' + ", bankCode='" + bankCode + '\'' + ", cardNo='" + bankCardNo + '\'' + ", gmtCreated="
                + gmtCreated + ", gmtModified=" + gmtModified + ", creator='" + creator + '\'' + ", modifier='" + modifier + '\'' + ", isDeleted='" + isDeleted
                + '\'' + '}';
    }
}
