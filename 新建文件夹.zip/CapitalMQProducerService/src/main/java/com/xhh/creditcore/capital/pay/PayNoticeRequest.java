package com.xhh.creditcore.capital.pay;

import com.xhh.creditcore.capital.enums.PayMerchantType;

/**
 * 支付回调通知请求对象 zhangweixin 2018-03-02
 */
public class PayNoticeRequest implements ConfigurableMerchantInfo {
    //原始通知数据
    private Object                   responseData;
    //商户信息
    private MerchantInfo             merchantInfo;
    //支付相关pay商户类型
    private PayMerchantType          payMerchantType;
    //产品code
    private String                   productCode;
    //回调通知业务handler委托
    private PayNoticeHandlerDelegate handlerDelegate;

    @Override
    public String getProductCode() {
        return productCode;
    }

    @Override
    public PayMerchantType getPayMerchantType() {
        return payMerchantType;
    }

    @Override
    public void setMerchantInfo(MerchantInfo merchantInfo) {
        this.merchantInfo = merchantInfo;
    }

    public MerchantInfo getMerchantInfo() {
        return merchantInfo;
    }

    public Object getResponseData() {
        return responseData;
    }

    public void setResponseData(Object responseData) {
        this.responseData = responseData;
    }

    public void setPayMerchantType(PayMerchantType payMerchantType) {
        this.payMerchantType = payMerchantType;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public PayNoticeHandlerDelegate getHandlerDelegate() {
        return handlerDelegate;
    }

    public void setHandlerDelegate(PayNoticeHandlerDelegate handlerDelegate) {
        this.handlerDelegate = handlerDelegate;
    }
}
