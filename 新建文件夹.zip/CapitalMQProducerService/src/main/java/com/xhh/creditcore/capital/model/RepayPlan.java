package com.xhh.creditcore.capital.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * <p>
 * 还款计划
 * </p>
 *
 * @author nathaniel123
 * @since 2018-01-09
 */

public class RepayPlan implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long              id;
    /**
     * 资金平台交易流水号
     */
    private String            capitalLoanTransNo;
    /**
     * 产品编码
     */
    private String            productCode;
    /**
     * 产品账户id
     */
    private Long              accountId;
    /**
     * 状态：1未还款、2已逾期、3已还款、4已撤销
     */
    private Integer           status;

    private Integer           isEffect;
    /**
     * 约定还款日
     */
    private Date              agreedRepayDate;
    /**
     * 最晚还款日
     */
    private Date              latestRepayDate;
    /**
     * 期数（第几期）
     */
    private Integer           termNo;
    /**
     * 总期数
     */
    private Integer           totalTerm;
    /**
     * 期数单位：1按月、2按天
     */
    private Integer           termUnit;
    /**
     * 应还本金
     */
    private BigDecimal        duePrincipal;
    /**
     * 应还利息
     */
    private BigDecimal        dueInterest;
    /**
     * 逾期罚息
     */
    private BigDecimal        duePenalty;
    /**
     * 优惠本金
     */
    private BigDecimal        freePrincipal;
    /**
     * 优惠利息
     */
    private BigDecimal        freeInterest;
    /**
     * 已冲还款本金
     */
    private BigDecimal        repaidPrincipal;
    /**
     * 已冲利息
     */
    private BigDecimal        repaidInterest;
    /**
     * 已冲罚息
     */
    private BigDecimal        repaidPenalty;
    /**
     * 应还服务费
     */
    private BigDecimal        dueFee;
    /**
     * 已冲服务费
     */
    private BigDecimal        repaidFee;
    /**
     * 创建时间
     */
    private Date              gmtCreated;
    /**
     * 最后修改时间
     */
    private Date              gmtModified;
    /**
     * 创建人
     */
    private String            creator;
    /**
     * 最后修改人
     */
    private String            modifier;
    /**
     * 删除标志位 N-未删除 Y-已删除
     */
    private String            isDeleted;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCapitalLoanTransNo() {
        return capitalLoanTransNo;
    }

    public void setCapitalLoanTransNo(String capitalLoanTransNo) {
        this.capitalLoanTransNo = capitalLoanTransNo;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public Long getAccountId() {
        return accountId;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Date getAgreedRepayDate() {
        return agreedRepayDate;
    }

    public void setAgreedRepayDate(Date agreedRepayDate) {
        this.agreedRepayDate = agreedRepayDate;
    }

    public Date getLatestRepayDate() {
        return latestRepayDate;
    }

    public void setLatestRepayDate(Date latestRepayDate) {
        this.latestRepayDate = latestRepayDate;
    }

    public Integer getTermNo() {
        return termNo;
    }

    public void setTermNo(Integer termNo) {
        this.termNo = termNo;
    }

    public Integer getTotalTerm() {
        return totalTerm;
    }

    public void setTotalTerm(Integer totalTerm) {
        this.totalTerm = totalTerm;
    }

    public Integer getTermUnit() {
        return termUnit;
    }

    public void setTermUnit(Integer termUnit) {
        this.termUnit = termUnit;
    }

    public BigDecimal getDuePrincipal() {
        return duePrincipal;
    }

    public void setDuePrincipal(BigDecimal duePrincipal) {
        this.duePrincipal = duePrincipal;
    }

    public BigDecimal getDueInterest() {
        return dueInterest;
    }

    public void setDueInterest(BigDecimal dueInterest) {
        this.dueInterest = dueInterest;
    }

    public BigDecimal getDuePenalty() {
        return duePenalty;
    }

    public void setDuePenalty(BigDecimal duePenalty) {
        this.duePenalty = duePenalty;
    }

    public BigDecimal getFreePrincipal() {
        return freePrincipal;
    }

    public void setFreePrincipal(BigDecimal freePrincipal) {
        this.freePrincipal = freePrincipal;
    }

    public BigDecimal getFreeInterest() {
        return freeInterest;
    }

    public void setFreeInterest(BigDecimal freeInterest) {
        this.freeInterest = freeInterest;
    }

    public BigDecimal getRepaidPrincipal() {
        return repaidPrincipal;
    }

    public void setRepaidPrincipal(BigDecimal repaidPrincipal) {
        this.repaidPrincipal = repaidPrincipal;
    }

    public BigDecimal getRepaidInterest() {
        return repaidInterest;
    }

    public void setRepaidInterest(BigDecimal repaidInterest) {
        this.repaidInterest = repaidInterest;
    }

    public BigDecimal getRepaidPenalty() {
        return repaidPenalty;
    }

    public void setRepaidPenalty(BigDecimal repaidPenalty) {
        this.repaidPenalty = repaidPenalty;
    }

    public BigDecimal getDueFee() {
        return dueFee;
    }

    public void setDueFee(BigDecimal dueFee) {
        this.dueFee = dueFee;
    }

    public BigDecimal getRepaidFee() {
        return repaidFee;
    }

    public void setRepaidFee(BigDecimal repaidFee) {
        this.repaidFee = repaidFee;
    }

    public Date getGmtCreated() {
        return gmtCreated;
    }

    public void setGmtCreated(Date gmtCreated) {
        this.gmtCreated = gmtCreated;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public String getModifier() {
        return modifier;
    }

    public void setModifier(String modifier) {
        this.modifier = modifier;
    }

    public String getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(String isDeleted) {
        this.isDeleted = isDeleted;
    }

    public Integer getIsEffect() {
        return isEffect;
    }

    public void setIsEffect(Integer isEffect) {
        this.isEffect = isEffect;
    }

    @Override
    public String toString() {
        return "RepayPlan [id=" + id + ", capitalLoanTransNo=" + capitalLoanTransNo + ", productCode=" + productCode + ", accountId=" + accountId + ", status="
                + status + ", agreedRepayDate=" + agreedRepayDate + ", latestRepayDate=" + latestRepayDate + ", termNo=" + termNo + ", totalTerm=" + totalTerm
                + ", termUnit=" + termUnit + ", duePrincipal=" + duePrincipal + ", dueInterest=" + dueInterest + ", duePenalty=" + duePenalty
                + ", freePrincipal=" + freePrincipal + ", freeInterest=" + freeInterest + ", repaidPrincipal=" + repaidPrincipal + ", repaidInterest="
                + repaidInterest + ", repaidPenalty=" + repaidPenalty + ", dueFee=" + dueFee + ", repaidFee=" + repaidFee + ", gmtCreated=" + gmtCreated
                + ", gmtModified=" + gmtModified + ", creator=" + creator + ", modifier=" + modifier + ", isDeleted=" + isDeleted + "]";
    }

}
