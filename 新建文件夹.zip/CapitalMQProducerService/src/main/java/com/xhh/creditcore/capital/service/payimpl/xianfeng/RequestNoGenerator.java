package com.xhh.creditcore.capital.service.payimpl.xianfeng;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import org.apache.commons.lang.time.DateFormatUtils;

/**
 * 请求序列生成器
 *
 * @author zhangweixin
 * @create 2017-09-23 10:05
 **/
public class RequestNoGenerator {

    private long       sequence      = 0L;
    private long       sequenceBits  = 14L;
    private long       sequenceMask  = -1L ^ (-1L << sequenceBits);
    private long       lastTimestamp = -1L;
    private final Lock lock          = new ReentrantLock();

    private RequestNoGenerator() {
    }

    /**
     * 生成一个唯一 序列
     *
     * @param prefix
     * @return
     */
    public String generatorOrderNo(String prefix) {
        long finalSequence = 0L;
        long currentTime = 0L;
        try {
            lock.lock();
            currentTime = timeGenetate();
            if (currentTime < lastTimestamp) {
                throw new RuntimeException("系统时钟错误");
            }

            if (currentTime == lastTimestamp) {
                sequence = (sequence + 1) & sequenceMask;
                if (sequence == 0) {
                    currentTime = spinNextMillis(lastTimestamp);
                }
            } else {
                sequence = 0;
            }

            finalSequence = sequence;
            lastTimestamp = currentTime;
        } finally {
            lock.unlock();
        }
        return prefix + DateFormatUtils.format(currentTime, "yyyyMMddHHmmssSSS") + (1L << sequenceBits) + finalSequence;
    }

    /**
     * 自旋到下一毫秒
     *
     * @param lastTimestamp 时间戳
     * @return
     */
    protected long spinNextMillis(long lastTimestamp) {
        long timestamp = timeGenetate();
        while (timestamp <= lastTimestamp) {
            timestamp = timeGenetate();
        }
        return timestamp;
    }

    /**
     * 产生时间戳(毫秒值)
     *
     * @return
     */
    protected long timeGenetate() {
        return System.currentTimeMillis();
    }

    public static RequestNoGenerator getGenerator() {
        return GeneratorHolder.instance;
    }

    static class GeneratorHolder {
        static RequestNoGenerator instance = new RequestNoGenerator();
    }

}
