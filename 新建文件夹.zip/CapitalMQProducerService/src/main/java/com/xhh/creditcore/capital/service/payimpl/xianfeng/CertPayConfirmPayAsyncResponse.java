package com.xhh.creditcore.capital.service.payimpl.xianfeng;

/**
 * 先锋支付认证支付确认支付响应
 * 
 * @author zhangweixin
 */
public class CertPayConfirmPayAsyncResponse extends CertPayConfirmPayResponse {
    private String tradeNo;

    public String getTradeNo() {
        return tradeNo;
    }

    public void setTradeNo(String tradeNo) {
        this.tradeNo = tradeNo;
    }
}
