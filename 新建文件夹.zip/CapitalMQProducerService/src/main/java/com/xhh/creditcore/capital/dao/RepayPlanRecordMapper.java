package com.xhh.creditcore.capital.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.xhh.creditcore.capital.model.RepayPlanRecord;
import org.springframework.stereotype.Repository;

/**
 * <p>
 * 还款计划变更流水表 Mapper 接口
 * </p>
 *
 * @author nathaniel123
 * @since 2018-01-09
 */
@Repository
public interface RepayPlanRecordMapper {
    int insert(RepayPlanRecord repayPlanRecord);

    RepayPlanRecord selectById(@Param("id") Long id);

    List<RepayPlanRecord> selectByCondition(RepayPlanRecord repayPlanRecord);

    int deleteById(@Param("id") Long id);

    int deleteByConditon(RepayPlanRecord repayPlanRecord);

    int updateNoNullColumnById(RepayPlanRecord repayPlanRecord);

    int updateAllColumnById(RepayPlanRecord repayPlanRecord);

    void updatePenaltyByRepayPlanId(RepayPlanRecord record);
}
