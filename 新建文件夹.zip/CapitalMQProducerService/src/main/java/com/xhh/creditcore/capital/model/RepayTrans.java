package com.xhh.creditcore.capital.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * <p>
 * 资金平台还款交易表
 * </p>
 *
 * @author nathaniel123
 * @since 2018-01-09
 */

public class RepayTrans implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long              id;
    /**
     * 产品编码
     */
    private String            productCode;
    /**
     * 产品账户id
     */
    private Long              accountId;
    /**
     * 外部还款订单交易流水号
     */
    private String            outerRepayOrderNo;
    /**
     * 资金平台交易流水号
     */
    private String            capitalLoanTransNo;
    /**
     * 币种
     */
    private String            currency;
    /**
     * 还款金额
     */
    private BigDecimal        repayAmount;
    /**
     * 状态：1初始化、2还款中、3还款成功、4还款失败
     */
    private Integer           status;
    /**
     * 还款触发类型：1自动代扣、2主动还款
     */
    private Integer           repayTriggerType;
    /**
     * 还款类型：1按期还款、2按金额还款
     */
    private Integer           repayType;
    /**
     * 按期还款的还款计划id
     */
    private Long              repayPlanId;
    /**
     * 还款申请时间
     */
    private Date              repayApplyTime;
    /**
     * 还款时间
     */
    private Date              repayFinishedTime;
    /**
     * 扣款手机号
     */
    private String            accountMobile;
    /**
     * 扣款银行卡号
     */
    private String            accountCardNo;
    /**
     * 第三方支付付款流水号
     */
    private String            payNo;
    /**
     * 第三方支付结果
     */
    private String            payResult;
    /**
     * 创建时间
     */
    private Date              gmtCreated;
    /**
     * 最后修改时间
     */
    private Date              gmtModified;
    /**
     * 创建人
     */
    private String            creator;
    /**
     * 最后修改人
     */
    private String            modifier;
    /**
     * 删除标志位 N-未删除 Y-已删除
     */
    private String            isDeleted;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public Long getAccountId() {
        return accountId;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public String getOuterRepayOrderNo() {
        return outerRepayOrderNo;
    }

    public void setOuterRepayOrderNo(String outerRepayOrderNo) {
        this.outerRepayOrderNo = outerRepayOrderNo;
    }

    public String getCapitalLoanTransNo() {
        return capitalLoanTransNo;
    }

    public void setCapitalLoanTransNo(String capitalLoanTransNo) {
        this.capitalLoanTransNo = capitalLoanTransNo;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public BigDecimal getRepayAmount() {
        return repayAmount;
    }

    public void setRepayAmount(BigDecimal repayAmount) {
        this.repayAmount = repayAmount;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getRepayTriggerType() {
        return repayTriggerType;
    }

    public void setRepayTriggerType(Integer repayTriggerType) {
        this.repayTriggerType = repayTriggerType;
    }

    public Integer getRepayType() {
        return repayType;
    }

    public void setRepayType(Integer repayType) {
        this.repayType = repayType;
    }

    public Long getRepayPlanId() {
        return repayPlanId;
    }

    public void setRepayPlanId(Long repayPlanId) {
        this.repayPlanId = repayPlanId;
    }

    public Date getRepayApplyTime() {
        return repayApplyTime;
    }

    public void setRepayApplyTime(Date repayApplyTime) {
        this.repayApplyTime = repayApplyTime;
    }

    public Date getRepayFinishedTime() {
        return repayFinishedTime;
    }

    public void setRepayFinishedTime(Date repayFinishedTime) {
        this.repayFinishedTime = repayFinishedTime;
    }

    public String getPayNo() {
        return payNo;
    }

    public void setPayNo(String payNo) {
        this.payNo = payNo;
    }

    public String getPayResult() {
        return payResult;
    }

    public void setPayResult(String payResult) {
        this.payResult = payResult;
    }

    public Date getGmtCreated() {
        return gmtCreated;
    }

    public void setGmtCreated(Date gmtCreated) {
        this.gmtCreated = gmtCreated;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public String getModifier() {
        return modifier;
    }

    public void setModifier(String modifier) {
        this.modifier = modifier;
    }

    public String getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(String isDeleted) {
        this.isDeleted = isDeleted;
    }

    public String getAccountMobile() {
        return accountMobile;
    }

    public void setAccountMobile(String accountMobile) {
        this.accountMobile = accountMobile;
    }

    public String getAccountCardNo() {
        return accountCardNo;
    }

    public void setAccountCardNo(String accountCardNo) {
        this.accountCardNo = accountCardNo;
    }

    @Override
    public String toString() {
        return "RepayTrans{" + "id=" + id + ", productCode='" + productCode + '\'' + ", accountId=" + accountId + ", outerRepayOrderNo='" + outerRepayOrderNo
                + '\'' + ", capitalLoanTransNo='" + capitalLoanTransNo + '\'' + ", currency='" + currency + '\'' + ", repayAmount=" + repayAmount + ", status="
                + status + ", repayTriggerType=" + repayTriggerType + ", repayType=" + repayType + ", repayPlanId=" + repayPlanId + ", repayApplyTime="
                + repayApplyTime + ", repayFinishedTime=" + repayFinishedTime + ", accountMobile='" + accountMobile + '\'' + ", accountCardNo='" + accountCardNo
                + '\'' + ", payNo='" + payNo + '\'' + ", payResult='" + payResult + '\'' + ", gmtCreated=" + gmtCreated + ", gmtModified=" + gmtModified
                + ", creator='" + creator + '\'' + ", modifier='" + modifier + '\'' + ", isDeleted='" + isDeleted + '\'' + '}';
    }
}
