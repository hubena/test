package com.xhh.creditcore.capital.model;

import java.util.Date;

public class BankCardbin {
    private Long    id;

    private String  bankName;

    private String  bankCode;

    private Integer cardLen;

    private String  issueOrganCode;

    private String  issueOrganName;

    private String  cardBin;

    private Integer cardBinLen;

    private Integer cardType;

    private String  remark;

    private String  extraInfo;

    private Date    gmtCreated;

    private String  creator;

    private Date    gmtModified;

    private String  modifier;

    private String  isDeleted;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName == null ? null : bankName.trim();
    }

    public String getBankCode() {
        return bankCode;
    }

    public void setBankCode(String bankCode) {
        this.bankCode = bankCode == null ? null : bankCode.trim();
    }

    public Integer getCardLen() {
        return cardLen;
    }

    public void setCardLen(Integer cardLen) {
        this.cardLen = cardLen;
    }

    public String getIssueOrganCode() {
        return issueOrganCode;
    }

    public void setIssueOrganCode(String issueOrganCode) {
        this.issueOrganCode = issueOrganCode == null ? null : issueOrganCode.trim();
    }

    public String getIssueOrganName() {
        return issueOrganName;
    }

    public void setIssueOrganName(String issueOrganName) {
        this.issueOrganName = issueOrganName == null ? null : issueOrganName.trim();
    }

    public String getCardBin() {
        return cardBin;
    }

    public void setCardBin(String cardBin) {
        this.cardBin = cardBin == null ? null : cardBin.trim();
    }

    public Integer getCardBinLen() {
        return cardBinLen;
    }

    public void setCardBinLen(Integer cardBinLen) {
        this.cardBinLen = cardBinLen;
    }

    public Integer getCardType() {
        return cardType;
    }

    public void setCardType(Integer cardType) {
        this.cardType = cardType;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    public String getExtraInfo() {
        return extraInfo;
    }

    public void setExtraInfo(String extraInfo) {
        this.extraInfo = extraInfo == null ? null : extraInfo.trim();
    }

    public Date getGmtCreated() {
        return gmtCreated;
    }

    public void setGmtCreated(Date gmtCreated) {
        this.gmtCreated = gmtCreated;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator == null ? null : creator.trim();
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public String getModifier() {
        return modifier;
    }

    public void setModifier(String modifier) {
        this.modifier = modifier == null ? null : modifier.trim();
    }

    public String getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(String isDeleted) {
        this.isDeleted = isDeleted == null ? null : isDeleted.trim();
    }
}
