package com.xhh.creditcore.capital.model;

import java.math.BigDecimal;
import java.util.Date;

public class CapitalLoanTrans {
    private Long       id;

    private String     capitalCode;

    private String     capitalLoanTransNo;

    private String     outerLoanOrderNo;

    private String     productCode;

    private Long       accountId;

    private BigDecimal amount;

    private BigDecimal interestRate;

    private BigDecimal interestAmount;

    private BigDecimal feeAmount;

    private BigDecimal actualLoanAmount;

    private BigDecimal penaltyInterestRate;

    private String     currency;

    private Integer    status;

    private String     repayPattern;

    private Integer    totalTerm;

    private Integer    termUnit;

    private String     accountMobile;

    private String     accountCardNo;

    private Date       applyTime;

    private Date       payFinishedTime;

    private String     payNo;

    private String     payResult;

    private Date       gmtCreated;

    private Date       gmtModified;

    private String     creator;

    private String     modifier;

    private String     isDeleted;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCapitalCode() {
        return capitalCode;
    }

    public void setCapitalCode(String capitalCode) {
        this.capitalCode = capitalCode == null ? null : capitalCode.trim();
    }

    public String getCapitalLoanTransNo() {
        return capitalLoanTransNo;
    }

    public void setCapitalLoanTransNo(String capitalLoanTransNo) {
        this.capitalLoanTransNo = capitalLoanTransNo == null ? null : capitalLoanTransNo.trim();
    }

    public String getOuterLoanOrderNo() {
        return outerLoanOrderNo;
    }

    public void setOuterLoanOrderNo(String outerLoanOrderNo) {
        this.outerLoanOrderNo = outerLoanOrderNo == null ? null : outerLoanOrderNo.trim();
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode == null ? null : productCode.trim();
    }

    public Long getAccountId() {
        return accountId;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public BigDecimal getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(BigDecimal interestRate) {
        this.interestRate = interestRate;
    }

    public BigDecimal getInterestAmount() {
        return interestAmount;
    }

    public void setInterestAmount(BigDecimal interestAmount) {
        this.interestAmount = interestAmount;
    }

    public BigDecimal getFeeAmount() {
        return feeAmount;
    }

    public void setFeeAmount(BigDecimal feeAmount) {
        this.feeAmount = feeAmount;
    }

    public BigDecimal getPenaltyInterestRate() {
        return penaltyInterestRate;
    }

    public void setPenaltyInterestRate(BigDecimal penaltyInterestRate) {
        this.penaltyInterestRate = penaltyInterestRate;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency == null ? null : currency.trim();
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getRepayPattern() {
        return repayPattern;
    }

    public void setRepayPattern(String repayPattern) {
        this.repayPattern = repayPattern == null ? null : repayPattern.trim();
    }

    public Integer getTotalTerm() {
        return totalTerm;
    }

    public void setTotalTerm(Integer totalTerm) {
        this.totalTerm = totalTerm;
    }

    public Integer getTermUnit() {
        return termUnit;
    }

    public void setTermUnit(Integer termUnit) {
        this.termUnit = termUnit;
    }

    public String getAccountMobile() {
        return accountMobile;
    }

    public void setAccountMobile(String accountMobile) {
        this.accountMobile = accountMobile == null ? null : accountMobile.trim();
    }

    public String getAccountCardNo() {
        return accountCardNo;
    }

    public void setAccountCardNo(String accountCardNo) {
        this.accountCardNo = accountCardNo == null ? null : accountCardNo.trim();
    }

    public Date getApplyTime() {
        return applyTime;
    }

    public void setApplyTime(Date applyTime) {
        this.applyTime = applyTime;
    }

    public Date getPayFinishedTime() {
        return payFinishedTime;
    }

    public void setPayFinishedTime(Date payFinishedTime) {
        this.payFinishedTime = payFinishedTime;
    }

    public String getPayNo() {
        return payNo;
    }

    public void setPayNo(String payNo) {
        this.payNo = payNo == null ? null : payNo.trim();
    }

    public String getPayResult() {
        return payResult;
    }

    public void setPayResult(String payResult) {
        this.payResult = payResult == null ? null : payResult.trim();
    }

    public Date getGmtCreated() {
        return gmtCreated;
    }

    public void setGmtCreated(Date gmtCreated) {
        this.gmtCreated = gmtCreated;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator == null ? null : creator.trim();
    }

    public String getModifier() {
        return modifier;
    }

    public void setModifier(String modifier) {
        this.modifier = modifier == null ? null : modifier.trim();
    }

    public String getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(String isDeleted) {
        this.isDeleted = isDeleted == null ? null : isDeleted.trim();
    }

    public BigDecimal getActualLoanAmount() {
        return actualLoanAmount;
    }

    public void setActualLoanAmount(BigDecimal actualLoanAmount) {
        this.actualLoanAmount = actualLoanAmount;
    }

}
