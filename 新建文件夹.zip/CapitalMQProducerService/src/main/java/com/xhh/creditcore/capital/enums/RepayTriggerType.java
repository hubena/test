package com.xhh.creditcore.capital.enums;

/**
 * zhangweixin 2018-01-10
 */
public enum RepayTriggerType {
    AUTO_DEDUCT(1, "自动代扣"),
    INITIATE_REPAY(2, "主动还款");
    private Integer key;
    private String  desc;

    public Integer getKey() {
        return key;
    }

    public String getDesc() {
        return desc;
    }

    RepayTriggerType(Integer key, String desc) {
        this.key = key;
        this.desc = desc;
    }

    public static RepayTriggerType getInstance(Integer key) {
        for (RepayTriggerType triggerType : RepayTriggerType.values()) {
            if (triggerType.key.equals(key)) {
                return triggerType;
            }
        }
        return null;
    }
}
