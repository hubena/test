package com.xhh.creditcore.capital.service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.*;

import javax.annotation.Resource;

import com.xhh.creditcore.capital.pay.PayRequest;
import com.xhh.creditcore.capital.service.sendSms.RepaymentSendSmsService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Lists;
import com.janty.cached.access.RedisCachedAccess;
import com.janty.core.dto.PageData;
import com.janty.core.dto.Pager;
import com.janty.core.exception.BusinessException;
import com.janty.core.spring.ApplicationContextUtil;
import com.janty.core.util.CommonBeanCopier;
import com.janty.core.util.DecimalUtil;
import com.janty.core.util.OrderNoGenerator;
import com.xhh.creditcore.capital.constant.CapitalConstants;
import com.xhh.creditcore.capital.constant.CapitalErrorCode;
import com.xhh.creditcore.capital.constant.CapitalRedisKey;
import com.xhh.creditcore.capital.dto.*;
import com.xhh.creditcore.capital.enums.*;
import com.xhh.creditcore.capital.model.*;
import com.xhh.creditcore.capital.pay.PayNoticeHandlerRequest;
import com.xhh.creditcore.capital.pay.PayResult;
import com.xhh.creditcore.capital.service.payimpl.PayServiceDelegate;
import com.xhh.creditcore.capital.service.remote.ProductRemoteService;
import com.xhh.creditcore.capital.service.remote.TransactionRemoteService;
import com.xhh.creditcore.capital.util.ListNotNullPredicate;
import com.xhh.creditcore.product.constant.ProductConfigKey;
import com.xhh.creditcore.product.enums.FeeChargePattern;
import com.xhh.creditcore.transaction.dto.LoanSettleRequest;

/**
 * 还款对外部系统接口服务类 zhangweixin 2018-01-10
 */
@Service
public class RepaymentService {

    private static Logger             logger       = LoggerFactory.getLogger(RepaymentService.class);
    @Resource
    private CapitalLoanTransService   loanTransService;
    @Resource
    private RepayTransService         repayTransService;
    @Resource
    private RepayPlanService          repayPlanService;
    @Resource
    private PayServiceDelegate        payServiceDelegate;
    @Resource
    private RepayPlanRecordService    repayPlanRecordService;
    @Resource
    private OrderLogService           orderLogService;
    @Resource
    AccountBankCardBindService        bankCardBindService;
    @Resource
    private TransactionRemoteService  transactionRemoteService;
    @Resource
    private RedisCachedAccess<Object> cachedAccess;
    @Resource
    private ProductRemoteService      productRemoteService;
    @Resource
    private PayOrderService           payOrderService;

    private ObjectMapper              objectMapper = new ObjectMapper();
    @Resource
    private RepaymentSendSmsService   repaymentSendSmsService;
    @Resource
    private RepaymentSendInnerLetterService repaymentSendInnerLetterService;

    /**
     * 按期还款
     *
     * @param request
     * @return
     */
    public void periodRepayment(PeriodRepaymentRequest request) throws Exception {
        CapitalLoanTrans loanTrans = loanTransService.queryDataByOutLoanOrderNo(request.getOuterLoanOrderNo());
        if (loanTrans == null) {
            throw new BusinessException(new CapitalErrorCode(CapitalErrorCode.Element.b_unknow_out_loan_order));
        }

        String key = CapitalRedisKey.LOCK_PREFIX + loanTrans.getCapitalLoanTransNo();
        try {
            cachedAccess.tryLock(key, 60L * 1000);
            //解决循环依赖问题
            RepaymentService repaymentService = ApplicationContextUtil.getContext().getBean(RepaymentService.class);
            repaymentService.doPeriodRepayment(loanTrans, request);
        } finally {
            cachedAccess.releaseLock(key);
        }
    }

    /**
     * 具体执行还款逻辑
     *
     * @param loanTrans
     * @param request
     * @return
     * @throws Exception
     */
    @Transactional(timeout = 60, rollbackFor = Exception.class)
    public RepayTrans doPeriodRepayment(CapitalLoanTrans loanTrans, PeriodRepaymentRequest request) throws JsonProcessingException {
        RepayPlan repayPlan = verifyRepay(loanTrans, request.getTermNo());
        RepayTrans repayTrans = createRepayTransRecord(request.getOuterRepayOrderNo(), request.getTriggerType(), repayPlan);
        PayRequest serviceRequest = buildPayRequest(repayTrans, PayMerchantType.PRINCIPAL_REPAY);
        processPayResult(payServiceDelegate.singleDeduct(serviceRequest));
        return repayTrans;
    }

    /**
     * 构建支付请求
     * 
     * @param repayTrans {@link RepayTrans} 还款交易记录
     * @param merchantType {@link PayMerchantType} 商户信息
     * @return
     */
    private PayRequest buildPayRequest(RepayTrans repayTrans, PayMerchantType merchantType) {
        AccountBankCardBind bankCardBind = getBankCardBindInfo(repayTrans.getAccountId());
        PayRequest request = new PayRequest();
        request.setCapitalOrderNo(repayTrans.getCapitalLoanTransNo());
        request.setProductCode(repayTrans.getProductCode());
        request.setAmount(repayTrans.getRepayAmount().doubleValue());
        request.setAccountName(bankCardBind.getAccountName());
        request.setBankCode(bankCardBind.getBankCode());
        request.setBankCardNo(bankCardBind.getBankCardNo());
        request.setCertNo(bankCardBind.getAccountIdCard());
        request.setMobile(bankCardBind.getAccountMobile());
        request.setPayMerchantType(merchantType);
        return request;
    }

    /**
     * 获取帐户绑卡信息
     * 
     * @param accountId {@link Long} 帐户id
     * @return
     */
    private AccountBankCardBind getBankCardBindInfo(Long accountId) {
        AccountBankCardBind bankCardBind = bankCardBindService.queryDataByAccountId(accountId);
        if (bankCardBind == null) {
            throw new BusinessException(new CapitalErrorCode(CapitalErrorCode.Element.b_card_info_not_exits));
        }
        return bankCardBind;
    }

    /**
     * 定时任务自动按期还款
     *
     * @param productCode 产品码
     */
    @Async
    public void autoRepayment(String productCode) throws Exception {
        List<RepayPlan> repayPlanList = repayPlanService.queryExpireRepayPlanByProductCode(productCode);
        for (RepayPlan repayPlan : repayPlanList) {
            PeriodRepaymentRequest repaymentRequest = new PeriodRepaymentRequest();
            CapitalLoanTrans loanTrans = loanTransService.queryDataByLoanTransNo(repayPlan.getCapitalLoanTransNo());
            repaymentRequest.setAccountId(repayPlan.getAccountId());
            repaymentRequest.setOuterLoanOrderNo(loanTrans.getOuterLoanOrderNo());
            repaymentRequest.setOuterRepayOrderNo(OrderNoGenerator.getOrderNo(CapitalConstants.capital_repay_biz_code));
            repaymentRequest.setTermNo(repayPlan.getTermNo());
            repaymentRequest.setTriggerType(RepayTriggerType.AUTO_DEDUCT.getKey());
            logger.info("开始自动还款,订单号:{}", repaymentRequest.toString());
            periodRepayment(repaymentRequest);
        }
    }

    /**
     * 验证该笔还款是否符合要求
     *
     * @param capitalLoanTrans 借贷借款交易记录
     * @param termNo 第几期
     * @return
     */
    public RepayPlan verifyRepay(CapitalLoanTrans capitalLoanTrans, Integer termNo) {

        Integer transStatus = capitalLoanTrans.getStatus();
        Integer overDue = CapitalLoanTransStatus.ORVER_DUE.getKey();
        Integer success = CapitalLoanTransStatus.SUCCESS.getKey();
        if (!transStatus.equals(overDue) && !transStatus.equals(success)) {
            logger.error("错误的借贷订单状态:" + transStatus);
            throw new BusinessException(new CapitalErrorCode(CapitalErrorCode.Element.b_error_loan_order_status));
        }

        Optional<RepayPlan> optionalRepayPlan = Optional.ofNullable(repayPlanService.queryCurrentVaildRepayPlan(capitalLoanTrans.getCapitalLoanTransNo()));
        return optionalRepayPlan.map(repayPlan -> {
            //判断是否跨期还款
            if (!repayPlan.getTermNo().equals(termNo)) {
                throw new BusinessException(new CapitalErrorCode(CapitalErrorCode.Element.b_not_allow_stride_period));
            }
            //判断状态是否正常
            Integer status = repayPlan.getStatus();
            if (status.equals(RepayPlanStatus.CANCELED.getKey()) || status.equals(RepayPlanStatus.REPAIED.getKey())) {
                throw new BusinessException(new CapitalErrorCode(CapitalErrorCode.Element.b_repay_plan_compelet_or_cancle));
            }
            return repayPlan;
        }).map((repayPlan) -> verifyRepayTrans(repayPlan))
                .orElseThrow(() -> new BusinessException(new CapitalErrorCode(CapitalErrorCode.Element.b_not_exsit_need_repay_plan)));
    }

    private RepayPlan verifyRepayTrans(RepayPlan repayPlan) {
        RepayTrans queryTrans = new RepayTrans();
        queryTrans.setAccountId(repayPlan.getAccountId());
        queryTrans.setRepayPlanId(repayPlan.getId());
        List<RepayTrans> repayTrans = repayTransService.queryDataByConditon(queryTrans);
        repayTrans.stream()
                  .filter(it -> !it.getStatus().equals(RepayTransStatus.PRE_PAY.getKey()))
                  .forEach(it -> {
                    if (!it.getStatus().equals(RepayTransStatus.FAIL.getKey())) {
                        throw new BusinessException(new CapitalErrorCode(CapitalErrorCode.Element.b_repay_process));
                    }
                  });
        return repayPlan;
    }

    /**
     * 创建并保存借贷还款交易记录
     *
     * @param repayPlan 还款计划
     */
    public RepayTrans createRepayTransRecord(String outRepayOrderNo, Integer triggerType, RepayPlan repayPlan) {
        AccountBankCardBind cardBindInfo = getBankCardBindInfo(repayPlan.getAccountId());
        Date date = new Date();
        RepayTrans repayTrans = new RepayTrans();
        repayTrans.setRepayType(RepayType.BY_PERIOD.getKey());
        repayTrans.setStatus(RepayTransStatus.INIT.getKey());
        repayTrans.setRepayTriggerType(triggerType);
        repayTrans.setRepayPlanId(repayPlan.getId());
        repayTrans.setAccountId(repayPlan.getAccountId());
        repayTrans.setCapitalLoanTransNo(OrderNoGenerator.getOrderNo(CapitalConstants.capital_repay_biz_code));
        repayTrans.setOuterRepayOrderNo(outRepayOrderNo);
        repayTrans.setProductCode(repayPlan.getProductCode());
        repayTrans.setAccountMobile(cardBindInfo.getAccountMobile());
        repayTrans.setAccountCardNo(cardBindInfo.getBankCardNo());
        repayTrans.setRepayApplyTime(date);
        repayTrans.setGmtModified(date);
        repayTrans.setGmtCreated(date);
        repayTrans.setRepayAmount(calculateDeductAmountAndSaveRecord(repayPlan, repayTrans.getCapitalLoanTransNo()));
        return repayTrans;
    }

    /**
     * 按期还款根据还款计划计算出本次应该还的金额并保存还款计划变动日志
     *
     * @param repayPlan
     * @param capitalRepayNo
     * @return
     */
    private BigDecimal calculateDeductAmountAndSaveRecord(RepayPlan repayPlan, String capitalRepayNo) {
        BigDecimal subtractPrincipal = DecimalUtil.subtract(repayPlan.getDuePrincipal(), repayPlan.getRepaidPrincipal());
        BigDecimal subtractInterest = DecimalUtil.subtract(repayPlan.getDueInterest(), repayPlan.getRepaidInterest());
        BigDecimal subtractPenalty = DecimalUtil.subtract(repayPlan.getDuePenalty(), repayPlan.getRepaidPenalty());
        BigDecimal subtractFee = DecimalUtil.subtract(repayPlan.getDueFee(), repayPlan.getRepaidFee());
        RepayPlanRecord newRepayPlanRecord = new RepayPlanRecord();
        List<RepayPlanRecord> repayPlanRecords = Lists.newArrayList();
        if (DecimalUtil.greaterThanZero(subtractPrincipal)) {
            newRepayPlanRecord.setAmountDirection(RepayPlanAmountDirection.REPAID.getKey());
            newRepayPlanRecord.setTransType(RepayPlanRecordTransType.REPAY.getKey());
            newRepayPlanRecord.setAmountType(RepayPlanRecordAmountType.PRINCIPAL.getKey());
            newRepayPlanRecord.setRepayPlanId(repayPlan.getId());
            newRepayPlanRecord.setAmount(subtractPrincipal);
            newRepayPlanRecord.setTransNo(capitalRepayNo);
            newRepayPlanRecord.setGmtCreated(new Date());
            newRepayPlanRecord.setAccountId(repayPlan.getAccountId());
            repayPlanRecords.add(newRepayPlanRecord);
        }

        if (DecimalUtil.greaterThanZero(subtractInterest)) {
            RepayPlanRecord temp = new RepayPlanRecord();
            CommonBeanCopier.copy(newRepayPlanRecord, temp);
            newRepayPlanRecord = temp;
            newRepayPlanRecord.setAmount(subtractInterest);
            newRepayPlanRecord.setAmountType(RepayPlanRecordAmountType.INTEREST.getKey());
            repayPlanRecords.add(newRepayPlanRecord);
        }

        if (DecimalUtil.greaterThanZero(subtractPenalty)) {
            RepayPlanRecord temp = new RepayPlanRecord();
            CommonBeanCopier.copy(newRepayPlanRecord, temp);
            newRepayPlanRecord = temp;
            newRepayPlanRecord.setAmount(subtractPenalty);
            newRepayPlanRecord.setAmountType(RepayPlanRecordAmountType.PENALTY.getKey());
            repayPlanRecords.add(newRepayPlanRecord);
        }

        if (DecimalUtil.greaterThanZero(subtractFee)) {
            RepayPlanRecord temp = new RepayPlanRecord();
            CommonBeanCopier.copy(newRepayPlanRecord, temp);
            newRepayPlanRecord = temp;
            newRepayPlanRecord.setAmount(subtractFee);
            newRepayPlanRecord.setAmountType(RepayPlanRecordAmountType.SERVICE_FEE.getKey());
            repayPlanRecords.add(newRepayPlanRecord);
        }

        repayPlanRecordService.addDataBatch(repayPlanRecords);
        subtractPrincipal = DecimalUtil.add(subtractPrincipal, subtractInterest);
        subtractPrincipal = DecimalUtil.add(subtractPrincipal, subtractPenalty);
        subtractPrincipal = DecimalUtil.add(subtractPrincipal, subtractFee);
        return subtractPrincipal;
    }

    /**
     * 计算本次此还款计划还剩多少钱要还
     *
     * @param repayPlan
     * @return
     */
    private BigDecimal calculateRemainRepayAmount(RepayPlan repayPlan) {
        BigDecimal subtractPrincipal = DecimalUtil.subtract(repayPlan.getDuePrincipal(), repayPlan.getRepaidPrincipal());
        BigDecimal subtractInterest = DecimalUtil.subtract(repayPlan.getDueInterest(), repayPlan.getRepaidInterest());
        BigDecimal subtractPenalty = DecimalUtil.subtract(repayPlan.getDuePenalty(), repayPlan.getRepaidPenalty());
        BigDecimal subtractFee = DecimalUtil.subtract(repayPlan.getDueFee(), repayPlan.getRepaidFee());
        subtractPrincipal = DecimalUtil.add(subtractPrincipal, subtractInterest);
        subtractPrincipal = DecimalUtil.add(subtractPrincipal, subtractPenalty);
        subtractPrincipal = DecimalUtil.add(subtractPrincipal, subtractFee);
        return subtractPrincipal;
    }

    private BigDecimal calculateOriginalRepayAmount(RepayPlan repayPlan) {
        BigDecimal amount;
        amount = DecimalUtil.add(repayPlan.getDuePrincipal(), repayPlan.getDueInterest());
        amount = DecimalUtil.add(amount, repayPlan.getDueFee());
        amount = DecimalUtil.add(amount, repayPlan.getDuePenalty());
        return amount;
    }

    /**
     * 认证支付还款预还款
     * 
     * @param repaymentPreRequest
     * @return
     */
    public RepaymentDto certPayRepaymentPrePay(CertPayRepayPreRequest repaymentPreRequest) {
        CapitalLoanTrans loanTrans = loanTransService.queryDataByOutLoanOrderNo(repaymentPreRequest.getOuterLoanOrderNo());
        if (loanTrans == null) {
            throw new BusinessException(new CapitalErrorCode(CapitalErrorCode.Element.b_unknow_out_loan_order));
        }

        RepaymentDto repaymentDto;
        String key = CapitalRedisKey.LOCK_PREFIX + loanTrans.getCapitalLoanTransNo();
        try {
            cachedAccess.tryLock(key, 60L * 1000);
            repaymentDto = doRepaymentPrePay(loanTrans, repaymentPreRequest);
        } finally {
            cachedAccess.releaseLock(key);
        }
        return repaymentDto;
    }

    /**
     * 执行预还款
     * 
     * @param loanTrans
     * @param request
     * @return
     */
    public RepaymentDto doRepaymentPrePay(CapitalLoanTrans loanTrans, CertPayRepayPreRequest request) {
        RepayPlan repayPlan = verifyRepay(loanTrans, request.getTermNo());
        RepayTrans repayTrans = createRepayTransRecord(request.getOuterRepayOrderNo(), request.getTriggerType(), repayPlan);
        repayTrans.setStatus(RepayTransStatus.PRE_PAY.getKey());
        repayTrans.setCapitalLoanTransNo(OrderNoGenerator.getOrderNo(CapitalConstants.capital_cert_pay_biz_code));

        AccountBankCardBind cardBindInfo = getBankCardBindInfo(repayPlan.getAccountId());
        PayRequest payRequest = new PayRequest();
        payRequest.setAmount(repayTrans.getRepayAmount().doubleValue());
        payRequest.setAccountId(repayTrans.getAccountId().toString());
        payRequest.setCapitalOrderNo(repayTrans.getCapitalLoanTransNo());
        payRequest.setProductCode(repayTrans.getProductCode());
        payRequest.setMobile(cardBindInfo.getAccountMobile());
        payRequest.setAccountName(cardBindInfo.getAccountName());
        payRequest.setCertNo(cardBindInfo.getAccountIdCard());
        payRequest.setBankCardNo(cardBindInfo.getBankCardNo());
        payRequest.setBankCode(cardBindInfo.getBankCode());
        payRequest.setPayMerchantType(PayMerchantType.PRINCIPAL_REPAY);
        PayResult payResult = payServiceDelegate.certPayPrePay(payRequest);

        RepaymentDto repaymentDto = new RepaymentDto();
        repaymentDto.setOuterRepayOrderNo(request.getOuterRepayOrderNo());
        if (payResult.getResCode().equals(PayResult.THIRD_SYNC_SUCCESS)) {
            repayTransService.addData(repayTrans);
            repaymentDto.setRespCode(RepaymentDto.SUCCESS_CODE);
        } else {
            repaymentDto.setRespCode(RepaymentDto.FAIL_CODE);
            repaymentDto.setRespMsg(payResult.getResMsg());
        }
        return repaymentDto;
    }

    /**
     * 认证支付还款确认还款
     * 
     * @param request
     * @return
     */
    public RepaymentDto certPayRepaymentConfirmPay(CertPayRepayConfirmRequest request) {
        Optional<RepayTrans> optional = Optional.ofNullable(repayTransService.queryDataByOutTransNo(request.getOuterRepayOrderNo()));
        if (optional.isPresent()) {
            RepayTrans repayTrans = optional.get();
            RepayPlan repayPlan = repayPlanService.queryDataById(repayTrans.getRepayPlanId());
            String key = CapitalRedisKey.LOCK_PREFIX + repayPlan.getCapitalLoanTransNo();
            try {
                cachedAccess.tryLock(key, 60L * 1000);
                //解决循环依赖问题
                RepaymentService repaymentService = ApplicationContextUtil.getContext().getBean(RepaymentService.class);
                return repaymentService.doRepaymentConfirmPay(request, repayPlan, repayTrans);
            } finally {
                cachedAccess.releaseLock(key);
            }
        } else {
            throw new BusinessException(new CapitalErrorCode(CapitalErrorCode.Element.b_error_repay_order));
        }
    }

    /**
     * 执行确认还款
     * 
     * @param request
     * @return
     */
    @Transactional(rollbackFor = Exception.class, timeout = 30)
    public RepaymentDto doRepaymentConfirmPay(CertPayRepayConfirmRequest request, RepayPlan repayPlan, RepayTrans repayTrans) {
        verifyRepayTrans(repayPlan);
        //double check 确保拿到的记录状态是最新的
        repayTrans = repayTransService.queryDataById(repayTrans.getId());
        Integer currStatus = repayTrans.getStatus();
        //预支付或者支付失败都过
        if (!currStatus.equals(RepayTransStatus.PRE_PAY.getKey()) && !currStatus.equals(RepayTransStatus.FAIL.getKey())) {
            throw new BusinessException(new CapitalErrorCode(CapitalErrorCode.Element.b_repay_process));
        }

        repayTrans.setStatus(RepayTransStatus.INIT.getKey());
        repayTransService.updateRetransRecordStatus(repayTrans);
        PayRequest payRequest = buildPayRequest(repayTrans, PayMerchantType.PRINCIPAL_REPAY);
        payRequest.setAccountId(repayTrans.getAccountId().toString());
        payRequest.setSmsCode(request.getSmsCode());
        return processPayResult(payServiceDelegate.certPayConfirmPay(payRequest));
    }

    /**
     * 处理支付结果
     * 
     * @param payResult
     * @return
     */
    private RepaymentDto processPayResult(PayResult payResult) {
        RepayTrans repayTrans = repayTransService.queryDataByTransNo(payResult.getOrderNo());
        OrderLog orderLog = new OrderLog();
        Date date = new Date();
        orderLog.setOrderType(OrderLogType.REPAY.getKey());
        orderLog.setOpName("还款");
        orderLog.setOpTime(date);
        orderLog.setGmtCreated(date);
        orderLog.setOrderNo(repayTrans.getCapitalLoanTransNo());
        try {
            orderLog.setRequestParam(objectMapper.writeValueAsString(payResult));
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }

        String resCode = payResult.getResCode();
        RepaymentDto payRepaymentDto = new RepaymentDto();
        payRepaymentDto.setOuterRepayOrderNo(repayTrans.getOuterRepayOrderNo());
        if (resCode.equals(PayResult.THIRD_SYNC_SUCCESS) || resCode.equals(PayResult.THIRD_SYNC_PENDING)) {
            repayTrans.setStatus(RepayTransStatus.PROCESSING.getKey());
            orderLog.setOpResult(OrderLogOpResult.SYNC_SUCCESS.getKey());
            payRepaymentDto.setRespCode(RepaymentDto.SUCCESS_CODE);
        } else if (resCode.equals(PayResult.THIRD_SYNC_FAIL)) {
            repayTrans.setStatus(RepayTransStatus.FAIL.getKey());
            orderLog.setOpResult(OrderLogOpResult.FAIL.getKey());
            payRepaymentDto.setRespCode(RepaymentDto.FAIL_CODE);
            payRepaymentDto.setRespMsg(payResult.getResMsg());
        } else if (resCode.equals(PayResult.THIRD_INVOKE_EXCEPTION)) {
            //暂时不做处理
            payRepaymentDto.setRespCode(RepaymentDto.SUCCESS_CODE);
        }
        repayTrans.setGmtModified(date);

        orderLogService.addData(orderLog);
        repayTransService.updateStatusByIdForSyncReturn(repayTrans);
        return payRepaymentDto;
    }

    /**
     * 认证支付重发验证码
     * 
     * @param request
     * @return
     */
    public RepaymentDto certPayRepaymentSendSms(CertPayRepaySendSmsRequest request) {
        Optional<Object> optional = Optional.ofNullable(repayTransService.queryDataByOutTransNo(request.getOuterRepayOrderNo()));
        if (!optional.isPresent()) {
            throw new BusinessException(new CapitalErrorCode(CapitalErrorCode.Element.b_error_repay_order));
        }

        RepayTrans repayTrans = (RepayTrans) optional.get();
        PayRequest payRequest = new PayRequest();
        payRequest.setCapitalOrderNo(repayTrans.getCapitalLoanTransNo());
        payRequest.setMobile(repayTrans.getAccountMobile());
        payRequest.setProductCode(repayTrans.getProductCode());
        payRequest.setPayMerchantType(PayMerchantType.PRINCIPAL_REPAY);

        PayResult payResult = payServiceDelegate.repeatSendSms(payRequest);
        RepaymentDto repaymentDto = new RepaymentDto();
        repaymentDto.setOuterRepayOrderNo(repayTrans.getOuterRepayOrderNo());
        if (payResult.getResCode().equals(PayResult.THIRD_SYNC_SUCCESS)) {
            repaymentDto.setRespCode(RepaymentDto.SUCCESS_CODE);
        } else {
            repaymentDto.setRespCode(RepaymentDto.FAIL_CODE);
            repaymentDto.setRespMsg("发送失败");
        }

        return repaymentDto;
    }

    /**
     * 处理还款中订单,定时查单任务调用
     */
    public void processRepayingOrder() throws Exception {
        ListNotNullPredicate.forEach(repayTransService.queryRepayStateOrder(), repayTrans -> {
            logger.info("查询还款订单处理结果,订单号:{}", repayTrans.getCapitalLoanTransNo());

            PayRequest payRequest = new PayRequest();
            payRequest.setProductCode(repayTrans.getProductCode());
            payRequest.setCapitalOrderNo(repayTrans.getCapitalLoanTransNo());
            payRequest.setPayMerchantType(PayMerchantType.PRINCIPAL_REPAY);
            PayResult queryResult;
            if (payRequest.getCapitalOrderNo().startsWith(CapitalConstants.capital_cert_pay_biz_code)) {
                queryResult = payServiceDelegate.certPayOrderQuery(payRequest);
            } else {
                queryResult = payServiceDelegate.singleDeductOrderQuery(payRequest);
            }
            logger.info("处理结果:{}", queryResult.toString());

            String resCode = queryResult.getResCode();
            PayNoticeHandlerRequest handlerRequest = new PayNoticeHandlerRequest();
            handlerRequest.setThirdResCode(resCode);
            handlerRequest.setThirdResMsg(queryResult.getResMsg());
            handlerRequest.setThirdOrderNo(queryResult.getThirdOrderNo());
            handlerRequest.setOrderNo(queryResult.getOrderNo());
            if (resCode.equals(PayResult.THIRD_SYNC_SUCCESS)) {
                //执行成功
                deductPrincipalSuccessHandle(handlerRequest);
            } else if (resCode.equals(PayResult.THIRD_SYNC_FAIL) || resCode.equals(PayResult.THIRD_UNCOMMIT)) {
                //执行失败
                deductPrincipalFailHandle(handlerRequest);
            }

        });
    }

    /**
     * 查询每个借款的还款计划
     *
     * @param repayPlanQueryRequest
     * @return
     */
    public List<RepayPlanQueryDto> queryRepayPlan(RepayPlanQueryRequest repayPlanQueryRequest) {
        Optional<CapitalLoanTrans> optionalLoanTrans;
        optionalLoanTrans = Optional.ofNullable(loanTransService.queryDataByOutLoanOrderNo(repayPlanQueryRequest.getOuterLoanOrderNo()));
        return optionalLoanTrans.map(loanTrans -> {

            List<RepayPlanQueryDto> repayPlanQueryDtos = Lists.newArrayList();
            RepayPlan queryRepayPlan = new RepayPlan();
            queryRepayPlan.setProductCode(repayPlanQueryRequest.getProductCode());
            queryRepayPlan.setAccountId(repayPlanQueryRequest.getAccountId());
            queryRepayPlan.setCapitalLoanTransNo(loanTrans.getCapitalLoanTransNo());
            List<RepayPlan> repayPlanList = repayPlanService.queryRepayPlan(queryRepayPlan);

            repayPlanList.forEach((repayPlan) -> {
                RepayPlanQueryDto repayPlanQueryDto = new RepayPlanQueryDto();
                CommonBeanCopier.copy(repayPlan, repayPlanQueryDto);

                if (repayPlanQueryDto.getStatus().equals(RepayPlanStatus.OVERDUED.getKey())) {
                    LocalDateTime dateTime = LocalDateTime.ofInstant(repayPlanQueryDto.getAgreedRepayDate().toInstant(), ZoneId.systemDefault());
                    repayPlanQueryDto.setOverDueDays((int) ChronoUnit.DAYS.between(dateTime.toLocalDate(), LocalDate.now()));
                    repayPlanQueryDto.setOverDuePenalty(DecimalUtil.subtract(repayPlan.getDuePenalty(), repayPlan.getRepaidPenalty()));
                } else {
                    repayPlanQueryDto.setOverDueDays(0);
                    repayPlanQueryDto.setOverDuePenalty(BigDecimal.ZERO);
                }

                repayPlanQueryDto.setRemainFee(DecimalUtil.subtract(repayPlan.getDueFee(), repayPlan.getRepaidFee()));
                repayPlanQueryDto.setRemainInterest(DecimalUtil.subtract(repayPlan.getDueInterest(), repayPlan.getRepaidInterest()));
                repayPlanQueryDto.setRemainPrincipal(DecimalUtil.subtract(repayPlan.getDuePrincipal(), repayPlan.getRepaidPrincipal()));
                repayPlanQueryDto.setRemainTotalRepay(calculateRemainRepayAmount(repayPlan));
                repayPlanQueryDto.setOriginalTotalRepay(calculateOriginalRepayAmount(repayPlan));
                repayPlanQueryDtos.add(repayPlanQueryDto);
            });
            return repayPlanQueryDtos;
        }).orElse(Lists.newArrayList());
    }

    /**
     * 分页查询还款交易记录
     *
     * @param request
     * @return
     */
    public PageData<RepayCapitalRecordQueryDto> queryRepayTransRecordByPage(CapitalRecordQueryRequest request) {
        Pager pager = new Pager();
        pager.setPageNum(request.getPageNum());
        pager.setPageSize(request.getPageSize());
        return repayTransService.queryRepayTransRecordByPage(request, pager);
    }

    /**
     * 代扣本息成功处理
     *
     * @param handlerRequest
     */
    public void deductPrincipalSuccessHandle(PayNoticeHandlerRequest handlerRequest) {
        RepaymentService proxy = ApplicationContextUtil.getBeanByType(RepaymentService.class);
        try {
            cachedAccess.tryLock(CapitalRedisKey.LOCK_PREFIX + handlerRequest.getOrderNo(), 1000 * 30L);
            if (proxy.doDeductPrincipalSuccessHandle(handlerRequest)) {
                proxy.noticeTransRepaySquared(handlerRequest.getOrderNo());
            }
        } finally {
            cachedAccess.releaseLock(CapitalRedisKey.LOCK_PREFIX + handlerRequest.getOrderNo());
        }
        proxy.payFee(handlerRequest.getOrderNo());
        //代扣成功发送短信
        repaymentSendSmsService.repaymentSuccessSendSms(handlerRequest.getOrderNo());
        //代扣成功发送站内信
        repaymentSendInnerLetterService.repaymentSuccessSendInnerLetter(handlerRequest.getOrderNo());

    }

    /**
     * 执行还款代扣成功业务逻辑
     *
     * @param handlerRequest {@link PayNoticeHandlerRequest}
     * @return true:通知交易还款已结清 false:不需要通知交易
     */
    @Transactional(rollbackFor = Exception.class, timeout = 60)
    public boolean doDeductPrincipalSuccessHandle(PayNoticeHandlerRequest handlerRequest) {
        Date date = new Date();
        RepayTrans repayTrans = getRepayTransForDeductPrincipalHandle(handlerRequest.getOrderNo());
        //返回null表明还款已经成功处理
        if (repayTrans == null) {
            return false;
        }

        //修改还款交易记录数据
        RepayTrans updateRepayTrans = new RepayTrans();
        updateRepayTrans.setId(repayTrans.getId());
        updateRepayTrans.setPayNo(handlerRequest.getThirdOrderNo());
        updateRepayTrans.setPayResult("SUCCESS");
        updateRepayTrans.setStatus(RepayTransStatus.SUCCESS.getKey());
        repayTransService.updateDataForDeductNotice(updateRepayTrans);

        //修改还款计划状态
        RepayPlan repayPlan = repayPlanService.queryDataById(repayTrans.getRepayPlanId());
        RepayPlan updateRepayPlan = new RepayPlan();
        updateRepayPlan.setId(repayTrans.getRepayPlanId());
        updateRepayPlan.setStatus(RepayPlanStatus.REPAIED.getKey());
        calculateRepaidAmount(updateRepayPlan);
        repayPlanService.updateDataForRepaySuccess(updateRepayPlan);

        //记录日志
        OrderLog orderLog = new OrderLog();
        orderLog.setOpResult(OrderLogOpResult.ASYNC_SUCCESS.getKey());
        orderLog.setOrderNo(handlerRequest.getOrderNo());
        orderLog.setOpName("代扣本金回调");
        orderLog.setOrderType(OrderLogType.REPAY.getKey());
        orderLog.setOpTime(date);
        orderLog.setResponseResult(handlerRequest.getThirdResMsg());
        orderLogService.addData(orderLog);

        //修改借贷交易记录状态
        List<RepayPlan> repayPlanList = repayPlanService.queryAllPlanByTransNo(repayPlan.getCapitalLoanTransNo());
        if (!repayPlanList.isEmpty()) {
            repayPlanList.sort(Comparator.comparing(RepayPlan::getTermNo));
            Integer lastTermNo = repayPlanList.get(repayPlanList.size() - 1).getTermNo();
            CapitalLoanTrans updateLoanTrans = new CapitalLoanTrans();
            Boolean noticeTrans = false;
            if (lastTermNo.equals(repayPlan.getTermNo())) {
                //最后一期改状态为结清
                updateLoanTrans.setStatus(CapitalLoanTransStatus.SQUARED_UP.getKey());
                noticeTrans = true;
            } else {
                //不是最后一期改状态为放款成功(还款中)
                updateLoanTrans.setStatus(CapitalLoanTransStatus.SUCCESS.getKey());
            }
            updateLoanTrans.setCapitalLoanTransNo(repayPlan.getCapitalLoanTransNo());
            loanTransService.updateDataForDeductSuccessNotice(updateLoanTrans);
            return noticeTrans;
        } else {
            logger.error("借款流水号:{}对应的还款计划不存在", repayPlan.getCapitalLoanTransNo());
            throw new BusinessException(new CapitalErrorCode(CapitalErrorCode.Element.b_not_found_repay_plans));
        }
    }

    /**
     * 通知交易系统还款结清
     *
     * @param orderNo
     */
    public void noticeTransRepaySquared(String orderNo) {
        try {
            RepayTrans repayTrans = repayTransService.queryDataByTransNo(orderNo);
            RepayPlan repayPlan = repayPlanService.queryDataById(repayTrans.getRepayPlanId());
            CapitalLoanTrans capitalLoanTrans = loanTransService.queryDataByLoanTransNo(repayPlan.getCapitalLoanTransNo());
            LoanSettleRequest settleRequest = new LoanSettleRequest();
            settleRequest.setLoanOrderNo(capitalLoanTrans.getOuterLoanOrderNo());
            transactionRemoteService.loanSettle(settleRequest);
        } catch (Exception e) {
            logger.error("还款结清通知交易系统失败,还款流水号:{}", orderNo, e);
        }
    }

    /**
     * 代付服务费
     *
     * @param orderNo {@link String} 还款流水号
     */
    public void payFee(String orderNo) {

        RepayTrans repayTrans = repayTransService.queryDataByTransNo(orderNo);
        Map<String, String> product = productRemoteService.getProductByCode(repayTrans.getProductCode());
        if (FeeChargePattern.installment.getKey().equals(product.get(ProductConfigKey.loan_fee_charge_pattern))) {
            RepayPlan repayPlan = repayPlanService.queryDataById(repayTrans.getRepayPlanId());
            BigDecimal dueFee = repayPlan.getDueFee();
            BigDecimal repaidFee = repayPlan.getRepaidFee();

            if (DecimalUtil.greaterThanZero(DecimalUtil.subtract(dueFee, repaidFee))) {
                PayOrder payOrder = payOrderService.queryDataByRelateTranNoAndTranType(orderNo, PayOrderTransType.LOAN_PAY_FEE.getKey());
                if (payOrder != null) {
                    logger.error("还款流水:[{}]对应的代付服务费已经在处理中...", orderNo);
                } else {
                    payOrderService.saveFeePayOrderByInstallment(repayPlan, repayTrans);
                }
            }
        } else {
            logger.info("还款流水:[{}]对应的借款不是按期收取服务费忽略执行", orderNo);
        }

    }

    /**
     * 还款(本息)成功计算还款计划需要冲正(冲销)的数据
     *
     * @param repayPlan
     */
    private void calculateRepaidAmount(RepayPlan repayPlan) {
        RepayPlanRecord queryRecord = new RepayPlanRecord();
        queryRecord.setRepayPlanId(repayPlan.getId());
        List<RepayPlanRecord> repayPlanRecords = repayPlanRecordService.queryDataBycondition(queryRecord);
        for (RepayPlanRecord record : repayPlanRecords) {
            String amountType = record.getAmountType();
            if (amountType.equals(RepayPlanRecordAmountType.PRINCIPAL.getKey())) {
                //冲正本金
                repayPlan.setRepaidPrincipal(record.getAmount());
            } else if (amountType.equals(RepayPlanRecordAmountType.INTEREST.getKey())) {
                //冲正利息
                repayPlan.setRepaidInterest(record.getAmount());
            } else if (amountType.equals(RepayPlanRecordAmountType.PENALTY.getKey())) {
                //冲正罚息
                repayPlan.setRepaidPenalty(record.getAmount());
            } else {
                //冲正服务费
                repayPlan.setRepaidFee(record.getAmount());
            }

        }
    }

    /**
     * 代扣本息失败处理
     *
     * @param handlerRequest
     */
    public void deductPrincipalFailHandle(PayNoticeHandlerRequest handlerRequest) {

        RepaymentService proxy = ApplicationContextUtil.getBeanByType(RepaymentService.class);
        try {
            cachedAccess.tryLock(CapitalRedisKey.LOCK_PREFIX + handlerRequest.getOrderNo(), 1000 * 30L);
            proxy.deductPrincipalFailHandle(handlerRequest);
        } finally {
            cachedAccess.releaseLock(CapitalRedisKey.LOCK_PREFIX + handlerRequest.getOrderNo());
        }
        //代扣失败短信发送
        repaymentSendSmsService.repaymentFailSendSms(handlerRequest.getOrderNo());
        //代扣失败发发送站内信
        repaymentSendInnerLetterService.repaymentFailSendInnerLetter(handlerRequest.getOrderNo());


    }

    @Transactional(rollbackFor = Exception.class, timeout = 30)
    public void doDeductPrincipalFailHandle(PayNoticeHandlerRequest handlerRequest) {
        Optional.ofNullable(getRepayTransForDeductPrincipalHandle(handlerRequest.getOrderNo())).ifPresent(repayTrans -> {
            //修改状态为失败
            RepayTrans updateRepayTrans = new RepayTrans();
            updateRepayTrans.setId(repayTrans.getId());
            updateRepayTrans.setPayNo(handlerRequest.getThirdOrderNo());
            updateRepayTrans.setPayResult("FAIL");
            updateRepayTrans.setStatus(RepayTransStatus.FAIL.getKey());
            repayTransService.updateDataForDeductNotice(updateRepayTrans);

            //记录日志
            OrderLog orderLog = new OrderLog();
            orderLog.setOpResult(OrderLogOpResult.FAIL.getKey());
            orderLog.setOrderNo(handlerRequest.getOrderNo());
            orderLog.setOpName("还款回调");
            orderLog.setOrderType(OrderLogType.REPAY.getKey());
            orderLog.setOpTime(new Date());
            orderLog.setResponseResult(handlerRequest.getThirdResMsg());
            orderLogService.addData(orderLog);
        });
    }

    /**
     * 代扣本息处理时获取还款交易记录并检查记录是否符合要求<br>
     * 1.不存在的订单号抛出异常 2.已经处理过返回null 3.还没有处理则返回待处理的还款交易记录
     *
     * @param repayOrderNo
     * @return
     */
    private RepayTrans getRepayTransForDeductPrincipalHandle(String repayOrderNo) {
        RepayTrans queryTrans = new RepayTrans();
        queryTrans.setCapitalLoanTransNo(repayOrderNo);
        return Optional.ofNullable(repayTransService.queryOneDataByConditon(queryTrans)).map(repayTrans -> {
            RepayTransStatus transStatus = RepayTransStatus.getInstance(repayTrans.getStatus());
            if (RepayTransStatus.SUCCESS.equals(transStatus) || RepayTransStatus.FAIL.equals(transStatus)) {
                logger.info("[{}]还款业务回调已处理成功,忽略回调.....", repayOrderNo);
                repayTrans = null;
            }
            return Optional.ofNullable(repayTrans);
        }).orElseThrow(() -> new BusinessException("未知还款订单号:" + repayOrderNo)).get();
    }

}
