package com.xhh.creditcore.capital.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.xhh.creditcore.capital.model.RepayPlan;

@Repository
public interface RepayPlanMapper {
    int deleteByPrimaryKey(Long id);

    int insert(RepayPlan record);

    int insertSelective(RepayPlan record);

    RepayPlan selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(RepayPlan record);

    int updateByPrimaryKey(RepayPlan record);

    List<RepayPlan> selectByCondition(RepayPlan repayPlan);

    RepayPlan selectCurrentVaildRepayPlan(RepayPlan repayPlan);

    int updateDataForRepaySuccess(RepayPlan repayPlanRecord);

    List<RepayPlan> selectListBeyondTime();

    List<RepayPlan> selectByStatus(@Param("status") Integer status);

    void updatePenalty(RepayPlan repayPlan);

    void updateStatusById(RepayPlan repayPlan);

    List<RepayPlan> queryAllPlanByTransNo(RepayPlan repayPlan);

    List<RepayPlan> queryExpireRepayPlanByProductCode(RepayPlan repayPlan);

    int updateIsEffect(@Param("isEffect") Integer isEffect, @Param("capitalLoanTransNo") String capitalLoanTransNo);

    /**
     * 查询当日后3天的还款记录
     */
    List<RepayPlan> queryTodayBeforeThreeDayRepayPlan();
    /**
     * 查询当日后1天的还款记录
     */
    List<RepayPlan>  queryTodayBeforeOneDayRepayPlan();

    /**
     * 查询逾期 1,2,3,4,5的还款计划
     * @return
     */
    List<RepayPlan> queryOverdueInfiveDayRepayPlan();
}
