package com.xhh.creditcore.capital.util;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

/**
 * 类StagesRepayUtils.java的实现描述：TODO 类实现描述
 * 
 * @author xiehuang 2018年1月16日 上午10:41:09
 */
public class StagesRepayUtils extends RepayStyleCalc {

    /**
     * 本息 = 贷款金额 *（月利率*月数 + 1） / 月数
     * 
     * @param invest 总借款额（贷款本金）
     * @param yearRate 年利率
     * @param month 还款总月数
     * @return 每月偿还本金和利息
     */
    @Override
    public Map<Integer, BigDecimal> calcPerMonthCapitalInterest(double invest, double yearRate, int month) {
        double monthRate = yearRate / 12;
        Map<Integer, BigDecimal> map = new HashMap<>();
        BigDecimal monthTotalIncome = new BigDecimal(invest).multiply(new BigDecimal(monthRate * month + 1)).setScale(scale, round_default);
        BigDecimal monthPerIncome = new BigDecimal(invest).multiply(new BigDecimal(monthRate * month + 1)).divide(new BigDecimal(month), scale, round_down);
        for (int i = 1; i <= month; i++) {
            if (i == month) {
                map.put(i, monthTotalIncome.subtract(monthPerIncome.multiply(new BigDecimal(month - 1))));
            } else {
                map.put(i, monthPerIncome);
            }

        }
        return map;
    }

    /**
     * 利息 = 本息 - 本金
     */
    @Override
    public Map<Integer, BigDecimal> calcPerMonthInterest(double invest, double yearRate, int month) {
        Map<Integer, BigDecimal> map = new HashMap<Integer, BigDecimal>();
        Map<Integer, BigDecimal> mapCapitalInterest = getPerMonthCapitalInterest(invest, yearRate, month);
        Map<Integer, BigDecimal> mapInterest = getPerMonthCapital(invest, yearRate, month);
        for (Map.Entry<Integer, BigDecimal> entry : mapCapitalInterest.entrySet()) {
            map.put(entry.getKey(), entry.getValue().subtract(mapInterest.get(entry.getKey())));
        }
        return map;
    }

    /**
     * 每月偿还本金
     * 
     * @param invest 总借款额（贷款本金）
     * @param yearRate 年利率
     * @param month 还款总月数
     * @return 每月偿还本金
     */
    @Override
    public Map<Integer, BigDecimal> calcPerMonthCapital(double invest, double yearRate, int month) {
        Map<Integer, BigDecimal> map = new HashMap<>();
        BigDecimal monthCapital = new BigDecimal(invest).divide(new BigDecimal(month), scale, round_down);
        for (int i = 1; i <= month; i++) {
            if (i == month) {
                map.put(i, new BigDecimal(invest).subtract(monthCapital.multiply(new BigDecimal(month - 1))));
            } else {
                map.put(i, monthCapital);
            }
        }
        return map;
    }
    
    @Override
    public void initData(double invest, double yearRate, int month) {
        setPerMonthCapital(calcPerMonthCapital(invest, yearRate, month));
        setPerMonthCapitalInterest(calcPerMonthCapitalInterest(invest, yearRate, month));
        setPerMonthInterest(calcPerMonthInterest(invest, yearRate, month));
    }

    /**
     * @param args
     */
    public static void main(String[] args) {

        double[] invests = { 3000, 4000, 5000, 6000, 7000, 8000, 9000, 10000 };
        int[] months = { 3, 6, 9 };
        double yearRate = 0.1392; // 年利率  

        for (double invest : invests) {
            for (int month : months) {
                String repayPatten = "分期还款";
                System.out.println(repayPatten + "---借款金额：" + invest);
                System.out.println(repayPatten + "---借款月数：" + month);
                StagesRepayUtils util = new StagesRepayUtils();
                Map<Integer, BigDecimal> mapCapitalInterest = util.getPerMonthCapitalInterest(invest, yearRate, month);

                System.out.println(repayPatten + "---每月本息：" + mapCapitalInterest);
                Map<Integer, BigDecimal> mapInterest = util.getPerMonthInterest(invest, yearRate, month);
                //                System.out.println(repayPatten + "---每月利息：" + mapInterest);
                //                Map<Integer, BigDecimal> mapCapital = util.getPerMonthCapital(invest, yearRate, month);
                //                System.out.println(repayPatten + "---每月本金：" + mapCapital);
                System.out.println(repayPatten + "---本息总和：" + util.sumCapitalInterest(invest, yearRate, month));
                //                System.out.println(repayPatten + "---利息总和：" + util.sumInterest(invest, yearRate, month));
                System.out.println(repayPatten + "---本金总和：" + util.sumCapital(invest, yearRate, month));
                System.out.println();
            }
        }

    }

}
