package com.xhh.creditcore.capital.service.payimpl;

import com.xhh.creditcore.capital.enums.PayChannel;
import com.xhh.creditcore.capital.enums.PayType;
import com.xhh.creditcore.capital.pay.*;
import com.xhh.creditcore.capital.service.PayService;

/***
 * 支付接口适配器 zhangweixin 2018-01-12
 */
public abstract class PayServiceAdaptor implements PayService {
    @Override
    public boolean supportPayType(PayType payType) {
        return false;
    }

    @Override
    public boolean supportPayChannel(PayChannel payChannel) {
        return false;
    }

    @Override
    public boolean isDefaultPayChannel() {
        return false;
    }

    @Override
    public PayResult singlePay(PayRequest request) {
        return null;
    }

    @Override
    public PayResult singPayOfPublic(PayRequest request) {
        return null;
    }

    @Override
    public PayResult singleDeduct(PayRequest request) {
        return null;
    }

    @Override
    public PayResult singlePayQuery(PayRequest request) {
        return null;
    }

    @Override
    public PayResult singleDeductOrderQuery(PayRequest request) {
        return null;
    }

    @Override
    public void singlePayNotice(PayNoticeRequest noticeRequest) {

    }

    @Override
    public void singleDeductNotice(PayNoticeRequest noticeRequest) {

    }

    @Override
    public void certPayNotice(PayNoticeRequest noticeRequest){

    }

    @Override
    public PayResult bankCardAuth(PayRequest request) throws Exception {
        return null;
    }

    @Override
    public PayResult certPayPrePay(PayRequest request) {
        return null;
    }

    @Override
    public PayResult certPayConfirmPay(PayRequest request) {
        return null;
    }

    @Override
    public PayResult repeatSendSms(PayRequest request) throws UnsupportedOperationException {
        return null;
    }

    @Override
    public PayResult certPayOrderQuery(PayRequest request) {
        return null;
    }
}
