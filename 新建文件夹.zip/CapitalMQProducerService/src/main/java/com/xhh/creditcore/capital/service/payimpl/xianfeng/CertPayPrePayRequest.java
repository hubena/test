package com.xhh.creditcore.capital.service.payimpl.xianfeng;

import java.util.HashMap;
import java.util.Map;

import com.xhh.creditcore.capital.pay.ConfigurableNoticeUrl;
import com.xhh.creditcore.capital.pay.MerchantInfo;

/**
 * 2017-12-29
 *
 * @author zhangweixin
 */
public class CertPayPrePayRequest extends BaseRequest implements ConfigurableNoticeUrl {
    private Map<String, String> signData     = new HashMap<>();
    private Map<String, String> businessData = new HashMap<>();

    public CertPayPrePayRequest(MerchantInfo merchantInfo) {
        super("MOBILE_CERTPAY_API3_PREPARE_PAY", "4.0.0", merchantInfo);
        businessData.put("methodVer", "3.0");
        businessData.put("productName", "信贷");
        businessData.put("closeOrderTime", "10");
        XianFengConfig config= XianFengConfig.getXianFengConfig();
        String url = config.NOTICE_PREFIX + config.SIGNLE_CERTPAY_NOTICE_PATH;
        businessData.put("noticeUrl", url);
    }

    /**
     * 设置商户id
     *
     * @param merchantId
     */
    public void setMerchantId(String merchantId) {
        signData.put("merchantId", merchantId);
    }

    public void setOutOrderId(String outOrderId) {
        businessData.put("outOrderId", outOrderId);
    }

    public void setUserId(String userId) {
        businessData.put("userId", userId);
    }

    public void setMobileNo(String mobileNo) {
        businessData.put("mobileNo", mobileNo);
    }

    public void setRealName(String realName) {
        businessData.put("realName", realName);
    }

    public void setCertNo(String certNo) {
        businessData.put("certNo", certNo);
    }

    public void setBankCardNo(String bankCardNo) {
        businessData.put("bankCardNo", bankCardNo);
    }

    public void setNoticeUrl(String noticeUrl) {
        businessData.put("noticeUrl", noticeUrl);
    }

    public void setAmount(Double amount) {
        amount = amount * 100;
        businessData.put("amount", String.valueOf(amount.longValue()));
    }

    @Override
    public Map<String, String> getBusinessData() {
        return businessData;
    }

    @Override
    protected Map<String, String> getSubClassSignData() {
        return signData;
    }


    @Override
    public String getRawNoticeUrl() {
        return businessData.get("noticeUrl");
    }

    @Override
    public void setNewNoticeUrl(String newUrl) {

    }
}
