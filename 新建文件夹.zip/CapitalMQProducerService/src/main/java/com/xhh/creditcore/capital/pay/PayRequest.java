package com.xhh.creditcore.capital.pay;

import com.xhh.creditcore.capital.enums.PayMerchantType;

/**
 * 具体支付服务请求 zhangweixin 2018-01-17
 */
public class PayRequest extends BasePayRequest implements ConfigurableMerchantInfo {
    //银行简码
    private String          bankCode;
    //银行卡号
    private String          bankCardNo;
    //姓名
    private String          accountName;
    //手机号
    private String          mobile;
    //证件号
    private String          certNo;
    //金额
    private Double          amount;
    //产品code
    private String          productCode;
    //资金平台相关支付操作流水号
    private String          capitalOrderNo;
    //对公交易联行号
    private String          issuer;
    //商户帐号类型
    private PayMerchantType payMerchantType;
    //支付商户信息
    private MerchantInfo    merchantInfo;
    //产品帐户id
    private String          accountId;
    //验证码
    private String          smsCode;

    public String getBankCode() {
        return bankCode;
    }

    public void setBankCode(String bankCode) {
        this.bankCode = bankCode;
    }

    public String getBankCardNo() {
        return bankCardNo;
    }

    public void setBankCardNo(String bankCardNo) {
        this.bankCardNo = bankCardNo;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getCertNo() {
        return certNo;
    }

    public void setCertNo(String certNo) {
        this.certNo = certNo;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    @Override
    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getCapitalOrderNo() {
        return capitalOrderNo;
    }

    public void setCapitalOrderNo(String capitalOrderNo) {
        this.capitalOrderNo = capitalOrderNo;
    }

    public String getIssuer() {
        return issuer;
    }

    public void setIssuer(String issuer) {
        this.issuer = issuer;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getSmsCode() {
        return smsCode;
    }

    public void setSmsCode(String smsCode) {
        this.smsCode = smsCode;
    }

    @Override
    public String toString() {
        return "PayRequest{" + "bankCode='" + bankCode + '\'' + ", bankCardNo='" + bankCardNo + '\'' + ", accountName='" + accountName + '\'' + ", mobile='"
                + mobile + '\'' + ", certNo='" + certNo + '\'' + ", amount=" + amount + ", productCode='" + productCode + '\'' + ", capitalOrderNo='"
                + capitalOrderNo + '\'' + ", issuer='" + issuer + '\'' + ", payMerchantType=" + payMerchantType + ", merchantInfo=" + merchantInfo + '}';
    }

    @Override
    public PayMerchantType getPayMerchantType() {
        return payMerchantType;
    }

    public void setPayMerchantType(PayMerchantType payMerchantType) {
        this.payMerchantType = payMerchantType;
    }

    public MerchantInfo getMerchantInfo() {
        return merchantInfo;
    }

    @Override
    public void setMerchantInfo(MerchantInfo merchantInfo) {
        this.merchantInfo = merchantInfo;
    }
}
