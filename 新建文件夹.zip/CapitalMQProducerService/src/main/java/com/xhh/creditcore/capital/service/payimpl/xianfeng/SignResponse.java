package com.xhh.creditcore.capital.service.payimpl.xianfeng;

/**
 * author zhangliang
 *
 * @Date:Create in 2018/1/13
 */
public class SignResponse extends BaseResponse {

}
