package com.xhh.creditcore.capital.enums;

/**
 * @author zhangliang
 * @Date:Create in 2018/1/26 鉴权的证件类型
 */
public enum CertificateType {

    IDENTITY_CARD("0", "身份证");

    private String key;
    private String desc;

    public String getKey() {
        return key;
    }

    public String getDesc() {
        return desc;
    }

    CertificateType(String key, String desc) {
        this.key = key;
        this.desc = desc;
    }

    public CertificateType getInstance(String key) {
        for (CertificateType certificateType : CertificateType.values()) {
            if (certificateType.key.equals(key))
                return certificateType;
        }
        return null;
    }
}
