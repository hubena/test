package com.xhh.creditcore.capital.service.payimpl.xianfeng;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.janty.core.exception.SystemException;

/**
 * 单笔代扣请求对象
 *
 * @author zhangweixin
 */
public class SingleDeductNotifyResponse extends NoticeBaseResponse {

    @Override
    public String toJson() {
        try {
            return new ObjectMapper().writeValueAsString(this);
        } catch (Exception e) {
            throw new SystemException("序列化" + SingleDeductNotifyResponse.class.getSimpleName() + "失败", e);
        }
    }
}
