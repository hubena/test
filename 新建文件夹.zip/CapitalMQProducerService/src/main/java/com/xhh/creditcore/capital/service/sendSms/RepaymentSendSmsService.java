package com.xhh.creditcore.capital.service.sendSms;

import com.janty.core.exception.BusinessException;
import com.janty.core.exception.SystemException;
import com.janty.core.util.*;
import com.xhh.creditcore.capital.bean.JudgeSendMessage;
import com.xhh.creditcore.capital.constant.RepaymentSmsConstants;
import com.xhh.creditcore.capital.dao.RepayPlanMapper;
import com.xhh.creditcore.capital.dao.RepayTransMapper;
import com.xhh.creditcore.capital.enums.RepayTransStatus;
import com.xhh.creditcore.capital.enums.RepayTriggerType;
import com.xhh.creditcore.capital.model.AccountBankCardBind;
import com.xhh.creditcore.capital.model.RepayPlan;
import com.xhh.creditcore.capital.model.RepayTrans;
import com.xhh.creditcore.capital.service.AccountBankCardBindService;
import com.xhh.creditcore.capital.service.RepayPlanService;
import com.xhh.creditcore.capital.service.RepayTransService;
import com.xhh.creditcore.capital.service.RepaymentSendInnerLetterService;
import com.xhh.creditcore.capital.service.remote.MessageCenterRemoteService;
import com.xhh.creditcore.capital.service.remote.ProductRemoteService;
import com.xhh.creditcore.transaction.constant.TransactionErrorCode;
import com.xhh.infrastructure.messagecenter.api.IMessageCenterApi;
import com.xhh.infrastructure.messagecenter.dto.SendSmsMessageRequest;
import net.sf.json.JSONObject;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.*;

/**
 * 还款短信提醒
 */
@Service("repaymentSendSmsService")
public class RepaymentSendSmsService {

    @Resource
    private RepayTransService repayTransService;
    @Resource
    private IMessageCenterApi messageCenterApi;
    @Resource
    private RepayTransMapper repayTransMapper;
    @Resource
    private RepayPlanMapper repayPlanMapper;
    @Resource
    private AccountBankCardBindService accountBankCardBindService;
    @Resource
    private RepayPlanService repayPlanService;
    @Resource
    private ProductRemoteService productRemoteService;
    @Resource
    private MessageCenterRemoteService messageCenterRemoteService;
    /**
     * 代扣成功发送通知短信
     *
     * @param capitalLoanTransNo
     */
    public void repaymentSuccessSendSms(String capitalLoanTransNo) {
        if (StringUtil.isNotNull(capitalLoanTransNo)) {
            RepayTrans queryTrans = new RepayTrans();
            queryTrans.setCapitalLoanTransNo(capitalLoanTransNo);
            RepayTrans tagerRepayTrans = repayTransService.queryOneDataByConditon(queryTrans);
            if (tagerRepayTrans != null) {
                    RepayTransStatus transStatus = RepayTransStatus.getInstance(tagerRepayTrans.getStatus());
                    if (RepayTransStatus.SUCCESS.equals(transStatus)) {
                        RepayPlan repayPlan = repayPlanService.queryDataById(tagerRepayTrans.getRepayPlanId());
                        sendSmsRaymentSuccess(tagerRepayTrans, repayPlan);
                    }


            } else {
                throw new BusinessException("未知代扣订单号:" + capitalLoanTransNo);
            }
        } else {
            throw new BusinessException("代扣订单号不存在;");
        }

    }


    /**
     * 代扣失败发送通知短信
     *
     * @param capitalLoanTransNo
     */
    public void repaymentFailSendSms(String capitalLoanTransNo) {
        if (StringUtil.isNotNull(capitalLoanTransNo)) {
            RepayTrans queryTrans = new RepayTrans();
            queryTrans.setCapitalLoanTransNo(capitalLoanTransNo);
            RepayTrans tagerRepayTrans = repayTransService.queryOneDataByConditon(queryTrans);
            if (tagerRepayTrans != null) {
                    RepayTransStatus transStatus = RepayTransStatus.getInstance(tagerRepayTrans.getStatus());
                    if (RepayTransStatus.FAIL.equals(transStatus)) {
                        RepayPlan repayPlan = repayPlanService.queryDataById(tagerRepayTrans.getRepayPlanId());
                        sendSmsRaymentFail(tagerRepayTrans, repayPlan);
                    }
            } else {
                throw new BusinessException("未知代扣订单号:" + capitalLoanTransNo);
            }
        } else {
            throw new BusinessException("代扣订单号不存在;");
        }
    }



    /**
     * 代扣失败短信发送
     *
     * @param tagerRepayTrans
     */
    public void sendSmsRaymentFail(RepayTrans tagerRepayTrans, RepayPlan repayPlan) {
        SendSmsMessageRequest sendSmsMessageRequest = new SendSmsMessageRequest();
        sendSmsMessageRequest.setSystemIp(IPUtil.getServerIP());
        sendSmsMessageRequest.setSmsOrder(sendSmsMessageRequest.getReqNo());
        sendSmsMessageRequest.setSmsTemplateId(RepaymentSmsConstants.repayment_fail_sms_template);
        sendSmsMessageRequest.setUserPhone(tagerRepayTrans.getAccountMobile());
        Map<String, String> paramMap = new HashMap<>();
        paramMap.put(RepaymentSmsConstants.repay_amount, tagerRepayTrans.getRepayAmount().toString());
        paramMap.put(RepaymentSmsConstants.account_card_no, tagerRepayTrans.getAccountCardNo().substring(tagerRepayTrans.getAccountCardNo().length() - 4, tagerRepayTrans.getAccountCardNo().length()));
        paramMap.put(RepaymentSmsConstants.term_no, repayPlan.getTermNo().toString());
        paramMap.put(RepaymentSmsConstants.total_term, repayPlan.getTotalTerm().toString());
        sendSmsMessageRequest.setParamMap(paramMap);
        sendSmsCommonUse(repayPlan.getProductCode(),sendSmsMessageRequest,RepaymentSmsConstants.send_sms_repay_fail);
    }

    /**
     * 代扣成功短信通知
     *
     * @param tagerRepayTrans
     */
    public void sendSmsRaymentSuccess(RepayTrans tagerRepayTrans, RepayPlan repayPlan) {
        SendSmsMessageRequest sendSmsMessageRequest = new SendSmsMessageRequest();
        sendSmsMessageRequest.setSystemIp(IPUtil.getServerIP());
        sendSmsMessageRequest.setSmsOrder(sendSmsMessageRequest.getReqNo());
        sendSmsMessageRequest.setSmsTemplateId(RepaymentSmsConstants.repayment_success_sms_template);
        sendSmsMessageRequest.setUserPhone(tagerRepayTrans.getAccountMobile());
        Map<String, String> paramMap = new HashMap<>();
        paramMap.put(RepaymentSmsConstants.term_no, repayPlan.getTermNo().toString());
        paramMap.put(RepaymentSmsConstants.total_term, repayPlan.getTotalTerm().toString());
        sendSmsMessageRequest.setParamMap(paramMap);
        sendSmsCommonUse(repayPlan.getProductCode(),sendSmsMessageRequest,RepaymentSmsConstants.send_sms_repay_success);

    }

    /**
     * 每天10点通知用户代扣结果
     */
    public void repaymentResultSendSmsToUser() {
        List<RepayTrans> tosendSmsRepayments = repayTransMapper.queryRepaymentoNToday();
        if (CollectionUtil.isListNull(tosendSmsRepayments)) {
            return;
        }
        for (RepayTrans repayTrans : tosendSmsRepayments) {
            if (RepayTriggerType.AUTO_DEDUCT.equals(RepayTriggerType.getInstance(repayTrans.getRepayTriggerType()))) {
                RepayTransStatus transStatus = RepayTransStatus.getInstance(repayTrans.getStatus());
                RepayPlan repayPlan = repayPlanService.queryDataById(repayTrans.getRepayPlanId());
                if (RepayTransStatus.SUCCESS.equals(transStatus)) {
                    sendSmsRaymentSuccess(repayTrans, repayPlan);
                }
                if (RepayTransStatus.FAIL.equals(transStatus)) {
                    sendSmsRaymentFail(repayTrans, repayPlan);
                }

            }
        }

    }


    /**
     * 代扣前3天提醒用户还款
     */
    public void remindSendSmsRepaymentToUserBeforeThreeDay() {
        List<RepayPlan> afterTodayThreeDayRepayPlan = repayPlanMapper.queryTodayBeforeThreeDayRepayPlan();
        if (CollectionUtil.isListNull(afterTodayThreeDayRepayPlan)) {
            return;
        }
        for (RepayPlan repayPlan : afterTodayThreeDayRepayPlan) {
            BigDecimal topayAllAmount = DecimalUtil.subtract(DecimalUtil.add(repayPlan.getDuePrincipal(), repayPlan.getDueInterest(), repayPlan.getDuePenalty()),
                    DecimalUtil.add(repayPlan.getRepaidInterest(), repayPlan.getRepaidPenalty(), repayPlan.getRepaidPrincipal()));
            AccountBankCardBind accountBankCardBind = accountBankCardBindService.queryDataByAccountId(repayPlan.getAccountId());
            if (accountBankCardBind != null) {
                SendSmsMessageRequest sendSmsMessageRequest = new SendSmsMessageRequest();
                sendSmsMessageRequest.setSystemIp(IPUtil.getServerIP());
                sendSmsMessageRequest.setUserPhone(accountBankCardBind.getAccountMobile());
                sendSmsMessageRequest.setSmsOrder(sendSmsMessageRequest.getReqNo());
                sendSmsMessageRequest.setSmsTemplateId(RepaymentSmsConstants.repayment_remind_before_three_day_sms_template);
                Map<String, String> paramMap = new HashMap<>();
                paramMap.put(RepaymentSmsConstants.repay_amount, topayAllAmount.toString());
                paramMap.put(RepaymentSmsConstants.account_card_no, accountBankCardBind.getBankCardNo().substring(accountBankCardBind.getBankCardNo().length() - 4, accountBankCardBind.getBankCardNo().length()));
                paramMap.put(RepaymentSmsConstants.remind_date, DateUtil.dateToString(DateUtil.getDateBefore(repayPlan.getAgreedRepayDate(), RepaymentSmsConstants.one_day), RepaymentSmsConstants.date_pattern));
                sendSmsMessageRequest.setParamMap(paramMap);
                sendSmsCommonUse(repayPlan.getProductCode(),sendSmsMessageRequest,RepaymentSmsConstants.repayment_remind_before_three_day_send_sms);
            }
        }

    }

    /**
     * 代扣前1天提醒用户还款
     */
    public void remindSendSmsRepaymentToUserBeforeOneDay() {
        List<RepayPlan> afterTodayOneDayRepayPlan = repayPlanMapper.queryTodayBeforeOneDayRepayPlan();
        if (CollectionUtil.isListNull(afterTodayOneDayRepayPlan)) {
            return;
        }
        for (RepayPlan repayPlan : afterTodayOneDayRepayPlan) {
            BigDecimal topayAllAmount = DecimalUtil.subtract(DecimalUtil.add(repayPlan.getDuePrincipal(), repayPlan.getDueInterest(), repayPlan.getDuePenalty()),
                    DecimalUtil.add(repayPlan.getRepaidInterest(), repayPlan.getRepaidPenalty(), repayPlan.getRepaidPrincipal()));
            AccountBankCardBind accountBankCardBind = accountBankCardBindService.queryDataByAccountId(repayPlan.getAccountId());
            if (accountBankCardBind != null) {
                SendSmsMessageRequest sendSmsMessageRequest = new SendSmsMessageRequest();
                sendSmsMessageRequest.setSystemIp(IPUtil.getServerIP());
                sendSmsMessageRequest.setUserPhone(accountBankCardBind.getAccountMobile());
                sendSmsMessageRequest.setSmsOrder(sendSmsMessageRequest.getReqNo());
                sendSmsMessageRequest.setSmsTemplateId(RepaymentSmsConstants.repayment_remind__before_one_day_sms_template);
                Map<String, String> paramMap = new HashMap<>();
                paramMap.put(RepaymentSmsConstants.repay_amount, topayAllAmount.toString());
                paramMap.put(RepaymentSmsConstants.account_card_no, accountBankCardBind.getBankCardNo().substring(accountBankCardBind.getBankCardNo().length() - 4, accountBankCardBind.getBankCardNo().length()));
                sendSmsMessageRequest.setParamMap(paramMap);
                sendSmsCommonUse(repayPlan.getProductCode(),sendSmsMessageRequest,RepaymentSmsConstants.repayment_remind_before_one_day_send_sms);

            }
        }
    }

    /**
     * 代扣前1天提醒用户还款和代扣前3天提醒用户还款
     */
    public void remindSendSmsRepaymentToUserBeforeThreeDayOrOneDay() {
        remindSendSmsRepaymentToUserBeforeThreeDay();
        remindSendSmsRepaymentToUserBeforeOneDay();
    }

    /**
     * 逾期1天、2天、3天、4天、5天上午10点推送逾期提醒消息
     */
    public void remindSendSmsOverdueRepaymentToUser() {
        List<RepayPlan> overdueInfiveDayRepayPlans = repayPlanMapper.queryOverdueInfiveDayRepayPlan();
        if (CollectionUtil.isListNotNull(overdueInfiveDayRepayPlans)) {
            for (RepayPlan repayPlan : overdueInfiveDayRepayPlans) {
                BigDecimal benxi = DecimalUtil.subtract(DecimalUtil.add(repayPlan.getDuePrincipal(), repayPlan.getDueInterest()),
                        DecimalUtil.add(repayPlan.getRepaidInterest(), repayPlan.getRepaidPrincipal()));
                BigDecimal duePenalty = DecimalUtil.subtract(repayPlan.getDuePenalty(), repayPlan.getRepaidPenalty());
                AccountBankCardBind accountBankCardBind = accountBankCardBindService.queryDataByAccountId(repayPlan.getAccountId());
                if (accountBankCardBind != null) {
                    SendSmsMessageRequest sendSmsMessageRequest = new SendSmsMessageRequest();
                    sendSmsMessageRequest.setSystemIp(IPUtil.getServerIP());
                    sendSmsMessageRequest.setUserPhone(accountBankCardBind.getAccountMobile());
                    sendSmsMessageRequest.setSmsOrder(sendSmsMessageRequest.getReqNo());
                    sendSmsMessageRequest.setSmsTemplateId(RepaymentSmsConstants.overdue_sms_template);
                    Map<String, String> paramMap = new HashMap<>();
                    paramMap.put(RepaymentSmsConstants.benxi, benxi.toString());
                    paramMap.put(RepaymentSmsConstants.due_penalty, duePenalty.toString());
                    paramMap.put(RepaymentSmsConstants.term_no, repayPlan.getTermNo().toString());
                    paramMap.put(RepaymentSmsConstants.total_term, repayPlan.getTotalTerm().toString());
                    paramMap.put(RepaymentSmsConstants.overdue_days, String.valueOf(DateUtil.getTimeDiffOfDays(repayPlan.getAgreedRepayDate(), new Date())));
                    sendSmsMessageRequest.setParamMap(paramMap);
                    sendSmsCommonUse(repayPlan.getProductCode(),sendSmsMessageRequest,RepaymentSmsConstants.send_sms_overdue);
                }
            }

        }

    }

    /**
     * 可配置短信发送通用接口
     * @param productCode
     * @param request
     * @param productfigkeyRedis
     */
    public void sendSmsCommonUse(String productCode, SendSmsMessageRequest request,String productfigkeyRedis) {
        String configKey = productfigkeyRedis;
        JudgeSendMessage judge = getJudge(request.getReqNo(), configKey, productCode);
        sendMessage(judge, request);
    }

    private JudgeSendMessage getJudge(String reqNo, String configKey, String productCode) {
        JudgeSendMessage judge = null;
        Map<String, String> map = productRemoteService.queryByConfigsProductCode(reqNo, productCode);
        String configValue = null;
        for (Map.Entry<String, String> entry : map.entrySet()) {
            if (configKey.equals(entry.getKey())) {
                configValue = entry.getValue();
            }
        }
        if (StringUtil.isEmpty(configValue)) {
            throw new SystemException(TransactionErrorCode.Element.s_product_config_send_message_no_not_exist.getMessage());
        }
        judge = assembleJudge(configValue);
        if (judge == null || judge.getTemplateId() == null) {
            throw new SystemException(TransactionErrorCode.Element.s_product_config_send_message_data_exception.getMessage());
        }
        return judge;
    }

    private void sendMessage(JudgeSendMessage judge, SendSmsMessageRequest request) {
        sendMessage(judge, request, true);
    }
    private void sendMessage(JudgeSendMessage judge, SendSmsMessageRequest request, boolean needJudge) {
        if (needJudge && (!judge.isNeedSend())) {
            return;
        }
        request.setSmsTemplateId(new Long(judge.getTemplateId()));
        messageCenterRemoteService.sendSms(request);
    }

    private JudgeSendMessage assembleJudge(String configValue) {
        JSONObject jsonObject = JSONObject.fromObject(configValue);
        JudgeSendMessage judge = (JudgeSendMessage) JSONObject.toBean(jsonObject, JudgeSendMessage.class);
        return judge;
    }
}
