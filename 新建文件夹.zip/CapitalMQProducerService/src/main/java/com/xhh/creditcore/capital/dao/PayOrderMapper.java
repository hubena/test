package com.xhh.creditcore.capital.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.xhh.creditcore.capital.model.PayOrder;

@Repository
public interface PayOrderMapper {
    int deleteByPrimaryKey(Long id);

    int insert(PayOrder record);

    int insertSelective(PayOrder record);

    PayOrder selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(PayOrder record);

    int updateByPrimaryKey(PayOrder record);

    PayOrder queryDataByRelateTranNoAndTranType(PayOrder record);

    int updateStatusForPayNotice(PayOrder record);

    int updateStatusForSyncFail(PayOrder record);

    int updateStatusForProcess(PayOrder record);

    List<PayOrder> queryPayOrderByCondiiton(PayOrder payOrder);
}
