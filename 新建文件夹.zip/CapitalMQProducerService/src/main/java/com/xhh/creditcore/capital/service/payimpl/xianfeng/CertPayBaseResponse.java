package com.xhh.creditcore.capital.service.payimpl.xianfeng;

/**
 * 先锋支付认证支付基础响应类
 * 
 * @author zhangweixin
 */
public class CertPayBaseResponse {

    public String respCode;

    public String respMsg;

    public String getRespCode() {
        return respCode;
    }

    public void setRespCode(String respCode) {
        this.respCode = respCode;
    }

    public String getRespMsg() {
        return respMsg;
    }

    public void setRespMsg(String respMsg) {
        this.respMsg = respMsg;
    }

    public boolean isRequestSuccess() {
        if ("00".equals(getRespCode())) {
            return true;
        } else {
            return false;
        }
    }
}
