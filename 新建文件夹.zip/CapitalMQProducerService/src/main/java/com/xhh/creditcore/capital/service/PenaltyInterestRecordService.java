package com.xhh.creditcore.capital.service;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.xhh.creditcore.capital.dao.PenaltyInterestRecordMapper;
import com.xhh.creditcore.capital.model.PenaltyInterestRecord;

/**
 * PenaltyInterestRecord服务类
 * 
 * @author xiehuang
 * @date 2018-1-11 17:45:17
 */
@Service("penaltyInterestRecordService")
public class PenaltyInterestRecordService {
    @Resource
    private PenaltyInterestRecordMapper penaltyInterestRecordMapper;

    /**
     * 根据id查询数据
     * 
     * @param id 实体id
     * @return 实体
     */
    public PenaltyInterestRecord queryDataById(long id) {
        return null;
    }

    /**
     * 新增数据
     * 
     * @param record 实体
     */
    public void addData(PenaltyInterestRecord record) {
        penaltyInterestRecordMapper.insert(record);
    }

    /**
     * 修改数据
     * 
     * @param record 实体
     */
    public void modifyData(PenaltyInterestRecord record) {

    }

    /**
     * 删除数据
     * 
     * @param record 实体
     */
    public void deleteData(PenaltyInterestRecord record) {

    }

    /**
     * 根据还款计划id查询罚息计算记录最新记录
     * 
     * @param repayPlanId
     * @return
     */
    public PenaltyInterestRecord queryLastestDataByPlanId(Long repayPlanId) {
        return penaltyInterestRecordMapper.selectLastestDataByPlanId(repayPlanId);
    }
}
