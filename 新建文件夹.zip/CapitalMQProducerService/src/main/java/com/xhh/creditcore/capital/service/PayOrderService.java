package com.xhh.creditcore.capital.service;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import com.janty.cached.access.RedisCachedAccess;
import com.janty.core.spring.ApplicationContextUtil;
import com.janty.core.util.DecimalUtil;
import com.janty.core.util.OrderNoGenerator;
import com.xhh.creditcore.capital.bean.FeePayAccountConfig;
import com.xhh.creditcore.capital.constant.CapitalConstants;
import com.xhh.creditcore.capital.constant.CapitalRedisKey;
import com.xhh.creditcore.capital.dao.PayOrderMapper;
import com.xhh.creditcore.capital.enums.PayMerchantType;
import com.xhh.creditcore.capital.enums.PayOrderObjectType;
import com.xhh.creditcore.capital.enums.PayOrderStatus;
import com.xhh.creditcore.capital.enums.PayOrderTransType;
import com.xhh.creditcore.capital.model.CapitalLoanTrans;
import com.xhh.creditcore.capital.model.PayOrder;
import com.xhh.creditcore.capital.model.RepayPlan;
import com.xhh.creditcore.capital.model.RepayTrans;
import com.xhh.creditcore.capital.pay.PayNoticeHandlerRequest;
import com.xhh.creditcore.capital.pay.PayRequest;
import com.xhh.creditcore.capital.pay.PayResult;
import com.xhh.creditcore.capital.service.payimpl.PayServiceDelegate;
import com.xhh.creditcore.capital.service.remote.ProductRemoteService;
import com.xhh.creditcore.product.constant.ProductConfigKey;
import com.xhh.creditcore.product.enums.FeeChargePattern;

/**
 * PayOrder服务类
 * 
 * @author zhangweixin
 * @date 2018-1-29 20:55:41
 */
@Service
@Lazy
public class PayOrderService {

    private static Logger        logger = LoggerFactory.getLogger(PayOrderService.class);

    @Resource
    private PayOrderMapper       payOrderMapper;
    @Resource
    private ProductRemoteService productService;
    @Resource
    private PayServiceDelegate   payServiceDelegate;
    @Resource
    RedisCachedAccess<String>    cachedAccess;
    @Resource
    FeeService                   feeService;

    /**
     * 根据id查询数据
     * 
     * @param id 实体id
     * @return 实体
     */
    public PayOrder queryDataById(long id) {
        return null;
    }

    /**
     * 新增数据
     * 
     * @param record 实体
     */
    public void addData(PayOrder record) {
        payOrderMapper.insert(record);
    }

    /**
     * 修改数据
     * 
     * @param record 实体
     */
    public void modifyData(PayOrder record) {

    }

    /**
     * 删除数据
     * 
     * @param record 实体
     */
    public void deleteData(PayOrder record) {

    }

    /**
     * 查询代付订单根据交易流水号
     *
     * @param transNo {@link String} 交易流水
     * @param transType {@link Integer} 交易类型
     * @return
     */
    public PayOrder queryDataByRelateTranNoAndTranType(String transNo, Integer transType) {
        PayOrder payOrder = new PayOrder();
        payOrder.setTransType(transType);
        payOrder.setOrderNo(transNo);
        return payOrderMapper.queryDataByRelateTranNoAndTranType(payOrder);
    }

    /**
     * 保存砍头代付手续费订单记录
     * 
     * @param loanTrans
     * @return
     */
    public void saveFeePayOrderByCut(CapitalLoanTrans loanTrans) {
        Map<String, String> product = productService.getProductByCode(loanTrans.getProductCode());
        //如果借款手续是砍头收取
        if (FeeChargePattern.cut.getKey().equals(product.get(ProductConfigKey.loan_fee_charge_pattern))) {
            PayOrder payOrder = new PayOrder();
            payOrder.setStatus(PayOrderStatus.WAITING.getKey());
            payOrder.setRelateTransNo(loanTrans.getCapitalLoanTransNo());
            payOrder.setTransType(PayOrderTransType.LOAN_PAY_FEE.getKey());
            payOrder.setOrderNo(OrderNoGenerator.getOrderNo(CapitalConstants.capital_pay_fee_biz_code));
            payOrder.setPayObjectType(PayOrderObjectType.COMPANY.getKey());
            payOrder.setAmount(loanTrans.getFeeAmount());
            payOrder.setGmtCreated(new Date());

            FeePayAccountConfig accountConfig = FeePayAccountConfig.getConfig();
            payOrder.setBankCode(accountConfig.getBankCode());
            payOrder.setLianhanghao(accountConfig.getLianHangHao());
            payOrder.setPayBankCardNo(accountConfig.getBankCardNo());
            payOrder.setPayName(accountConfig.getPayname());
            addData(payOrder);
        } else {
            logger.info("[{}]不是砍头收取手续费忽略处理...", loanTrans.getCapitalLoanTransNo());
        }
    }

    /**
     * 保存每期还款代付手续费订单记录
     *
     * @param repayPlan
     * @param repayTrans
     * @return
     */
    public void saveFeePayOrderByInstallment(RepayPlan repayPlan, RepayTrans repayTrans) {
        Map<String, String> product = productService.getProductByCode(repayPlan.getProductCode());
        //如果借款手续是每期收取
        if (FeeChargePattern.installment.getKey().equals(product.get(ProductConfigKey.loan_fee_charge_pattern))) {
            //保存支付数据
            PayOrder payOrder = new PayOrder();
            payOrder.setRelateTransNo(repayTrans.getCapitalLoanTransNo());
            payOrder.setGmtCreated(new Date());
            payOrder.setTransType(PayOrderTransType.REPAY_PAY_FEE.getKey());
            payOrder.setPayObjectType(PayOrderObjectType.COMPANY.getKey());
            payOrder.setAmount(DecimalUtil.subtract(repayPlan.getDueFee(), repayPlan.getRepaidFee()));
            payOrder.setStatus(PayOrderStatus.WAITING.getKey());
            payOrder.setOrderNo(OrderNoGenerator.getOrderNo(CapitalConstants.capital_pay_fee_biz_code));
            payOrder.setBankCode(FeePayAccountConfig.getConfig().getBankCode());
            payOrder.setLianhanghao(FeePayAccountConfig.getConfig().getLianHangHao());
            payOrder.setPayBankCardNo(FeePayAccountConfig.getConfig().getBankCardNo());
            payOrder.setPayName(FeePayAccountConfig.getConfig().getPayname());
            addData(payOrder);
        } else {
            logger.info("[{}]不是每期还款收取手续费忽略处理...", repayTrans.getCapitalLoanTransNo());
        }
    }

    /**
     * 查询所有待支付payOrder
     * 
     * @return
     */
    public List<PayOrder> queryNeedProcessPayOrder() {
        PayOrder payOrder = new PayOrder();
        payOrder.setStatus(PayOrderStatus.WAITING.getKey());
        return payOrderMapper.queryPayOrderByCondiiton(payOrder);
    }

    /**
     * 处理等待支付服务费payorder记录
     * 
     * @param payOrder
     */
    public void procerssWaittingPayOrder(PayOrder payOrder) {
        payOrder = payOrderMapper.queryDataByRelateTranNoAndTranType(payOrder);
        if (PayOrderStatus.WAITING.getKey().equals(payOrder.getStatus())) {
            logger.info("开始代付服务费，订单号:{}...", payOrder.getOrderNo());
            payOrder.setStatus(PayOrderStatus.PROCESSING.getKey());
            payOrderMapper.updateStatusForProcess(payOrder);

            //构建支付请求
            PayRequest payRequest = new PayRequest();
            payRequest.setPayMerchantType(PayMerchantType.PAY);
            payRequest.setIssuer(payOrder.getLianhanghao());
            payRequest.setAmount(payOrder.getAmount().doubleValue());
            payRequest.setBankCardNo(payOrder.getPayBankCardNo());
            payRequest.setAccountName(payOrder.getPayName());
            payRequest.setBankCode(payOrder.getBankCode());
            payRequest.setCapitalOrderNo(payOrder.getOrderNo());
            payRequest.setProductCode(getProductCode(payOrder));

            PayResult result = payServiceDelegate.singPayOfPublic(payRequest);
            String resultCode = result.getResCode();
            if (PayResult.THIRD_SYNC_SUCCESS.equals(resultCode) || PayResult.THIRD_SYNC_PENDING.equals(resultCode)) {
                logger.info("代付服务费提交成功");
            } else if (PayResult.THIRD_SYNC_FAIL.equals(resultCode)) {
                payOrder.setStatus(PayOrderStatus.FAIL.getKey());
                payOrder.setGmtModified(new Date());
                updateStatusForSyncFail(payOrder);
            }
        } else {
            logger.info("[{}]代付服务费订单已经被处理忽略执行...", payOrder.getOrderNo());
        }
    }

    /**
     * 查询payOrder处理中状态记录第三方支付结果
     */
    public void queryPayOrderResult() {
        PayOrder payOrder = new PayOrder();
        payOrder.setStatus(PayOrderStatus.PROCESSING.getKey());
        List<PayOrder> payOrderList = payOrderMapper.queryPayOrderByCondiiton(payOrder);
        payOrderList.forEach(order -> {
            String lockKey = CapitalRedisKey.LOCK_PREFIX + order.getOrderNo();
            try {
                //与业务回调handler互斥
                cachedAccess.tryLock(lockKey, 30 * 1000L);
                doQueryPayOrderResult(order);
            } finally {
                cachedAccess.releaseLock(lockKey);
            }
        });
    }

    private void doQueryPayOrderResult(PayOrder order) {
        logger.info("查询PayOrder支付结果:{}", order.getOrderNo());
        PayRequest payRequest = new PayRequest();
        payRequest.setPayMerchantType(PayMerchantType.PAY);
        payRequest.setCapitalOrderNo(order.getOrderNo());
        payRequest.setProductCode(getProductCode(order));

        PayResult payResult = payServiceDelegate.singlePayQuery(payRequest);
        String resultCode = payResult.getResCode();

        PayNoticeHandlerRequest handlerRequest = new PayNoticeHandlerRequest();
        handlerRequest.setThirdOrderNo(payResult.getThirdOrderNo());
        handlerRequest.setOrderNo(payResult.getOrderNo());
        handlerRequest.setThirdResMsg(payResult.getResMsg());
        if (PayResult.THIRD_SYNC_SUCCESS.equals(resultCode)) {
            logger.info("PayOrder[{}]支付成功.....", order.getOrderNo());
            feeService.payFeeSucessHandle(handlerRequest);
        } else if (PayResult.THIRD_SYNC_FAIL.equals(resultCode) || PayResult.THIRD_UNCOMMIT.equals(resultCode)) {
            logger.info("PayOrder[{}]支付失败.....", order.getOrderNo());
            feeService.payFeeFailHandle(handlerRequest);
        }
    }

    private String getProductCode(PayOrder payOrder) {
        Integer status = payOrder.getStatus();
        if (PayOrderTransType.LOAN.getKey().equals(status) || PayOrderTransType.LOAN_PAY_FEE.getKey().equals(status)) {
            CapitalLoanTransService loanTransService = ApplicationContextUtil.getBeanByType(CapitalLoanTransService.class);
            return Optional.ofNullable(loanTransService.queryDataByLoanTransNo(payOrder.getRelateTransNo())).map(order -> order.getProductCode()).orElse(null);
        } else {
            RepayTransService repayTransService = ApplicationContextUtil.getBeanByType(RepayTransService.class);
            return Optional.ofNullable(repayTransService.queryDataByTransNo(payOrder.getRelateTransNo())).map(order -> order.getProductCode()).orElse(null);
        }
    }

    /**
     * 支付回调后更新支付订单状态
     * 
     * @param record
     */
    public void updateStatusForPayNotice(PayOrder record) {
        payOrderMapper.updateStatusForPayNotice(record);
    }

    /**
     * 同步执行失败更新支付订单状态
     * 
     * @param record
     */
    public void updateStatusForSyncFail(PayOrder record) {
        payOrderMapper.updateStatusForSyncFail(record);
    }

}
