package com.xhh.creditcore.capital.pay;

/**
 * 支付需要的商户信息 zhangweixin 2018-01-19
 */
public class MerchantInfo {
    private String merchantId;
    private String merchantName;
    private String secretKey;

    public String getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(String merchantId) {
        this.merchantId = merchantId;
    }

    public String getMerchantName() {
        return merchantName;
    }

    public void setMerchantName(String merchantName) {
        this.merchantName = merchantName;
    }

    public String getSecretKey() {
        return secretKey;
    }

    public void setSecretKey(String secretKey) {
        this.secretKey = secretKey;
    }
}
