package com.xhh.creditcore.capital.service.remote;

import com.janty.core.util.BaseRemoteService;
import com.xhh.creditcore.capital.constant.CapitalErrorCode;
import com.xhh.creditcore.transaction.api.ILoanApi;
import com.xhh.creditcore.transaction.dto.LoanResultNoticeRequest;
import com.xhh.creditcore.transaction.dto.LoanSettleRequest;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service("transactionRemoteService")
public class TransactionRemoteService extends BaseRemoteService {

    @Resource
    private ILoanApi loanApi;

    /**
     * 放款结果通知
     * 
     * @param request
     */
    public void loanResultNotice(LoanResultNoticeRequest request) {
        try {
            loanApi.loanResultNotice(request);

        } catch (Exception e) {
            processException(e, new CapitalErrorCode(CapitalErrorCode.Element.r_transaction_remote_fail));
        }
    }

    public void loanSettle(LoanSettleRequest settleRequest) {
        try {
            loanApi.loanSettle(settleRequest);
        } catch (Exception e) {
            processException(e, new CapitalErrorCode(CapitalErrorCode.Element.r_transaction_remote_fail));
        }
    }

}
