package com.xhh.creditcore.capital.pay;

import com.google.common.collect.Maps;

import java.util.Map;

/**
 * 支付/回调业务通知 请求基类 zhangweixin 2018-01-17
 */
@Deprecated
public class BasePayRequest {
    /**
     * 附加数据回调业务处理器beanName
     */
    public final static String  NOTICE_HANDLER_BEAN_NAME = "handlerName";

    /**
     * 附加数据
     */
    private Map<String, Object> appendData;

    /**
     * 获取与第三方支付之间的附加数据
     *
     * @return
     */
    public Map<String, Object> getAppendData() {
        return appendData;
    }

    /**
     * 设置与第三方支付之间的附加数据
     *
     * @param appendData
     */
    public void setAppendData(Map<String, Object> appendData) {
        if (this.appendData != null) {
            this.appendData.putAll(appendData);
        } else {
            this.appendData = appendData;
        }

    }

    public void addAppendData(String key, Object value) {
        if (appendData == null) {
            appendData = Maps.newHashMap();
        }
        appendData.put(key, value);
    }

    /**
     * 设置支付回调业务处理器beanName
     *
     * @param beanName
     */
    public void setNoticeBusinessHandlerBeanName(String beanName) {
        addAppendData(NOTICE_HANDLER_BEAN_NAME, beanName);
    }
}
