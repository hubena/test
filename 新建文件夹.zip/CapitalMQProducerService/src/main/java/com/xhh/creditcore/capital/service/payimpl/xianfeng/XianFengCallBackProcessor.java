package com.xhh.creditcore.capital.service.payimpl.xianfeng;

/**
 * 先锋回调处理器 zhangweixin 2018-01-10
 */
public interface XianFengCallBackProcessor {
    void doProcess(String decryptStr) throws Exception;
}
