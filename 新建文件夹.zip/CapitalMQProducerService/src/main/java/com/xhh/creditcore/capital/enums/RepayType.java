package com.xhh.creditcore.capital.enums;

/**
 * zhangweixin 2018-01-10
 */
public enum RepayType {
    BY_PERIOD(1, "按期还款"),
    BY_AMOUNT(2, "按金额还款");
    private Integer key;
    private String  desc;

    public Integer getKey() {
        return key;
    }

    public String getDesc() {
        return desc;
    }

    private RepayType(Integer key, String desc) {
        this.key = key;
        this.desc = desc;
    }

    public static RepayType getInstance(Integer key) {
        for (RepayType repayType : RepayType.values()) {
            if (repayType.key.equals(key)) {
                return repayType;
            }
        }
        return null;
    }
}
