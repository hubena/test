package com.xhh.creditcore.capital.dao;

import com.xhh.creditcore.capital.model.CapitalProvider;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * <p>
 * 资金方 Mapper 接口
 * </p>
 *
 * @author nathaniel123
 * @since 2018-01-09
 */
@Repository
public interface CapitalProviderMapper {

    int insert(CapitalProvider capitalProvider);

    CapitalProvider selectById(@Param("id") Long id);

    List<CapitalProvider> selectByCondition(CapitalProvider capitalProvider);

    int deleteById(@Param("id") Long id);

    int deleteByConditon(CapitalProvider capitalProvider);

    int updateNoNullColumnById(CapitalProvider capitalProvider);

    int updateAllColumnById(CapitalProvider capitalProvider);

}
