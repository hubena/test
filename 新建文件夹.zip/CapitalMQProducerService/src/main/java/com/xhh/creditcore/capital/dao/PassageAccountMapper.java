package com.xhh.creditcore.capital.dao;

import com.xhh.creditcore.capital.model.PassageAccount;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface PassageAccountMapper {
    int deleteByPrimaryKey(Long id);

    int insert(PassageAccount record);

    int insertSelective(PassageAccount record);

    PassageAccount selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(PassageAccount record);

    int updateByPrimaryKey(PassageAccount record);

    PassageAccount queryDataByAccountCode(@Param("accountCode") String accountCode);
}
