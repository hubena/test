package com.xhh.creditcore.capital.service;

import com.janty.core.exception.BusinessException;
import com.janty.core.util.CommonBeanCopier;
import com.xhh.creditcore.capital.constant.CapitalConstants;
import com.xhh.creditcore.capital.constant.CapitalErrorCode;
import com.xhh.creditcore.capital.dto.AccountBankCardDto;
import com.xhh.creditcore.capital.dto.AccountBankCardRequest;
import com.xhh.creditcore.capital.dto.BankCardbinDto;
import com.xhh.creditcore.capital.dto.CapitalBindBankRequest;
import com.xhh.creditcore.capital.enums.BankCardType;
import com.xhh.creditcore.capital.enums.PayMerchantType;
import com.xhh.creditcore.capital.model.AccountBankCardBind;
import com.xhh.creditcore.capital.pay.PayRequest;
import com.xhh.creditcore.capital.pay.PayResult;
import com.xhh.creditcore.capital.service.payimpl.PayServiceDelegate;
import com.xhh.creditcore.capital.service.payimpl.xianfeng.RequestNoGenerator;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;

/**
 * 对外接入绑卡服务逻辑类 zhangweixin 2018-01-10
 */
@Service
public class BankCardService {
    @Resource
    private AccountBankCardBindService bankCardBindService;

    @Resource
    private PayServiceDelegate         payServiceDelegate;

    @Resource
    private BankCardbinService         bankCardbinService;

    public AccountBankCardDto queryAccountBankCardInfo(AccountBankCardRequest bankCardRequest) {
        AccountBankCardBind bankCardBind = bankCardBindService.queryDataByAccountId(bankCardRequest.getAccountId());
        if (bankCardBind == null) {
            return null;
        } else {
            AccountBankCardDto accountBankCardDto = new AccountBankCardDto();
            CommonBeanCopier.copy(bankCardBind, accountBankCardDto);
            return accountBankCardDto;
        }
    }

    /**
     * 绑卡
     * 
     * @param request
     * @return
     * @throws Exception
     */
    public void bindBank(CapitalBindBankRequest request) throws Exception {
        BankCardbinDto bankCardbinDto = bankCardbinService.queryByCardNo(request.getBankCardNo());
        if (bankCardbinDto == null)
            throw new BusinessException(new CapitalErrorCode(CapitalErrorCode.Element.b_bind_card_fail));
        if (!bankCardbinDto.getCardType().equals(BankCardType.DEBIT_CARD.getKey()))
            throw new BusinessException(new CapitalErrorCode(CapitalErrorCode.Element.b_not_support_card));
        PayRequest payRequest = new PayRequest();
        payRequest.setAccountName(request.getAccountName());
        payRequest.setBankCardNo(request.getBankCardNo());
        payRequest.setCertNo(request.getAccountCardNo());
        payRequest.setMobile(request.getAccountMobile());
        payRequest.setProductCode(request.getProductCode());
        payRequest.setCapitalOrderNo(RequestNoGenerator.getGenerator().generatorOrderNo(CapitalConstants.BANK_AUTH));
        payRequest.setPayMerchantType(PayMerchantType.BANK_AUTH);
        PayResult result = payServiceDelegate.bankCardAuth(payRequest);
        if (!PayResult.THIRD_SYNC_SUCCESS.equals(result.getResCode()))
            throw new BusinessException(new CapitalErrorCode(CapitalErrorCode.Element.b_bind_card_fail));

        AccountBankCardBind accountBankCardBind = bankCardBindService.queryDataByAccountId(request.getAccountId());
        if (accountBankCardBind == null) {
            //新增
            accountBankCardBind = new AccountBankCardBind();
            accountBankCardBind.setAccountId(request.getAccountId());
            accountBankCardBind.setAccountIdCard(request.getAccountCardNo());
            accountBankCardBind.setAccountMobile(request.getAccountMobile());
            accountBankCardBind.setBankCardNo(request.getBankCardNo());
            accountBankCardBind.setAccountName(request.getAccountName());
            accountBankCardBind.setBankCode(bankCardbinDto.getBankCode());
            accountBankCardBind.setGmtCreated(new Date());
            bankCardBindService.addData(accountBankCardBind);
        } else {
            //更新
            accountBankCardBind.setAccountName(request.getAccountName());
            accountBankCardBind.setAccountIdCard(request.getAccountCardNo());
            accountBankCardBind.setBankCardNo(request.getBankCardNo());
            accountBankCardBind.setAccountMobile(request.getAccountMobile());
            accountBankCardBind.setBankCode(bankCardbinDto.getBankCode());
            accountBankCardBind.setGmtModified(new Date());
            bankCardBindService.updateBankCardBindById(accountBankCardBind);
        }

    }
}
