package com.xhh.creditcore.capital.service;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.xhh.creditcore.capital.dao.ExcepitonOrderMapper;
import com.xhh.creditcore.capital.model.ExcepitonOrder;

/**
 * <p>
 * 异常订单表 服务实现类
 * </p>
 *
 * @author nathaniel123
 * @since 2018-01-09
 */
@Service("ExcepitonOrderService")
public class ExcepitonOrderService {
    @Resource
    private ExcepitonOrderMapper excepitonOrderMapper;

    /**
     * 根据id查询数据
     *
     * @param id 实体id
     * @return 实体
     */
    public ExcepitonOrder queryDataById(long id) {
        return null;
    }

    /**
     * 新增数据
     *
     * @param record 实体
     */
    public void addData(ExcepitonOrder record) {

    }

    /**
     * 修改数据
     *
     * @param record 实体
     */
    public void modifyData(ExcepitonOrder record) {

    }

    /**
     * 删除数据
     *
     * @param record 实体
     */
    public void deleteData(ExcepitonOrder record) {

    }
}
