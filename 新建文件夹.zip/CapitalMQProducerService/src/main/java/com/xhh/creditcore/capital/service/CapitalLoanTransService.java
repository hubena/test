package com.xhh.creditcore.capital.service;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import com.xhh.creditcore.capital.pay.*;
import org.apache.ibatis.session.RowBounds;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Lazy;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.google.common.collect.Lists;
import com.janty.cached.access.RedisCachedAccess;
import com.janty.core.dto.PageData;
import com.janty.core.dto.Pager;
import com.janty.core.exception.BusinessException;
import com.janty.core.exception.SystemException;
import com.janty.core.spring.ApplicationContextUtil;
import com.janty.core.util.CommonBeanCopier;
import com.janty.core.util.OrderNoGenerator;
import com.janty.mybatis.util.CountHelper;
import com.xhh.creditcore.capital.bean.TransRecordCondition;
import com.xhh.creditcore.capital.constant.CapitalConstants;
import com.xhh.creditcore.capital.constant.CapitalErrorCode;
import com.xhh.creditcore.capital.dao.CapitalLoanTransMapper;
import com.xhh.creditcore.capital.dao.RepayPlanMapper;
import com.xhh.creditcore.capital.dto.CapitalLoanDto;
import com.xhh.creditcore.capital.dto.CapitalLoanRequest;
import com.xhh.creditcore.capital.dto.CapitalPayRequest;
import com.xhh.creditcore.capital.dto.CapitalPublicPayRequest;
import com.xhh.creditcore.capital.dto.CapitalRecordQueryRequest;
import com.xhh.creditcore.capital.dto.LoanTrialDto;
import com.xhh.creditcore.capital.dto.OverdueAccountOrderDto;
import com.xhh.creditcore.capital.dto.OverdueAccountOrderRequest;
import com.xhh.creditcore.capital.dto.PayCapitalRecordQueryDto;
import com.xhh.creditcore.capital.dto.ProcessingAccountOrderDto;
import com.xhh.creditcore.capital.dto.ProcessingAccountOrderRequest;
import com.xhh.creditcore.capital.dto.RepayPlanDto;
import com.xhh.creditcore.capital.enums.CapitalLoanTransStatus;
import com.xhh.creditcore.capital.enums.IsEffect;
import com.xhh.creditcore.capital.enums.PayMerchantType;
import com.xhh.creditcore.capital.model.AccountBankCardBind;
import com.xhh.creditcore.capital.model.CapitalLoanTrans;
import com.xhh.creditcore.capital.model.CapitalProvider;
import com.xhh.creditcore.capital.model.PassageAccount;
import com.xhh.creditcore.capital.model.RepayPlan;
import com.xhh.creditcore.capital.pay.PayRequest;
import com.xhh.creditcore.capital.service.payimpl.PayServiceDelegate;
import com.xhh.creditcore.capital.service.payimpl.xianfeng.XianFengPayService;
import com.xhh.creditcore.capital.service.remote.ProductRemoteService;
import com.xhh.creditcore.capital.service.remote.TransactionRemoteService;
import com.xhh.creditcore.product.constant.ProductConfigKey;
import com.xhh.creditcore.transaction.dto.LoanResultNoticeRequest;

/**
 * <p>
 * 资金借款交易表 服务实现类
 * </p>
 *
 * @author nathaniel123
 * @since 2018-01-09
 */
@Service("capitalLoanTransService")
@Lazy
public class CapitalLoanTransService {

    private static Logger              logger = LoggerFactory.getLogger(CapitalLoanTransService.class);

    @Resource
    private CapitalLoanTransMapper     capitalLoanTransMapper;

    @Resource
    private RepayPlanMapper            repayPlanMapper;

    @Resource
    private ProductRemoteService       remoteService;

    @Resource
    private CapitalProviderService     capitalProviderService;

    @Resource
    private AccountBankCardBindService accountBankCardBindService;

    @Resource
    private LoanTrialService           loanTrialService;

    @Resource
    private PayServiceDelegate         payServiceDelegate;

    @Resource
    private RedisCachedAccess<String>  cachedAccess;

    @Resource
    private TransactionRemoteService   transactionRemoteService;

    @Resource
    private PassageAccountService      passageAccountService;

    @Resource
    private PayOrderService            payOrderService;

    private CapitalLoanTransService    capitalLoanTransService;

    /**
     * 根据id查询数据
     *
     * @param id 实体id
     * @return 实体
     */
    public CapitalLoanTrans queryDataById(long id) {
        return null;
    }

    /**
     * 新增数据
     *
     * @param record 实体
     */
    public void addData(CapitalLoanTrans record) {

    }

    /**
     * 修改数据
     *
     * @param record 实体
     */
    public void modifyData(CapitalLoanTrans record) {

    }

    /**
     * 删除数据
     *
     * @param record 实体
     */
    public void deleteData(CapitalLoanTrans record) {

    }

    /**
     * 更新状态为已逾期
     * 
     * @param loan
     */
    public void updateToOverdueByNo(CapitalLoanTrans loan) {
        capitalLoanTransMapper.updateToOverdueByNo(loan);
    }

    /**
     * 更新状态
     * 
     * @param status
     * @param capitalLoanTransNo
     */
    public void modifyStatus(Integer status, String capitalLoanTransNo) {
        capitalLoanTransMapper.updateStatus(status, capitalLoanTransNo);
    }

    /**
     * 根据外部流水号及产品编码查询
     * 
     * @param productCode
     * @param outerLoanOrderNo
     * @return
     */
    public CapitalLoanTrans queryByOuterOrderNoAndProductCode(String productCode, String outerLoanOrderNo) {
        CapitalLoanTrans condition = new CapitalLoanTrans();
        condition.setProductCode(productCode);
        condition.setOuterLoanOrderNo(outerLoanOrderNo);

        List<CapitalLoanTrans> list = capitalLoanTransMapper.selectByCondition(condition);
        if (!CollectionUtils.isEmpty(list)) {
            return list.get(0);
        } else {
            return null;
        }
    }

    /**
     * 根据外部交易流水号查询借贷交易记录
     *
     * @param outLoanOrderNo
     * @return
     */
    public CapitalLoanTrans queryDataByOutLoanOrderNo(String outLoanOrderNo) {
        CapitalLoanTrans loanTrans = new CapitalLoanTrans();
        loanTrans.setOuterLoanOrderNo(outLoanOrderNo);
        List<CapitalLoanTrans> loanTransList = capitalLoanTransMapper.selectByCondition(loanTrans);
        if (!CollectionUtils.isEmpty(loanTransList)) {
            return loanTransList.get(0);
        } else {
            return null;
        }
    }

    /**
     * 通过内部交易流水号查询
     * 
     * @param capitalLoanTransNo
     * @return
     */
    public CapitalLoanTrans queryDataByLoanTransNo(String capitalLoanTransNo) {
        CapitalLoanTrans loanTrans = new CapitalLoanTrans();
        loanTrans.setCapitalLoanTransNo(capitalLoanTransNo);
        List<CapitalLoanTrans> loanTransList = capitalLoanTransMapper.selectByCondition(loanTrans);
        if (!CollectionUtils.isEmpty(loanTransList)) {
            return loanTransList.get(0);
        } else {
            return null;
        }
    }

    /**
     * 扣款成功后更新逾期订单状态为放款成功(还款中)/结清
     *
     * @param record
     */
    public void updateDataForDeductSuccessNotice(CapitalLoanTrans record) {
        capitalLoanTransMapper.updateDataForDeductSuccessNotice(record);
    }

    /**
     * 查询产品账户下面逾期订单
     *
     * @param capitalLoanTrans
     * @return
     */
    public List<CapitalLoanTrans> queryAccountOverdueOrder(CapitalLoanTrans capitalLoanTrans) {
        return capitalLoanTransMapper.queryAccountOverdueOrder(capitalLoanTrans);
    }

    /**
     * 查询产品账户进行中订单(非结清或者放款失败订单)
     *
     * @param capitalLoanTrans
     * @return
     */
    public List<CapitalLoanTrans> queryAccountProcessingOrder(CapitalLoanTrans capitalLoanTrans) {
        return capitalLoanTransMapper.queryAccountProcessingOrder(capitalLoanTrans);
    }

    /**
     * 根据capital_loan_trans_no 查询
     *
     * @param capitalLoanTransNo
     * @return
     */
    public CapitalLoanTrans queryDataByCapitalNo(String capitalLoanTransNo) {
        return capitalLoanTransMapper.selectByCapitalNo(capitalLoanTransNo);
    }

    /**
     * 根据状态查询
     * 
     * @param status
     * @return
     */
    public List<CapitalLoanTrans> queryByStatus(Integer status) {
        return capitalLoanTransMapper.selectByStatus(status);
    }

    /**
     * 查询出账记录
     *
     * @param request
     * @param pager
     * @return
     */
    public PageData<PayCapitalRecordQueryDto> queryLoanTransRecordByPage(CapitalRecordQueryRequest request, Pager pager) {
        TransRecordCondition condition = new TransRecordCondition();
        CommonBeanCopier.copy(request, condition);
        RowBounds rowBounds = new RowBounds(pager.getOffset(), pager.getPageSize());
        List<CapitalLoanTrans> loanTransList = capitalLoanTransMapper.queryPayTransRecordByPage(condition, rowBounds);
        List<PayCapitalRecordQueryDto> queryDtoList = Lists.newArrayList();
        for (CapitalLoanTrans loanTrans : loanTransList) {
            PayCapitalRecordQueryDto recordQueryDto = new PayCapitalRecordQueryDto();
            CommonBeanCopier.copy(loanTrans, recordQueryDto);
            recordQueryDto.setAmount(loanTrans.getActualLoanAmount());
            queryDtoList.add(recordQueryDto);
        }
        PageData<PayCapitalRecordQueryDto> queryDtoPageData = new PageData<>();
        queryDtoPageData.assembleResult(pager, queryDtoList, CountHelper.getTotalRow());
        return queryDtoPageData;
    }

    /**
     * 借款
     * 
     * @param request
     * @param
     * @return
     */
    public CapitalLoanDto loan(CapitalLoanRequest request) {
        Map<String, String> productConfig = remoteService.getProductByCode(request.getProductCode());
        String capitalCode = productConfig.get(ProductConfigKey.capital_capital_code);
        String penaltyInterestRateStr = productConfig.get(ProductConfigKey.post_loan_penalty_interest_rate);

        CapitalProvider capitalProvider = capitalProviderService.queryDataByCapitalCode(capitalCode);
        if (capitalProvider == null) {
            throw new SystemException("资金方不存在");
        }
        if (StringUtils.isEmpty(penaltyInterestRateStr)) {
            throw new SystemException("罚息利率不存在");
        }
        //罚息利率
        BigDecimal penaltyInterestRate = new BigDecimal(penaltyInterestRateStr);
        //从绑卡表里面冗余手机号、银行卡
        AccountBankCardBind accountBankCardBind = accountBankCardBindService.queryDataByAccountId(request.getAccountId());
        if (accountBankCardBind == null) {
            //绑卡信息不存在
            throw new BusinessException(new CapitalErrorCode(CapitalErrorCode.Element.b_card_info_not_exits));
        }
        CapitalLoanTrans capitalLoanTrans = null;
        //判断外部流水号记录是否存在
        CapitalLoanTrans existData = queryByOuterOrderNoAndProductCode(request.getProductCode(), request.getOuterLoanOrderNo());
        if (existData != null) {
            CapitalLoanTransStatus status = CapitalLoanTransStatus.getByKey(existData.getStatus());
            if (status != CapitalLoanTransStatus.WAITING) {
                //如果存在的交易状态为待放款,可以继续往下走,调放款,其他状态直接返回
                CapitalLoanDto returnData = new CapitalLoanDto();
                returnData.setCapitalLoanTransNo(existData.getCapitalLoanTransNo());
                return returnData;
            } else {
                capitalLoanTrans = existData;
            }

        } else {
            //借款试算
            LoanTrialDto loanTrialDto = loanTrialService.calcLoan(request);
            if (loanTrialDto == null) {
                throw new SystemException("还款试算结果为空");
            }
            capitalLoanTransService = ApplicationContextUtil.getBeanByType(CapitalLoanTransService.class);
            //保存数据
            capitalLoanTrans = capitalLoanTransService.saveLoanTrans(request, capitalProvider, accountBankCardBind, loanTrialDto, penaltyInterestRate);
        }

        //放款
        loansCapitalAllot(capitalLoanTrans, accountBankCardBind);

        CapitalLoanDto capitalLoanDto = new CapitalLoanDto();
        capitalLoanDto.setCapitalLoanTransNo(capitalLoanTrans.getCapitalLoanTransNo());

        return capitalLoanDto;

    }

    /**
     * 直接代付
     * 
     * @param request
     * @return
     */
    public CapitalLoanDto pay(CapitalPayRequest request) {

        CapitalProvider capitalProvider = capitalProviderService.queryDataByCapitalCode(request.getCapitalCode());
        if (capitalProvider == null) {
            //资金方不存在
            throw new SystemException("资金方不存在");

        }
        //判断外部流水号记录是否存在
        CapitalLoanTrans existData = queryByOuterOrderNoAndProductCode(request.getProductCode(), request.getOuterLoanOrderNo());
        if (existData != null) {
            //如果存在直接返回
            CapitalLoanTransStatus status = CapitalLoanTransStatus.getByKey(existData.getStatus());
            if (status != CapitalLoanTransStatus.WAITING) {
                //如果存在的交易状态为待放款,可以继续往下走,调放款,其他状态直接返回
                CapitalLoanDto returnData = new CapitalLoanDto();
                returnData.setCapitalLoanTransNo(existData.getCapitalLoanTransNo());
                return returnData;
            }
        }

        AccountBankCardBind accountBankCardBind = new AccountBankCardBind();
        accountBankCardBind.setAccountMobile(request.getMobile());
        accountBankCardBind.setBankCardNo(request.getBankCardNo());//银行卡
        accountBankCardBind.setAccountName(request.getRealName());//姓名
        accountBankCardBind.setBankCode(request.getBankCode());//银行编码

        CapitalLoanTrans record = new CapitalLoanTrans();
        CommonBeanCopier.copy(request, record);
        record.setCapitalCode(capitalProvider.getCapitalCode());
        String capitalLoanTransNo = OrderNoGenerator.getOrderNo(CapitalConstants.capital_loan_biz_code);
        record.setCapitalLoanTransNo(capitalLoanTransNo);
        record.setAmount(request.getLoanAmount());
        record.setStatus(CapitalLoanTransStatus.WAITING.getKey());//状态为待放款
        record.setAccountMobile(accountBankCardBind.getAccountMobile());//手机号
        record.setAccountCardNo(accountBankCardBind.getBankCardNo());//银行卡

        Date now = new Date();
        record.setApplyTime(now);
        record.setGmtCreated(now);

        capitalLoanTransMapper.insertSelective(record);

        CapitalLoanDto capitalLoanDto = new CapitalLoanDto();
        capitalLoanDto.setCapitalLoanTransNo(record.getCapitalLoanTransNo());
        //放款
        loansCapitalAllot(record, accountBankCardBind);

        return capitalLoanDto;

    }

    /**
     * 直接对公代付
     *
     * @param request
     * @return
     */
    public CapitalLoanDto payOfPublic(CapitalPublicPayRequest request) {
        XianFengPayService payService = ApplicationContextUtil.getBeanByType(XianFengPayService.class);
        PayRequest payRequest = new PayRequest();
        payRequest.setAccountName(request.getRealName());
        payRequest.setBankCode(request.getBankCode());
        payRequest.setBankCardNo(request.getBankCardNo());
        payRequest.setAmount(request.getLoanAmount().doubleValue());
        String capitalLoanTransNo = OrderNoGenerator.getOrderNo(CapitalConstants.capital_loan_biz_code);
        payRequest.setCapitalOrderNo(capitalLoanTransNo);
        payRequest.setIssuer(request.getIssuer());

        CapitalProvider provider = capitalProviderService.queryDataByCapitalCode(request.getCapitalCode());
        PassageAccount passageAccount = new PassageAccount();
        passageAccount.setAccountCode(provider.getPaymentAccount());
        passageAccount = passageAccountService.queryDataByAccountCode(passageAccount);
        MerchantInfo merchantInfo = new MerchantInfo();
        merchantInfo.setMerchantId(passageAccount.getMerchantId());
        merchantInfo.setSecretKey(passageAccount.getSecretKey());
        payRequest.setMerchantInfo(merchantInfo);
        payService.singPayOfPublic(payRequest);
        CapitalLoanDto loanDto = new CapitalLoanDto();
        loanDto.setCapitalLoanTransNo(capitalLoanTransNo);
        return loanDto;
    }

    /**
     * 保存借款交易
     * 
     * @param request
     * @param capitalProvider
     * @param accountBankCardBind
     */
    @Transactional(rollbackFor = Exception.class, timeout = 30)
    public CapitalLoanTrans saveLoanTrans(CapitalLoanRequest request, CapitalProvider capitalProvider, AccountBankCardBind accountBankCardBind,
                                          LoanTrialDto loanTrialDto, BigDecimal penaltyInterestRate) {
        CapitalLoanTrans record = new CapitalLoanTrans();
        CommonBeanCopier.copy(request, record);
        record.setCapitalCode(capitalProvider.getCapitalCode());
        String capitalLoanTransNo = OrderNoGenerator.getOrderNo(CapitalConstants.capital_loan_biz_code);
        record.setCapitalLoanTransNo(capitalLoanTransNo);
        record.setAmount(request.getLoanAmount());
        record.setStatus(CapitalLoanTransStatus.WAITING.getKey());//状态为待放款
        record.setAccountMobile(accountBankCardBind.getAccountMobile());//手机号
        record.setAccountCardNo(accountBankCardBind.getBankCardNo());//银行卡

        Date now = new Date();
        record.setApplyTime(now);
        record.setGmtCreated(now);

        record.setPenaltyInterestRate(penaltyInterestRate);
        record.setInterestRate(loanTrialDto.getInterestRate());
        record.setInterestAmount(loanTrialDto.getInterestAmount());
        record.setFeeAmount(loanTrialDto.getFeeAmount());
        record.setActualLoanAmount(loanTrialDto.getActualLoanAmount());

        capitalLoanTransMapper.insertSelective(record);

        //生成还款计划,状态:未生效
        List<RepayPlanDto> repayPlanDtoList = loanTrialDto.getRepayPlanDtoList();
        if (CollectionUtils.isEmpty(repayPlanDtoList)) {
            throw new SystemException("还款计划试算的还款计划为空");
        }
        for (RepayPlanDto repayPlanDto : repayPlanDtoList) {
            RepayPlan repayPlan = new RepayPlan();
            CommonBeanCopier.copy(repayPlanDto, repayPlan);
            repayPlan.setCapitalLoanTransNo(record.getCapitalLoanTransNo());
            repayPlan.setProductCode(record.getProductCode());
            repayPlan.setAccountId(record.getAccountId());
            repayPlan.setTermUnit(request.getTermUnit());
            repayPlan.setTotalTerm(request.getTotalTerm());
            repayPlanMapper.insertSelective(repayPlan);
        }

        return record;
    }

    /**
     * 资金划拨，也就是放款
     * 
     * @param
     */
    public void loansCapitalAllot(CapitalLoanTrans trans, AccountBankCardBind accountBankCardBind) {
        String capitalLoanTransNo = trans.getCapitalLoanTransNo();
        PayRequest request = new PayRequest();
        request.setProductCode(trans.getProductCode());
        request.setBankCode(accountBankCardBind.getBankCode());
        request.setBankCardNo(accountBankCardBind.getBankCardNo());//银行卡
        request.setAccountName(accountBankCardBind.getAccountName());
        request.setMobile(accountBankCardBind.getAccountMobile());
        request.setAmount(trans.getActualLoanAmount().doubleValue());//实际放款金额
        request.setCapitalOrderNo(capitalLoanTransNo);
        request.setPayMerchantType(PayMerchantType.PAY);
        Map<String, Object> appendData = new HashMap<String, Object>();
        //放款通知处理者
        appendData.put(request.NOTICE_HANDLER_BEAN_NAME, "loanPayResultNoticeHandler");
        request.setAppendData(appendData);

        //调用先锋放款
        PayResult resultDto = payServiceDelegate.singlePay(request);
        if (PayResult.THIRD_SYNC_SUCCESS.equals(resultDto.getResCode()) || PayResult.THIRD_SYNC_PENDING.equals(resultDto.getResCode())) {
            //放款申请成功,或者支付告诉我在处理中,更新状态为放款中
            modifyStatus(CapitalLoanTransStatus.PROCESSING.getKey(), capitalLoanTransNo);

        } else if (PayResult.THIRD_SYNC_FAIL.equals(resultDto.getResCode())) {
            //放款申请失败
            //更改状态，返回失败
            capitalLoanTransMapper.loanFail(resultDto.getThirdOrderNo(), resultDto.getResMsg(), capitalLoanTransNo);
            logger.error("放款代付返回错误, capitalLoanTransNo-{}，返回结果{}", capitalLoanTransNo, resultDto.getResMsg());
            throw new BusinessException(new CapitalErrorCode(CapitalErrorCode.Element.b_pay_return_fail));
        } else if (PayResult.THIRD_INVOKE_EXCEPTION.equals(resultDto.getResCode())) {
            //调用异常,因为不明确有没有调用成功，当做调用成功，把状态改为放款中，后面通过任务查询
            modifyStatus(CapitalLoanTransStatus.PROCESSING.getKey(), capitalLoanTransNo);
            logger.error("放款代付返回调用异常, capitalLoanTransNo-{}，返回结果{}", capitalLoanTransNo, resultDto.getResMsg());
        }
    }

    /**
     * 主动查询放款代付结果
     */
    @Async
    public void queryLoanPayResult() {
        //查询放款中的订单
        List<CapitalLoanTrans> list = queryByStatus(CapitalLoanTransStatus.PROCESSING.getKey());
        if (CollectionUtils.isEmpty(list)) {
            return;
        }
        for (CapitalLoanTrans capitalLoanTrans : list) {
            PayRequest request = new PayRequest();
            request.setProductCode(capitalLoanTrans.getProductCode());
            request.setCapitalOrderNo(capitalLoanTrans.getCapitalLoanTransNo());
            request.setPayMerchantType(PayMerchantType.PAY);

            PayResult resultDto = payServiceDelegate.singlePayQuery(request);
            PayNoticeHandlerRequest handlerRequest = new PayNoticeHandlerRequest();
            handlerRequest.setOrderNo(capitalLoanTrans.getCapitalLoanTransNo());
            handlerRequest.setThirdOrderNo(resultDto.getThirdOrderNo());
            handlerRequest.setThirdResMsg(resultDto.getResMsg());
            LoanPayResultNoticeHandler payNoticeHandler = ApplicationContextUtil.getBeanByType(LoanPayResultNoticeHandler.class);
            if (PayResult.THIRD_SYNC_SUCCESS.equals(resultDto.getResCode())) {
                //代付成功
                //复用通知的处理
                payNoticeHandler.paySuccessHandle(handlerRequest);
            } else if (PayResult.THIRD_SYNC_FAIL.equals(resultDto.getResCode())) {
                //代付失败
                //复用通知的处理
                payNoticeHandler.payFailHandle(handlerRequest);
            } else if (PayResult.THIRD_UNCOMMIT.equals(resultDto.getResCode())) {
                //没有找到订单
                logger.error("放款结果查询代付错误, capitalLoanTransNo-{}，第三方支付返回无效订单号", capitalLoanTrans.getCapitalLoanTransNo());
                //todo:记录异常订单
            }
        }
    }

    /**
     * 放款成功
     * 
     * @param capitalLoanTrans
     * @param payNo
     */
    @Transactional(rollbackFor = Exception.class, timeout = 30)
    public void loanPaySuccess(CapitalLoanTrans capitalLoanTrans, String payNo) {

        //更新状态为放款成功,放款时间、支付流水号
        capitalLoanTransMapper.loanSuccess(payNo, capitalLoanTrans.getCapitalLoanTransNo());
        //更改还款计划状态为生效
        repayPlanMapper.updateIsEffect(IsEffect.effect.getKey(), capitalLoanTrans.getCapitalLoanTransNo());
        //收取手续费
        payOrderService.saveFeePayOrderByCut(capitalLoanTrans);
        //通知交易
        loanResultNotice(capitalLoanTrans, CapitalLoanTransStatus.SUCCESS);

    }

    /**
     * 放款失败
     * 
     * @param capitalLoanTrans
     * @param payNo
     * @param payResult
     */
    @Transactional(rollbackFor = Exception.class, timeout = 30)
    public void loanPayFail(CapitalLoanTrans capitalLoanTrans, String payNo, String payResult) {

        //更新状态为放款失败,支付流水号,第三方支付返回结果
        capitalLoanTransMapper.loanFail(payNo, payResult, capitalLoanTrans.getCapitalLoanTransNo());
        //通知交易
        loanResultNotice(capitalLoanTrans, CapitalLoanTransStatus.FAIL);
    }

    public PageData<PayCapitalRecordQueryDto> queryLoanTransRecordByPage(CapitalRecordQueryRequest request) {
        Pager pager = new Pager();
        pager.setPageNum(request.getPageNum());
        pager.setPageSize(request.getPageSize());
        return queryLoanTransRecordByPage(request, pager);
    }

    /**
     * 查询账户未结束订单(非结清或者放款失败订单)
     *
     * @param accountOrderRequest
     * @return
     */
    public List<ProcessingAccountOrderDto> queryAccountProcessingOrder(ProcessingAccountOrderRequest accountOrderRequest) {
        CapitalLoanTrans loanTrans = new CapitalLoanTrans();
        loanTrans.setAccountId(accountOrderRequest.getAccountId());
        List<CapitalLoanTrans> capitalLoanTransList = queryAccountProcessingOrder(loanTrans);
        List<ProcessingAccountOrderDto> processingAccountOrderDtos = Lists.newArrayList();
        for (CapitalLoanTrans capitalLoanTrans : capitalLoanTransList) {
            ProcessingAccountOrderDto processingAccountOrderDto = new ProcessingAccountOrderDto();
            CommonBeanCopier.copy(capitalLoanTrans, processingAccountOrderDto);
            processingAccountOrderDtos.add(processingAccountOrderDto);
        }
        return processingAccountOrderDtos;
    }

    /**
     * 查询账户逾期订单
     *
     * @param accountOrderRequest
     * @return
     */
    public List<OverdueAccountOrderDto> queryAccountOverdueOrder(OverdueAccountOrderRequest accountOrderRequest) {
        CapitalLoanTrans loanTrans = new CapitalLoanTrans();
        loanTrans.setAccountId(accountOrderRequest.getAccountId());
        List<CapitalLoanTrans> capitalLoanTransList = queryAccountOverdueOrder(loanTrans);
        List<OverdueAccountOrderDto> accountOrderDtos = Lists.newArrayList();
        for (CapitalLoanTrans capitalLoanTrans : capitalLoanTransList) {
            OverdueAccountOrderDto accountOrderDto = new OverdueAccountOrderDto();
            CommonBeanCopier.copy(capitalLoanTrans, accountOrderDto);
            accountOrderDtos.add(accountOrderDto);
        }
        return accountOrderDtos;
    }

    /**
     * 放款结果通知
     * 
     * @param capitalLoanTrans
     * @param result
     */
    @Async
    public void loanResultNotice(CapitalLoanTrans capitalLoanTrans, CapitalLoanTransStatus result) {
        try {
            //通知交易
            LoanResultNoticeRequest loanResultNoticeRequest = new LoanResultNoticeRequest();
            loanResultNoticeRequest.setLoanResult(result.getKey());
            loanResultNoticeRequest.setLoanOrderNo(capitalLoanTrans.getOuterLoanOrderNo());
            transactionRemoteService.loanResultNotice(loanResultNoticeRequest);
        } catch (Exception e) {
            logger.error("放款失败结果通知交易失败,capitalLoanTransNo-{}", capitalLoanTrans.getCapitalLoanTransNo(), e);
        }
    }

}
