package com.xhh.creditcore.capital.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.xhh.creditcore.capital.dao.CapitalProviderMapper;
import com.xhh.creditcore.capital.model.CapitalProvider;

/**
 * <p>
 * 资金方 服务实现类
 * </p>
 *
 * @author nathaniel123
 * @since 2018-01-09
 */
@Service("CapitalProviderService")
public class CapitalProviderService {
    @Resource
    private CapitalProviderMapper capitalProviderMapper;

    /**
     * 根据id查询数据
     *
     * @param id 实体id
     * @return 实体
     */
    public CapitalProvider queryDataById(long id) {
        return null;
    }

    /**
     * 新增数据
     *
     * @param record 实体
     */
    public void addData(CapitalProvider record) {

    }

    /**
     * 修改数据
     *
     * @param record 实体
     */
    public void modifyData(CapitalProvider record) {

    }

    /**
     * 删除数据
     *
     * @param record 实体
     */
    public void deleteData(CapitalProvider record) {

    }

    public CapitalProvider queryDataByCapitalCode(String capitalCode) {
        CapitalProvider capitalProvider = new CapitalProvider();
        capitalProvider.setCapitalCode(capitalCode);
        List<CapitalProvider> capitalProviders = capitalProviderMapper.selectByCondition(capitalProvider);
        if (!CollectionUtils.isEmpty(capitalProviders)) {
            return capitalProviders.get(0);
        }
        return null;
    }
}
