package com.xhh.creditcore.capital.service.payimpl.xianfeng;

import java.io.IOException;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.janty.core.exception.SystemException;
import com.squareup.okhttp.FormEncodingBuilder;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;
import com.ucf.sdk.util.AESCoder;

/**
 * 发送先锋支付请求执行者
 * 
 * @author zhangweixin
 */
public class XianFengRequestExecutor {
    private static Logger         logger     = LoggerFactory.getLogger(XianFengRequestExecutor.class);
    private static OkHttpClient   httpClient = new OkHttpClient();
    private static XianFengConfig config     = XianFengConfig.getXianFengConfig();

    static {
        httpClient.setConnectTimeout(config.HTTP_CONNECTION_TIMEOUT, TimeUnit.SECONDS);
        httpClient.setWriteTimeout(config.HTTP_WRITE_TIMEOUT, TimeUnit.SECONDS);
        httpClient.setReadTimeout(config.HTTP_READ_TIMEOUT, TimeUnit.SECONDS);
    }

    /**
     * 执行先锋支付请求
     * 
     * @param baseRequest
     * @param type
     * @param <T>
     * @return
     * @throws Exception
     */
    public static <T> T execute(BaseRequest baseRequest, TypeReference<T> type) throws Exception {
        baseRequest.executeSign();
        String encryptData = doExecute(baseRequest.baseRequestDatatoJson());
        String reponseStr = decryptData(encryptData, baseRequest.getMerRSAKey());
        logger.info("先锋返回响应:{}", reponseStr);
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        return objectMapper.readValue(reponseStr, type);
    }

    /**
     * 执行请求
     * 
     * @param jsonBody 请求参数json串
     * @return
     * @throws IOException
     */
    private static String doExecute(String jsonBody) throws IOException {

        logger.info("先锋支付执行请求数据:{}", jsonBody);
        FormEncodingBuilder encodingBuilder = new FormEncodingBuilder();
        Map<String, String> params = new ObjectMapper().readValue(jsonBody, new TypeReference<Map<String, String>>() {
        });

        params.entrySet().forEach((entry) -> {
            encodingBuilder.add(entry.getKey(), entry.getValue());
        });

        Request.Builder requestBuilder = new Request.Builder();
        requestBuilder.post(encodingBuilder.build()).url(config.UCF_GATEWAY_URL);
        Response response = httpClient.newCall(requestBuilder.build()).execute();
        if (response.isSuccessful()) {
            return response.body().string();
        } else {
            throw new IOException("先锋支付发起请求失败,返回码-" + response.code());
        }
    }

    /**
     * 对返回数据解密
     *
     * @param encryptStr
     * @return
     * @throws Exception
     */
    private static String decryptData(String encryptStr, String merRSAKey) {
        try {
            return AESCoder.decrypt(encryptStr, merRSAKey);
        } catch (Exception e) {
            throw new SystemException("解密失败", e);
        }
    }
}
