package com.xhh.creditcore.capital.model;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 异常订单表
 * </p>
 *
 * @author nathaniel123
 * @since 2018-01-09
 */

public class ExcepitonOrder implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long              id;
    /**
     * 订单类型：1借款、2还款
     */
    private Integer           orderType;
    /**
     * 订单号
     */
    private String            orderNo;
    /**
     * 异常信息
     */
    private String            exceptionMessage;
    /**
     * 异常时间
     */
    private Date              exceptionTime;
    /**
     * 创建时间
     */
    private Date              gmtCreated;
    /**
     * 最后修改时间
     */
    private Date              gmtModified;
    /**
     * 创建人
     */
    private String            creator;
    /**
     * 最后修改人
     */
    private String            modifier;
    /**
     * 删除标志位 N-未删除 Y-已删除
     */
    private String            isDeleted;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getOrderType() {
        return orderType;
    }

    public void setOrderType(Integer orderType) {
        this.orderType = orderType;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getExceptionMessage() {
        return exceptionMessage;
    }

    public void setExceptionMessage(String exceptionMessage) {
        this.exceptionMessage = exceptionMessage;
    }

    public Date getExceptionTime() {
        return exceptionTime;
    }

    public void setExceptionTime(Date exceptionTime) {
        this.exceptionTime = exceptionTime;
    }

    public Date getGmtCreated() {
        return gmtCreated;
    }

    public void setGmtCreated(Date gmtCreated) {
        this.gmtCreated = gmtCreated;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public String getModifier() {
        return modifier;
    }

    public void setModifier(String modifier) {
        this.modifier = modifier;
    }

    public String getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(String isDeleted) {
        this.isDeleted = isDeleted;
    }

    @Override
    public String toString() {
        return "ExcepitonOrder{" + "id=" + id + ", orderType=" + orderType + ", orderNo=" + orderNo + ", exceptionMessage=" + exceptionMessage
                + ", exceptionTime=" + exceptionTime + ", gmtCreated=" + gmtCreated + ", gmtModified=" + gmtModified + ", creator=" + creator + ", modifier="
                + modifier + ", isDeleted=" + isDeleted + "}";
    }
}
