package com.xhh.creditcore.capital.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.janty.core.util.CommonBeanCopier;
import com.janty.core.util.StringUtil;
import com.xhh.creditcore.capital.dao.BankCardbinMapper;
import com.xhh.creditcore.capital.dto.BankCardbinDto;
import com.xhh.creditcore.capital.model.BankCardbin;

/**
 * BankCardbin服务类
 * 
 * @author jan
 * @date 2018-1-17 14:24:56
 */
@Service("bankCardbinService")
public class BankCardbinService {
    @Resource
    private BankCardbinMapper bankCardbinMapper;

    /**
     * 根据id查询数据
     * 
     * @param id 实体id
     * @return 实体
     */
    public BankCardbin queryDataById(long id) {
        return null;
    }

    /**
     * 新增数据
     * 
     * @param record 实体
     */
    public void addData(BankCardbin record) {

    }

    /**
     * 修改数据
     * 
     * @param record 实体
     */
    public void modifyData(BankCardbin record) {

    }

    /**
     * 删除数据
     * 
     * @param record 实体
     */
    public void deleteData(BankCardbin record) {

    }

    /**
     * 查询卡bin信息
     * 
     * @param bankCardNo
     * @return
     */
    public BankCardbinDto queryByCardNo(String bankCardNo) {
        Map<String, String> map = new HashMap<>();
        if (StringUtil.isEmpty(bankCardNo) || bankCardNo.length() < 10)
            return null;
        String cardNo = bankCardNo;
        int count = 5;
        while (count <= 10) {
            map.put("cardBin" + count, cardNo.substring(0, count));
            count++;
        }
        List<BankCardbin> list = bankCardbinMapper.selectByCardBin(map);
        if (!CollectionUtils.isEmpty(list)) {
            BankCardbinDto bankCardbinDto = new BankCardbinDto();
            CommonBeanCopier.copy(list.get(0), bankCardbinDto);
            return bankCardbinDto;
        }
        return null;
    }
}
