package com.xhh.creditcore.capital.pay;

import javax.annotation.Resource;

import com.xhh.creditcore.capital.constant.CapitalConstants;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import com.janty.cached.access.RedisCachedAccess;
import com.xhh.creditcore.capital.constant.CapitalRedisKey;
import com.xhh.creditcore.capital.enums.CapitalLoanTransStatus;
import com.xhh.creditcore.capital.model.CapitalLoanTrans;
import com.xhh.creditcore.capital.service.CapitalLoanTransService;

/**
 * 放款结果通知 类LoanPayResultNoticeHandler.java的实现描述：TODO 类实现描述
 * 
 * @author feng 2018年1月18日 下午2:23:16
 */
@Component("loanPayResultNoticeHandler")
@Lazy
public class LoanPayResultNoticeHandler extends PayNoticeHandlerAdaptor {

    private static Logger             logger = LoggerFactory.getLogger(LoanPayResultNoticeHandler.class);

    @Resource
    private RedisCachedAccess<String> cachedAccess;
    @Resource
    private CapitalLoanTransService   capitalLoanTransService;

    /**
     * 放款成功处理
     */
    @Override
    public void paySuccessHandle(PayNoticeHandlerRequest handlerRequest) {
        String capitalLoanTransNo = handlerRequest.getOrderNo();
        String payNo = handlerRequest.getThirdOrderNo();
        logger.info("第三方支付放款成功通知处理开始，capitalLoanTransNo-{}，payNo-{}", capitalLoanTransNo, payNo);
        try {

            if (StringUtils.isEmpty(capitalLoanTransNo)) {
                logger.error("capitalLoanTransNo为空");
                return;
            }
            //锁外部交易流水号
            cachedAccess.tryLock(CapitalRedisKey.LOCK_PREFIX + capitalLoanTransNo);
            CapitalLoanTrans capitalLoanTrans = capitalLoanTransService.queryDataByLoanTransNo(capitalLoanTransNo);
            if (capitalLoanTrans == null) {
                logger.error("capitalLoanTransNo-{}没有找到资金平台借款交易", capitalLoanTransNo);
                return;
            }
            CapitalLoanTransStatus status = CapitalLoanTransStatus.getByKey(capitalLoanTrans.getStatus());
            if (status != CapitalLoanTransStatus.PROCESSING) {
                //状态非放款中,证明已经通知过,不用做处理
                logger.error("capitalLoanTransNo-{}状态为{}，无重复处理", capitalLoanTransNo, capitalLoanTrans.getStatus());
                return;
            }
            //放款成功
            capitalLoanTransService.loanPaySuccess(capitalLoanTrans, payNo);

        } catch (Exception e) {
            logger.error("第三方支付放款成功通知处理异常, capitalLoanTransNo-{}，payNo-{}", capitalLoanTransNo, payNo, e);
        } finally {
            //释放锁
            cachedAccess.releaseLock(CapitalRedisKey.LOCK_PREFIX + capitalLoanTransNo);
        }
        logger.info("第三方支付放款成功通知处理结束，capitalLoanTransNo-{}，payNo-{}", capitalLoanTransNo, payNo);

    }

    /**
     * 放款失败处理
     */
    @Override
    public void payFailHandle(PayNoticeHandlerRequest handlerRequest) {
        String capitalLoanTransNo = handlerRequest.getOrderNo();
        String payNo = handlerRequest.getThirdOrderNo();
        logger.info("第三方支付放款失败通知处理开始，capitalLoanTransNo-{}，payNo-{}", capitalLoanTransNo, payNo);
        try {

            if (StringUtils.isEmpty(capitalLoanTransNo)) {
                logger.error("capitalLoanTransNo为空");
                return;
            }
            //锁外部交易流水号
            cachedAccess.tryLock(CapitalRedisKey.LOCK_PREFIX + capitalLoanTransNo);
            CapitalLoanTrans capitalLoanTrans = capitalLoanTransService.queryDataByLoanTransNo(capitalLoanTransNo);
            if (capitalLoanTrans == null) {
                logger.error("capitalLoanTransNo-{}没有找到资金平台借款交易", capitalLoanTransNo);
                return;
            }
            CapitalLoanTransStatus status = CapitalLoanTransStatus.getByKey(capitalLoanTrans.getStatus());
            if (status != CapitalLoanTransStatus.PROCESSING) {
                //状态非放款中,证明已经通知过,不用做处理
                logger.error("capitalLoanTransNo-{}状态为{}，勿重复处理", capitalLoanTransNo, capitalLoanTrans.getStatus());
                return;
            }
            //放款失败
            capitalLoanTransService.loanPayFail(capitalLoanTrans, payNo, handlerRequest.getThirdResMsg());

        } catch (Exception e) {
            logger.error("第三方支付放款失败通知处理异常, capitalLoanTransNo-{}，payNo-{}", capitalLoanTransNo, payNo, e);
        } finally {
            //释放锁
            cachedAccess.releaseLock(CapitalRedisKey.LOCK_PREFIX + capitalLoanTransNo);
        }
        logger.info("第三方支付放款失败通知处理结束，capitalLoanTransNo-{}，payNo-{}", capitalLoanTransNo, payNo);

    }

    @Override
    public boolean isSupportOrderType(String orderNo) {
        return orderNo.startsWith(CapitalConstants.capital_loan_biz_code);
    }
}
