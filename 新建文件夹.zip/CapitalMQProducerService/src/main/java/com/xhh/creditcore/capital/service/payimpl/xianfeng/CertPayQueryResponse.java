package com.xhh.creditcore.capital.service.payimpl.xianfeng;

/**
 * 支付认证查单响应
 * 
 * @author zhangweixin
 */
public class CertPayQueryResponse extends CertPayConfirmPayResponse {
    private String errorCode;
    private String errorMessage;

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    @Override
    public boolean isOrderSuccess() {
        return getOrderStatus().equals("00");
    }

    @Override
    public boolean isOrderPending() {
        return getOrderStatus().equals("02");
    }

    @Override
    public boolean isOrderFail() {
        return getOrderStatus().equals("01");
    }

    public boolean isUncommit() {
        return getOrderStatus().equals("03");
    }
}
