package com.xhh.creditcore.capital.bean;

import com.janty.core.dto.BaseModel;

/**
 * 类JudgeSendMessage.java 类实现描述: 判断发短信bean
 * 
 * @author xiehuang 2018年1月26日 上午11:36:02
 */
public class JudgeSendMessage extends BaseModel {

    /**
     * 是否需要发送
     */
    private boolean needSend;

    /**
     * 短信模板id
     */
    private Integer templateId;

    /**
     * 短信通道id 备用
     */
    private Integer channelId;

    public boolean isNeedSend() {
        return needSend;
    }

    public void setNeedSend(boolean needSend) {
        this.needSend = needSend;
    }

    public Integer getTemplateId() {
        return templateId;
    }

    public void setTemplateId(Integer templateId) {
        this.templateId = templateId;
    }

    public Integer getChannelId() {
        return channelId;
    }

    public void setChannelId(Integer channelId) {
        this.channelId = channelId;
    }

}
