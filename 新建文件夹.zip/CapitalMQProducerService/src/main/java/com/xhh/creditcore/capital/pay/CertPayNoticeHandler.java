package com.xhh.creditcore.capital.pay;

import com.xhh.creditcore.capital.service.RepaymentService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.xhh.creditcore.capital.constant.CapitalConstants;

import javax.annotation.Resource;

/**
 * 代付服务费结果通知
 *
 * @author zhangweixin 2018年2月28日 下午2:23:16
 */
@Component
public class CertPayNoticeHandler extends PayNoticeHandlerAdaptor {
    @Resource
    private RepaymentService repaymentService;

    @Override
    public void certPayFailHandle(PayNoticeHandlerRequest handlerRequest) {
        repaymentService.deductPrincipalFailHandle(handlerRequest);
    }

    @Override
    public void certPaySuccessHandle(PayNoticeHandlerRequest handlerRequest) {
        repaymentService.deductPrincipalSuccessHandle(handlerRequest);
    }

    @Override
    public boolean isSupportOrderType(String orderNo) {
        return orderNo.startsWith(CapitalConstants.capital_cert_pay_biz_code);
    }
}
