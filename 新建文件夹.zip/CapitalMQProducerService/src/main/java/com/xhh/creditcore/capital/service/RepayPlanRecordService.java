package com.xhh.creditcore.capital.service;

import com.xhh.creditcore.capital.model.RepayPlanRecord;
import com.xhh.creditcore.capital.dao.RepayPlanRecordMapper;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p>
 * 还款计划变更流水表 服务实现类
 * </p>
 *
 * @author nathaniel123
 * @since 2018-01-09
 */
@Service("RepayPlanRecordService")
public class RepayPlanRecordService {
    @Resource
    private RepayPlanRecordMapper repayPlanRecordMapper;

    /**
     * 根据id查询数据
     *
     * @param id 实体id
     * @return 实体
     */
    public RepayPlanRecord queryDataById(long id) {
        return repayPlanRecordMapper.selectById(id);
    }

    /**
     * 新增数据
     *
     * @param record 实体
     */
    public void addData(RepayPlanRecord record) {
        repayPlanRecordMapper.insert(record);
    }

    /**
     * 修改数据
     *
     * @param record 实体
     */
    public void modifyData(RepayPlanRecord record) {

    }

    /**
     * 删除数据
     *
     * @param record 实体
     */
    public void deleteData(RepayPlanRecord record) {

    }

    /**
     * 根据还款计划id更新罚息金额
     *
     * @param record 实体
     */
    public void modifyDataByRepayPlanId(RepayPlanRecord record) {
        repayPlanRecordMapper.updatePenaltyByRepayPlanId(record);
    }

    /**
     * 批量添加数据
     *
     * @param repayPlanRecords
     */
    public void addDataBatch(List<RepayPlanRecord> repayPlanRecords) {
        if (!CollectionUtils.isEmpty(repayPlanRecords)) {
            for (RepayPlanRecord repayPlanRecord : repayPlanRecords) {
                repayPlanRecordMapper.insert(repayPlanRecord);
            }
        }
    }

    public List<RepayPlanRecord> queryDataBycondition(RepayPlanRecord record) {
        return repayPlanRecordMapper.selectByCondition(record);
    }
}
