package com.xhh.creditcore.capital.model;

import java.math.BigDecimal;
import java.util.Date;

public class PenaltyInterestRecord {
    private Long       id;

    private Long       repayPlanId;

    private String     penaltyInterestDate;

    private BigDecimal penaltyInterestAmount;

    private BigDecimal penaltyInterestTotalAmount;
    
    private BigDecimal penaltyInterestRate;

    private Date       gmtCreated;

    private Date       gmtModified;

    private String     creator;

    private String     modifier;

    private String     isDeleted;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getRepayPlanId() {
        return repayPlanId;
    }

    public void setRepayPlanId(Long repayPlanId) {
        this.repayPlanId = repayPlanId;
    }

    public String getPenaltyInterestDate() {
        return penaltyInterestDate;
    }

    public void setPenaltyInterestDate(String penaltyInterestDate) {
        this.penaltyInterestDate = penaltyInterestDate == null ? null : penaltyInterestDate.trim();
    }

    public BigDecimal getPenaltyInterestTotalAmount() {
        return penaltyInterestTotalAmount;
    }

    public void setPenaltyInterestTotalAmount(BigDecimal penaltyInterestTotalAmount) {
        this.penaltyInterestTotalAmount = penaltyInterestTotalAmount;
    }

    public BigDecimal getPenaltyInterestAmount() {
        return penaltyInterestAmount;
    }

    public void setPenaltyInterestAmount(BigDecimal penaltyInterestAmount) {
        this.penaltyInterestAmount = penaltyInterestAmount;
    }

    public BigDecimal getPenaltyInterestRate() {
        return penaltyInterestRate;
    }

    public void setPenaltyInterestRate(BigDecimal penaltyInterestRate) {
        this.penaltyInterestRate = penaltyInterestRate;
    }

    public Date getGmtCreated() {
        return gmtCreated;
    }

    public void setGmtCreated(Date gmtCreated) {
        this.gmtCreated = gmtCreated;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator == null ? null : creator.trim();
    }

    public String getModifier() {
        return modifier;
    }

    public void setModifier(String modifier) {
        this.modifier = modifier == null ? null : modifier.trim();
    }

    public String getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(String isDeleted) {
        this.isDeleted = isDeleted == null ? null : isDeleted.trim();
    }
}
