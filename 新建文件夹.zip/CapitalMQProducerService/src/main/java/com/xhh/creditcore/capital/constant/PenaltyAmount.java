package com.xhh.creditcore.capital.constant;

import java.math.BigDecimal;

/**
 * 类PenaltyAmount.java 类实现描述 罚息金额计算常量
 * 
 * @author xiehuang 2018年1月11日 下午9:04:29
 */
public interface PenaltyAmount {
    /**
     * 高精度，保留小数位数
     */
    public static int HIGH_SCALE     = 4;
    /**
     * 保留小数位数
     */
    public static int SCALE          = 2;
    /**
     * 向上取整
     */
    public static int ROUND          = BigDecimal.ROUND_UP;
    /**
     * 一年天数
     */
    public static int YEAR_DAY_COUNT = 360;
}
