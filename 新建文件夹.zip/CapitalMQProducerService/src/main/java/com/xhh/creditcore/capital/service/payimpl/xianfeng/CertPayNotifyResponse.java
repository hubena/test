package com.xhh.creditcore.capital.service.payimpl.xianfeng;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.janty.core.exception.SystemException;

/**
 * 认证支付回调通知响应
 *
 * @author zhangweixin
 */
public class CertPayNotifyResponse extends NoticeBaseResponse {

    private String outOrderId;
    private String orderStatus;

    @Override
    public String toJson() {
        try {
            return new ObjectMapper().writeValueAsString(this);
        } catch (Exception e) {
            throw new SystemException("序列化" + CertPayNotifyResponse.class.getSimpleName() + "失败", e);
        }
    }

    @Override
    public String getMerchantNo() {
        return getOutOrderId();
    }

    @Override
    public boolean isOrderSuccess() {
        return getOrderStatus().equals("00");
    }

    @Override
    public boolean isOrderFail() {
        return getOrderStatus().equals("01");
    }

    @Override
    public boolean isOrderPending() {
        return getOrderStatus().equals("02");
    }

    public String getOutOrderId() {
        return outOrderId;
    }

    public void setOutOrderId(String outOrderId) {
        this.outOrderId = outOrderId;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }
}
