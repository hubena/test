package com.xhh.creditcore.capital.enums;

/**
 * @author zhangliang
 * @Date:Create in 2018/2/1
 */
public enum BankCardType {

    DEBIT_CARD(1, "借记卡"),
    CREDIT_CARD(2, "贷记卡"),
    QUASI_CREDIT_CARD(3, "准贷记卡"),
    CASH_ACCOUNT(4, "现金账户");

    private Integer key;
    private String  desc;

    public Integer getKey() {
        return key;
    }

    public String getDesc() {
        return desc;
    }

    BankCardType(Integer key, String desc) {
        this.key = key;
        this.desc = desc;
    }

    public BankCardType getInstance(Integer key) {
        for (BankCardType bankCardType : BankCardType.values()) {
            if (bankCardType.key.equals(key)) {
                return bankCardType;
            }
        }
        return null;
    }
}
