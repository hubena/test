package com.xhh.creditcore.capital.service;

import java.util.List;

import javax.annotation.Resource;

import org.apache.ibatis.session.RowBounds;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.google.common.collect.Lists;
import com.janty.core.dto.PageData;
import com.janty.core.dto.Pager;
import com.janty.core.util.CommonBeanCopier;
import com.janty.mybatis.util.CountHelper;
import com.xhh.creditcore.capital.bean.TransRecordCondition;
import com.xhh.creditcore.capital.dao.RepayTransMapper;
import com.xhh.creditcore.capital.dto.CapitalRecordQueryRequest;
import com.xhh.creditcore.capital.dto.RepayCapitalRecordQueryDto;
import com.xhh.creditcore.capital.model.RepayTrans;

/**
 * <p>
 * 资金平台还款交易表 服务实现类
 * </p>
 *
 * @author nathaniel123
 * @since 2018-01-09
 */
@Service("repayTransService")
public class RepayTransService {

    private static Logger    logger = LoggerFactory.getLogger(RepayTransService.class);

    @Resource
    private RepayTransMapper repayTransMapper;

    /**
     * 根据id查询数据
     *
     * @param id 实体id
     * @return 实体
     */
    public RepayTrans queryDataById(long id) {
        return repayTransMapper.selectById(id);
    }

    /**
     * 新增数据
     *
     * @param record 实体
     */
    public void addData(RepayTrans record) {
        repayTransMapper.insert(record);
    }

    /**
     * 修改数据
     *
     * @param record 实体
     */
    public void modifyData(RepayTrans record) {
        repayTransMapper.updateNoNullColumnById(record);
    }

    /**
     * 还款同步返回调用根据id更新记录状态
     *
     * @param record
     */
    public void updateStatusByIdForSyncReturn(RepayTrans record) {
        RepayTrans temp = new RepayTrans();
        temp.setId(record.getId());
        temp.setGmtModified(record.getGmtModified());
        temp.setStatus(record.getStatus());
        repayTransMapper.updateStatusByIdForSyncReturn(temp);
    }

    /**
     * 删除数据
     *
     * @param record 实体
     */
    public void deleteData(RepayTrans record) {
        repayTransMapper.deleteById(record.getId());
    }

    public List<RepayTrans> queryDataByConditon(RepayTrans record) {
        return repayTransMapper.selectByCondition(record);
    }

    public RepayTrans queryOneDataByConditon(RepayTrans record) {
        List<RepayTrans> repayTrans = queryDataByConditon(record);
        if (CollectionUtils.isEmpty(repayTrans)) {
            return null;
        } else {
            return repayTrans.get(0);
        }
    }

    public RepayTrans queryDataByTransNo(String transOrderNo) {
        RepayTrans repayTrans = new RepayTrans();
        repayTrans.setCapitalLoanTransNo(transOrderNo);
        return queryOneDataByConditon(repayTrans);
    }

    public RepayTrans queryDataByOutTransNo(String outTransOrderNo) {
        RepayTrans repayTrans = new RepayTrans();
        repayTrans.setOuterRepayOrderNo(outTransOrderNo);
        return queryOneDataByConditon(repayTrans);
    }

    /**
     * 回调成功更新还款交易数据
     *
     * @param record
     */
    public void updateDataForDeductNotice(RepayTrans record) {
        repayTransMapper.updateDataForDeductNotice(record);
    }

    public void updateRetransRecordStatus(RepayTrans record) {
        repayTransMapper.updateRetransRecordStatusById(record);
    }

    /**
     * 查询处在还款状态的订单
     */
    public List<RepayTrans> queryRepayStateOrder() {
        return repayTransMapper.queryRepayStateOrder();
    }

    /**
     * 查询入账记录
     *
     * @param request
     * @param pager
     * @return
     */
    public PageData<RepayCapitalRecordQueryDto> queryRepayTransRecordByPage(CapitalRecordQueryRequest request, Pager pager) {
        TransRecordCondition condition = new TransRecordCondition();
        CommonBeanCopier.copy(request, condition);
        RowBounds rowBounds = new RowBounds(pager.getOffset(), pager.getPageSize());
        List<RepayTrans> repayTransList = repayTransMapper.queryRepayTransRecordByPage(condition, rowBounds);
        List<RepayCapitalRecordQueryDto> queryDtoList = Lists.newArrayList();
        for (RepayTrans repayTrans : repayTransList) {
            RepayCapitalRecordQueryDto recordQueryDto = new RepayCapitalRecordQueryDto();
            CommonBeanCopier.copy(repayTrans, recordQueryDto);
            recordQueryDto.setAmount(repayTrans.getRepayAmount());
            queryDtoList.add(recordQueryDto);
        }
        PageData<RepayCapitalRecordQueryDto> queryDtoPageData = new PageData<>();
        queryDtoPageData.assembleResult(pager, queryDtoList, CountHelper.getTotalRow());
        return queryDtoPageData;
    }

    /**
     * 删除过期未支付的认证支付订单
     */
    public void removeOverDueRepayTrans() {
        List<RepayTrans> repayTransList = repayTransMapper.selectOverdueRepayTrans();
        repayTransList.forEach(repayTrans -> {
            logger.info("删除过期认证支付记录:{}", repayTrans.toString());
            repayTransMapper.deleteById(repayTrans.getId());
        });
    }
}
