package com.xhh.creditcore.capital.pay;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.janty.core.exception.SystemException;
import com.janty.core.spring.ApplicationContextUtil;
import org.springframework.util.StringUtils;

/**
 * zhangweixin 2018-01-18
 */
@Component
public class PayNoticeHandlerDelegate implements PayNoticeHandler {
    private static Logger                 logger = LoggerFactory.getLogger(PayNoticeHandlerDelegate.class);

    @Resource
    private List<PayNoticeHandlerAdaptor> noticeHandlerAdaptorList;

    @Override
    public void deductSuccessHandle(PayNoticeHandlerRequest handlerRequest) {
        getDeledate(handlerRequest).deductSuccessHandle(handlerRequest);
    }

    @Override
    public void deductFailHandle(PayNoticeHandlerRequest handlerRequest) {
        getDeledate(handlerRequest).deductFailHandle(handlerRequest);
    }

    @Override
    public void paySuccessHandle(PayNoticeHandlerRequest handlerRequest) {
        getDeledate(handlerRequest).paySuccessHandle(handlerRequest);
    }

    @Override
    public void payFailHandle(PayNoticeHandlerRequest handlerRequest) {
        getDeledate(handlerRequest).payFailHandle(handlerRequest);
    }

    @Override
    public boolean isSupportOrderType(String orderNo) {
        return false;
    }

    @Override
    public void certPayFailHandle(PayNoticeHandlerRequest handlerRequest) {
        getDeledate(handlerRequest).certPayFailHandle(handlerRequest);
    }

    @Override
    public void certPaySuccessHandle(PayNoticeHandlerRequest handlerRequest) {
        getDeledate(handlerRequest).certPaySuccessHandle(handlerRequest);
    }

    private PayNoticeHandler getDeledate(PayNoticeHandlerRequest handlerRequest) {
        logger.info("开始处理支付业务回调处理请求:", handlerRequest.toString());
        PayNoticeHandlerAdaptor handlerAdaptor = null;
        for (PayNoticeHandlerAdaptor handler : noticeHandlerAdaptorList) {
            if (handler.isSupportOrderType(handlerRequest.getOrderNo())) {
                handlerAdaptor = handler;
                break;
            }
        }

        if (handlerAdaptor == null) {
            throw new SystemException("找不到支持订单处理的业务noticeHandler");
        } else {
            logger.info("检索到回调业务handler:{}", handlerAdaptor.getClass().getName());
        }
        return handlerAdaptor;
    }

}
