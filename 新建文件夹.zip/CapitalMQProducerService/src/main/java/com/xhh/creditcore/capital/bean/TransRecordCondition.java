package com.xhh.creditcore.capital.bean;

import java.util.Date;

/**
 * zhangweixin
 */
public class TransRecordCondition {
    private String  accountMobile;
    private String  transOrderNo;
    private Integer status;
    private Date    transBeginTime;
    private Date    transEndTime;

    public String getAccountMobile() {
        return accountMobile;
    }

    public void setAccountMobile(String accountMobile) {
        this.accountMobile = accountMobile;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Date getTransBeginTime() {
        return transBeginTime;
    }

    public void setTransBeginTime(Date transBeginTime) {
        this.transBeginTime = transBeginTime;
    }

    public Date getTransEndTime() {
        return transEndTime;
    }

    public void setTransEndTime(Date transEndTime) {
        this.transEndTime = transEndTime;
    }

    public String getTransOrderNo() {
        return transOrderNo;
    }

    public void setTransOrderNo(String transOrderNo) {
        this.transOrderNo = transOrderNo;
    }

    @Override
    public String toString() {
        return "TransRecordCondition{" + "accountMobile='" + accountMobile + '\'' + ", transOrderNo='" + transOrderNo + '\'' + ", status=" + status
                + ", transBeginTime=" + transBeginTime + ", transEndTime=" + transEndTime + '}';
    }
}
