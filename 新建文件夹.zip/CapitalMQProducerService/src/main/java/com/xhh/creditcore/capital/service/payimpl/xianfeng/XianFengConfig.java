package com.xhh.creditcore.capital.service.payimpl.xianfeng;

import com.janty.core.spring.ApplicationContextUtil;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * 先锋配置 zhangweixin 2018-01-16
 */
@Component
public class XianFengConfig {
    @Value("${xf.sec.id:RSA}")
    public String SEC_ID;
    @Value("${xf.gateway.url}")
    public String UCF_GATEWAY_URL;
    @Value("${xf.single.pay.notice.path}")
    public String SIGNLE_PAY_NOTICE_PATH;
    @Value("${xf.signle.withhold.notice.path}")
    public String SIGNLE_WITHHOLD_NOTICE_PATH;
    @Value("${xf.signle.certpay.notice.path}")
    public String SIGNLE_CERTPAY_NOTICE_PATH;
    @Value("${xf.notice.prefix}")
    public String NOTICE_PREFIX;
    @Value("${xf.http.connection.timeout}")
    public Long   HTTP_CONNECTION_TIMEOUT;
    @Value("${xf.http.read.timeout}")
    public Long   HTTP_READ_TIMEOUT;
    @Value("${xf.http.write.timeout}")
    public Long   HTTP_WRITE_TIMEOUT;

    public static XianFengConfig getXianFengConfig() {
        return ApplicationContextUtil.getBeanByType(XianFengConfig.class);
    }
}
