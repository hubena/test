package com.xhh.creditcore.capital.controller;

import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.google.common.collect.Maps;
import com.xhh.creditcore.capital.enums.PayMerchantType;
import com.xhh.creditcore.capital.pay.PayNoticeHandlerDelegate;
import com.xhh.creditcore.capital.pay.PayNoticeRequest;
import com.xhh.creditcore.capital.service.payimpl.PayServiceDelegate;

/**
 * 外部http回调接口 zhangweixin 2018-01-10
 */
@Controller
@RequestMapping("/capital/callback")
public class PayCallBackController {
    private static Logger    logger = LoggerFactory.getLogger(PayCallBackController.class);
    @Resource
    PayNoticeHandlerDelegate handlerDelegate;
    @Resource
    PayServiceDelegate       payServiceDelegate;

    /**
     * 先锋支付还款代扣回调通知
     *
     * @return
     */
    @RequestMapping(value = "/deduct/xf/{productCode}/{merchantType}", method = RequestMethod.POST)
    public ResponseEntity<String> xianFengDeductNotify(@RequestParam(value = "data") String responseData, @PathVariable("productCode") String productCode,
                                                       @PathVariable("merchantType") Integer type) {
        try {
            payServiceDelegate.singleDeductNotice(buildRequest(productCode, responseData, type));
            return new ResponseEntity<>("SUCCESS", HttpStatus.OK);
        } catch (Exception e) {
            logger.error("先锋支付单笔代扣回调处理失败", e);
            return new ResponseEntity<>("FAIL", HttpStatus.BAD_REQUEST);
        }
    }

    /**
     * 先锋支付还款代扣回调通知
     *
     * @return
     */
    @RequestMapping(value = "/certpay/xf/{productCode}/{merchantType}", method = RequestMethod.POST)
    public ResponseEntity<Map<String, String>> xianFengCertPayNotify(@RequestParam(value = "data") String responseData,
                                                                     @PathVariable("productCode") String productCode,
                                                                     @PathVariable("merchantType") Integer type) {
        Map<String, String> response = Maps.newHashMap();
        try {
            payServiceDelegate.certPayNotice(buildRequest(productCode, responseData, type));
            response.put("errno", "0");
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            logger.error("先锋支付认证支付回调处理失败", e);
            response.put("errno", "1");
            response.put("errorMsg", e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        }
    }

    /**
     * 先锋支付借款代付回调通知
     *
     * @return
     */
    @RequestMapping(value = "/pay/xf/{productCode}/{merchantType}", method = RequestMethod.POST)
    public ResponseEntity<String> xianFengPayNotify(@RequestParam(value = "data") String responseData, @PathVariable("productCode") String productCode,
                                                    @PathVariable("merchantType") Integer type) {
        try {
            payServiceDelegate.singlePayNotice(buildRequest(productCode, responseData, type));
            return new ResponseEntity<>("SUCCESS", HttpStatus.OK);
        } catch (Exception e) {
            logger.error("先锋支付单笔代付回调处理失败", e);
            return new ResponseEntity<>("FAIL", HttpStatus.BAD_REQUEST);
        }
    }

    private PayNoticeRequest buildRequest(String productCode, String responseData, Integer type) {
        PayNoticeRequest payNoticeRequest = new PayNoticeRequest();
        payNoticeRequest.setPayMerchantType(PayMerchantType.getInstance(type));
        payNoticeRequest.setProductCode(productCode);
        payNoticeRequest.setResponseData(responseData);
        payNoticeRequest.setHandlerDelegate(handlerDelegate);
        return payNoticeRequest;
    }

}
