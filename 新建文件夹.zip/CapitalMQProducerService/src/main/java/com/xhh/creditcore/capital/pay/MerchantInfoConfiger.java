package com.xhh.creditcore.capital.pay;

/**
 * zhangweixin 2018-01-19
 */
public interface MerchantInfoConfiger {
    /**
     * 配置支付需要的商户信息
     * 
     * @param configurableMerchantInfo {@link ConfigurableMerchantInfo}
     */
    void configMerchantInfo(ConfigurableMerchantInfo configurableMerchantInfo);
}
