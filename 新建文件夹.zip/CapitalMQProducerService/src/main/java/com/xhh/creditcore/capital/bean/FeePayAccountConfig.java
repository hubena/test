package com.xhh.creditcore.capital.bean;

import com.janty.core.spring.ApplicationContextUtil;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class FeePayAccountConfig {
    @Value("${fee.pay.card.no}")
    private String bankCardNo;
    @Value("${fee.pay.bank.code}")
    private String bankCode;
    @Value("${fee.pay.name}")
    private String payname;
    @Value("${fee.pay.lianhanghao}")
    private String lianHangHao;

    public static FeePayAccountConfig getConfig() {
        return ApplicationContextUtil.getBeanByType(FeePayAccountConfig.class);
    }

    public String getBankCardNo() {
        return bankCardNo;
    }

    public void setBankCardNo(String bankCardNo) {
        this.bankCardNo = bankCardNo;
    }

    public String getBankCode() {
        return bankCode;
    }

    public void setBankCode(String bankCode) {
        this.bankCode = bankCode;
    }

    public String getPayname() {
        return payname;
    }

    public void setPayname(String payname) {
        this.payname = payname;
    }

    public String getLianHangHao() {
        return lianHangHao;
    }

    public void setLianHangHao(String lianHangHao) {
        this.lianHangHao = lianHangHao;
    }
}
