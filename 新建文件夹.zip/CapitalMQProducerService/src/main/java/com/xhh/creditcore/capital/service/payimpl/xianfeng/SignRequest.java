package com.xhh.creditcore.capital.service.payimpl.xianfeng;

import com.xhh.creditcore.capital.pay.MerchantInfo;

import java.util.HashMap;
import java.util.Map;

public class SignRequest extends BaseRequest {

    private Map<String, String> businessData = new HashMap<>();

    public SignRequest(MerchantInfo merchantInfo) {
        super("REQ_BANKCARD_AUTH", "4.0.0", merchantInfo);
    }

    /**
     * 设置商户订单号
     *
     * @param merchantNo
     */
    public void setMerchantNo(String merchantNo) {
        businessData.put("merchantNo", merchantNo);
    }

    public void setAccountNo(String accountNo) {
        businessData.put("accountNo", accountNo);
    }

    public void setAccountName(String accountName) {
        businessData.put("accountName", accountName);
    }

    public void setCertificateType(String certificateType) {
        businessData.put("certificateType", certificateType);
    }

    public void setCertificateNo(String certificateNo) {
        businessData.put("certificateNo", certificateNo);
    }

    public void setMobileNo(String mobileNo) {
        businessData.put("mobileNo", mobileNo);
    }

    public void setNoticeUrl(String noticeUrl) {
        businessData.put("noticeUrl", noticeUrl);
    }

    public void setMemo(String memo) {
        businessData.put("memo", memo);
    }

    @Override
    public Map<String, String> getBusinessData() {
        return businessData;
    }

    @Override
    protected Map<String, String> getSubClassSignData() {
        // TODO Auto-generated method stub
        return null;
    }
}
