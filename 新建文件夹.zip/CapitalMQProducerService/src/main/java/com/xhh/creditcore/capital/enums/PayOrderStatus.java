package com.xhh.creditcore.capital.enums;

/**
 * zhangweixin 2018-01-10
 */
public enum PayOrderStatus {
    WAITING(1, "待支付"),
    PROCESSING(2, "支付中"),
    SUCEESS(3, "支付成功"),
    FAIL(4, "支付失败");
    private Integer key;
    private String  desc;

    public Integer getKey() {
        return key;
    }

    public String getDesc() {
        return desc;
    }

    private PayOrderStatus(Integer key, String desc) {
        this.key = key;
        this.desc = desc;
    }

    public static PayOrderStatus getInstance(Integer key) {
        for (PayOrderStatus payType : PayOrderStatus.values()) {
            if (payType.key.equals(key)) {
                return payType;
            }
        }
        return null;
    }
}
