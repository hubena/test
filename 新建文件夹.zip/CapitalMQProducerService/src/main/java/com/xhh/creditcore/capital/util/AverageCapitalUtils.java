package com.xhh.creditcore.capital.util;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

/**
 * 类AverageCapitalUtils.java的实现描述：TODO 类实现描述
 * 
 * @author xiehuang 2018年1月16日 上午11:05:06
 */
public class AverageCapitalUtils extends RepayStyleCalc {

    /**
     * 本息 = 本金+利息
     * 
     * @param invest 总借款额（贷款本金）
     * @param yearRate 年利率
     * @param month 还款总月数
     * @return 每月偿还本金和利息
     */
    @Override
    public Map<Integer, BigDecimal> calcPerMonthCapitalInterest(double invest, double yearRate, int month) {
        Map<Integer, BigDecimal> mapCapitalAndInterest = new HashMap<>();
        Map<Integer, BigDecimal> mapCapital = getPerMonthCapital(invest, yearRate, month);
        Map<Integer, BigDecimal> mapInterest = getPerMonthInterest(invest, yearRate, month);
        for (Map.Entry<Integer, BigDecimal> entry : mapCapital.entrySet()) {
            mapCapitalAndInterest.put(entry.getKey(), entry.getValue().add(mapInterest.get(entry.getKey())));
        }
        return mapCapitalAndInterest;
    }

    /**
     * 等额本金计算获取还款方式为等额本金的每月偿还利息 公式：每月应还利息=剩余本金×月利率=(贷款本金-已归还本金累计额)×月利率
     * 
     * @param invest 总借款额（贷款本金）
     * @param yearRate 年利率
     * @param month 还款总月数
     * @return 每月偿还利息
     */
    @Override
    public Map<Integer, BigDecimal> calcPerMonthInterest(double invest, double yearRate, int month) {
        Map<Integer, BigDecimal> map = new HashMap<Integer, BigDecimal>();
        double monthPri = new BigDecimal(invest).divide(new BigDecimal(month), 2, BigDecimal.ROUND_DOWN).doubleValue();
        double monthRate = yearRate / 12;
        double totalInteger = 0.0;
        BigDecimal totalNoLastInteger = new BigDecimal(0);
        for (int i = 1; i <= month; i++) {
            double monthRes = (invest - monthPri * (i - 1)) * monthRate;
            totalInteger = totalInteger + monthRes;
            BigDecimal bMonthRes = new BigDecimal(monthRes).setScale(scale, round_down);
            if (i == month) {
                map.put(i, new BigDecimal(totalInteger).setScale(scale, round_default).subtract(totalNoLastInteger));
            } else {
                totalNoLastInteger.add(bMonthRes);
                map.put(i, bMonthRes);
            }
        }
        return map;
    }

    /**
     * 计算每个月应还本金
     */
    @Override
    public Map<Integer, BigDecimal> calcPerMonthCapital(double invest, double yearRate, int month) {
        BigDecimal perMonthCapital = new BigDecimal(invest).divide(new BigDecimal(month), 2, BigDecimal.ROUND_DOWN);
        Map<Integer, BigDecimal> mapCapital = new HashMap<>();
        for (int i = 1; i <= month - 1; i++) {
            mapCapital.put(i, perMonthCapital);
        }
        mapCapital.put(month, new BigDecimal(invest).subtract(perMonthCapital.multiply(new BigDecimal(month - 1))));
        return mapCapital;
    }
    
    @Override
    public void initData(double invest, double yearRate, int month) {
        setPerMonthInterest(calcPerMonthInterest(invest, yearRate, month));
        setPerMonthCapital(calcPerMonthCapital(invest, yearRate, month));
        setPerMonthCapitalInterest(calcPerMonthCapitalInterest(invest, yearRate, month));
    }

    /**
     * @param args
     */
    public static void main(String[] args) {
        double invest = 1000; // 本金  
        int month = 3;
        double yearRate = 0.15; // 年利率  
        AverageCapitalUtils utils = new AverageCapitalUtils();
        Map<Integer, BigDecimal> getPerMonthCapitalInterest = utils.getPerMonthCapitalInterest(invest, yearRate, month);
        System.out.println("等额本金---每月本息：" + getPerMonthCapitalInterest);
        Map<Integer, BigDecimal> mapInterest = utils.getPerMonthInterest(invest, yearRate, month);
        System.out.println("等额本金---每月利息:" + mapInterest);
        Map<Integer, BigDecimal> mapCapital = utils.getPerMonthCapital(invest, yearRate, month);
        System.out.println("等额本金---每月本金：" + mapCapital);
        System.out.println("等额本息---本息总和：" + utils.sumCapitalInterest(invest, yearRate, month));
        System.out.println("等额本息---利息总和：" + utils.sumInterest(invest, yearRate, month));
        System.out.println("等额本息---本金总和：" + utils.sumCapital(invest, yearRate, month));
    }

}
