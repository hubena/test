package com.xhh.creditcore.capital.service.payimpl.xianfeng;

import java.util.HashMap;
import java.util.Map;

import com.xhh.creditcore.capital.pay.MerchantInfo;

/**
 * 2017-12-29
 *
 * @author zhangweixin
 */
public class CertPayOrderQueryRequest extends BaseRequest {
    private Map<String, String> signData     = new HashMap<>();
    private Map<String, String> businessData = new HashMap<>();

    public CertPayOrderQueryRequest(MerchantInfo merchantInfo) {
        super("MOBILE_CERTPAY_QUERYORDERSTATUS", "4.0.0", merchantInfo);
        signData.put("merchantId", merchantInfo.getMerchantId());
    }

    /**
     * 支付订单号
     * 
     * @param outOrderId
     */
    public void setOutOrderId(String outOrderId) {
        businessData.put("outOrderId", outOrderId);
    }

    @Override
    public Map<String, String> getBusinessData() {
        return businessData;
    }

    @Override
    protected Map<String, String> getSubClassSignData() {
        return signData;
    }
}
