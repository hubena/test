package com.xhh.creditcore.capital.util;

import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Predicate;

/**
 * 如果集合不为空 执行给定的consumer zhangweixin 2018-02-01
 */
public class ListNotNullPredicate {

    public static <T> void forEach(List<T> lt, Consumer<T> consumer) {
        Predicate predicate = (Predicate<List<T>>) list -> {
            return Optional.ofNullable(list).map((it) -> !it.isEmpty()).orElse(false);
        };

        if (predicate.test(lt)) {
            lt.forEach(consumer);
        }
    }
}
