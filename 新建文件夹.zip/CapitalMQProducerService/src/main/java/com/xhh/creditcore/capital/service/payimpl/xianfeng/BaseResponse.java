package com.xhh.creditcore.capital.service.payimpl.xianfeng;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * 先锋支付基础响应类
 * 
 * @author zhangweixin
 */
public class BaseResponse implements OrderStatus {
    // 订单状态
    private String status;
    // 应答码
    private String resCode;
    // 应答消息
    private String resMessage;
    // 附加数据
    private String memo;
    // 商户号
    private String merchantId;

    public boolean isSuccess() {
        if ("00000".equals(resCode)) {
            return true;
        }
        return false;
    }

    public boolean isPending() {
        if ("00001".equals(resCode)) {
            return true;
        } else if ("00002".equals(resCode)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 订单是否交易成功
     *
     * @return
     */
    @Override
    public boolean isOrderSuccess() {
        return "S".equals(status);
    }

    /**
     * 订单是否交易失败
     *
     * @return
     */
    @Override
    public boolean isOrderFail() {
        return "F".equals(status);
    }

    /**
     * 订单是否在处理中
     *
     * @return
     */
    @Override
    public boolean isOrderPending() {
        if ("I".equals(status)) {
            return true;
        } else if (status == null) {
            return true;
        } else {
            return false;
        }
    }

    public String toJson() throws JsonProcessingException {
        return new ObjectMapper().writeValueAsString(this);
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getResCode() {
        return resCode;
    }

    public void setResCode(String resCode) {
        this.resCode = resCode;
    }

    public String getResMessage() {
        return resMessage;
    }

    public void setResMessage(String resMessage) {
        this.resMessage = resMessage;
    }

    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }

    public String getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(String merchantId) {
        this.merchantId = merchantId;
    }

}
