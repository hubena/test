package com.xhh.creditcore.capital.controller;

import javax.annotation.Resource;

import com.xhh.creditcore.capital.service.*;
import com.xhh.creditcore.capital.service.sendSms.RepaymentSendSmsService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.janty.core.dto.BaseResponse;
import com.janty.core.util.ResponseUtil;

/**
 * zhangweixin 2018-01-09 定时任务调度controller接口
 */

@RestController
@RequestMapping("/task")
public class TaskController {
    private static Logger           logger = LoggerFactory.getLogger(TaskController.class);
    @Resource
    private RepaymentService        repaymentService;
    @Resource
    private CapitalLoanTransService capitalLoanTransService;
    @Resource
    private RepayPlanService        repayPlanService;
    @Resource
    private FeeService              feeService;
    @Resource
    private RepaymentSendSmsService repaymentSendSmsService;
    @Resource
    private RepayTransService       repayTransService;
    @Resource
    private PayOrderService         payOrderService;
    @Resource
    private RepaymentSendInnerLetterService repaymentSendInnerLetterService;

    /**
     * 按期还款自动代扣调度接口
     */
    @RequestMapping("/repaymentByPeriod")
    public BaseResponse<Void> repaymentByPeriod(@RequestParam("params") String params) {
        logger.info("TaskController-repaymentByPeriod-请求开始,productCode:{}", params);
        BaseResponse<Void> response = ResponseUtil.createDefaultResponse();
        try {
            repaymentService.autoRepayment(params);
            ResponseUtil.success(response, null);
        } catch (Exception e) {
            logger.error("TaskController-repaymentByPeriod-异常", e);
            ResponseUtil.handleException(response, e);
        }
        logger.info("TaskController-repaymentByPeriod-请求结束,返回-{}", response);
        return response;
    }

    /**
     * 还款第三方订单查询
     */
    @RequestMapping("/queryRepayResult")
    public BaseResponse<Void> queryRepayResult() {
        logger.info("TaskController-queryRepayResult-请求开始");
        BaseResponse<Void> response = ResponseUtil.createDefaultResponse();
        try {
            repaymentService.processRepayingOrder();
            ResponseUtil.success(response, null);
        } catch (Exception e) {
            logger.error("TaskController-queryRepayResult-异常", e);
            ResponseUtil.handleException(response, e);
        }
        logger.info("TaskController-queryRepayResult-请求结束,返回-{}", response);
        return response;
    }

    /**
     * 放款支付结果查询
     *
     * @return
     */
    @RequestMapping("/queryLoanPayResult")
    public BaseResponse<Void> queryLoanPayResult() {
        logger.info("TaskController-queryLoanPayResult-请求开始");
        BaseResponse<Void> response = ResponseUtil.createDefaultResponse();
        try {
            capitalLoanTransService.queryLoanPayResult();
            ResponseUtil.success(response, null);
        } catch (Exception e) {
            logger.error("TaskController-queryLoanPayResult-异常", e);
            ResponseUtil.handleException(response, e);
        }
        logger.info("TaskController-queryLoanPayResult-请求结束,返回-{}", response);
        return response;
    }

    /**
     * 更新逾期状态job
     */
    @RequestMapping("/overdued")
    public BaseResponse<Void> overdued() {
        logger.info("TaskController-overdued-请求开始");
        BaseResponse<Void> response = ResponseUtil.createDefaultResponse();
        try {
            repayPlanService.overdued();
            ResponseUtil.success(response, null);
        } catch (Exception e) {
            logger.error("TaskController-overdued-请求异常", e);
            ResponseUtil.handleException(response, e);
        }
        logger.info("TaskController-overdued-请求结束,返回-{}", response);
        return response;
    }

    /**
     * 更新罚息金额job
     *
     * @return
     */
    @RequestMapping("/lastestPenalty")
    public BaseResponse<Void> lastestPenalty() {
        logger.info("TaskController-lastestPenalty-请求开始");
        BaseResponse<Void> response = ResponseUtil.createDefaultResponse();
        try {
            repayPlanService.lastestPenalty();
            ResponseUtil.success(response, null);
        } catch (Exception e) {
            logger.error("TaskController-lastestPenalty-请求异常", e);
            ResponseUtil.handleException(response, e);
        }
        logger.info("TaskController-lastestPenalty-请求结束,返回-{}", response);
        return response;
    }

    /**
     * 处理待支付服务费订单
     *
     * @return
     */
    @RequestMapping("/processWaittingPayFeeOrder")
    public BaseResponse<Void> processWaittingPayFeeOrder() {
        logger.info("TaskController-processWaittingPayFeeOrder-请求开始");
        BaseResponse<Void> response = ResponseUtil.createDefaultResponse();
        try {
            feeService.payFee();
            ResponseUtil.success(response, null);
        } catch (Exception e) {
            logger.error("TaskController-processWaittingPayFeeOrder-异常", e);
            ResponseUtil.handleException(response, e);
        }
        logger.info("TaskController-processWaittingPayFeeOrder-请求结束,返回-{}", response);
        return response;
    }

    /**
     * 代扣前3天提醒用户还款和代扣前1天提醒用户还款
     *
     * @return
     */
    @RequestMapping("/remindSendSmsBeforeThreeDayOrOneDay")
    public BaseResponse<Void> remindSendSmsRepaymentToUserBeforeThreeDayOrOneDay() {
        logger.info("TaskController-remindSendSmsBeforeThreeDay-请求开始");
        BaseResponse<Void> response = ResponseUtil.createDefaultResponse();
        try {
            repaymentSendSmsService.remindSendSmsRepaymentToUserBeforeThreeDayOrOneDay();
            ResponseUtil.success(response, null);
        } catch (Exception e) {
            logger.error("TaskController-remindSendSmsBeforeThreeDay-异常", e);
            ResponseUtil.handleException(response, e);
        }
        logger.info("TaskController-remindSendSmsBeforeThreeDay-请求结束,返回-{}", response);
        return response;
    }

    /**
     * 逾期1天、2天、3天、4天、5天上午10点推送逾期提醒消息
     *
     * @return
     */
    @RequestMapping("/remindSendSmsOverdueRepaymentToUser")
    public BaseResponse<Void> remindSendSmsOverdueRepaymentToUser() {
        logger.info("TaskController-remindSendSmsOverdueRepaymentToUser-请求开始");
        BaseResponse<Void> response = ResponseUtil.createDefaultResponse();
        try {
            repaymentSendSmsService.remindSendSmsOverdueRepaymentToUser();
            ResponseUtil.success(response, null);
        } catch (Exception e) {
            logger.error("TaskController-remindSendSmsOverdueRepaymentToUser-异常", e);
            ResponseUtil.handleException(response, e);
        }
        logger.info("TaskController-remindSendSmsOverdueRepaymentToUser-请求结束,返回-{}", response);
        return response;
    }

    /**
     * 删除逾期认证支付记录
     * 
     * @return
     */
    @RequestMapping("/removeOverDueRepayTrans")
    public BaseResponse<Void> removeOverDueRepayTrans() {
        logger.info("TaskController-removeOverDueRepayTrans-请求开始");
        BaseResponse<Void> response = ResponseUtil.createDefaultResponse();
        try {
            repayTransService.removeOverDueRepayTrans();
            ResponseUtil.success(response, null);
        } catch (Exception e) {
            logger.error("TaskController-removeOverDueRepayTrans-异常", e);
            ResponseUtil.handleException(response, e);
        }
        logger.info("TaskController-removeOverDueRepayTrans-请求结束,返回-{}", response);
        return response;
    }



    /**
     * 代扣前3天提醒用户还款和代扣前1天站内信发送
     *
     * @return
     */
    @RequestMapping("/remindSendInnerLetterBeforeThreeDayOrOneDay")
    public BaseResponse<Void> remindInnerLetterRepaymentToUserBeforeThreeDayOrOneDay() {
        logger.info("TaskController-remindInnerLetterRepaymentToUserBeforeThreeDayOrOneDay-请求开始");
        BaseResponse<Void> response = ResponseUtil.createDefaultResponse();
        try {
            repaymentSendInnerLetterService.remindsendInnerLetterRepaymentToUserBeforeThreeDayOrOneDay();
            ResponseUtil.success(response, null);
        } catch (Exception e) {
            logger.error("TaskController-remindInnerLetterRepaymentToUserBeforeThreeDayOrOneDay-异常", e);
            ResponseUtil.handleException(response, e);
        }
        logger.info("TaskController-remindSendInnerLetterBeforeThreeDayOrOneDay-请求结束,返回-{}", response);
        return response;
    }

    /**
     * 逾期1天、2天、3天、4天、5天上午10点推送逾期提醒消息
     *
     * @return
     */
    @RequestMapping("/remindsendInnerLetterOverdueRepaymentToUser")
    public BaseResponse<Void> remindsendInnerLetterOverdueRepaymentToUser() {
        logger.info("TaskController-remindsendInnerLetterOverdueRepaymentToUser-请求开始");
        BaseResponse<Void> response = ResponseUtil.createDefaultResponse();
        try {
            repaymentSendInnerLetterService.remindsendInnerLetterOverdueRepaymentToUser();
            ResponseUtil.success(response, null);
        } catch (Exception e) {
            logger.error("TaskController-remindsendInnerLetterOverdueRepaymentToUser-异常", e);
            ResponseUtil.handleException(response, e);
        }
        logger.info("TaskController-remindsendInnerLetterOverdueRepaymentToUser-请求结束,返回-{}", response);
        return response;
    }


    /**
     * 代付服务费订单结果查询
     *
     * @return
     */
    @RequestMapping("/payOrderResultQuery")
    public BaseResponse<Void> payOrderResultQuery() {
        logger.info("TaskController-payOrderResultQuery-请求开始");
        BaseResponse<Void> response = ResponseUtil.createDefaultResponse();
        try {
            payOrderService.queryPayOrderResult();
            ResponseUtil.success(response, null);
        } catch (Exception e) {
            logger.error("TaskController-payOrderResultQuery-异常", e);
            ResponseUtil.handleException(response, e);
        }
        logger.info("TaskController-payOrderResultQuery-请求结束,返回-{}", response);
        return response;
    }

}
