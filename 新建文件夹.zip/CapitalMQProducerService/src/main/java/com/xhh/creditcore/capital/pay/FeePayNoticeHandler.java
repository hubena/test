package com.xhh.creditcore.capital.pay;

import javax.annotation.Resource;

import com.xhh.creditcore.capital.constant.CapitalConstants;
import com.xhh.creditcore.capital.service.FeeService;
import com.xhh.creditcore.capital.service.RepaymentService;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import com.janty.cached.access.RedisCachedAccess;
import com.xhh.creditcore.capital.constant.CapitalRedisKey;
import com.xhh.creditcore.capital.enums.CapitalLoanTransStatus;
import com.xhh.creditcore.capital.model.CapitalLoanTrans;
import com.xhh.creditcore.capital.service.CapitalLoanTransService;

/**
 * 代付服务费结果通知
 *
 * @author zhangweixin 2018年1月18日 下午2:23:16
 */
@Component("feePayNoticeHandler")
public class FeePayNoticeHandler extends PayNoticeHandlerAdaptor {

    private static Logger     logger = LoggerFactory.getLogger(FeePayNoticeHandler.class);
    @Resource
    FeeService feeService;
    @Resource
    RedisCachedAccess<String> cachedAccess;

    /**
     * 代付成功处理
     */
    @Override
    public void paySuccessHandle(PayNoticeHandlerRequest handlerRequest) {
        try {
            cachedAccess.tryLock(CapitalRedisKey.LOCK_PREFIX + handlerRequest.getOrderNo(), 1000 * 30L);
            feeService.payFeeSucessHandle(handlerRequest);
        } finally {
            cachedAccess.releaseLock(CapitalRedisKey.LOCK_PREFIX + handlerRequest.getOrderNo());
        }
    }

    /**
     * 代付失败处理
     */
    @Override
    public void payFailHandle(PayNoticeHandlerRequest handlerRequest) {
        try {
            cachedAccess.tryLock(CapitalRedisKey.LOCK_PREFIX + handlerRequest.getOrderNo(), 1000 * 30L);
            feeService.payFeeFailHandle(handlerRequest);
        } finally {
            cachedAccess.releaseLock(CapitalRedisKey.LOCK_PREFIX + handlerRequest.getOrderNo());
        }
    }

    @Override
    public boolean isSupportOrderType(String orderNo) {
        return  orderNo.startsWith(CapitalConstants.capital_pay_fee_biz_code);
    }
}
