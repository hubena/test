package com.xhh.creditcore.capital.service;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.xhh.creditcore.capital.dao.OrderLogMapper;
import com.xhh.creditcore.capital.model.OrderLog;

/**
 * <p>
 * 订单日志表 服务实现类
 * </p>
 *
 * @author nathaniel123
 * @since 2018-01-09
 */
@Service("orderLogService")
public class OrderLogService {
    @Resource
    private OrderLogMapper orderLogMapper;

    /**
     * 根据id查询数据
     *
     * @param id 实体id
     * @return 实体
     */
    public OrderLog queryDataById(long id) {
        return null;
    }

    /**
     * 新增数据
     *
     * @param record 实体
     */
    public void addData(OrderLog record) {
        orderLogMapper.insert(record);
    }

    /**
     * 修改数据
     *
     * @param record 实体
     */
    public void modifyData(OrderLog record) {

    }

    /**
     * 删除数据
     *
     * @param record 实体
     */
    public void deleteData(OrderLog record) {

    }
}
