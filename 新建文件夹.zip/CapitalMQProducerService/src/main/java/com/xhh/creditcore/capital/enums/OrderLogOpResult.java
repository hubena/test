package com.xhh.creditcore.capital.enums;

/**
 * zhangweixin 2018-01-10
 */
public enum OrderLogOpResult {
    SYNC_SUCCESS("SYNC_SUCCESS", "同步成功"),
    FAIL("FAIL", "失败"),
    PENDING("PENDING", "处理中"),
    ASYNC_SUCCESS("ASYNC_SUCCESS", "异步成功"),
    EXCEPTION("EXCEPTION", "异常");
    private String key;
    private String desc;

    public String getKey() {
        return key;
    }

    public String getDesc() {
        return desc;
    }

    OrderLogOpResult(String key, String desc) {
        this.key = key;
        this.desc = desc;
    }

    public static OrderLogOpResult getInstance(String key) {
        for (OrderLogOpResult orderLogOpResult : OrderLogOpResult.values()) {
            if (orderLogOpResult.key.equals(key)) {
                return orderLogOpResult;
            }
        }
        return null;
    }
}
