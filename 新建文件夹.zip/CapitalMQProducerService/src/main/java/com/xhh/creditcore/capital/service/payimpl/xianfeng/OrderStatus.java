package com.xhh.creditcore.capital.service.payimpl.xianfeng;

public interface OrderStatus {

    boolean isOrderSuccess();

    boolean isOrderPending();

    boolean isOrderFail();
}
