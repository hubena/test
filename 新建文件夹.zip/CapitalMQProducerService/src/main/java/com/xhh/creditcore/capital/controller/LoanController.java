package com.xhh.creditcore.capital.controller;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.janty.core.controller.BaseController;
import com.janty.core.dto.BaseResponse;
import com.janty.core.util.ResponseUtil;
import com.xhh.creditcore.capital.api.CapitalApi;
import com.xhh.creditcore.capital.dto.CapitalLoanDto;
import com.xhh.creditcore.capital.dto.CapitalPayRequest;
import com.xhh.creditcore.capital.dto.CapitalPublicPayRequest;

@Controller
@RequestMapping("/loan")
public class LoanController extends BaseController {

    @Resource
    private CapitalApi capitalApi;

    /**
     * 直接代付
     * 
     * @param request
     * @return
     */
    @RequestMapping("/pay")
    @ResponseBody
    public BaseResponse<CapitalLoanDto> pay(CapitalPayRequest request) {
        logger.info("LoanController-loan-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);

        BaseResponse<CapitalLoanDto> response = ResponseUtil.createDefaultResponse();

        /*
         * try { request.setProductCode("100001");
         * request.setCapitalCode("CP100001");
         * request.setOuterLoanOrderNo(ObjectId.getId());
         * request.setAccountId(100000000000000000L);
         * request.setRepayPattern("4"); request.setTotalTerm(1);
         * request.setTermUnit(1); ValidateUtil.validate(request);
         * CapitalLoanDto capitalLoanDto = capitalApi.pay(request);
         * ResponseUtil.success(response, capitalLoanDto); } catch (Exception e)
         * { logger.error("LoanController-pay-请求异常, reqNo-{}-{}",
         * request.getReqNo(), ExceptionUtil.getType(e), e);
         * ResponseUtil.handleException(response, e); }
         */

        logger.info("LoanController-pay-请求结束, reqNo-{}-返回-{}", request.getReqNo(), response);
        return response;
    }

    /**
     * 直接对公代付
     *
     * @param request
     * @return
     */
    @RequestMapping("/public/pay")
    @ResponseBody
    public BaseResponse<CapitalLoanDto> payOfPublic(CapitalPublicPayRequest request) {
        logger.info("LoanController-payOfPublic-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);

        BaseResponse<CapitalLoanDto> response = ResponseUtil.createDefaultResponse();
        //        try {
        //            ValidateUtil.validate(request);
        //            CapitalLoanDto capitalLoanDto = capitalApi.payOfPublic(request);
        //            ResponseUtil.success(response, capitalLoanDto);
        //        } catch (Exception e) {
        //            logger.error("LoanController-payOfPublic-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e),
        //                    e);
        //            ResponseUtil.handleException(response, e);
        //        }

        logger.info("LoanController-payOfPublic-请求结束, reqNo-{}-返回-{}", request.getReqNo(), response);
        return response;
    }

}
