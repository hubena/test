package com.xhh.creditcore.capital.constant;

public interface RepaymentSmsConstants {
    //还款成功短信模板id
    Long repayment_success_sms_template = 4L;
    //还款失败短信模板id
    Long repayment_fail_sms_template = 5L;
    //还款提醒前3天短信模板id
    Long repayment_remind_before_three_day_sms_template = 6L;
    //还款提醒前1天短信模板id
    Long repayment_remind__before_one_day_sms_template = 7L;
    //逾期短信模板id
    Long overdue_sms_template = 8L;
    //还款金额
    String repay_amount = "Amtt";
    //还款银行卡号
    String account_card_no = "Pltno";
    //还款提醒日期
    String remind_date = "date";
    //时间间隔相差一天
    int one_day = 1;
    //实际格式 不含分秒
    String date_pattern = "yyyy-MM-dd";
    //第几期
    String term_no = "X";
    //总共几期
    String total_term = "Y";
    //本息
    String benxi = "Prin";
    //逾期罚息
    String due_penalty = "Penalty";
    //逾期天数
    String overdue_days = "Z";
    //还款失败
    String send_sms_repay_fail = "send_sms_repay_fail";
    //还款成功
    String send_sms_repay_success = "send_sms_repay_success";
    //还款提醒前3天短信
    String repayment_remind_before_three_day_send_sms = "repayment_remind_before_three_day_send_sms";
    //还款提醒前1天短信
    String repayment_remind_before_one_day_send_sms = "repayment_remind_before_one_day_send_sms";
    //逾期短信提醒
    String send_sms_overdue = "send_sms_overdue";


}
