package com.xhh.creditcore.capital.dao;

import com.xhh.creditcore.capital.model.ExcepitonOrder;
import org.springframework.stereotype.Repository;

/**
 * <p>
 * 异常订单表 Mapper 接口
 * </p>
 *
 * @author nathaniel123
 * @since 2018-01-09
 */
@Repository
public interface ExcepitonOrderMapper {
    int insert(ExcepitonOrder excepitonOrder);
}
