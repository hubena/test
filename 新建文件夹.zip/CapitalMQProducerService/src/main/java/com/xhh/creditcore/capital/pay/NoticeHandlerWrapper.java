package com.xhh.creditcore.capital.pay;

/**
 * zhangweixin 2018-03-02
 */
public interface NoticeHandlerWrapper {
    /**
     * 处理成功通知
     * 
     * @param handlerRequest
     */
    void noticeForSuccess(PayNoticeHandlerRequest handlerRequest);

    /**
     * 处理失败通知
     * 
     * @param handlerRequest
     */
    void noticeForFail(PayNoticeHandlerRequest handlerRequest);

}
