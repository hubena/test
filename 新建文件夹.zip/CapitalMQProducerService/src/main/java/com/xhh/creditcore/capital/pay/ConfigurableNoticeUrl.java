package com.xhh.creditcore.capital.pay;

/**
 * zhangweixin
 */
public interface ConfigurableNoticeUrl {
    String getRawNoticeUrl();

    void setNewNoticeUrl(String newUrl);
}
