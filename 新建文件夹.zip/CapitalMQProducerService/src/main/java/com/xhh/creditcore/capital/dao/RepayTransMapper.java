package com.xhh.creditcore.capital.dao;

import com.xhh.creditcore.capital.bean.TransRecordCondition;
import com.xhh.creditcore.capital.model.RepayTrans;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * <p>
 * 资金平台还款交易表 Mapper 接口
 * </p>
 *
 * @author nathaniel123
 * @since 2018-01-09
 */
@Repository
public interface RepayTransMapper {

    int insert(RepayTrans repayTrans);

    RepayTrans selectById(@Param("id") Long id);

    List<RepayTrans> selectByCondition(RepayTrans repayTrans);

    int deleteById(@Param("id") Long id);

    int deleteByConditon(RepayTrans repayTrans);

    int updateNoNullColumnById(RepayTrans repayTrans);

    int updateAllColumnById(RepayTrans repayTrans);

    /**
     * 更新数据
     *
     * @param repayTrans
     * @return
     */
    int updateDataForDeductNotice(RepayTrans repayTrans);

    int updateStatusByIdForSyncReturn(RepayTrans repayTrans);

    List<RepayTrans> queryRepayStateOrder();

    /**
     * 分页查询入账数据
     *
     * @param params
     * @param rowBounds
     * @return
     */
    List<RepayTrans> queryRepayTransRecordByPage(@Param("params") TransRecordCondition params, RowBounds rowBounds);

    /**
     * 查询当日代扣还款记录
     * @return
     */
    List<RepayTrans> queryRepaymentoNToday();


    List<RepayTrans> selectOverdueRepayTrans();


    int updateRetransRecordStatusById(RepayTrans repayTrans);

}
