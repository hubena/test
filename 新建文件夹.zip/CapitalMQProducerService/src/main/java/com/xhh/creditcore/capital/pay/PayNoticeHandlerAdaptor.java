package com.xhh.creditcore.capital.pay;

/**
 * zhangweixin 2018-01-18
 */
public class PayNoticeHandlerAdaptor implements PayNoticeHandler {
    @Override
    public void deductSuccessHandle(PayNoticeHandlerRequest handlerRequest) {

    }

    @Override
    public void deductFailHandle(PayNoticeHandlerRequest handlerRequest) {

    }

    @Override
    public void paySuccessHandle(PayNoticeHandlerRequest handlerRequest) {

    }

    @Override
    public void payFailHandle(PayNoticeHandlerRequest handlerRequest) {

    }

    @Override
    public boolean isSupportOrderType(String orderNo) {
        return false;
    }

    @Override
    public void certPayFailHandle(PayNoticeHandlerRequest handlerRequest) {

    }

    @Override
    public void certPaySuccessHandle(PayNoticeHandlerRequest handlerRequest) {

    }
}
