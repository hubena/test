package com.xhh.creditcore.capital.constant;

/**
 * redis key定义
 */
public interface CapitalRedisKey {
    String LOCK_PREFIX        = "CAPITAL_LOCK_";
    String CERT_PAY_PREPAY    = "CERT_PAY_PREPAY";
    String fee_charge_pattern = "fee_charge_pattern";
}
