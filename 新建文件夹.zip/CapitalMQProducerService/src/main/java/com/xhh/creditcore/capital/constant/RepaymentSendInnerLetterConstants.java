package com.xhh.creditcore.capital.constant;

public interface RepaymentSendInnerLetterConstants {
    //第几期
    String term_no = "X";
    //总共几期
    String total_term = "Y";
    //还款金额
    String repay_amount = "Amtt";
    //还款银行卡号
    String account_card_no = "Pltno";
    //还款提醒日期
    String remind_date = "date";
    //时间间隔相差一天
    int one_day = 1;
    //实际格式 不含分秒
    String date_pattern = "yyyy-MM-dd";
    //本息
    String benxi = "Prin";
    //逾期罚息
    String due_penalty = "Penalty";
    //逾期天数
    String overdue_days = "Z";

}
