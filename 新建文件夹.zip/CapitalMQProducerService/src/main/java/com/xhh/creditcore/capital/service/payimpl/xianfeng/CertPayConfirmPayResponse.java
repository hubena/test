package com.xhh.creditcore.capital.service.payimpl.xianfeng;

/**
 * 先锋支付认证支付确认支付响应
 * 
 * @author zhangweixin
 */
public class CertPayConfirmPayResponse extends CertPayBaseResponse implements  OrderStatus{

    private String orderStatus;

    private String outOrderId;

    @Override
    public boolean isOrderSuccess() {
        if ("S".equals(orderStatus)) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public boolean isOrderPending() {
        if ("I".equals(orderStatus)) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public boolean isOrderFail() {
        if ("F".equals(orderStatus)) {
            return true;
        } else {
            return false;
        }
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public String getOutOrderId() {
        return outOrderId;
    }

    public void setOutOrderId(String outOrderId) {
        this.outOrderId = outOrderId;
    }
}
