package com.xhh.creditcore.capital.service;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.springframework.stereotype.Service;

@Service("cashLoanRepayDateService")
public class CashLoanRepayDateService implements IRepayDateService {

    public static final String format_date = "yyyy-MM-dd HH:mm:ss";

    @Override
    public Date getMonthAfter(Date date, int monthNum) {
        Date result = null;
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH);
        int day = c.get(Calendar.DAY_OF_MONTH);

        //最大天数
        int maxDay = getMaxDayOfMonth(date);

        c.set(Calendar.DAY_OF_MONTH, 1);
        c.set(Calendar.MONTH, month + monthNum);
        int newMonth = c.get(Calendar.MONTH);
        int newMaxDay = getMaxDayOfMonth(c.getTime());
        int newDay = getMyDay(day, maxDay, newMaxDay);
        int newYear = year + (month + monthNum) / 12;

        c.set(Calendar.YEAR, newYear);
        c.set(Calendar.MONTH, newMonth);
        c.set(Calendar.DAY_OF_MONTH, newDay);
        result = c.getTime();
        return result;
    }

    private int getMyDay(int day, int maxDay, int newMaxDay) {
        if (day <= 28) {
            return day;
        }
        if (day >= newMaxDay) {
            return newMaxDay;
        }
        return day;
    }

    public String dateToString(Date date) {
        SimpleDateFormat simFormat = new SimpleDateFormat(format_date);
        return simFormat.format(date);
    }

    public int getMaxDayOfMonth(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.set(Calendar.DATE, 1);
        cal.roll(Calendar.DATE, -1);
        return cal.get(Calendar.DATE);
    }

    public static void main(String[] args) {
        SimpleDateFormat simFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        CashLoanRepayDateService service = new CashLoanRepayDateService();
        Date date;
        for (int d = 28; d <= 31; d++) {
            try {
                String loanDate = "2020-01-" + d + " 22:45:56";
                System.out.println("借款日：" + loanDate);
                date = simFormat.parse(loanDate);
                for (int i = 1; i < 40; i++) {
                    System.out.println("第" + i + "期:" + service.dateToString(service.getMonthAfter(date, i)));
                }
            } catch (Exception e) {
            }
            System.out.println();
        }
    }
}
