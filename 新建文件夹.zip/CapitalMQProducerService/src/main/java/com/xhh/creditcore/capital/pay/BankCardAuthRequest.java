package com.xhh.creditcore.capital.pay;

import java.util.Map;

/**
 * 银行卡鉴权请求 zhangweixin 2018-01-12
 */
public class BankCardAuthRequest {
    //账户姓名
    private String              accountName;
    //银行卡号
    private String              bankCardNo;
    //手机号
    private String              mobile;
    //身份证号
    private String              cardNo;
    //不同鉴权实现需要的额外非公共数据
    private Map<String, String> extendData;
    //产品编码
    private String              productCode;

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public String getBankCardNo() {
        return bankCardNo;
    }

    public void setBankCardNo(String bankCardNo) {
        this.bankCardNo = bankCardNo;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getCardNo() {
        return cardNo;
    }

    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    public Map<String, String> getExtendData() {
        return extendData;
    }

    public void setExtendData(Map<String, String> extendData) {
        this.extendData = extendData;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }
}
