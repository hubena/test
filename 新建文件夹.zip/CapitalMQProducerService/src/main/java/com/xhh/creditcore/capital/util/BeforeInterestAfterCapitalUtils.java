package com.xhh.creditcore.capital.util;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

/**
 * 类BeforeInterestAfterCapitalUtils.java的实现描述：先息后本
 * 
 * @author xiehuang 2018年1月16日 上午10:41:09
 */
public class BeforeInterestAfterCapitalUtils extends RepayStyleCalc {

    /**
     * 本息 = 本金 + 利息
     */
    @Override
    public Map<Integer, BigDecimal> calcPerMonthCapitalInterest(double invest, double yearRate, int month) {
        Map<Integer, BigDecimal> mapCapitalAndInterest = new HashMap<>();
        Map<Integer, BigDecimal> mapCapital = getPerMonthCapital(invest, yearRate, month);
        Map<Integer, BigDecimal> mapInterest = getPerMonthInterest(invest, yearRate, month);
        for (Map.Entry<Integer, BigDecimal> entry : mapCapital.entrySet()) {
            mapCapitalAndInterest.put(entry.getKey(), entry.getValue().add(mapInterest.get(entry.getKey())));
        }
        return mapCapitalAndInterest;
    }

    /**
     * 利息 = 本金*年利率/12
     * 
     * @param invest 总借款额（贷款本金）
     * @param yearRate 年利率
     * @param month 还款总月数
     * @return 每月偿还利息
     */
    @Override
    public Map<Integer, BigDecimal> calcPerMonthInterest(double invest, double yearRate, int month) {
        double monthRate = yearRate / 12;
        Map<Integer, BigDecimal> map = new HashMap<>();
        BigDecimal monthTotalInterest = new BigDecimal(invest).multiply(new BigDecimal(monthRate * month)).setScale(scale, round_default);
        BigDecimal monthPerInterest = new BigDecimal(invest).multiply(new BigDecimal(monthRate)).setScale(scale, round_down);
        BigDecimal lastMonthInterest = monthTotalInterest.subtract(monthPerInterest.multiply(new BigDecimal(month - 1)));
        BigDecimal correctInterest = perciousInterest(monthPerInterest, lastMonthInterest, month);
        for (int i = 1; i <= month; i++) {
            if (i == month) {
                map.put(i, lastMonthInterest.subtract(correctInterest.multiply(new BigDecimal(month - 1))));
            } else {
                map.put(i, monthPerInterest.add(correctInterest));
            }
        }
        return map;
    }

    private BigDecimal perciousInterest(BigDecimal monthPerInterest, BigDecimal lastMonthInterest, int month) {
        BigDecimal result = new BigDecimal(0);
        BigDecimal correctValue = lastMonthInterest.subtract(monthPerInterest).divide(new BigDecimal(month));
        if(correctValue.multiply(new BigDecimal(Math.pow(10, scale))).compareTo(new BigDecimal(1)) == 0) {
            result = correctValue;
        }
        return result;
    }

    /**
     * 每月偿还本金
     * 
     * @param invest 总借款额（贷款本金）
     * @param yearRate 年利率
     * @param month 还款总月数
     * @return 每月偿还本金
     */
    @Override
    public Map<Integer, BigDecimal> calcPerMonthCapital(double invest, double yearRate, int month) {
        Map<Integer, BigDecimal> map = new HashMap<>();
        for (int i = 1; i <= month; i++) {
            map.put(i, new BigDecimal(0));
        }
        map.put(month, new BigDecimal(invest));
        return map;
    }
    
    @Override
    public void initData(double invest, double yearRate, int month) {
        setPerMonthCapital(calcPerMonthCapital(invest, yearRate, month));
        setPerMonthInterest(calcPerMonthInterest(invest, yearRate, month));
        setPerMonthCapitalInterest(calcPerMonthCapitalInterest(invest, yearRate, month));
    }

    /**
     * @param args
     */
    public static void main(String[] args) {
        double invest = 3000; // 本金  
        int month = 3;
        double yearRate = 0.1392; // 年利率  
        BeforeInterestAfterCapitalUtils util = new BeforeInterestAfterCapitalUtils();
        Map<Integer, BigDecimal> mapCapitalInterest = util.getPerMonthCapitalInterest(invest, yearRate, month);
        System.out.println("先息后本---每月本息：" + mapCapitalInterest);
        Map<Integer, BigDecimal> mapInterest = util.getPerMonthInterest(invest, yearRate, month);
        System.out.println("先息后本---每月利息：" + mapInterest);
        Map<Integer, BigDecimal> mapCapital = util.getPerMonthCapital(invest, yearRate, month);
        System.out.println("先息后本---每月本金：" + mapCapital);
        System.out.println("先息后本---本息总和：" + util.sumCapitalInterest(invest, yearRate, month));
        System.out.println("先息后本---利息总和：" + util.sumInterest(invest, yearRate, month));
        System.out.println("先息后本---本金总和：" + util.sumCapital(invest, yearRate, month));
    }

}
