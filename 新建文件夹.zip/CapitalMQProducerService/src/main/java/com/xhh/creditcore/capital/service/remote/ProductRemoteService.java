package com.xhh.creditcore.capital.service.remote;

import com.janty.core.dto.StringRequest;
import com.janty.core.util.BaseRemoteService;
import com.xhh.creditcore.capital.constant.CapitalErrorCode;
import com.xhh.creditcore.product.api.IProductApi;
import com.xhh.creditcore.product.dto.ProductDto;
import com.xhh.creditcore.product.dto.ProductFeeDto;
import com.xhh.creditcore.product.dto.ProductFeeFixAmountRequest;
import com.xhh.creditcore.transaction.constant.TransactionErrorCode;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author feng
 */
@Service("productRemoteService")
public class ProductRemoteService extends BaseRemoteService {
    @Resource
    private IProductApi productApi;


    public Map<String, String> getProductByCode(String productCode) {

        try {
            StringRequest stringRequest = new StringRequest();
            stringRequest.setParam(productCode);
            return productApi.queryByConfigsProductCode(stringRequest);

        } catch (Exception e) {
            return processException(e, new CapitalErrorCode(CapitalErrorCode.Element.r_product_remote_fail));

        }
    }

    /**
     * 通过产品编码获取产品
     * 
     * @param
     * @return
     */
    public ProductDto getProductByCode(StringRequest request) {
        try {
            return productApi.getProductByCode(request);

        } catch (Exception e) {
            return processException(e, new TransactionErrorCode(TransactionErrorCode.Element.r_product_remote_fail));

        }
    }

    /**
     * 根据产品编码查询产品所有配置
     * 
     * @param productCode
     * @return
     */
    public Map<String, String> queryByConfigsProductCode(String reqNo, String productCode) {
        try {
            StringRequest productRequest = new StringRequest();
            productRequest.setParam(productCode);
            productRequest.setReqNo(reqNo);
            Map<String, String> map = productApi.queryByConfigsProductCode(productRequest);
            if (map == null) {
                map = new HashMap<String, String>();
            }
            return map;

        } catch (Exception e) {
            return processException(e, new TransactionErrorCode(TransactionErrorCode.Element.r_product_remote_fail));

        }
    }

    public BigDecimal queryInterestRate(ProductFeeFixAmountRequest request) {
        try {
            return productApi.queryInterestRate(request);

        } catch (Exception e) {
            return processException(e, new CapitalErrorCode(CapitalErrorCode.Element.r_product_remote_fail));

        }
    }

    public List<ProductFeeDto> queryRateNoInterestRate(ProductFeeFixAmountRequest request) {
        try {
            return productApi.queryRateNoInterestRate(request);

        } catch (Exception e) {
            return processException(e, new CapitalErrorCode(CapitalErrorCode.Element.r_product_remote_fail));

        }
    }

}
