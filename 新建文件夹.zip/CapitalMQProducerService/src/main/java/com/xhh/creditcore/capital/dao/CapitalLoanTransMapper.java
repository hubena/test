package com.xhh.creditcore.capital.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;
import org.springframework.stereotype.Repository;

import com.xhh.creditcore.capital.bean.TransRecordCondition;
import com.xhh.creditcore.capital.model.CapitalLoanTrans;

@Repository
public interface CapitalLoanTransMapper {
    int deleteByPrimaryKey(Long id);

    int insert(CapitalLoanTrans record);

    int insertSelective(CapitalLoanTrans record);

    CapitalLoanTrans selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(CapitalLoanTrans record);

    int updateByPrimaryKey(CapitalLoanTrans record);

    int updateDataForDeductSuccessNotice(CapitalLoanTrans capitalLoanTrans);

    List<CapitalLoanTrans> queryAccountOverdueOrder(CapitalLoanTrans capitalLoanTrans);

    List<CapitalLoanTrans> queryAccountProcessingOrder(CapitalLoanTrans capitalLoanTrans);

    void updateToOverdueByNo(CapitalLoanTrans loan);

    List<CapitalLoanTrans> selectByCondition(CapitalLoanTrans capitalLoanTrans);

    CapitalLoanTrans selectByCapitalNo(@Param("capitalLoanTransNo") String capitalLoanTransNo);

    /**
     * 分页查询出账记录
     *
     * @param params
     * @param rowBounds
     * @return
     */
    List<CapitalLoanTrans> queryPayTransRecordByPage(@Param("params") TransRecordCondition params, RowBounds rowBounds);

    List<CapitalLoanTrans> selectByStatus(@Param("status") Integer status);

    int updateStatus(@Param("status") Integer status, @Param("capitalLoanTransNo") String capitalLoanTransNo);

    int loanSuccess(@Param("payNo") String payNo, @Param("capitalLoanTransNo") String capitalLoanTransNo);

    int loanFail(@Param("payNo") String payNo, @Param("payResult") String payResult, @Param("capitalLoanTransNo") String capitalLoanTransNo);
}
