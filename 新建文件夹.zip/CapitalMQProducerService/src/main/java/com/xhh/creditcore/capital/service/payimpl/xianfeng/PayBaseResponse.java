package com.xhh.creditcore.capital.service.payimpl.xianfeng;

/**
 * 先锋单笔代收/代付相关响应类
 *
 * @author zhangweixin
 */
public class PayBaseResponse extends BaseResponse {
    private String tradeNo;
    private String merchantNo;

    public String getTradeNo() {
        return tradeNo;
    }

    public void setTradeNo(String tradeNo) {
        this.tradeNo = tradeNo;
    }

    public String getMerchantNo() {
        return merchantNo;
    }

    public void setMerchantNo(String merchantNo) {
        this.merchantNo = merchantNo;
    }
}
