package com.xhh.creditcore.capital.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.janty.cached.access.RedisCachedAccess;
import com.janty.core.exception.SystemException;
import com.janty.core.util.DateUtil;
import com.janty.core.util.DecimalUtil;
import com.xhh.creditcore.capital.constant.CapitalConstants;
import com.xhh.creditcore.capital.constant.CapitalErrorCode;
import com.xhh.creditcore.capital.dto.CapitalLoanOrderFeeDto;
import com.xhh.creditcore.capital.dto.CapitalLoanRequest;
import com.xhh.creditcore.capital.dto.LoanTrialDto;
import com.xhh.creditcore.capital.dto.RepayPlanDto;
import com.xhh.creditcore.capital.enums.RepayPattern;
import com.xhh.creditcore.capital.service.remote.ProductRemoteService;
import com.xhh.creditcore.capital.util.AverageCapitalPlusInterestUtils;
import com.xhh.creditcore.capital.util.AverageCapitalUtils;
import com.xhh.creditcore.capital.util.BeforeInterestAfterCapitalUtils;
import com.xhh.creditcore.capital.util.RepayStyleCalc;
import com.xhh.creditcore.capital.util.StagesRepayUtils;
import com.xhh.creditcore.product.constant.ProductConfigKey;
import com.xhh.creditcore.product.dto.ProductFeeDto;
import com.xhh.creditcore.product.dto.ProductFeeFixAmountRequest;
import com.xhh.creditcore.product.enums.FeeChargePattern;
import com.xhh.creditcore.product.enums.IsDeleted;
import com.xhh.creditcore.product.enums.TermUnit;

/**
 * LoanTrial服务类
 *
 * @author xiehuang
 * @date 2018-1-12 11:18:04
 */
@Service("loanTrialService")
public class LoanTrialService {

    @Resource
    private ProductRemoteService      productRemoteService;

    @Resource
    @Qualifier("cashLoanRepayDateService")
    private IRepayDateService         repayDateService;

    @Resource
    private RedisCachedAccess<String> redisCachedAccess;

    /**
     * 借款试算
     * 
     * @param request
     */
    public LoanTrialDto calcLoan(CapitalLoanRequest request) {
        LoanTrialDto result = new LoanTrialDto();
        Date now = new Date();

        //利率
        calcInterestRate(result, request);
        //服务费以及费用详情
        calcLoanOrderFee(result, request);
        //计算实际放款，tempFee
        calcAbountChargePattern(result, request);
        //利息总计以及还款详情
        calcRepayPlan(result, request, now);
        //计算应还总额
        result.setRepayTotalAmount(DecimalUtil.add(result.getActualLoanAmount(), result.getInterestAmount(), result.getFeeAmount()));
        return result;
    }

    /**
     * 计算实际发放金额，tempFee
     * 
     * @param result
     * @param request
     */
    private void calcAbountChargePattern(LoanTrialDto result, CapitalLoanRequest request) {
        Map<String, String> map = productRemoteService.getProductByCode(request.getProductCode());
        String pattern = map.get(ProductConfigKey.loan_fee_charge_pattern);
        FeeChargePattern feeChargePattern = FeeChargePattern.getByKey(pattern);
        if (feeChargePattern == null) {
            throw new SystemException("无效费用收取模式");
        }
        if (feeChargePattern == FeeChargePattern.cut) {
            result.setActualLoanAmount(DecimalUtil.subtract(request.getLoanAmount(), result.getFeeAmount()));
            result.setTempFee(DecimalUtil.ZERO);
        } else if (feeChargePattern == FeeChargePattern.installment) {
            result.setActualLoanAmount(request.getLoanAmount());
            calcDueFee(result, request);
        }
    }

    private void calcDueFee(LoanTrialDto result, CapitalLoanRequest request) {
        if (request.getTermUnit() == TermUnit.day.getKey()) {
            result.setTempFee(result.getFeeAmount());
        } else if (request.getTermUnit() == TermUnit.month.getKey()) {
            if(request.getTotalTerm().intValue() == 0) {
                throw new SystemException("无效的借款时间");
            }
            result.setTempFee(result.getFeeAmount().divide(new BigDecimal(request.getTotalTerm()), CapitalConstants.scale, RoundingMode.DOWN));
        } else {
            throw new SystemException("无效的借款时间单位");
        }
    }

    /**
     * 利息总计以及还款详情
     * 
     * @param result
     * @param request
     * @param now
     */
    private void calcRepayPlan(LoanTrialDto result, CapitalLoanRequest request, Date now) {

        if (request.getTermUnit() == TermUnit.day.getKey()) {
            setOneTermReplan(result, request, now, CapitalConstants.year_day);
        } else if (request.getTermUnit() == TermUnit.month.getKey()) {
            RepayPattern repayPattern = RepayPattern.getByKey(request.getRepayPattern());
            if (RepayPattern.capital_clearing_with_interests == repayPattern) {
                //利随本清
                setOneTermReplan(result, request, now, CapitalConstants.year_month);
            } else {
                RepayStyleCalc repayStyleCalc = null;
                if (RepayPattern.average_capital_plus_interest == repayPattern) {
                    //等额本息
                    repayStyleCalc = new AverageCapitalPlusInterestUtils();
                } else if (RepayPattern.average_capital == repayPattern) {
                    //等额本金
                    repayStyleCalc = new AverageCapitalUtils();
                } else if (RepayPattern.before_interest_after_capital == repayPattern) {
                    //先息后本
                    repayStyleCalc = new BeforeInterestAfterCapitalUtils();
                } else if (RepayPattern.stages_repay == repayPattern) {
                    //分期还款
                    repayStyleCalc = new StagesRepayUtils();
                }
                setRepayPlanAndDueInterest(result, request, repayStyleCalc, now);
            }
        } else {
            throw new SystemException("无效的借款单位");
        }
    }

    private void setRepayPlanAndDueInterest(LoanTrialDto result, CapitalLoanRequest request, RepayStyleCalc repayStyleCalc, Date now) {

        BigDecimal interestAmount = DecimalUtil.ZERO;
        List<RepayPlanDto> repayPlanDtoList = new ArrayList<>();

        double invest = request.getLoanAmount().doubleValue();
        double yearRate = result.getInterestRate().doubleValue();
        int month = request.getTotalTerm().intValue();
        Map<Integer, BigDecimal> perMonthCapital = repayStyleCalc.getPerMonthCapital(invest, yearRate, month);
        Map<Integer, BigDecimal> perMonthInterest = repayStyleCalc.getPerMonthInterest(invest, yearRate, month);

        RepayPlanDto repayPlanDto = null;
        for (Map.Entry<Integer, BigDecimal> entry : perMonthCapital.entrySet()) {
            repayPlanDto = new RepayPlanDto();
            BigDecimal duePrincipal = entry.getValue();
            Integer termNo = entry.getKey();
            BigDecimal dueInterest = perMonthInterest.get(termNo);
            Date repayDate = repayDateService.getMonthAfter(now, termNo);

            repayPlanDto.setDuePrincipal(duePrincipal);
            repayPlanDto.setTermNo(termNo);
            repayPlanDto.setDueInterest(dueInterest);
            repayPlanDto.setAgreedRepayDate(repayDate);
            repayPlanDto.setDueFee(result.getTempFee());

            repayPlanDtoList.add(repayPlanDto);
            interestAmount = DecimalUtil.add(interestAmount, dueInterest);
        }
        if(!DecimalUtil.eq(result.getTempFee(), DecimalUtil.ZERO)) {
            BigDecimal lastTermDueFee = DecimalUtil.subtract(result.getFeeAmount(),
                    DecimalUtil.multiply(result.getTempFee(), new BigDecimal(repayPlanDtoList.size() - 1)));
            repayPlanDto = repayPlanDtoList.get(repayPlanDtoList.size() - 1);
            repayPlanDto.setDueFee(lastTermDueFee);
            repayPlanDtoList.remove(repayPlanDtoList.size() - 1);
            repayPlanDtoList.add(repayPlanDto);
        }

        result.setInterestAmount(interestAmount);
        result.setRepayPlanDtoList(repayPlanDtoList);
    }

    private void setOneTermReplan(LoanTrialDto result, CapitalLoanRequest request, Date now, int yearUnitTotal) {
        BigDecimal interestAmount = DecimalUtil.ZERO;
        List<RepayPlanDto> repayPlanAddList = new ArrayList<>();

        RepayPlanDto repayPlanDto = new RepayPlanDto();
        Date repayDate = (yearUnitTotal == CapitalConstants.year_day) ? DateUtil.getDateAfter(now, request.getTotalTerm())
                : repayDateService.getMonthAfter(now, request.getTotalTerm());
        repayPlanDto.setAgreedRepayDate(repayDate);
        repayPlanDto.setDuePrincipal(request.getLoanAmount());
        BigDecimal dueInterest = DecimalUtil
                .divide(DecimalUtil.multiply(new BigDecimal(request.getTotalTerm()), request.getLoanAmount(), result.getInterestRate()),
                        new BigDecimal(yearUnitTotal), 2)
                .setScale(CapitalConstants.scale, CapitalConstants.round);
        repayPlanDto.setDueInterest(dueInterest);
        repayPlanDto.setTermNo(CapitalConstants.one_term);
        if (result.getTempFee() != DecimalUtil.ZERO) {
            repayPlanDto.setDueFee(result.getFeeAmount());
        } else {
            repayPlanDto.setDueFee(DecimalUtil.ZERO);
        }
        repayPlanAddList.add(repayPlanDto);
        interestAmount = dueInterest;

        result.setInterestAmount(interestAmount);
        result.setRepayPlanDtoList(repayPlanAddList);
    }

    /**
     * 服务费以及费用详情
     * 
     * @param result
     * @param request
     */
    private void calcLoanOrderFee(LoanTrialDto result, CapitalLoanRequest request) {
        ProductFeeFixAmountRequest productFeeRequest = new ProductFeeFixAmountRequest();
        productFeeRequest.setProductCode(request.getProductCode());
        productFeeRequest.setTotalTerm(request.getTotalTerm());
        productFeeRequest.setTermUnit(request.getTermUnit());
        productFeeRequest.setIsDeleted(IsDeleted.not_deleted.getKey());
        productFeeRequest.setAmount(request.getLoanAmount().toString());
        List<ProductFeeDto> list = productRemoteService.queryRateNoInterestRate(productFeeRequest);
        List<CapitalLoanOrderFeeDto> feeList = new ArrayList<>();
        BigDecimal feeAmount = DecimalUtil.ZERO;

        ProductFeeDto productFeeDto = null;
        CapitalLoanOrderFeeDto feeDto = null;
        for (int i = 0; i < list.size(); i++) {
            productFeeDto = list.get(i);
            feeDto = new CapitalLoanOrderFeeDto();
            feeDto.setFeeName(productFeeDto.getFeeName());
            feeDto.setFeeCode(productFeeDto.getFeeCode());
            feeDto.setFeeAmount(DecimalUtil.multiply(request.getLoanAmount(), productFeeDto.getFeeRate()));
            feeAmount = DecimalUtil.add(feeAmount, feeDto.getFeeAmount());
            feeList.add(feeDto);
        }
        result.setFeeAmount(feeAmount);
        result.setLoanOrderFeeList(feeList);
    }

    /**
     * 利率
     * 
     * @param result
     * @param request
     */
    private void calcInterestRate(LoanTrialDto result, CapitalLoanRequest request) {
        ProductFeeFixAmountRequest productFeeRequest = new ProductFeeFixAmountRequest();
        productFeeRequest.setProductCode(request.getProductCode());
        productFeeRequest.setTotalTerm(request.getTotalTerm());
        productFeeRequest.setTermUnit(request.getTermUnit());
        productFeeRequest.setIsDeleted(IsDeleted.not_deleted.getKey());
        productFeeRequest.setAmount(request.getLoanAmount().toString());
        BigDecimal interestRate = productRemoteService.queryInterestRate(productFeeRequest);
        if (interestRate == null || DecimalUtil.eq(interestRate, DecimalUtil.ZERO)) {
            throw new SystemException(CapitalErrorCode.Element.s_loan_interest_rate_exception.getMessage());
        }
        result.setInterestRate(interestRate);
    }

}
