package com.xhh.creditcore.capital.enums;

/**
 * zhangweixin 2018-01-10
 */
public enum PayOrderObjectType {
    PERSIONAL(1, "个人"),
    COMPANY(2, "公司");
    private Integer key;
    private String  desc;

    public Integer getKey() {
        return key;
    }

    public String getDesc() {
        return desc;
    }

    PayOrderObjectType(Integer key, String desc) {
        this.key = key;
        this.desc = desc;
    }

    public static PayOrderObjectType getInstance(Integer key) {
        for (PayOrderObjectType payType : PayOrderObjectType.values()) {
            if (payType.key.equals(key)) {
                return payType;
            }
        }
        return null;
    }
}
