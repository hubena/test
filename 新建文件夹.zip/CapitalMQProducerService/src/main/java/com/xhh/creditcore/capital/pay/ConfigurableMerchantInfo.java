package com.xhh.creditcore.capital.pay;

import com.xhh.creditcore.capital.enums.PayMerchantType;

/**
 * zhangweixin 2018-01-19
 */
public interface ConfigurableMerchantInfo {
    /**
     * 提供产品code
     *
     * @return
     */
    String getProductCode();

    /**
     * 提供PayMerchantType
     *
     * @return
     */
    PayMerchantType getPayMerchantType();

    /**
     * 设置商户信息
     *
     * @param merchantInfo
     */
    void setMerchantInfo(MerchantInfo merchantInfo);
}
