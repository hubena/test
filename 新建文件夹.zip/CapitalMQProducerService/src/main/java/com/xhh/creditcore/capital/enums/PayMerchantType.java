package com.xhh.creditcore.capital.enums;

/**
 * 支付相关商户类型 zhangweixin 2018-01-18
 */
public enum PayMerchantType {
    PRINCIPAL_REPAY(1, "本息代收商户"),
    FEE_REPAY(2, "服务费代收商户"),
    PAY(3, "款项代付"),
    BANK_AUTH(4, "银行卡鉴权");
    private Integer key;
    private String  desc;

    public Integer getKey() {
        return key;
    }

    public String getDesc() {
        return desc;
    }

    PayMerchantType(Integer key, String desc) {
        this.key = key;
        this.desc = desc;
    }

    public static PayMerchantType getInstance(Integer key) {
        for (PayMerchantType repayType : PayMerchantType.values()) {
            if (repayType.key.equals(key)) {
                return repayType;
            }
        }
        return null;
    }
}
