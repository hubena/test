package com.xhh.creditcore.capital.model;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 订单日志表
 * </p>
 *
 * @author nathaniel123
 * @since 2018-01-09
 */

public class OrderLog implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long              id;
    /**
     * 订单类型：1授信、2借款
     */
    private Integer           orderType;
    /**
     * 订单号
     */
    private String            orderNo;
    /**
     * 操作名称
     */
    private String            opName;
    /**
     * 操作时间
     */
    private Date              opTime;
    /**
     * 操作结果：成功、失败、异常
     */
    private String            opResult;
    /**
     * 操作人
     */
    private String            operator;
    /**
     * 备注
     */
    private String            remark;
    /**
     * 与第三方通信请求参数
     */
    private String            requestParam;
    /**
     * 与第三方通信返回值
     */
    private String            responseResult;
    /**
     * 创建时间
     */
    private Date              gmtCreated;
    /**
     * 最后修改时间
     */
    private Date              gmtModified;
    /**
     * 创建人
     */
    private String            creator;
    /**
     * 最后修改人
     */
    private String            modifier;
    /**
     * 删除标志位 N-未删除 Y-已删除
     */
    private String            isDeleted;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getOrderType() {
        return orderType;
    }

    public void setOrderType(Integer orderType) {
        this.orderType = orderType;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getOpName() {
        return opName;
    }

    public void setOpName(String opName) {
        this.opName = opName;
    }

    public Date getOpTime() {
        return opTime;
    }

    public void setOpTime(Date opTime) {
        this.opTime = opTime;
    }

    public String getOpResult() {
        return opResult;
    }

    public void setOpResult(String opResult) {
        this.opResult = opResult;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getRequestParam() {
        return requestParam;
    }

    public void setRequestParam(String requestParam) {
        this.requestParam = requestParam;
    }

    public String getResponseResult() {
        return responseResult;
    }

    public void setResponseResult(String responseResult) {
        this.responseResult = responseResult;
    }

    public Date getGmtCreated() {
        return gmtCreated;
    }

    public void setGmtCreated(Date gmtCreated) {
        this.gmtCreated = gmtCreated;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public String getModifier() {
        return modifier;
    }

    public void setModifier(String modifier) {
        this.modifier = modifier;
    }

    public String getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(String isDeleted) {
        this.isDeleted = isDeleted;
    }

    @Override
    public String toString() {
        return "OrderLog{" + "id=" + id + ", orderType=" + orderType + ", orderNo=" + orderNo + ", opName=" + opName + ", opTime=" + opTime + ", opResult="
                + opResult + ", operator=" + operator + ", remark=" + remark + ", requestParam=" + requestParam + ", responseResult=" + responseResult
                + ", gmtCreated=" + gmtCreated + ", gmtModified=" + gmtModified + ", creator=" + creator + ", modifier=" + modifier + ", isDeleted=" + isDeleted
                + "}";
    }
}
