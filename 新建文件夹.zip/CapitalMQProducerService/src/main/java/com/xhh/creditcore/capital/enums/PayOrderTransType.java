package com.xhh.creditcore.capital.enums;

/**
 * zhangweixin 2018-01-10
 */
public enum PayOrderTransType {
    LOAN(1, "放款"),
    LOAN_PAY_FEE(2, "放款代付服务费"),
    REPAY(3, "还款"),
    REPAY_PAY_FEE(4, "还款代付服务费");
    private Integer key;
    private String  desc;

    public Integer getKey() {
        return key;
    }

    public String getDesc() {
        return desc;
    }

    private PayOrderTransType(Integer key, String desc) {
        this.key = key;
        this.desc = desc;
    }

    public static PayOrderTransType getInstance(Integer key) {
        for (PayOrderTransType payType : PayOrderTransType.values()) {
            if (payType.key.equals(key)) {
                return payType;
            }
        }
        return null;
    }
}
