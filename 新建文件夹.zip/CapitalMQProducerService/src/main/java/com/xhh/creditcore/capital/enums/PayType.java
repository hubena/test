package com.xhh.creditcore.capital.enums;

/**
 * zhangweixin 2018-01-10
 */
public enum PayType {
    THIRD_PAY(1, "第三方支付"),
    THIRD_PLATFORM(2, "第三方资金平台");
    private Integer key;
    private String  desc;

    public Integer getKey() {
        return key;
    }

    public String getDesc() {
        return desc;
    }

    private PayType(Integer key, String desc) {
        this.key = key;
        this.desc = desc;
    }

    public static PayType getInstance(Integer key) {
        for (PayType payType : PayType.values()) {
            if (payType.key.equals(key)) {
                return payType;
            }
        }
        return null;
    }
}
