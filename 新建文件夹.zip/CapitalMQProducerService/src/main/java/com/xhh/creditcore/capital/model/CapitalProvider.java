package com.xhh.creditcore.capital.model;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 资金方
 * </p>
 *
 * @author nathaniel123
 * @since 2018-01-09
 */

public class CapitalProvider implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long              id;
    /**
     * 资金方编码
     */
    private String            capitalCode;
    /**
     * 资金方名称
     */
    private String            providerName;
    /**
     * 放款通道类型：1归集放款、2资金方自行放款
     */
    private Integer           loanPassageType;
    /**
     * 还款通道类型：1归集还款、2资金方自行还款
     */
    private Integer           repayPassageType;
    /**
     * 归集放款支付通道编码
     */
    private String            loanPayPassageCode;
    /**
     * 归集还款支付通道编码
     */
    private String            repayPayPassageCode;

    /**
     * 归集服务费代收账户编码
     */
    private String            principalCollectionAccount;
    /**
     * 归集代付账户编码
     */
    private String            feeCollectionAccount;
    /**
     * 鉴权账户编码
     */
    private String            authenticationAccount;
    /**
     * 归集代付账户编码
     */
    private String            paymentAccount;

    /**
     * 鉴权通道
     */
    private String            authenticationPassageCode;
    /**
     * 创建时间
     */
    private Date              gmtCreated;
    /**
     * 最后修改时间
     */
    private Date              gmtModified;
    /**
     * 创建人
     */
    private String            creator;
    /**
     * 最后修改人
     */
    private String            modifier;
    /**
     * 删除标志位 N-未删除 Y-已删除
     */
    private String            isDeleted;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCapitalCode() {
        return capitalCode;
    }

    public void setCapitalCode(String capitalCode) {
        this.capitalCode = capitalCode;
    }

    public String getProviderName() {
        return providerName;
    }

    public void setProviderName(String providerName) {
        this.providerName = providerName;
    }

    public Integer getLoanPassageType() {
        return loanPassageType;
    }

    public void setLoanPassageType(Integer loanPassageType) {
        this.loanPassageType = loanPassageType;
    }

    public Integer getRepayPassageType() {
        return repayPassageType;
    }

    public void setRepayPassageType(Integer repayPassageType) {
        this.repayPassageType = repayPassageType;
    }

    public String getLoanPayPassageCode() {
        return loanPayPassageCode;
    }

    public void setLoanPayPassageCode(String loanPayPassageCode) {
        this.loanPayPassageCode = loanPayPassageCode;
    }

    public String getRepayPayPassageCode() {
        return repayPayPassageCode;
    }

    public void setRepayPayPassageCode(String repayPayPassageCode) {
        this.repayPayPassageCode = repayPayPassageCode;
    }

    public String getPrincipalCollectionAccount() {
        return principalCollectionAccount;
    }

    public void setPrincipalCollectionAccount(String principalCollectionAccount) {
        this.principalCollectionAccount = principalCollectionAccount;
    }

    public String getPaymentAccount() {
        return paymentAccount;
    }

    public void setPaymentAccount(String paymentAccount) {
        this.paymentAccount = paymentAccount;
    }

    public String getAuthenticationPassageCode() {
        return authenticationPassageCode;
    }

    public void setAuthenticationPassageCode(String authenticationPassageCode) {
        this.authenticationPassageCode = authenticationPassageCode;
    }

    public Date getGmtCreated() {
        return gmtCreated;
    }

    public void setGmtCreated(Date gmtCreated) {
        this.gmtCreated = gmtCreated;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public String getModifier() {
        return modifier;
    }

    public void setModifier(String modifier) {
        this.modifier = modifier;
    }

    public String getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(String isDeleted) {
        this.isDeleted = isDeleted;
    }

    public String getFeeCollectionAccount() {
        return feeCollectionAccount;
    }

    public void setFeeCollectionAccount(String feeCollectionAccount) {
        this.feeCollectionAccount = feeCollectionAccount;
    }

    public String getAuthenticationAccount() {
        return authenticationAccount;
    }

    public void setAuthenticationAccount(String authenticationAccount) {
        this.authenticationAccount = authenticationAccount;
    }

    @Override
    public String toString() {
        return "CapitalProvider{" + "id=" + id + ", capitalCode='" + capitalCode + '\'' + ", providerName='" + providerName + '\'' + ", loanPassageType="
                + loanPassageType + ", repayPassageType=" + repayPassageType + ", loanPayPassageCode='" + loanPayPassageCode + '\'' + ", repayPayPassageCode='"
                + repayPayPassageCode + '\'' + ", principalCollectionAccount='" + principalCollectionAccount + '\'' + ", feeCollectionAccount='"
                + feeCollectionAccount + '\'' + ", authenticationAccount='" + authenticationAccount + '\'' + ", paymentAccount='" + paymentAccount + '\''
                + ", authenticationPassageCode='" + authenticationPassageCode + '\'' + ", gmtCreated=" + gmtCreated + ", gmtModified=" + gmtModified
                + ", creator='" + creator + '\'' + ", modifier='" + modifier + '\'' + ", isDeleted='" + isDeleted + '\'' + '}';
    }
}
