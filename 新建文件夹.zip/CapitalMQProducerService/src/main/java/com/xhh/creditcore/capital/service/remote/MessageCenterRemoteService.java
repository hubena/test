package com.xhh.creditcore.capital.service.remote;

import com.janty.core.util.BaseRemoteService;
import com.xhh.creditcore.transaction.constant.TransactionErrorCode;
import com.xhh.infrastructure.messagecenter.api.IMessageCenterApi;
import com.xhh.infrastructure.messagecenter.dto.SendSmsMessageRequest;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * @author xh
 */
@Service("messageCenterRemoteService")
public class MessageCenterRemoteService extends BaseRemoteService {
    @Resource
    private IMessageCenterApi messageCenterApi;

    public void sendSms(SendSmsMessageRequest request) {
        try {
            messageCenterApi.sendSms(request);
        } catch (Exception e) {
            processException(e, new TransactionErrorCode(TransactionErrorCode.Element.r_send_message_remote_fail));
        }
    }

}
