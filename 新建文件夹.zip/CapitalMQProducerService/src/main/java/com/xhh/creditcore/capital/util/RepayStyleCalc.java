package com.xhh.creditcore.capital.util;

import java.math.BigDecimal;
import java.util.Map;

/**
 * 类RepayStyleCalc.java的实现描述：还款方式计算抽象类
 * 
 * @author xiehuang 2018年1月16日 下午3:36:33
 */
public abstract class RepayStyleCalc {

    public static int scale         = 2;
    public static int round_default = BigDecimal.ROUND_UP;
    public static int round_up      = BigDecimal.ROUND_UP;
    public static int round_down    = BigDecimal.ROUND_DOWN;

    public abstract Map<Integer, BigDecimal> calcPerMonthCapitalInterest(double invest, double yearRate, int month);

    public abstract Map<Integer, BigDecimal> calcPerMonthInterest(double invest, double yearRate, int month);

    public abstract Map<Integer, BigDecimal> calcPerMonthCapital(double invest, double yearRate, int month);

    public abstract void initData(double invest, double yearRate, int month);

    public Map<Integer, BigDecimal> getPerMonthCapitalInterest(double invest, double yearRate, int month) {
        if(getPerMonthCapitalInterest() == null) {
            initData(invest, yearRate, month);
        }
        return getPerMonthCapitalInterest();
    }
    public Map<Integer, BigDecimal> getPerMonthInterest(double invest, double yearRate, int month) {
        if(getPerMonthInterest() == null) {
            initData(invest, yearRate, month);
        }
        return getPerMonthInterest();
    }
    public Map<Integer, BigDecimal> getPerMonthCapital(double invest, double yearRate, int month) {
        if(getPerMonthCapital() == null) {
            initData(invest, yearRate, month);
        }
        return getPerMonthCapital();
    }
    
    private Map<Integer, BigDecimal> perMonthCapitalInterest;
    private Map<Integer, BigDecimal> perMonthInterest;
    private Map<Integer, BigDecimal> perMonthCapital;
    
    public Map<Integer, BigDecimal> getPerMonthCapitalInterest() {
        return perMonthCapitalInterest;
    }
    public void setPerMonthCapitalInterest(Map<Integer, BigDecimal> perMonthCapitalInterest) {
        this.perMonthCapitalInterest = perMonthCapitalInterest;
    }
    public Map<Integer, BigDecimal> getPerMonthInterest() {
        return perMonthInterest;
    }
    public void setPerMonthInterest(Map<Integer, BigDecimal> perMonthInterest) {
        this.perMonthInterest = perMonthInterest;
    }
    public Map<Integer, BigDecimal> getPerMonthCapital() {
        return perMonthCapital;
    }
    public void setPerMonthCapital(Map<Integer, BigDecimal> perMonthCapital) {
        this.perMonthCapital = perMonthCapital;
    }

    public BigDecimal sumCapitalInterest(double invest, double yearRate, int month) {
        return sumMapDecimal(getPerMonthCapitalInterest(invest, yearRate, month));
    }

    public BigDecimal sumInterest(double invest, double yearRate, int month) {
        return sumMapDecimal(getPerMonthInterest(invest, yearRate, month));
    }

    public BigDecimal sumCapital(double invest, double yearRate, int month) {
        return sumMapDecimal(getPerMonthCapital(invest, yearRate, month));
    }

    public BigDecimal sumMapDecimal(Map<Integer, BigDecimal> map) {
        BigDecimal res = new BigDecimal(0);
        for (Map.Entry<Integer, BigDecimal> entry : map.entrySet()) {
            res = res.add(entry.getValue());
        }
        return res;
    }
}
