package com.xhh.creditcore.capital.pay;

/**
 * 支付回调通知业务处理者 zhangweixin 2018-01-17
 */
public interface PayNoticeHandler {

    /**
     * 根据订单号判断是否支持此类业务处理
     * 
     * @param orderNo
     * @return
     */
    boolean isSupportOrderType(String orderNo);

    /**
     * 单笔代扣成功回调
     *
     * @param handlerRequest
     */
    void deductSuccessHandle(PayNoticeHandlerRequest handlerRequest);

    /**
     * 单笔代扣失败回调
     *
     * @param handlerRequest
     */
    void deductFailHandle(PayNoticeHandlerRequest handlerRequest);

    /**
     * 单笔代付成功回调
     *
     * @param handlerRequest
     */
    void paySuccessHandle(PayNoticeHandlerRequest handlerRequest);

    /**
     * 单笔代付失败回调
     *
     * @param handlerRequest
     */
    void payFailHandle(PayNoticeHandlerRequest handlerRequest);

    /**
     * 认证支付失败回调通知
     *
     * @param handlerRequest
     */
    void certPayFailHandle(PayNoticeHandlerRequest handlerRequest);

    /**
     * 认证支付成功回调通知
     * 
     * @param handlerRequest
     */
    void certPaySuccessHandle(PayNoticeHandlerRequest handlerRequest);
}
