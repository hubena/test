package com.xhh.creditcore.capital.api;

import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.janty.cached.access.RedisCachedAccess;
import com.janty.core.dto.PageData;
import com.janty.core.dto.StringRequest;
import com.janty.core.util.CommonBeanCopier;
import com.janty.core.util.ExceptionUtil;
import com.janty.core.util.ValidateUtil;
import com.xhh.creditcore.capital.constant.CapitalRedisKey;
import com.xhh.creditcore.capital.dto.*;
import com.xhh.creditcore.capital.enums.RepayTriggerType;
import com.xhh.creditcore.capital.model.CapitalLoanTrans;
import com.xhh.creditcore.capital.service.BankCardService;
import com.xhh.creditcore.capital.service.BankCardbinService;
import com.xhh.creditcore.capital.service.CapitalLoanTransService;
import com.xhh.creditcore.capital.service.RepaymentService;

/**
 * 对外提供服务总接口 zhangweixin 2018-01-10
 */
@Service("capitalApi")
public class CapitalApi implements ICapitalApi {
    private static Logger             logger = LoggerFactory.getLogger(CapitalApi.class);

    @Resource
    private RepaymentService          repaymentService;
    @Resource
    BankCardService                   bankCardService;
    @Resource
    private CapitalLoanTransService   capitalLoanTransService;
    @Resource
    private RedisCachedAccess<String> cachedAccess;
    @Resource
    private BankCardbinService        bankCardbinService;


    @Override
    public RepaymentDto certPayRepaymentPrePay(CertPayRepayPreRequest preRequest) {
        logger.info("CapitalApi-certPayRepaymentPrePay-请求开始, reqNo-{}-请求参数-{}", preRequest.getReqNo(), preRequest);
        RepaymentDto result;
        try {
            ValidateUtil.validate(preRequest);
            preRequest.setTriggerType(RepayTriggerType.INITIATE_REPAY.getKey());
            result = repaymentService.certPayRepaymentPrePay(preRequest);
        } catch (Exception e) {
            logger.error("CapitalApi-certPayRepaymentPrePay-请求异常, reqNo-{}-{}", preRequest.getReqNo(), ExceptionUtil.getType(e), e);
            throw e;
        }
        logger.info("CapitalApi-certPayRepaymentPrePay-请求结束, reqNo-{}-返回-{}", preRequest.getReqNo(), result);
        return result;
    }

    @Override
    public RepaymentDto certPayRepaymentConfirmPay(CertPayRepayConfirmRequest confirmRequest) {
        logger.info("CapitalApi-certPayRepaymentConfirmPay-请求开始, reqNo-{}-请求参数-{}", confirmRequest.getReqNo(), confirmRequest);
        RepaymentDto result;
        try {
            ValidateUtil.validate(confirmRequest);
            result = repaymentService.certPayRepaymentConfirmPay(confirmRequest);
        } catch (Exception e) {
            logger.error("CapitalApi-certPayRepaymentConfirmPay-请求异常, reqNo-{}-{}", confirmRequest.getReqNo(), ExceptionUtil.getType(e), e);
            throw e;
        }
        logger.info("CapitalApi-certPayRepaymentConfirmPay-请求结束, reqNo-{}-返回-{}", confirmRequest.getReqNo(), result);
        return result;
    }

    @Override
    public RepaymentDto certPayRepaymentSendSms(CertPayRepaySendSmsRequest sendSmsRequest) {
        logger.info("CapitalApi-certPayRepaymentSendSms-请求开始, reqNo-{}-请求参数-{}", sendSmsRequest.getReqNo(), sendSmsRequest);
        RepaymentDto result;
        try {
            ValidateUtil.validate(sendSmsRequest);
            result = repaymentService.certPayRepaymentSendSms(sendSmsRequest);
        } catch (Exception e) {
            logger.error("CapitalApi-certPayRepaymentSendSms-请求异常, reqNo-{}-{}", sendSmsRequest.getReqNo(), ExceptionUtil.getType(e), e);
            throw e;
        }
        logger.info("CapitalApi-certPayRepaymentSendSms-请求结束, reqNo-{}-返回-{}", sendSmsRequest.getReqNo(), result);
        return result;
    }

    @Override
    public AccountBankCardDto queryAccountBankCardInfo(AccountBankCardRequest request) {
        logger.info("CapitalApi-queryAccountBankCardInfo-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);
        AccountBankCardDto result;
        try {
            ValidateUtil.validate(request);
            result = bankCardService.queryAccountBankCardInfo(request);
        } catch (Exception e) {
            logger.error("CapitalApi-queryAccountBankCardInfo-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            throw e;
        }
        logger.info("CapitalApi-queryAccountBankCardInfo-请求结束, reqNo-{}-返回-{}", request.getReqNo(), result);
        return result;
    }

    @Override
    public List<OverdueAccountOrderDto> queryAccountOverdueOrder(OverdueAccountOrderRequest request) {
        logger.info("CapitalApi-queryAccountOverdueOrder-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);
        List<OverdueAccountOrderDto> result;
        try {
            ValidateUtil.validate(request);
            result = capitalLoanTransService.queryAccountOverdueOrder(request);
        } catch (Exception e) {
            logger.error("CapitalApi-queryAccountOverdueOrder-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            throw e;
        }
        logger.info("CapitalApi-queryAccountOverdueOrder-请求结束, reqNo-{}-返回-{}", request.getReqNo(), result);
        return result;
    }

    @Override
    public List<ProcessingAccountOrderDto> queryAccountProcessingOrder(ProcessingAccountOrderRequest request) {
        logger.info("CapitalApi-queryAccountProcessingOrder-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);
        List<ProcessingAccountOrderDto> result;
        try {
            ValidateUtil.validate(request);
            result = capitalLoanTransService.queryAccountProcessingOrder(request);
        } catch (Exception e) {
            logger.error("CapitalApi-queryAccountProcessingOrder-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            throw e;
        }
        logger.info("CapitalApi-queryAccountProcessingOrder-请求结束, reqNo-{}-返回-{}", request.getReqNo(), result);
        return result;
    }

    @Override
    public List<RepayPlanQueryDto> queryAccountRepayPlan(RepayPlanQueryRequest request) {
        logger.info("CapitalApi-queryAccountRepayPlan-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);
        List<RepayPlanQueryDto> result;
        try {
            ValidateUtil.validate(request);
            result = repaymentService.queryRepayPlan(request);
        } catch (Exception e) {
            logger.error("CapitalApi-queryAccountRepayPlan-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            throw e;
        }
        logger.info("CapitalApi-queryAccountRepayPlan-请求结束, reqNo-{}-返回-{}", request.getReqNo(), result);
        return result;
    }

    @Override
    public void bindBank(CapitalBindBankRequest request) throws Exception {
        logger.info("CapitalApi-bindBank-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);
        try {
            ValidateUtil.validate(request);
            bankCardService.bindBank(request);
        } catch (Exception e) {
            logger.error("CapitalApi-bindBank-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            throw e;
        }
        logger.info("CapitalApi-bindBank-请求结束, reqNo-{}-返回-{}", request.getReqNo(), null);
    }

    @Override
    public PageData<RepayCapitalRecordQueryDto> queryRepayTransRecordByPage(CapitalRecordQueryRequest request) {
        logger.info("CapitalApi-queryRepayTransRecordByPage-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);
        PageData<RepayCapitalRecordQueryDto> result;
        try {
            ValidateUtil.validate(request);
            result = repaymentService.queryRepayTransRecordByPage(request);
        } catch (Exception e) {
            logger.error("CapitalApi-queryRepayTransRecordByPage-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            throw e;
        }
        logger.info("CapitalApi-queryRepayTransRecordByPage-请求结束, reqNo-{}-返回-{}", request.getReqNo(), result);
        return result;
    }

    @Override
    public PageData<PayCapitalRecordQueryDto> queryPayTransRecordByPage(CapitalRecordQueryRequest request) {
        logger.info("CapitalApi-queryPayTransRecordByPage-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);
        PageData<PayCapitalRecordQueryDto> result;
        try {
            ValidateUtil.validate(request);
            result = capitalLoanTransService.queryLoanTransRecordByPage(request);
        } catch (Exception e) {
            logger.error("CapitalApi-queryPayTransRecordByPage-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            throw e;
        }
        logger.info("CapitalApi-queryPayTransRecordByPage-请求结束, reqNo-{}-返回-{}", request.getReqNo(), result);
        return result;
    }

    /**
     * 借款
     */
    @Override
    public CapitalLoanDto loan(CapitalLoanRequest request) {
        logger.info("LoanApi-loan-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);
        CapitalLoanDto result = null;
        try {
            ValidateUtil.validate(request);
            //锁外部交易流水号
            cachedAccess.tryLock(CapitalRedisKey.LOCK_PREFIX + request.getOuterLoanOrderNo());
            result = capitalLoanTransService.loan(request);

        } catch (Exception e) {
            logger.error("LoanApi-loan-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            throw e;
        } finally {
            //释放锁
            cachedAccess.releaseLock(CapitalRedisKey.LOCK_PREFIX + request.getOuterLoanOrderNo());
        }

        logger.info("LoanApi-loan-请求结束, reqNo-{}-返回-{}", request.getReqNo(), result);

        return result;
    }

    /**
     * 直接代付
     */
    @Override
    public CapitalLoanDto pay(CapitalPayRequest request) {
        logger.info("LoanApi-pay-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);
        CapitalLoanDto result = null;
        try {
            ValidateUtil.validate(request);
            //锁外部交易流水号
            cachedAccess.tryLock(CapitalRedisKey.LOCK_PREFIX + request.getOuterLoanOrderNo());
            result = capitalLoanTransService.pay(request);

        } catch (Exception e) {
            logger.error("LoanApi-pay-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            throw e;
        } finally {
            //释放锁
            cachedAccess.releaseLock(CapitalRedisKey.LOCK_PREFIX + request.getOuterLoanOrderNo());
        }

        logger.info("LoanApi-pay-请求结束, reqNo-{}-返回-{}", request.getReqNo(), result);

        return result;
    }

    @Override
    public CapitalLoanDto payOfPublic(CapitalPublicPayRequest request) {
        logger.info("capitalApi-payOfPublic-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);
        CapitalLoanDto result = null;
        try {
            ValidateUtil.validate(request);
            //锁外部交易流水号
            cachedAccess.tryLock(CapitalRedisKey.LOCK_PREFIX + request.getOuterLoanOrderNo());
            result = capitalLoanTransService.payOfPublic(request);
        } catch (Exception e) {
            logger.error("capitalApi-payOfPublic-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            throw e;
        } finally {
            //释放锁
            cachedAccess.releaseLock(CapitalRedisKey.LOCK_PREFIX + request.getOuterLoanOrderNo());
        }
        logger.info("capitalApi-payOfPublic-请求结束, reqNo-{}-返回-{}", request.getReqNo(), result);
        return result;
    }

    /**
     * 根据外部订单号查询资金出账交易
     * 
     * @param request
     * @return
     */
    @Override
    public CapitalLoanDto queryTransByOuterOrderNo(StringRequest request) {
        logger.info("CapitalApi-queryTransByOuterOrderNo-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);
        CapitalLoanDto result = null;

        try {
            CapitalLoanTrans capitalLoanTrans = capitalLoanTransService.queryDataByOutLoanOrderNo(request.getParam());
            if (capitalLoanTrans != null) {
                result = new CapitalLoanDto();
                CommonBeanCopier.copy(capitalLoanTrans, result);
            }
        } catch (Exception e) {
            logger.error("CapitalApi-queryTransByOuterOrderNo-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            throw e;
        }
        logger.info("CapitalApi-queryTransByOuterOrderNo-请求结束, reqNo-{}-返回-{}", request.getReqNo(), result);
        return result;
    }

    /**
     * 查询卡bin信息
     * 
     * @param request
     * @return
     */
    @Override
    public BankCardbinDto queryBankCardbin(QueryBankCardbinRequest request) {
        logger.info("CapitalApi-queryBankCardbin-请求开始, reqNo-{}-请求参数-{}", request.getReqNo(), request);
        BankCardbinDto result = null;
        try {
            ValidateUtil.validate(request);
            result = bankCardbinService.queryByCardNo(request.getCardNo());
        } catch (Exception e) {
            logger.error("CapitalApi-queryBankCardbin-请求异常, reqNo-{}-{}", request.getReqNo(), ExceptionUtil.getType(e), e);
            throw e;
        }

        logger.info("CapitalApi-queryBankCardbin-请求结束, reqNo-{}-返回-{}", request.getReqNo(), result);
        return result;
    }

}
