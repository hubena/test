package com.xhh.creditcore.capital.service.payimpl;

import java.text.MessageFormat;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import com.janty.core.exception.BusinessException;
import com.janty.core.exception.SystemException;
import com.xhh.creditcore.capital.constant.CapitalErrorCode;
import com.xhh.creditcore.capital.enums.PayChannel;
import com.xhh.creditcore.capital.enums.PayMerchantType;
import com.xhh.creditcore.capital.enums.PayRouteType;
import com.xhh.creditcore.capital.enums.PayType;
import com.xhh.creditcore.capital.model.CapitalProvider;
import com.xhh.creditcore.capital.model.PassageAccount;
import com.xhh.creditcore.capital.pay.*;
import com.xhh.creditcore.capital.service.CapitalProviderService;
import com.xhh.creditcore.capital.service.PassageAccountService;
import com.xhh.creditcore.capital.service.PayService;
import com.xhh.creditcore.capital.service.remote.ProductRemoteService;
import com.xhh.creditcore.product.constant.ProductConfigKey;

/**
 * zhangweixin 2017-01-09
 */
@Component("payServiceDelegate")
@Lazy
public class PayServiceDelegate implements PayService, MerchantInfoConfiger {

    private static Logger                              logger                 = LoggerFactory.getLogger(PayServiceDelegate.class);

    @Autowired
    private List<PayServiceAdaptor>                    payServices;
    @Autowired
    private ProductRemoteService                       productRemoteService;
    @Autowired
    private CapitalProviderService                     capitalProviderService;
    @Autowired
    private PassageAccountService                      accountService;
    private ConcurrentHashMap<String, CapitalProvider> payTypeAndChannelCache = new ConcurrentHashMap<>();

    @Override
    public boolean supportPayType(PayType payType) {
        return false;
    }

    @Override
    public boolean supportPayChannel(PayChannel payChannel) {
        return false;
    }

    @Override
    public boolean isDefaultPayChannel() {
        return false;
    }

    @Override
    public PayResult singlePay(PayRequest request) {
        PayServiceAdaptor executeService = getRelatedPayRoute(request);
        return executeService.singlePay(request);
    }


    @Override
    public PayResult singPayOfPublic(PayRequest request) {
        PayServiceAdaptor executeService = getRelatedPayRoute(request);
        return executeService.singPayOfPublic(request);
    }

    @Override
    public PayResult singleDeduct(PayRequest request) {
        PayServiceAdaptor payService = getRelatedRepayRoute(request);
        return payService.singleDeduct(request);
    }

    @Override
    public PayResult singlePayQuery(PayRequest request) {
        PayServiceAdaptor payService = getRelatedPayRoute(request);
        return payService.singlePayQuery(request);
    }

    @Override
    public PayResult singleDeductOrderQuery(PayRequest request) {
        PayServiceAdaptor payService = getRelatedRepayRoute(request);
        return payService.singleDeductOrderQuery(request);
    }

    @Override
    public void singlePayNotice(PayNoticeRequest noticeRequest) {
        PayServiceAdaptor payService = getRelatedRepayRoute(noticeRequest);
        payService.singlePayNotice(noticeRequest);
    }

    @Override
    public void singleDeductNotice(PayNoticeRequest noticeRequest) {
        PayServiceAdaptor payService = getRelatedRepayRoute(noticeRequest);
        payService.singleDeductNotice(noticeRequest);
    }

    @Override
    public void certPayNotice(PayNoticeRequest noticeRequest) {
        PayServiceAdaptor payService = getRelatedRepayRoute(noticeRequest);
        payService.certPayNotice(noticeRequest);
    }

    @Override
    public PayResult bankCardAuth(PayRequest request) throws Exception {
        PayService payService = getRelatedSignRoute(request);
        return payService.bankCardAuth(request);
    }

    @Override
    public PayResult certPayPrePay(PayRequest request) {
        PayServiceAdaptor payService = getRelatedRepayRoute(request);
        return payService.certPayPrePay(request);
    }

    @Override
    public PayResult certPayConfirmPay(PayRequest request) {
        PayServiceAdaptor payService = getRelatedRepayRoute(request);
        return payService.certPayConfirmPay(request);
    }

    @Override
    public PayResult repeatSendSms(PayRequest request) throws UnsupportedOperationException {
        PayServiceAdaptor payService = getRelatedRepayRoute(request);
        return payService.repeatSendSms(request);
    }

    @Override
    public PayResult certPayOrderQuery(PayRequest request) {
        PayServiceAdaptor payService = getRelatedRepayRoute(request);
        return payService.certPayOrderQuery(request);
    }

    /**
     * 获取与鉴权相关路由
     *
     * @param serviceRequest
     * @return
     */
    public PayServiceAdaptor getRelatedSignRoute(ConfigurableMerchantInfo serviceRequest) {
        configMerchantInfo(serviceRequest);
        return getRouteService(serviceRequest.getProductCode(), PayRouteType.SIGN);
    }

    /**
     * 获取代付相关路由
     *
     * @param serviceRequest
     * @return
     */
    public PayServiceAdaptor getRelatedPayRoute(ConfigurableMerchantInfo serviceRequest) {
        configMerchantInfo(serviceRequest);
        return getRouteService(serviceRequest.getProductCode(), PayRouteType.PAY);
    }

    /**
     * 获取代扣相关路由
     *
     * @param serviceRequest
     * @return
     */
    public PayServiceAdaptor getRelatedRepayRoute(ConfigurableMerchantInfo serviceRequest) {
        configMerchantInfo(serviceRequest);
        return getRouteService(serviceRequest.getProductCode(), PayRouteType.REPAY);
    }

    /**
     * 支付请求根据产品配置的通道类型以及通道编码路由到相关支付实现类上
     *
     * @param productCode
     * @param routeType
     * @return
     */
    public PayServiceAdaptor getRouteService(String productCode, PayRouteType routeType) {

        //查缓存
        CapitalProvider cacheValue = queryCapitalProvider(productCode);
        PayChannel payChannel;
        PayService executeService = null;
        if (PayRouteType.SIGN.equals(routeType)) {
            payChannel = PayChannel.getInstance(cacheValue.getAuthenticationPassageCode());
            for (PayService payService : payServices) {
                if (payService.supportPayChannel(payChannel)) {
                    executeService = payService;
                    logger.info("支付通道:{} 路由服务:{}", payChannel.getDesc(), executeService.getClass().getName());
                    break;
                }
            }
        } else {
            PayType payType;
            if (PayRouteType.PAY.equals(routeType)) {
                payType = PayType.getInstance(cacheValue.getLoanPassageType());
                payChannel = PayChannel.getInstance(cacheValue.getLoanPayPassageCode());
            } else {
                payType = PayType.getInstance(cacheValue.getRepayPassageType());
                payChannel = PayChannel.getInstance(cacheValue.getRepayPayPassageCode());
            }

            if (payType == null || payChannel == null) {
                String msg = MessageFormat.format("不知道的通道类型或者通道码:type-{0},code-{1}", payType, payChannel);
                throw new SystemException(msg);
            }

            for (PayService payService : payServices) {
                if (payService.supportPayType(payType)) {
                    if (payService.supportPayChannel(payChannel)) {
                        executeService = payService;
                        logger.info("检索到路由：支付方式-{} 支付通道-{} 路由服务-{}", payType.getDesc(), payChannel.getDesc(), executeService.getClass().getName());
                        break;
                    }
                }
            }

            if (executeService == null) {
                logger.error("找不到具体的支付实现,payType:" + payType.getDesc() + " payChannel:" + payChannel.getDesc());
                throw new BusinessException(new CapitalErrorCode(CapitalErrorCode.Element.b_not_found_route));
            }
        }
        return (PayServiceAdaptor) executeService;
    }

    /**
     * 根据产品code查询资金信息
     * 
     * @param productCode
     * @return
     */
    public CapitalProvider queryCapitalProvider(String productCode) {
        //查缓存
        Optional<CapitalProvider> cacheProvider = Optional.ofNullable(payTypeAndChannelCache.get(productCode));
        return cacheProvider.orElseGet(() -> {
            Optional<Map<String, String>> productMap = Optional.ofNullable(productRemoteService.getProductByCode(productCode));
            return productMap.map(productConfig -> productConfig.get(ProductConfigKey.capital_capital_code))
                    .map(capitalCode -> capitalProviderService.queryDataByCapitalCode(capitalCode)).map(provider -> {
                        payTypeAndChannelCache.putIfAbsent(productCode, provider);
                        return provider;
                    }).orElseThrow(() -> new SystemException("productCode:" + productCode + "对应的资金配置异常"));
        });
    }

    @Override
    public void configMerchantInfo(ConfigurableMerchantInfo configurableMerchantInfo) {
        Optional.ofNullable(configurableMerchantInfo.getPayMerchantType()).map(merchantType -> {
            CapitalProvider capitalProvider = queryCapitalProvider(configurableMerchantInfo.getProductCode());
            String code = capitalProvider.getPaymentAccount();
            if (PayMerchantType.FEE_REPAY.equals(merchantType)) {
                code = capitalProvider.getFeeCollectionAccount();
            } else if (PayMerchantType.PRINCIPAL_REPAY.equals(merchantType)) {
                code = capitalProvider.getPrincipalCollectionAccount();
            } else if (PayMerchantType.PAY.equals(merchantType)) {
                code = capitalProvider.getPaymentAccount();
            } else if (PayMerchantType.BANK_AUTH.equals(merchantType)) {
                code = capitalProvider.getAuthenticationAccount();
            }

            PassageAccount passageAccount = new PassageAccount();
            passageAccount.setAccountCode(code);
            passageAccount = accountService.queryDataByAccountCode(passageAccount);
            MerchantInfo merchantInfo = new MerchantInfo();
            merchantInfo.setMerchantId(passageAccount.getMerchantId());
            merchantInfo.setMerchantName(passageAccount.getMerchantName());
            merchantInfo.setSecretKey(passageAccount.getSecretKey());
            configurableMerchantInfo.setMerchantInfo(merchantInfo);
            return Optional.empty();
        }).orElseThrow(() -> new SystemException("必须指定支付相关的merchantType"));
    }

}
