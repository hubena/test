package com.xhh.creditcore.capital.pay;

/**
 * 还款订单查询结果抽象 zhangweixin 2018-01-11
 */
abstract public class OrderQueryResult<T> {
    //成功
    private Boolean success    = false;
    //失败
    private Boolean fail       = false;
    //处理中
    private Boolean processing = false;
    //未提交
    private Boolean uncommit   = false;

    public Boolean isSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }

    public Boolean isFail() {
        return fail;
    }

    public void setFail(Boolean fail) {
        this.fail = fail;
    }

    public Boolean isProcessing() {
        return processing;
    }

    public void setProcessing(Boolean processing) {
        this.processing = processing;
    }

    public Boolean isUncommit() {
        return uncommit;
    }

    public void setUncommit(Boolean uncommit) {
        this.uncommit = uncommit;
    }

    /**
     * 子类扩展数据
     *
     * @return
     */
    abstract public T getExtendData();
}
