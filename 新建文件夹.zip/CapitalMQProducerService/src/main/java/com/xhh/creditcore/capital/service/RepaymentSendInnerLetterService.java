package com.xhh.creditcore.capital.service;

import com.janty.core.exception.BusinessException;
import com.janty.core.util.*;
import com.xhh.creditcore.capital.constant.RepaymentSendInnerLetterConstants;
import com.xhh.creditcore.capital.constant.RepaymentSmsConstants;
import com.xhh.creditcore.capital.dao.RepayPlanMapper;
import com.xhh.creditcore.capital.enums.RepayTransStatus;
import com.xhh.creditcore.capital.enums.RepayTriggerType;
import com.xhh.creditcore.capital.model.AccountBankCardBind;
import com.xhh.creditcore.capital.model.RepayPlan;
import com.xhh.creditcore.capital.model.RepayTrans;
import com.xhh.creditpre.cashloan.dto.NoticeBusinessMessageDto;
import com.xhh.creditpre.cashloan.enums.MessagePushType;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class RepaymentSendInnerLetterService {
    @Resource
    private RepayTransService repayTransService;
    @Resource
    private RepayPlanService repayPlanService;
    @Resource
    private CapitalMQProducerService capitalMQProducerService;
    @Resource
    private RepayPlanMapper repayPlanMapper;
    @Resource
    private AccountBankCardBindService accountBankCardBindService;

    /**
     * 代扣成功发送站内信
     *
     * @param capitalLoanTransNo
     */
    public void repaymentSuccessSendInnerLetter(String capitalLoanTransNo) {
        if (StringUtil.isNotNull(capitalLoanTransNo)) {
            RepayTrans queryTrans = new RepayTrans();
            queryTrans.setCapitalLoanTransNo(capitalLoanTransNo);
            RepayTrans tagerRepayTrans = repayTransService.queryOneDataByConditon(queryTrans);
            if (tagerRepayTrans != null) {
                if (RepayTriggerType.INITIATE_REPAY.equals(RepayTriggerType.getInstance(tagerRepayTrans.getRepayTriggerType()))) {
                    RepayTransStatus transStatus = RepayTransStatus.getInstance(tagerRepayTrans.getStatus());
                    if (RepayTransStatus.SUCCESS.equals(transStatus)) {
                        RepayPlan repayPlan = repayPlanService.queryDataById(tagerRepayTrans.getRepayPlanId());
                        sendInnerLetterRaymentSuccess(tagerRepayTrans, repayPlan);
                    }
                }

            } else {
                throw new BusinessException("未知代扣订单号:" + capitalLoanTransNo);
            }
        } else {
            throw new BusinessException("代扣订单号不存在;");
        }

    }


    /**
     * 代扣失败发送站内信
     *
     * @param capitalLoanTransNo
     */
    public void repaymentFailSendInnerLetter(String capitalLoanTransNo) {
        if (StringUtil.isNotNull(capitalLoanTransNo)) {
            RepayTrans queryTrans = new RepayTrans();
            queryTrans.setCapitalLoanTransNo(capitalLoanTransNo);
            RepayTrans tagerRepayTrans = repayTransService.queryOneDataByConditon(queryTrans);
            if (tagerRepayTrans != null) {
                if (RepayTriggerType.INITIATE_REPAY.equals(RepayTriggerType.getInstance(tagerRepayTrans.getRepayTriggerType()))) {
                    RepayTransStatus transStatus = RepayTransStatus.getInstance(tagerRepayTrans.getStatus());
                    if (RepayTransStatus.FAIL.equals(transStatus)) {
                        RepayPlan repayPlan = repayPlanService.queryDataById(tagerRepayTrans.getRepayPlanId());
                        sendInnerLetterRaymentFail(tagerRepayTrans, repayPlan);
                    }
                }
            } else {
                throw new BusinessException("未知代扣订单号:" + capitalLoanTransNo);
            }
        } else {
            throw new BusinessException("代扣订单号不存在;");
        }
    }


    /**
     * 代扣失败发送站内信
     *
     * @param tagerRepayTrans
     */
    public void sendInnerLetterRaymentFail(RepayTrans tagerRepayTrans, RepayPlan repayPlan) {
        NoticeBusinessMessageDto noticeBusinessMessageDto = new NoticeBusinessMessageDto();
        noticeBusinessMessageDto.setAccountId(tagerRepayTrans.getAccountId());
        noticeBusinessMessageDto.setMsgSubtype(MessagePushType.CHARGE_FAIL.getKey());
        Map<String, String> paramMap = new HashMap<>();
        paramMap.put(RepaymentSendInnerLetterConstants.repay_amount, tagerRepayTrans.getRepayAmount().toString());
        paramMap.put(RepaymentSendInnerLetterConstants.account_card_no, tagerRepayTrans.getAccountCardNo().substring(tagerRepayTrans.getAccountCardNo().length() - 4, tagerRepayTrans.getAccountCardNo().length()));
        paramMap.put(RepaymentSendInnerLetterConstants.term_no, repayPlan.getTermNo().toString());
        paramMap.put(RepaymentSendInnerLetterConstants.total_term, repayPlan.getTotalTerm().toString());
        noticeBusinessMessageDto.setMap(paramMap);
        capitalMQProducerService.repaymentSendInnerLetterNotity(noticeBusinessMessageDto);
    }

    /**
     * 代扣成功发送站内信
     *
     * @param tagerRepayTrans
     */
    public void sendInnerLetterRaymentSuccess(RepayTrans tagerRepayTrans, RepayPlan repayPlan) {
        NoticeBusinessMessageDto noticeBusinessMessageDto = new NoticeBusinessMessageDto();
        noticeBusinessMessageDto.setAccountId(tagerRepayTrans.getAccountId());
        noticeBusinessMessageDto.setMsgSubtype(MessagePushType.CHARGE_SUCCESS.getKey());
        Map<String, String> paramMap = new HashMap<>();
        paramMap.put(RepaymentSendInnerLetterConstants.term_no, repayPlan.getTermNo().toString());
        paramMap.put(RepaymentSendInnerLetterConstants.total_term, repayPlan.getTotalTerm().toString());
        noticeBusinessMessageDto.setMap(paramMap);
        capitalMQProducerService.repaymentSendInnerLetterNotity(noticeBusinessMessageDto);
    }


    /**
     * 代扣前3天提醒用户还款,发送站内信
     */
    public void remindsendInnerLetterRepaymentToUserBeforeThreeDay() {
        List<RepayPlan> afterTodayThreeDayRepayPlan = repayPlanMapper.queryTodayBeforeThreeDayRepayPlan();
        if (CollectionUtil.isListNull(afterTodayThreeDayRepayPlan)) {
            return;
        }
        for (RepayPlan repayPlan : afterTodayThreeDayRepayPlan) {
            BigDecimal topayAllAmount = DecimalUtil.subtract(DecimalUtil.add(repayPlan.getDuePrincipal(), repayPlan.getDueInterest(), repayPlan.getDuePenalty()),
                    DecimalUtil.add(repayPlan.getRepaidInterest(), repayPlan.getRepaidPenalty(), repayPlan.getRepaidPrincipal()));
            AccountBankCardBind accountBankCardBind = accountBankCardBindService.queryDataByAccountId(repayPlan.getAccountId());
            if (accountBankCardBind != null) {
                NoticeBusinessMessageDto noticeBusinessMessageDto = new NoticeBusinessMessageDto();
                noticeBusinessMessageDto.setAccountId(repayPlan.getAccountId());
                noticeBusinessMessageDto.setMsgSubtype(MessagePushType.REPAYMENT_NOTICE_THREE_DAYS.getKey());
                Map<String, String> paramMap = new HashMap<>();
                paramMap.put(RepaymentSendInnerLetterConstants.repay_amount, topayAllAmount.toString());
                paramMap.put(RepaymentSendInnerLetterConstants.account_card_no, accountBankCardBind.getBankCardNo().substring(accountBankCardBind.getBankCardNo().length() - 4, accountBankCardBind.getBankCardNo().length()));
                paramMap.put(RepaymentSendInnerLetterConstants.remind_date, DateUtil.dateToString(DateUtil.getDateBefore(repayPlan.getAgreedRepayDate(), RepaymentSendInnerLetterConstants.one_day), RepaymentSendInnerLetterConstants.date_pattern));
                noticeBusinessMessageDto.setMap(paramMap);
                capitalMQProducerService.repaymentSendInnerLetterNotity(noticeBusinessMessageDto);
            }
        }

    }

    /**
     * 代扣前1天提醒用户还款,发送站内信
     */
    public void remindsendInnerLetterRepaymentToUserBeforeOneDay() {
        List<RepayPlan> afterTodayOneDayRepayPlan = repayPlanMapper.queryTodayBeforeOneDayRepayPlan();
        if (CollectionUtil.isListNull(afterTodayOneDayRepayPlan)) {
            return;
        }
        for (RepayPlan repayPlan : afterTodayOneDayRepayPlan) {
            BigDecimal topayAllAmount = DecimalUtil.subtract(DecimalUtil.add(repayPlan.getDuePrincipal(), repayPlan.getDueInterest(), repayPlan.getDuePenalty()),
                    DecimalUtil.add(repayPlan.getRepaidInterest(), repayPlan.getRepaidPenalty(), repayPlan.getRepaidPrincipal()));
            AccountBankCardBind accountBankCardBind = accountBankCardBindService.queryDataByAccountId(repayPlan.getAccountId());
            if (accountBankCardBind != null) {
                NoticeBusinessMessageDto noticeBusinessMessageDto = new NoticeBusinessMessageDto();
                noticeBusinessMessageDto.setAccountId(repayPlan.getAccountId());
                noticeBusinessMessageDto.setMsgSubtype(MessagePushType.REPAYMENT_NOTICE_ONE_DAY.getKey());
                Map<String, String> paramMap = new HashMap<>();
                paramMap.put(RepaymentSendInnerLetterConstants.repay_amount, topayAllAmount.toString());
                paramMap.put(RepaymentSendInnerLetterConstants.account_card_no, accountBankCardBind.getBankCardNo().substring(accountBankCardBind.getBankCardNo().length() - 4, accountBankCardBind.getBankCardNo().length()));
                noticeBusinessMessageDto.setMap(paramMap);
                capitalMQProducerService.repaymentSendInnerLetterNotity(noticeBusinessMessageDto);

            }
        }
    }

    /**
     * 代扣前1天提醒用户还款和代扣前3天提醒用户还款,发送站内信
     */
    public void remindsendInnerLetterRepaymentToUserBeforeThreeDayOrOneDay() {
        remindsendInnerLetterRepaymentToUserBeforeThreeDay();
        remindsendInnerLetterRepaymentToUserBeforeOneDay();
    }

    /**
     * 逾期1天、2天、3天、4天、5天上午10点推送逾期提醒消息,发送站内信
     */
    public void remindsendInnerLetterOverdueRepaymentToUser() {
        List<RepayPlan> overdueInfiveDayRepayPlans = repayPlanMapper.queryOverdueInfiveDayRepayPlan();
        if (CollectionUtil.isListNotNull(overdueInfiveDayRepayPlans)) {
            for (RepayPlan repayPlan : overdueInfiveDayRepayPlans) {
                BigDecimal benxi = DecimalUtil.subtract(DecimalUtil.add(repayPlan.getDuePrincipal(), repayPlan.getDueInterest()),
                        DecimalUtil.add(repayPlan.getRepaidInterest(), repayPlan.getRepaidPrincipal()));
                BigDecimal duePenalty = DecimalUtil.subtract(repayPlan.getDuePenalty(), repayPlan.getRepaidPenalty());
                AccountBankCardBind accountBankCardBind = accountBankCardBindService.queryDataByAccountId(repayPlan.getAccountId());
                if (accountBankCardBind != null) {
                    NoticeBusinessMessageDto noticeBusinessMessageDto = new NoticeBusinessMessageDto();
                    noticeBusinessMessageDto.setAccountId(repayPlan.getAccountId());
                    noticeBusinessMessageDto.setMsgSubtype(MessagePushType.OVERDUE_NOTICE.getKey());
                    Map<String, String> paramMap = new HashMap<>();
                    paramMap.put(RepaymentSendInnerLetterConstants.benxi, benxi.toString());
                    paramMap.put(RepaymentSendInnerLetterConstants.due_penalty, duePenalty.toString());
                    paramMap.put(RepaymentSendInnerLetterConstants.term_no, repayPlan.getTermNo().toString());
                    paramMap.put(RepaymentSendInnerLetterConstants.total_term, repayPlan.getTotalTerm().toString());
                    paramMap.put(RepaymentSendInnerLetterConstants.overdue_days, String.valueOf(DateUtil.getTimeDiffOfDays(repayPlan.getAgreedRepayDate(), new Date())));
                    noticeBusinessMessageDto.setMap(paramMap);
                    capitalMQProducerService.repaymentSendInnerLetterNotity(noticeBusinessMessageDto);
                }
            }

        }

    }

}
