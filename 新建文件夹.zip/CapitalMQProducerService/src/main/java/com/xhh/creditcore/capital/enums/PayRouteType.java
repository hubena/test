package com.xhh.creditcore.capital.enums;

/**
 * 支付路由类型
 */
public enum PayRouteType {
    PAY(1, "代付相关路由"),
    REPAY(2, "代扣相关路由"),
    SIGN(3, "签名鉴权相关路由");
    private Integer key;
    private String  desc;

    public Integer getKey() {
        return key;
    }

    public String getDesc() {
        return desc;
    }

    PayRouteType(Integer key, String desc) {
        this.key = key;
        this.desc = desc;
    }

    public static PayRouteType getInstance(Integer key) {
        for (PayRouteType repayType : PayRouteType.values()) {
            if (repayType.key.equals(key)) {
                return repayType;
            }
        }
        return null;
    }
}
