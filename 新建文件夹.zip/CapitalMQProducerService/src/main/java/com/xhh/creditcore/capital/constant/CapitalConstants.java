package com.xhh.creditcore.capital.constant;

import java.math.BigDecimal;

/**
 * 类CapitalConstants.java的实现描述
 *
 * @author xiehuang 2016年7月27日 上午11:52:59
 */
public interface CapitalConstants {

    /**
     * 资金平台借款交易业务编码
     */
    String  capital_loan_biz_code     = "14";

    /**
     * 资金平台还款交易业务编码
     */
    String  capital_repay_biz_code    = "13";

    /**
     * 资金平台代付服务费业务编码
     */
    String  capital_pay_fee_biz_code  = "20";

    /**
     * 资金平台认证支付费业务编码
     */
    String  capital_cert_pay_biz_code = "21";

    /**
     * 产品费用 金额区间分隔符
     */
    String  amount_range_separator    = "-";

    /**
     * 产品费用 利息年化率 费用编码
     */
    String  interest_rate_fee_code    = "interest_rate";

    /**
     * 保留小数位数
     */
    int     scale                     = 2;
    /**
     * 向上取整
     */
    int     round                     = BigDecimal.ROUND_UP;
    /**
     * 360
     */
    int     year_day                  = 360;
    /**
     * 12
     */
    int     year_month                = 12;
    /**
     * 期限天 默认期数
     */
    Integer one_term                  = 1;

    /**
     * 鉴权订单号前缀
     */
    String  BANK_AUTH                 = "BANK_AUTH";

    /**
     * 收取模式
     */
    String  loan_fee_charge_pattern   = "loan_fee_charge_pattern";
}
