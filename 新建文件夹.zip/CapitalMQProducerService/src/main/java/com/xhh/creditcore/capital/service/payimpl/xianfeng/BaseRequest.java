package com.xhh.creditcore.capital.service.payimpl.xianfeng;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Maps;
import com.janty.core.exception.SystemException;
import com.ucf.sdk.UcfForOnline;
import com.ucf.sdk.util.AESCoder;
import com.xhh.creditcore.capital.pay.MerchantInfo;

/**
 * 2017-12-18
 *
 * @author zhangweixin
 */
public abstract class BaseRequest {
    private static Logger       logger       = LoggerFactory.getLogger(BaseRequest.class);
    // 签名算法
    private final String        secId        = XianFengConfig.getXianFengConfig().SEC_ID;
    // 服务
    private String              service;
    // 版本号
    private String              version;
    // 请求序列号
    private String              reqSn;

    private Map<String, String> requestData  = Maps.newHashMap();
    private MerchantInfo        merchantInfo;
    private ObjectMapper        objectMapper = new ObjectMapper();

    /**
     * @param service 服务名称
     * @param version 服务版本
     * @param merchantInfo 商户信息
     */
    public BaseRequest(String service, String version, MerchantInfo merchantInfo) {
        this.service = service;
        this.version = version;
        this.reqSn = RequestNoGenerator.getGenerator().generatorOrderNo("XF");
        this.merchantInfo = merchantInfo;
    }

    public String getMerRSAKey() {
        return merchantInfo.getSecretKey();
    }

    public String getService() {
        return service;
    }

    public String getVersion() {
        return version;
    }

    public String getReqSn() {
        return reqSn;
    }

    public String getSecId() {
        return secId;
    }

    public String getMerchantId() {
        return merchantInfo.getMerchantId();
    }

    private Map<String, String> getSignData() throws Exception {
        Map<String, String> signData = new HashMap<>();
        signData.put("secId", secId);
        signData.put("merchantId", getMerchantId());
        signData.put("service", service);
        signData.put("version", version);
        signData.put("reqSn", reqSn);
        if (!CollectionUtils.isEmpty(getSubClassSignData())) {
            signData.putAll(getSubClassSignData());
        }

        if (!CollectionUtils.isEmpty(getBusinessData())) {
            String jsonData = businessDataToJson();
            logger.info("先锋支付请求传递的加密业务数据:{}", jsonData);
            signData.put("data", encryptData(jsonData));
        }
        return signData;
    }

    public final void executeSign() {
        try {
            Map<String, String> signData = getSignData();
            String sign = UcfForOnline.createSign(getMerRSAKey(), "sign", signData, secId);
            requestData.clear();
            requestData.put("sign", sign);
            requestData.putAll(signData);
        } catch (Exception e) {
            throw new SystemException("签名失败", e);
        }
    }

    public String baseRequestDatatoJson() throws Exception {
        return objectMapper.writeValueAsString(requestData);
    }

    public String businessDataToJson() throws JsonProcessingException {
        return objectMapper.writeValueAsString(getBusinessData());
    }

    private String encryptData(String jsonData) throws Exception {
        return AESCoder.encrypt(jsonData, getMerRSAKey());
    }

    /**
     * 获取需要加密的业务数据
     *
     * @return
     */
    abstract public Map<String, String> getBusinessData();

    /**
     * 子请求需要直接参与签名的数据
     *
     * @return
     */
    abstract protected Map<String, String> getSubClassSignData();
}
