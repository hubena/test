package com.xhh.creditcore.capital.service;

import com.xhh.creditcore.capital.dao.PassageAccountMapper;
import com.xhh.creditcore.capital.model.PassageAccount;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * PassageAccount服务类
 *
 * @author jan
 * @date 2018-1-18 17:29:18
 */
@Service("passageAccountService")
public class PassageAccountService {
    @Resource
    private PassageAccountMapper passageAccountMapper;

    /**
     * 根据id查询数据
     *
     * @param id 实体id
     * @return 实体
     */
    public PassageAccount queryDataById(long id) {
        return null;
    }

    /**
     * 新增数据
     *
     * @param record 实体
     */
    public void addData(PassageAccount record) {

    }

    /**
     * 修改数据
     *
     * @param record 实体
     */
    public void modifyData(PassageAccount record) {

    }

    /**
     * 删除数据
     *
     * @param record 实体
     */
    public void deleteData(PassageAccount record) {

    }

    public PassageAccount queryDataByAccountCode(PassageAccount record) {
        return passageAccountMapper.queryDataByAccountCode(record.getAccountCode());
    }
}
