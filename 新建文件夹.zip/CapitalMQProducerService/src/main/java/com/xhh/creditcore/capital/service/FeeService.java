package com.xhh.creditcore.capital.service;

import com.janty.cached.access.RedisCachedAccess;
import com.janty.core.exception.BusinessException;
import com.xhh.creditcore.capital.constant.CapitalErrorCode;
import com.xhh.creditcore.capital.constant.CapitalRedisKey;
import com.xhh.creditcore.capital.enums.PayOrderStatus;
import com.xhh.creditcore.capital.enums.PayOrderTransType;
import com.xhh.creditcore.capital.model.PayOrder;
import com.xhh.creditcore.capital.pay.PayNoticeHandlerRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

/**
 * zhangweixin 2018-02-27
 */
@Service
public class FeeService {

    private static Logger             logger = LoggerFactory.getLogger(FeeService.class);

    @Resource
    private PayOrderService           payOrderService;
    @Resource
    private RedisCachedAccess<String> cachedAccess;

    public void payFee() {
        List<PayOrder> payOrderList = payOrderService.queryNeedProcessPayOrder();
        payOrderList.forEach(payOrder -> {
            String lockKey = CapitalRedisKey.LOCK_PREFIX + payOrder.getOrderNo();
            try {
                cachedAccess.tryLock(lockKey, 1000 * 30L);
                payOrderService.procerssWaittingPayOrder(payOrder);
            } catch (Exception e) {
                logger.error("代付手续费失败:" + payOrder.getOrderNo(), e);
            } finally {
                cachedAccess.releaseLock(lockKey);
            }
        });
    }

    /**
     * 代付服务费成功异步通知
     *
     * @param handlerRequest {@link PayNoticeHandlerRequest}
     */
    public void payFeeSucessHandle(PayNoticeHandlerRequest handlerRequest) {
        PayOrder payOrder = payOrderService.queryDataByRelateTranNoAndTranType(handlerRequest.getOrderNo(), PayOrderTransType.LOAN_PAY_FEE.getKey());
        if (payOrder == null) {
            throw new BusinessException(new CapitalErrorCode(CapitalErrorCode.Element.b_pay_fee_order_no_not_exist));
        }

        if (!PayOrderStatus.SUCEESS.getKey().equals(payOrder.getStatus())) {
            payOrder.setThirdOrderNo(handlerRequest.getThirdOrderNo());
            payOrder.setStatus(PayOrderStatus.SUCEESS.getKey());
            payOrder.setGmtModified(new Date());
            payOrderService.updateStatusForPayNotice(payOrder);
        } else {
            logger.info("订单号:{},异步回调成功已经处理忽略执行", payOrder.getOrderNo());
        }

    }

    /**
     * 代付服务费失败异步通知
     *
     * @param handlerRequest
     */
    public void payFeeFailHandle(PayNoticeHandlerRequest handlerRequest) {
        PayOrder payOrder = payOrderService.queryDataByRelateTranNoAndTranType(handlerRequest.getOrderNo(), PayOrderTransType.LOAN_PAY_FEE.getKey());
        if (payOrder == null) {
            throw new BusinessException(new CapitalErrorCode(CapitalErrorCode.Element.b_pay_fee_order_no_not_exist));
        }

        if (PayOrderStatus.PROCESSING.getKey().equals(payOrder.getStatus())) {
            payOrder.setThirdOrderNo(handlerRequest.getThirdOrderNo());
            payOrder.setStatus(PayOrderStatus.FAIL.getKey());
            payOrder.setGmtModified(new Date());
            payOrderService.updateStatusForPayNotice(payOrder);
        } else {
            logger.info("订单号:{},异步回调失败已经处理忽略执行", payOrder.getOrderNo());
        }
    }
}
