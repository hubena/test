package com.xhh.creditcore.capital.dao;

import com.xhh.creditcore.capital.model.BankCardbin;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface BankCardbinMapper {
    int deleteByPrimaryKey(Long id);

    int insert(BankCardbin record);

    int insertSelective(BankCardbin record);

    BankCardbin selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(BankCardbin record);

    int updateByPrimaryKey(BankCardbin record);

    List<BankCardbin> selectByCardBin(Map<String, String> map);
}
