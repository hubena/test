package com.xhh.creditcore.capital.pay;

/**
 * 支付回调请求 zhangweixin 2018-01-17
 */
public class PayNoticeHandlerRequest extends BasePayRequest {
    /**
     * 订单号
     */
    private String orderNo;
    /*
     * 支付平台订单号
     */
    private String thirdOrderNo;
    /**
     * 第三方返回码
     */
    private String thirdResCode;
    /**
     * 第三方返回消息
     */
    private String thirdResMsg;

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getThirdOrderNo() {
        return thirdOrderNo;
    }

    public void setThirdOrderNo(String thirdOrderNo) {
        this.thirdOrderNo = thirdOrderNo;
    }

    public String getThirdResCode() {
        return thirdResCode;
    }

    public void setThirdResCode(String thirdResCode) {
        this.thirdResCode = thirdResCode;
    }

    public String getThirdResMsg() {
        return thirdResMsg;
    }

    public void setThirdResMsg(String thirdResMsg) {
        this.thirdResMsg = thirdResMsg;
    }

    @Override
    public String toString() {
        return "PayNoticeHandlerRequest{" + "orderNo='" + orderNo + '\'' + ", thirdOrderNo='" + thirdOrderNo + '\'' + ", thirdResCode='" + thirdResCode + '\''
                + ", thirdResMsg='" + thirdResMsg + '\'' + '}';
    }
}
