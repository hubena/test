package com.xhh.creditcore.capital.service.payimpl.xianfeng;

import java.util.HashMap;
import java.util.Map;

import com.xhh.creditcore.capital.pay.MerchantInfo;

/**
 * 2017-12-29
 *
 * @author zhangweixin
 */
public class CertPayConfirmPayRequest extends BaseRequest {
    private Map<String, String> signData     = new HashMap<>();
    private Map<String, String> businessData = new HashMap<>();

    public CertPayConfirmPayRequest(MerchantInfo merchantInfo) {
        super("MOBILE_CERTPAY_API3_CONFIRM_PAY", "4.0.0", merchantInfo);
        businessData.put("methodVer", "3.0");
        signData.put("merchantId", merchantInfo.getMerchantId());
    }

    /**
     * 设置订单号
     * 
     * @param outOrderId
     */
    public void setOutOrderId(String outOrderId) {
        businessData.put("outOrderId", outOrderId);
    }

    /**
     * 设置验证码
     * 
     * @param smsCode
     */
    public void setSmsCode(String smsCode) {
        businessData.put("smsCode", smsCode);
    }

    @Override
    public Map<String, String> getBusinessData() {
        return businessData;
    }

    @Override
    protected Map<String, String> getSubClassSignData() {
        return signData;
    }
}
