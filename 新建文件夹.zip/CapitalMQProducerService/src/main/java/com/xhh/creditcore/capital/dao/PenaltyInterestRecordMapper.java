package com.xhh.creditcore.capital.dao;

import org.springframework.stereotype.Repository;

import com.xhh.creditcore.capital.model.PenaltyInterestRecord;

@Repository
public interface PenaltyInterestRecordMapper {
    int deleteByPrimaryKey(Long id);

    int insert(PenaltyInterestRecord record);

    int insertSelective(PenaltyInterestRecord record);

    PenaltyInterestRecord selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(PenaltyInterestRecord record);

    int updateByPrimaryKey(PenaltyInterestRecord record);

    PenaltyInterestRecord selectLastestDataByPlanId(Long repayPlanId);
}
