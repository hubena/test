package com.xhh.creditcore.capital.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * <p>
 * 还款计划变更流水表
 * </p>
 *
 * @author nathaniel123
 * @since 2018-01-09
 */

public class RepayPlanRecord implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long              id;
    /**
     * 产品账户id
     */
    private Long              accountId;
    /**
     * 还款计划id
     */
    private Long              repayPlanId;
    /**
     * 发生金额
     */
    private BigDecimal        amount;
    /**
     * 发生金额类型：1本金、2利息、3罚息、4服务费
     */
    private String            amountType;
    /**
     * 发生金额方向：1增加、2冲销、3减免
     */
    private Integer           amountDirection;
    /**
     * 关联交易流水号（还款等）
     */
    private String            transNo;
    /**
     * 交易类型：1借款、2还款、3罚息
     */
    private Integer           transType;
    /**
     * 交易时间
     */
    private Date              transTime;
    /**
     * 创建时间
     */
    private Date              gmtCreated;
    /**
     * 最后修改时间
     */
    private Date              gmtModified;
    /**
     * 创建人
     */
    private String            creator;
    /**
     * 最后修改人
     */
    private String            modifier;
    /**
     * 删除标志位 N-未删除 Y-已删除
     */
    private String            isDeleted;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getAccountId() {
        return accountId;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public Long getRepayPlanId() {
        return repayPlanId;
    }

    public void setRepayPlanId(Long repayPlanId) {
        this.repayPlanId = repayPlanId;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getAmountType() {
        return amountType;
    }

    public void setAmountType(String amountType) {
        this.amountType = amountType;
    }

    public Integer getAmountDirection() {
        return amountDirection;
    }

    public void setAmountDirection(Integer amountDirection) {
        this.amountDirection = amountDirection;
    }

    public String getTransNo() {
        return transNo;
    }

    public void setTransNo(String transNo) {
        this.transNo = transNo;
    }

    public Integer getTransType() {
        return transType;
    }

    public void setTransType(Integer transType) {
        this.transType = transType;
    }

    public Date getTransTime() {
        return transTime;
    }

    public void setTransTime(Date transTime) {
        this.transTime = transTime;
    }

    public Date getGmtCreated() {
        return gmtCreated;
    }

    public void setGmtCreated(Date gmtCreated) {
        this.gmtCreated = gmtCreated;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public String getModifier() {
        return modifier;
    }

    public void setModifier(String modifier) {
        this.modifier = modifier;
    }

    public String getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(String isDeleted) {
        this.isDeleted = isDeleted;
    }

    @Override
    public String toString() {
        return "RepayPlanRecord{" + "id=" + id + ", accountId=" + accountId + ", repayPlanId=" + repayPlanId + ", amount=" + amount + ", amountType="
                + amountType + ", amountDirection=" + amountDirection + ", transNo=" + transNo + ", transType=" + transType + ", transTime=" + transTime
                + ", gmtCreated=" + gmtCreated + ", gmtModified=" + gmtModified + ", creator=" + creator + ", modifier=" + modifier + ", isDeleted=" + isDeleted
                + "}";
    }
}
