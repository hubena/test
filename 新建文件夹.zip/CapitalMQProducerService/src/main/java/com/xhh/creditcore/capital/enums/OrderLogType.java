package com.xhh.creditcore.capital.enums;

/**
 * zhangweixin 2018-01-10
 */
public enum OrderLogType {
    PAY(1, "借款"),
    REPAY(2, "还款");
    private Integer key;
    private String  desc;

    public Integer getKey() {
        return key;
    }

    public String getDesc() {
        return desc;
    }

    OrderLogType(Integer key, String desc) {
        this.key = key;
        this.desc = desc;
    }

    public static OrderLogType getInstance(Integer key) {
        for (OrderLogType orderLogType : OrderLogType.values()) {
            if (orderLogType.key.equals(key)) {
                return orderLogType;
            }
        }
        return null;
    }
}
