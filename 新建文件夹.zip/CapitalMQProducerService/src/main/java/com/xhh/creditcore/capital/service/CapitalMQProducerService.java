package com.xhh.creditcore.capital.service;

import javax.annotation.Resource;

import com.xhh.creditpre.cashloan.dto.NoticeBusinessMessageDto;
import org.springframework.stereotype.Service;

import com.janty.mq.rabbitmq.producer.Publisher;


@Service("transactionMQProducerService")
public class CapitalMQProducerService {

    @Resource
    private Publisher rabbitmqPublisher;

    public void repaymentSendInnerLetterNotity(NoticeBusinessMessageDto noticeBusinessMessageDto) {
        rabbitmqPublisher.sendTopicMsg("topic.bizname.common", noticeBusinessMessageDto);
    }

}
