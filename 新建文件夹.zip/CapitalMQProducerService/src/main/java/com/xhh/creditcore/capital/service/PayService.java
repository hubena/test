package com.xhh.creditcore.capital.service;

import com.xhh.creditcore.capital.enums.PayChannel;
import com.xhh.creditcore.capital.enums.PayType;
import com.xhh.creditcore.capital.pay.*;

/**
 * 内部系统支付接口 zhangweixin 2018-01-09
 */
public interface PayService {
    /**
     * 是否支持传递的支付方式
     *
     * @return
     */
    boolean supportPayType(PayType payType);

    /**
     * 是否支持传递的支付通道
     *
     * @param payChannel
     * @return
     */
    boolean supportPayChannel(PayChannel payChannel);

    /**
     * 是否是默认的支付通道
     *
     * @return
     */
    boolean isDefaultPayChannel();

    /**
     * 单笔代付接口
     *
     * @param request
     * @throws Exception
     */
    PayResult singlePay(PayRequest request);

    /**
     * 单笔对公代付接口
     * 
     * @param request
     * @return
     */
    PayResult singPayOfPublic(PayRequest request);

    /**
     * 单笔代扣接口
     *
     * @param request
     */
    PayResult singleDeduct(PayRequest request);

    /**
     * 单笔代付查询
     *
     * @param request
     * @return
     */
    PayResult singlePayQuery(PayRequest request);

    /**
     * 单笔代扣查询
     *
     * @param request
     */
    PayResult singleDeductOrderQuery(PayRequest request);

    /**
     * 单笔代付通知
     *
     * @param noticeRequest
     */
    void singlePayNotice(PayNoticeRequest noticeRequest);

    /**
     * 单笔代扣通知
     *
     * @param noticeRequest
     * @throws Exception
     */
    void singleDeductNotice(PayNoticeRequest noticeRequest) throws Exception;

    /**
     * 认证支付通知
     * 
     * @param noticeRequest
     */
    public void certPayNotice(PayNoticeRequest noticeRequest);

    /**
     * 银行卡鉴权接口
     *
     * @param request
     * @return
     * @throws Exception
     */
    PayResult bankCardAuth(PayRequest request) throws Exception;

    /**
     * 认证支付预支付接口(发短信)
     * 
     * @return
     * @throws Exception
     */
    PayResult certPayPrePay(PayRequest request);

    /**
     * 认证支付确认支付接口
     *
     * @return
     * @throws Exception
     */
    PayResult certPayConfirmPay(PayRequest request);

    /**
     * 认证支付重发短信(如果实现不支持这个接口调用预支付接口重发短信)
     * 
     * @param request
     * @return
     * @throws UnsupportedOperationException 如果实现不支持则抛出此异常
     */
    PayResult repeatSendSms(PayRequest request) throws UnsupportedOperationException;

    /**
     * 认证支付订单查询
     * 
     * @param request
     * @return
     */
    PayResult certPayOrderQuery(PayRequest request);

}
