package com.xhh.creditcore.capital.pay;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import com.xhh.creditcore.capital.constant.CapitalConstants;
import com.xhh.creditcore.capital.service.RepaymentService;

/**
 * 代扣本金回调业务通知处理<br>
 * zhangweixin 2018-01-18
 */
@Component("deductPrincipalNoticeHandler")
public class DeductPrincipalNoticeHandler extends PayNoticeHandlerAdaptor {
    @Resource
    private RepaymentService repaymentService;

    @Override
    public void deductSuccessHandle(PayNoticeHandlerRequest handlerRequest) {
        repaymentService.deductPrincipalSuccessHandle(handlerRequest);
    }

    @Override
    public void deductFailHandle(PayNoticeHandlerRequest handlerRequest) {
        repaymentService.deductPrincipalFailHandle(handlerRequest);
    }

    @Override
    public boolean isSupportOrderType(String orderNo) {
        return orderNo.startsWith(CapitalConstants.capital_repay_biz_code);
    }
}
