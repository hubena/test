package com.xhh.creditcore.capital.service;

import com.xhh.creditcore.capital.model.AccountBankCardBind;
import com.xhh.creditcore.capital.dao.AccountBankCardBindMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p>
 * 产品账户绑卡表，账户系统 服务实现类
 * </p>
 *
 * @author nathaniel123
 * @since 2018-01-09
 */
@Service("accountBankCardBindService")
public class AccountBankCardBindService {
    @Resource
    private AccountBankCardBindMapper accountbankcardbindmapper;

    /**
     * 根据id查询数据
     *
     * @param id 实体id
     * @return 实体
     */
    public AccountBankCardBind queryDataById(long id) {
        return null;
    }

    /**
     * 新增数据
     *
     * @param record 实体
     */
    public void addData(AccountBankCardBind record) {
        accountbankcardbindmapper.insert(record);
    }

    /**
     * 修改数据
     *
     * @param record 实体
     */
    public void modifyData(AccountBankCardBind record) {

    }

    /**
     * 删除数据
     *
     * @param record 实体
     */
    public void deleteData(AccountBankCardBind record) {

    }

    /**
     * 查询数据根据产品账户id
     *
     * @param accountId
     * @return
     */
    public AccountBankCardBind queryDataByAccountId(Long accountId) {
        AccountBankCardBind bankCardBind = new AccountBankCardBind();
        bankCardBind.setAccountId(accountId);
        List<AccountBankCardBind> accountBankCardBinds = accountbankcardbindmapper.selectByCondition(bankCardBind);
        if (!CollectionUtils.isEmpty(accountBankCardBinds)) {
            return accountBankCardBinds.get(0);
        }
        return null;

    }

    @Transactional(rollbackFor = Exception.class, timeout = 30)
    public void updateBankCardBindById(AccountBankCardBind accountBankCardBind) {
        accountbankcardbindmapper.updateBankCardBindById(accountBankCardBind);
    }
}
