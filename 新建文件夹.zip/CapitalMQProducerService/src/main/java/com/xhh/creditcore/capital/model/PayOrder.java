package com.xhh.creditcore.capital.model;

import java.math.BigDecimal;
import java.util.Date;

public class PayOrder {
    private Long       id;

    private String     relateTransNo;

    private Integer    transType;

    private Integer    payObjectType;

    private String     orderNo;

    private String     thirdOrderNo;

    private Integer    status;

    private BigDecimal amount;

    private String     payBankCardNo;

    private String     payName;

    private String     bankCode;

    private String     lianhanghao;

    private Date       gmtCreated;

    private Date       gmtModified;

    private String     creator;

    private String     modifier;

    private String     isDeleted;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getRelateTransNo() {
        return relateTransNo;
    }

    public void setRelateTransNo(String relateTransNo) {
        this.relateTransNo = relateTransNo == null ? null : relateTransNo.trim();
    }

    public Integer getTransType() {
        return transType;
    }

    public void setTransType(Integer transType) {
        this.transType = transType;
    }

    public Integer getPayObjectType() {
        return payObjectType;
    }

    public void setPayObjectType(Integer payObjectType) {
        this.payObjectType = payObjectType;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo == null ? null : orderNo.trim();
    }

    public String getThirdOrderNo() {
        return thirdOrderNo;
    }

    public void setThirdOrderNo(String thirdOrderNo) {
        this.thirdOrderNo = thirdOrderNo == null ? null : thirdOrderNo.trim();
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getPayBankCardNo() {
        return payBankCardNo;
    }

    public void setPayBankCardNo(String payBankCardNo) {
        this.payBankCardNo = payBankCardNo == null ? null : payBankCardNo.trim();
    }

    public String getPayName() {
        return payName;
    }

    public void setPayName(String payName) {
        this.payName = payName == null ? null : payName.trim();
    }

    public String getBankCode() {
        return bankCode;
    }

    public void setBankCode(String bankCode) {
        this.bankCode = bankCode == null ? null : bankCode.trim();
    }

    public String getLianhanghao() {
        return lianhanghao;
    }

    public void setLianhanghao(String lianhanghao) {
        this.lianhanghao = lianhanghao == null ? null : lianhanghao.trim();
    }

    public Date getGmtCreated() {
        return gmtCreated;
    }

    public void setGmtCreated(Date gmtCreated) {
        this.gmtCreated = gmtCreated;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator == null ? null : creator.trim();
    }

    public String getModifier() {
        return modifier;
    }

    public void setModifier(String modifier) {
        this.modifier = modifier == null ? null : modifier.trim();
    }

    public String getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(String isDeleted) {
        this.isDeleted = isDeleted == null ? null : isDeleted.trim();
    }

    @Override
    public String toString() {
        return "PayOrder{" + "id=" + id + ", relateTransNo='" + relateTransNo + '\'' + ", transType=" + transType + ", payObjectType=" + payObjectType
                + ", orderNo='" + orderNo + '\'' + ", thirdOrderNo='" + thirdOrderNo + '\'' + ", status=" + status + ", amount=" + amount + ", payBankCardNo='"
                + payBankCardNo + '\'' + ", payName='" + payName + '\'' + ", bankCode='" + bankCode + '\'' + ", lianhanghao='" + lianhanghao + '\''
                + ", gmtCreated=" + gmtCreated + ", gmtModified=" + gmtModified + ", creator='" + creator + '\'' + ", modifier='" + modifier + '\''
                + ", isDeleted='" + isDeleted + '\'' + '}';
    }
}
