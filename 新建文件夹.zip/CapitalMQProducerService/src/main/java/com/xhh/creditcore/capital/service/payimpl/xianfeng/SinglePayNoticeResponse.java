package com.xhh.creditcore.capital.service.payimpl.xianfeng;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.janty.core.exception.SystemException;

/**
 * @author zhangwexin
 */
public class SinglePayNoticeResponse extends NoticeBaseResponse {
    private String transCur;
    private String tradeTime;
    private String amount;

    public String getTransCur() {
        return transCur;
    }

    public void setTransCur(String transCur) {
        this.transCur = transCur;
    }

    public String getTradeTime() {
        return tradeTime;
    }

    public void setTradeTime(String tradeTime) {
        this.tradeTime = tradeTime;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    @Override
    public String toJson() {
        try {
            return new ObjectMapper().writeValueAsString(this);
        } catch (Exception e) {
            throw new SystemException("序列化" + SingleDeductNotifyResponse.class.getSimpleName(), e);
        }
    }
}
