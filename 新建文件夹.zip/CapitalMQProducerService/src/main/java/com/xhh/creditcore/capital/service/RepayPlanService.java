package com.xhh.creditcore.capital.service;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.janty.core.util.DateUtil;
import com.janty.core.util.DecimalUtil;
import com.xhh.creditcore.capital.constant.PenaltyAmount;
import com.xhh.creditcore.capital.dao.RepayPlanMapper;
import com.xhh.creditcore.capital.enums.CapitalLoanTransStatus;
import com.xhh.creditcore.capital.enums.RepayPlanAmountDirection;
import com.xhh.creditcore.capital.enums.RepayPlanRecordAmountType;
import com.xhh.creditcore.capital.enums.RepayPlanRecordTransType;
import com.xhh.creditcore.capital.enums.RepayPlanStatus;
import com.xhh.creditcore.capital.model.CapitalLoanTrans;
import com.xhh.creditcore.capital.model.PenaltyInterestRecord;
import com.xhh.creditcore.capital.model.RepayPlan;
import com.xhh.creditcore.capital.model.RepayPlanRecord;
import com.xhh.creditcore.capital.service.remote.ProductRemoteService;

/**
 * <p>
 * 还款计划 服务实现类
 * </p>
 *
 * @author nathaniel123
 * @since 2018-01-09
 */
@Service("repayPlanService")
@Lazy
public class RepayPlanService {
    @Resource
    private RepayPlanMapper              repayPlanMapper;
    @Resource
    private ProductRemoteService         productRemoteService;
    @Resource
    private RepayPlanRecordService       repayPlanRecordService;
    @Resource
    private PenaltyInterestRecordService penaltyInterestRecordService;

    @Resource
    private CapitalLoanTransService      capitalLoanTransService;
    @Resource
    private RepayPlanService             repayPlanService;

    /**
     * 根据id查询数据
     *
     * @param id 实体id
     * @return 实体
     */
    public RepayPlan queryDataById(Long id) {
        return repayPlanMapper.selectByPrimaryKey(id);
    }

    /**
     * 新增数据
     *
     * @param record 实体
     */
    public void addData(RepayPlan record) {

        repayPlanMapper.insertSelective(record);
    }

    /**
     * 修改数据
     *
     * @param record 实体
     */
    public void modifyData(RepayPlan record) {

    }

    /**
     * 删除数据
     *
     * @param record 实体
     */
    public void deleteData(RepayPlan record) {

    }

    /**
     * 根据借贷交易流水查询当前需要还款的还款计划
     *
     * @param capitalLoanTransNo
     */
    public RepayPlan queryCurrentVaildRepayPlan(String capitalLoanTransNo) {
        RepayPlan repayPlan = new RepayPlan();
        repayPlan.setCapitalLoanTransNo(capitalLoanTransNo);
        return repayPlanMapper.selectCurrentVaildRepayPlan(repayPlan);
    }

    /**
     * 还款成功更新还款计划数据
     *
     * @param record
     */
    public void updateDataForRepaySuccess(RepayPlan record) {
        repayPlanMapper.updateDataForRepaySuccess(record);
    }

    /**
     * 根据借贷流水号查询ALL还款计划
     *
     * @param capitalLoanTransNo
     * @return
     */
    public List<RepayPlan> queryAllPlanByTransNo(String capitalLoanTransNo) {
        RepayPlan repayPlan = new RepayPlan();
        repayPlan.setCapitalLoanTransNo(capitalLoanTransNo);
        return repayPlanMapper.queryAllPlanByTransNo(repayPlan);
    }

    /**
     * 根据产品码查询所有到期还款计划(到达约定还款日或者逾期的还款计划)
     *
     * @param productCode
     * @return
     */
    public List<RepayPlan> queryExpireRepayPlanByProductCode(String productCode) {
        RepayPlan repayPlan = new RepayPlan();
        repayPlan.setProductCode(productCode);
        return repayPlanMapper.queryExpireRepayPlanByProductCode(repayPlan);
    }

    /**
     * 修改逾期罚息 due_penalty
     *
     * @param plan
     */
    public void modifyPenalty(RepayPlan plan) {
        repayPlanMapper.updatePenalty(plan);
    }

    /**
     * 根据还款计划状态查询
     *
     * @return
     */
    @Transactional(readOnly = true)
    public List<RepayPlan> queryOverdueList() {
        return repayPlanMapper.selectByStatus(Integer.valueOf(RepayPlanStatus.OVERDUED.getKey()));
    }

    /**
     * 根据超过时间（逾期）查询
     *
     * @return
     */
    public List<RepayPlan> queryListBeyondTime() {
        return repayPlanMapper.selectListBeyondTime();
    }

    /**
     * 更新id记录状态为已逾期
     *
     * @param repayPlan
     */
    public void modifyToOverdueById(RepayPlan repayPlan) {
        repayPlan.setStatus(RepayPlanStatus.OVERDUED.getKey());
        repayPlanMapper.updateStatusById(repayPlan);
    }

    /**
     * 更新逾期状态
     */
    public void overdued() {
        List<RepayPlan> repayList = queryListBeyondTime();
        if (CollectionUtils.isEmpty(repayList)) {
            return;
        }
        RepayPlan plan = null;
        CapitalLoanTrans loan = null;
        for (int i = 0; i < repayList.size(); i++) {
            plan = repayList.get(i);
            loan = new CapitalLoanTrans();
            loan.setCapitalLoanTransNo(plan.getCapitalLoanTransNo());
            repayPlanService.overduedTras(plan, loan);
        }
    }

    @Transactional(rollbackFor = Exception.class, timeout = 30)
    public void overduedTras(RepayPlan plan, CapitalLoanTrans loan) {
        modifyToOverdueById(plan);
        loan.setStatus(CapitalLoanTransStatus.ORVER_DUE.getKey());
        capitalLoanTransService.updateToOverdueByNo(loan);
    }

    /**
     * 更新最新罚息数据
     */
    public void lastestPenalty() {
        List<RepayPlan> repayList = repayPlanService.queryOverdueList();
        if (CollectionUtils.isEmpty(repayList)) {
            return;
        }
        RepayPlan plan = null;
        Date now = null;
        RepayPlanRecord planRecord = null;
        PenaltyInterestRecord newPenaltyRecord = null;
        PenaltyInterestRecord lastestPenaltyRecord = null;

        for (int i = 0; i < repayList.size(); i++) {
            plan = repayList.get(i);
            lastestPenaltyRecord = penaltyInterestRecordService.queryLastestDataByPlanId(plan.getId());
            BigDecimal calcDuePenalty = calcDuePenalty(plan, lastestPenaltyRecord);
            if (DecimalUtil.greaterThanZero(calcDuePenalty)) {
                now = new Date();
                planRecord = new RepayPlanRecord();
                planRecord.setAccountId(plan.getAccountId());
                planRecord.setRepayPlanId(plan.getId());
                planRecord.setAmount(calcDuePenalty);
                planRecord.setAmountType(RepayPlanRecordAmountType.PENALTY.getKey());
                planRecord.setAmountDirection(RepayPlanAmountDirection.ADD.getKey());
                planRecord.setTransNo(plan.getCapitalLoanTransNo());
                planRecord.setTransType(RepayPlanRecordTransType.PENALTY.getKey());
                planRecord.setGmtCreated(now);

                newPenaltyRecord = new PenaltyInterestRecord();
                newPenaltyRecord.setRepayPlanId(plan.getId());
                newPenaltyRecord.setPenaltyInterestDate(DateUtil.dateToString(now, DateUtil.format_date));
                newPenaltyRecord.setPenaltyInterestAmount(calcDuePenalty);
                newPenaltyRecord.setGmtCreated(now);
                if (lastestPenaltyRecord != null) {
                    newPenaltyRecord.setPenaltyInterestTotalAmount(lastestPenaltyRecord.getPenaltyInterestTotalAmount().add(calcDuePenalty));
                } else {
                    newPenaltyRecord.setPenaltyInterestTotalAmount(calcDuePenalty);
                }
                
                plan.setDuePenalty(newPenaltyRecord.getPenaltyInterestTotalAmount().setScale(PenaltyAmount.SCALE, PenaltyAmount.ROUND));
                
                repayPlanService.lastestPenaltyTranc(planRecord, newPenaltyRecord, plan);
            }
        }
    }

    /**
     * 更新最新罚息数据 事务
     *
     * @param plan
     * @param newPenaltyRecord
     * @param planRecord
     */
    @Transactional(rollbackFor = Exception.class, timeout = 30)
    public void lastestPenaltyTranc(RepayPlanRecord planRecord, PenaltyInterestRecord newPenaltyRecord, RepayPlan plan) {
        repayPlanRecordService.addData(planRecord);
        penaltyInterestRecordService.addData(newPenaltyRecord);
        modifyPenalty(plan);
    }

    /**
     * 一天的逾期罚息 = （本金+利息）* 逾期罚息利率/360 保留四位有效小数，第五位小数向上取整
     *
     * @param plan
     * @return
     */
    private BigDecimal calcDuePenalty(RepayPlan plan, PenaltyInterestRecord penaltyRecord) {
        BigDecimal result = DecimalUtil.ZERO;
        Date rapayLastestDate = null;
        if (penaltyRecord != null) {
            rapayLastestDate = DateUtil.stringToDate(penaltyRecord.getPenaltyInterestDate(), DateUtil.format_date);
        } else {
            rapayLastestDate = plan.getAgreedRepayDate();
        }

        Date now = new Date();
        int intervalDay = getTimeDiffOfDays(rapayLastestDate, now);
        if (intervalDay > 0) {
            CapitalLoanTrans loan = capitalLoanTransService.queryDataByCapitalNo(plan.getCapitalLoanTransNo());
            BigDecimal penaltyInterestRate = loan.getPenaltyInterestRate();
            BigDecimal duePrincipal = plan.getDuePrincipal();
            BigDecimal dueInterest = plan.getDueInterest();
            result = DecimalUtil.multiply(DecimalUtil.add(duePrincipal, dueInterest), penaltyInterestRate, new BigDecimal(intervalDay))
                    .divide(new BigDecimal(PenaltyAmount.YEAR_DAY_COUNT), PenaltyAmount.HIGH_SCALE, PenaltyAmount.ROUND);
        }
        return result;
    }

    public int getTimeDiffOfDays(Date beforeDate, Date now) {
        long beforeTime = beforeDate.getTime();
        long nowTime = now.getTime();
        if(beforeTime >= nowTime) {
            return 0;
        }
        return (int) ((nowTime - beforeTime) / (1000*60*60*24));
    }

    public List<RepayPlan> queryRepayPlan(RepayPlan repayPlan) {
        return repayPlanMapper.selectByCondition(repayPlan);
    }

}
