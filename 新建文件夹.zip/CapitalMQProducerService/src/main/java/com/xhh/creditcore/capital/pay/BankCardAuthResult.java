package com.xhh.creditcore.capital.pay;

/**
 * 银行卡鉴权响应 zhangweixin 2018-01-12
 */
public abstract class BankCardAuthResult<T> {
    //响应码
    private String resCode;
    //响应消息
    private String resMsg;

    //附加数据
    private T      extendData;

    public String getResCode() {
        return resCode;
    }

    public void setResCode(String resCode) {
        this.resCode = resCode;
    }

    public String getResMsg() {
        return resMsg;
    }

    public void setResMsg(String resMsg) {
        this.resMsg = resMsg;
    }

    public T getExtendData() {
        return extendData;
    }

    public void setExtendData(T extendData) {
        this.extendData = extendData;
    }

    //是否成功
    public abstract boolean isSuccess();

}
