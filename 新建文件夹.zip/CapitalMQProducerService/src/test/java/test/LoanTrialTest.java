package test;

import java.math.BigDecimal;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.xhh.creditcore.capital.dto.CapitalLoanRequest;
import com.xhh.creditcore.capital.dto.LoanTrialDto;
import com.xhh.creditcore.capital.service.CapitalLoanTransService;
import com.xhh.creditcore.capital.service.LoanTrialService;
import com.xhh.creditcore.capital.service.RepayPlanService;

import base.BaseJUnitTest;

public class LoanTrialTest extends BaseJUnitTest {

    @Autowired
    private LoanTrialService loanTrialService;

    //    @Autowired
    //    private CapitalLoanTransService capitalLoanTransService;

    @Test
    public void calcLoan() {
        CapitalLoanRequest request = new CapitalLoanRequest();
        request.setProductCode("100001");
        request.setAccountId(1L);
        request.setLoanAmount(new BigDecimal(1000));
        request.setRepayPattern("2");
        request.setTermUnit(1);
        request.setTotalTerm(3);
        //测试数据
        LoanTrialDto loanTrialDto = loanTrialService.calcLoan(request);
        System.out.println(loanTrialDto);
    }
}
