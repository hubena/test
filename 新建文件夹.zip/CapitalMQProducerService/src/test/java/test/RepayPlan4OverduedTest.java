package test;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.xhh.creditcore.capital.service.RepayPlanService;

import base.BaseJUnitTest;

public class RepayPlan4OverduedTest extends BaseJUnitTest {

    @Autowired
    private RepayPlanService repayPlanService;

    @Test
    public void overdued() {
        repayPlanService.overdued();
    }

    @Test
    public void lastestPenalty() {
        repayPlanService.lastestPenalty();
    }
}
