package test;

import com.janty.core.util.DateUtil;
import org.junit.Test;

import java.time.LocalDate;
import java.util.Date;

public class DateTest {

    @Test
    public void testDate() {
        System.out.println(LocalDate.parse(DateUtil.dateToString(new Date(), "yyyy-MM-dd")));


        LocalDate date1 = LocalDate.parse("2017-12-31");
        LocalDate now = LocalDate.now();
        System.out.println(now.toEpochDay()-date1.toEpochDay());
    }
}
