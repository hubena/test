package test;

import base.BaseJUnitTest;
import com.xhh.creditcore.capital.enums.PayMerchantType;
import com.xhh.creditcore.capital.pay.MerchantInfo;
import com.xhh.creditcore.capital.pay.PayNoticeHandlerRequest;
import com.xhh.creditcore.capital.pay.PayRequest;
import com.xhh.creditcore.capital.pay.PayResult;
import com.xhh.creditcore.capital.service.RepaymentService;
import com.xhh.creditcore.capital.service.payimpl.xianfeng.XianFengPayService;
import com.xhh.creditcore.capital.service.remote.TransactionRemoteService;
import com.xhh.creditcore.transaction.dto.LoanSettleRequest;
import org.junit.Test;

import javax.annotation.Resource;

public class XianFengTest extends BaseJUnitTest {
    @Resource
    XianFengPayService       payService;

    @Resource
    TransactionRemoteService transactionRemoteService;

    @Resource
    RepaymentService         repaymentService;

    @Test
    public void testDeduct() {
        PayRequest request = new PayRequest();
        request.setBankCode("BOCOM");
        request.setAccountName("张维新");
        request.setAmount(12d);
        request.setBankCardNo("6222528888888888");
        request.setCertNo("610323199107016810");
        request.setCapitalOrderNo("test1234566654523427");
        request.setProductCode("100001");
        request.setPayMerchantType(PayMerchantType.PRINCIPAL_REPAY);
        MerchantInfo merchantInfo = new MerchantInfo();
        merchantInfo.setSecretKey(
                "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQChFetx5+VKDoEXzZ+5Wozt3MfWMM/TiKMlWmAKXBViv8/e6j6SU/lSlWkMajd59aiWczs+qf9dMuRpe/l9Qke9DnVMn24JNLXjWD+y+w3yKRwd3CTtF7gx8/ToZl5XqFIT5YB1QfQCdAf8Z18IdQrJIijs8ssczY/RfqKZLo+KLQIDAQAB");
        merchantInfo.setMerchantId("M200000550");
        request.setMerchantInfo(merchantInfo);
        payService.singleDeduct(request);
    }

    @Test
    public void testPay() {
        PayRequest request = new PayRequest();
        request.setBankCode("BOCOM");
        request.setAccountName("张维新");
        request.setAmount(12d);
        request.setBankCardNo("6222528888888888");
        request.setCapitalOrderNo("test1234566654523429");
        request.setProductCode("100001");
        request.setPayMerchantType(PayMerchantType.PAY);
        MerchantInfo merchantInfo = new MerchantInfo();
        merchantInfo.setSecretKey(
                "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQChFetx5+VKDoEXzZ+5Wozt3MfWMM/TiKMlWmAKXBViv8/e6j6SU/lSlWkMajd59aiWczs+qf9dMuRpe/l9Qke9DnVMn24JNLXjWD+y+w3yKRwd3CTtF7gx8/ToZl5XqFIT5YB1QfQCdAf8Z18IdQrJIijs8ssczY/RfqKZLo+KLQIDAQAB");
        merchantInfo.setMerchantId("M200000550");
        request.setMerchantInfo(merchantInfo);
        payService.singlePay(request);
    }

    @Test
    public void testOptioanl() {
        LoanSettleRequest settleRequest = new LoanSettleRequest();
        settleRequest.setLoanOrderNo("1145242132018020414413553357");
        transactionRemoteService.loanSettle(settleRequest);
    }

    public PayResult getResult() {
        return null;
    }

    @Test
    public void testNotice() {
        PayNoticeHandlerRequest handlerRequest = new PayNoticeHandlerRequest();
        handlerRequest.setOrderNo("1345242132018020415094285164");
        handlerRequest.setThirdOrderNo("12345678");
        repaymentService.deductPrincipalSuccessHandle(handlerRequest);
    }
}
