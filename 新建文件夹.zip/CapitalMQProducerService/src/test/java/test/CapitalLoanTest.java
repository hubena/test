package test;

import javax.annotation.Resource;

import com.xhh.creditcore.capital.service.RepayTransService;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.xhh.creditcore.capital.pay.LoanPayResultNoticeHandler;
import com.xhh.creditcore.capital.pay.PayNoticeHandlerRequest;
import com.xhh.creditcore.capital.service.CapitalLoanTransService;
import com.xhh.creditcore.capital.service.remote.ProductRemoteService;

import base.BaseJUnitTest;

public class CapitalLoanTest extends BaseJUnitTest {

    private static Logger              logger = LoggerFactory.getLogger(CapitalLoanTest.class);

    @Resource
    private LoanPayResultNoticeHandler loanPayResultNoticeHandler;

    @Resource
    private CapitalLoanTransService    capitalLoanTransService;

    @Resource
    private ProductRemoteService       productRemoteService;

    @Resource
    private RepayTransService          repayTransService;

    /**
     * 放款成功
     */
    @Test
    public void testPaySuccess() {
        PayNoticeHandlerRequest handlerRequest = new PayNoticeHandlerRequest();
        handlerRequest.setOrderNo("1445242132018020417452527470");
        handlerRequest.setThirdOrderNo("12321321312");
        loanPayResultNoticeHandler.paySuccessHandle(handlerRequest);
    }

    /**
     * 放款失败
     */
    @Test
    public void testPayFail() {
        PayNoticeHandlerRequest handlerRequest = new PayNoticeHandlerRequest();
        handlerRequest.setOrderNo("1486787952018013115140303047");
        handlerRequest.setThirdOrderNo("12321321312001");
        loanPayResultNoticeHandler.payFailHandle(handlerRequest);
    }

    /**
     * 主动查询先锋
     */
    @Test
    public void testQueryLoanPayResult() {
        capitalLoanTransService.queryLoanPayResult();
    }

    @Test
    public void testException() {
        try {
            productRemoteService.getProductByCode("123");
        } catch (Exception e) {
            logger.error("出异常了", e);
        }

    }

    @Test
    public void testQueryRepayTrans() {
        System.out.println(repayTransService.queryDataByTransNo("1345242132018020415094285164"));
    }

}
