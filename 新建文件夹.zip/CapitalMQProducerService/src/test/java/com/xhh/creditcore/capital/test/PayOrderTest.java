package com.xhh.creditcore.capital.test;

import base.BaseJUnitTest;
import com.xhh.creditcore.capital.service.PayOrderService;
import org.junit.Test;

import javax.annotation.Resource;

public class PayOrderTest extends BaseJUnitTest{
    @Resource
    public PayOrderService payOrderService;
    @Test
    public void testOrderQuery() {
        payOrderService.queryPayOrderResult();
    }
}
