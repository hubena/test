package com.xhh.creditcore.capital.test;

import base.BaseJUnitTest;
import com.xhh.creditcore.capital.service.RepayTransService;
import org.junit.Test;

import javax.annotation.Resource;

public class RepayTransTest extends BaseJUnitTest {

    @Resource
    private RepayTransService repayTransService;

    @Test
    public void testRemoveOverdueTrans() {
        repayTransService.removeOverDueRepayTrans();
    }
}
