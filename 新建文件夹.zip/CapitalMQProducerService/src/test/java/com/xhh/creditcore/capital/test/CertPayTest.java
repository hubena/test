package com.xhh.creditcore.capital.test;

import base.BaseJUnitTest;
import com.xhh.creditcore.capital.dto.CertPayRepayConfirmRequest;
import com.xhh.creditcore.capital.dto.CertPayRepayPreRequest;
import com.xhh.creditcore.capital.dto.CertPayRepaySendSmsRequest;
import com.xhh.creditcore.capital.enums.RepayTriggerType;
import com.xhh.creditcore.capital.service.RepaymentService;
import org.junit.Test;

import javax.annotation.Resource;

public class CertPayTest extends BaseJUnitTest {

    @Resource
    RepaymentService repaymentService;

    @Test
    public void prePayTest() {
        CertPayRepayPreRequest repaymentPreRequest = new CertPayRepayPreRequest();
        repaymentPreRequest.setAccountId(57L);
        repaymentPreRequest.setOuterLoanOrderNo("1145242132018030816460196171");
        repaymentPreRequest.setOuterRepayOrderNo("1445242132018030818035891259");
        repaymentPreRequest.setTermNo(2);
        repaymentPreRequest.setTriggerType(RepayTriggerType.INITIATE_REPAY.getKey());
        System.out.println(repaymentService.certPayRepaymentPrePay(repaymentPreRequest));
    }

    @Test
    public void confirmPayTest() {
        CertPayRepayConfirmRequest repaymentConfirmRequest = new CertPayRepayConfirmRequest();
        repaymentConfirmRequest.setOuterRepayOrderNo("1445242132018030817553555648");
        repaymentConfirmRequest.setSmsCode("999999");
        System.out.println(repaymentService.certPayRepaymentConfirmPay(repaymentConfirmRequest));
    }

    @Test
    public void certPayQuery() throws Exception {
        repaymentService.processRepayingOrder();
    }


    @Test
    public void confirmPaySendSms() {
        CertPayRepaySendSmsRequest sendSmsRequest = new CertPayRepaySendSmsRequest();
        sendSmsRequest.setOuterRepayOrderNo("HK1234567");
        System.out.println(repaymentService.certPayRepaymentSendSms(sendSmsRequest));
    }
}
