package com.xhh.creditcore.capital.test;

import base.BaseJUnitTest;
import com.google.common.collect.Maps;
import com.janty.core.util.ObjectId;
import com.xhh.creditcore.capital.api.CapitalApi;
import com.xhh.creditcore.capital.dto.*;
import com.xhh.creditcore.capital.enums.PayMerchantType;
import com.xhh.creditcore.capital.enums.RepayTransStatus;
import com.xhh.creditcore.capital.enums.RepayTriggerType;
import com.xhh.creditcore.capital.model.RepayTrans;
import com.xhh.creditcore.capital.pay.PayRequest;
import com.xhh.creditcore.capital.service.*;
import com.xhh.creditcore.capital.service.payimpl.PayServiceDelegate;
import org.junit.Test;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Map;

/**
 * zhangweixin
 */
public class CapitalApiTest extends BaseJUnitTest {

    @Resource
    PayServiceDelegate      serviceDelegate;
    @Resource
    RepaymentService        repaymentService;
    @Resource
    RepayTransService       repayTransService;
    @Resource
    CapitalLoanTransService capitalLoanTransService;
    @Resource
    CapitalApi              capitalApi;
    //    @Resource
    //    PaymentService          paymentService;
    @Resource
    BankCardService         bankCardService;

    @Resource
    BankCardbinService      bankCardbinService;

    @Test
    public void testQueryRepayPlan() {
        PayRequest serviceRequest = new PayRequest();
        serviceRequest.setProductCode("100001");
        serviceRequest.setPayMerchantType(PayMerchantType.PRINCIPAL_REPAY);
        serviceRequest.setAmount(120D);
        serviceRequest.setMobile("15619308769");
        serviceRequest.setCapitalOrderNo("DFTEST1234567815");
        serviceRequest.setCertNo("610323199107016818");
        serviceRequest.setBankCardNo("6222528888888888");
        serviceRequest.setBankCode("BOCOM");
        serviceRequest.setAccountName("张维新");
        Map<String, Object> map = Maps.newHashMap();
        map.put(PayRequest.NOTICE_HANDLER_BEAN_NAME, "deductPrincipalNoticeHandler");
        serviceRequest.setAppendData(map);
        serviceDelegate.singleDeduct(serviceRequest);
    }

    @Test
    public void testRepayment() throws Exception {
        //OUTDF12345
        PeriodRepaymentRequest repaymentRequest = new PeriodRepaymentRequest();
        repaymentRequest.setOuterLoanOrderNo("OUTDF12345");
        repaymentRequest.setOuterRepayOrderNo("OUTDS12345");
        repaymentRequest.setAccountId(12L);
        repaymentRequest.setTermNo(1);
        repaymentRequest.setTriggerType(RepayTriggerType.INITIATE_REPAY.getKey());
        repaymentService.periodRepayment(repaymentRequest);
    }

    @Test
    public void testUpdate() {
        RepayTrans updateRepayTrans = new RepayTrans();
        updateRepayTrans.setId(22l);
        updateRepayTrans.setPayNo("123456");
        updateRepayTrans.setRepayFinishedTime(new Date());
        updateRepayTrans.setPayResult("SUCCESS");
        updateRepayTrans.setStatus(RepayTransStatus.SUCCESS.getKey());
        updateRepayTrans.setGmtModified(new Date());
        repayTransService.updateDataForDeductNotice(updateRepayTrans);
    }

    /**
     * 直接代付
     * 
     * @throws Exception
     */
    @Test
    public void testPay() throws Exception {
        CapitalPayRequest request = new CapitalPayRequest();
        request.setProductCode("100001");
        request.setOuterLoanOrderNo(ObjectId.getId());
        request.setAccountId(100000000000000000L);
        request.setLoanAmount(new BigDecimal("1.00"));
        request.setRepayPattern("4");
        request.setTotalTerm(1);
        request.setTermUnit(1);
        request.setMobile("15619308769");
        request.setCapitalCode("CP100001");
        request.setBankCode("BOCOM");
        request.setBankCardNo("6222528888888888");
        request.setRealName("张维新");
        capitalLoanTransService.pay(request);
    }

    /**
     * 直接对公代付
     *
     * @throws Exception
     */
    @Test
    public void testPayOfPublic() throws Exception {
        CapitalPayRequest request = new CapitalPayRequest();
        request.setAccountId(100000000000000000L);
        request.setLoanAmount(new BigDecimal("1.00"));
        request.setCapitalCode("CP100001");
        request.setBankCode("CCB");
        request.setBankCardNo("44250100018200000403");
        request.setRealName("深圳量子信商业保理有限公司");
        request.setIssuer("105584001395");
        //capitalLoanTransService.payOfPublic(request);
    }

    @Test
    public void testQueryRepayPlan1() {
        RepayPlanQueryRequest request = new RepayPlanQueryRequest();
        request.setOuterLoanOrderNo("1145242132018020816075830787");
        request.setProductCode("100001");
        request.setAccountId(44L);
        capitalApi.queryAccountRepayPlan(request).forEach(System.out::println);
    }

    @Test
    public void testQueryRepayTrans() {
        CapitalRecordQueryRequest queryRequest = new CapitalRecordQueryRequest();
        queryRequest.setPageNum(1);
        queryRequest.setPageSize(10);
        queryRequest.setAccountMobile("156");
        queryRequest.setTransOrderNo("1365107232018012416153303269");
        //System.out.println(repaymentService.queryRepayTransRecordByPage(queryRequest));
        System.out.println(capitalApi.queryRepayTransRecordByPage(queryRequest));
    }

    @Test
    public void testQueryLoanTrans() {
        CapitalRecordQueryRequest queryRequest = new CapitalRecordQueryRequest();
        queryRequest.setPageNum(1);
        queryRequest.setPageSize(10);
        queryRequest.setTransOrderNo("14867879520180130171916178951");
        //System.out.println(paymentService.queryLoanTransRecordByPage(queryRequest));
        System.out.println(capitalApi.queryPayTransRecordByPage(queryRequest));
    }

    @Test
    public void testQueryProcessingLoanOrder() {
        ProcessingAccountOrderRequest orderRequest = new ProcessingAccountOrderRequest();
        orderRequest.setAccountId(12L);
        /*
         * paymentService.queryAccountProcessingOrder(orderRequest).forEach(it
         * -> { System.out.println(it); });
         */
        capitalApi.queryAccountProcessingOrder(orderRequest).forEach(System.out::println);
    }

    @Test
    public void testQueryOverDueLoanOrder() {
        OverdueAccountOrderRequest orderRequest = new OverdueAccountOrderRequest();
        orderRequest.setAccountId(12l);
        /*
         * paymentService.queryAccountOverdueOrder(orderRequest).forEach(it -> {
         * System.out.println(it); });
         */
        capitalApi.queryAccountOverdueOrder(orderRequest).forEach(System.out::println);
    }

    @Test
    public void testBankBind() {
        CapitalBindBankRequest capitalBindBankRequest = new CapitalBindBankRequest();
        capitalBindBankRequest.setAccountCardNo("341281199302111611");
        capitalBindBankRequest.setAccountId(1L);
        capitalBindBankRequest.setAccountMobile("15914112496");
        capitalBindBankRequest.setAccountName("张亮");
        capitalBindBankRequest.setBankCardNo("6216602000000327013");
        capitalBindBankRequest.setProductCode("100001");
        try {
            bankCardService.bindBank(capitalBindBankRequest);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testRetryOrder() throws Exception {
        repaymentService.processRepayingOrder();
    }

    @Test
    public void testCardBin() {

        BankCardbinDto bankCardbinDto = bankCardbinService.queryByCardNo("6230580000112809806");

        System.out.println(bankCardbinDto);

    }
}
