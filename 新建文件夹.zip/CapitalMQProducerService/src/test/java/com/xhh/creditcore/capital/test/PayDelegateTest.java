package com.xhh.creditcore.capital.test;

import base.BaseJUnitTest;
import com.xhh.creditcore.capital.service.payimpl.PayServiceDelegate;
import org.junit.Test;

import javax.annotation.Resource;

public class PayDelegateTest extends BaseJUnitTest {

    @Resource
    private PayServiceDelegate payServiceDelegate;

    @Test
    public void testQueryCapitalProvider() {
        payServiceDelegate.queryCapitalProvider("123");
    }
}
